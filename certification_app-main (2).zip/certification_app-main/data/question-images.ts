// 이 파일은 scripts/extract_question_images.py 가 자동 생성합니다. 직접 수정하지 마세요.
// assets/images/questions/ 폴더의 PNG 파일을 Question.image 키로 매핑합니다.

export interface QuestionImageAsset {
  source: number;
  aspectRatio: number; // width / height
}

export const QUESTION_IMAGES: Record<string, QuestionImageAsset> = {
  "adsp44-25": { source: require("../assets/images/questions/adsp44-25.png"), aspectRatio: 0.7518 },
  "adsp44-31": { source: require("../assets/images/questions/adsp44-31.png"), aspectRatio: 1.6242 },
  "adsp44-33": { source: require("../assets/images/questions/adsp44-33.png"), aspectRatio: 2.5465 },
  "adsp44-50": { source: require("../assets/images/questions/adsp44-50.png"), aspectRatio: 4.6720 },
  "adsp45-44": { source: require("../assets/images/questions/adsp45-44.png"), aspectRatio: 1.0142 },
  "adsp45-45": { source: require("../assets/images/questions/adsp45-45.png"), aspectRatio: 3.0932 },
  "adsp46-49": { source: require("../assets/images/questions/adsp46-49.png"), aspectRatio: 2.8247 },
  "adsp47-23": { source: require("../assets/images/questions/adsp47-23.png"), aspectRatio: 0.7852 },
  "adsp47-27": { source: require("../assets/images/questions/adsp47-27.png"), aspectRatio: 0.9147 },
  "adsp47-44": { source: require("../assets/images/questions/adsp47-44.png"), aspectRatio: 1.9023 },
  "adsp47-46": { source: require("../assets/images/questions/adsp47-46.png"), aspectRatio: 1.4098 },
  "adsp47-50": { source: require("../assets/images/questions/adsp47-50.png"), aspectRatio: 5.8400 },
  "adsp48-29": { source: require("../assets/images/questions/adsp48-29.png"), aspectRatio: 1.1007 },
  "adsp48-49": { source: require("../assets/images/questions/adsp48-49.png"), aspectRatio: 1.9711 },
  "adsp49-26": { source: require("../assets/images/questions/adsp49-26.png"), aspectRatio: 1.9711 },
  "adsp49-41": { source: require("../assets/images/questions/adsp49-41.png"), aspectRatio: 3.0903 },
  "adsp49-44": { source: require("../assets/images/questions/adsp49-44.png"), aspectRatio: 1.9600 },
  "adsp49-48": { source: require("../assets/images/questions/adsp49-48.png"), aspectRatio: 2.0564 },
  "adsp49-49": { source: require("../assets/images/questions/adsp49-49.png"), aspectRatio: 2.4343 },
  "adsp50-27": { source: require("../assets/images/questions/adsp50-27.png"), aspectRatio: 6.1689 },
  "adsp50-28": { source: require("../assets/images/questions/adsp50-28.png"), aspectRatio: 4.9489 },
  "adsp50-31": { source: require("../assets/images/questions/adsp50-31.png"), aspectRatio: 1.3731 },
  "adsp50-32": { source: require("../assets/images/questions/adsp50-32.png"), aspectRatio: 2.4195 },
  "adsp50-35": { source: require("../assets/images/questions/adsp50-35.png"), aspectRatio: 2.1432 },
  "adsp50-41": { source: require("../assets/images/questions/adsp50-41.png"), aspectRatio: 2.6204 },
  "adsp50-46": { source: require("../assets/images/questions/adsp50-46.png"), aspectRatio: 2.7930 },
  "adsp50-49": { source: require("../assets/images/questions/adsp50-49.png"), aspectRatio: 2.2737 },
};

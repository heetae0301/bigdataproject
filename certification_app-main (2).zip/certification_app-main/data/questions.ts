import { pastExamQuestions } from "./past-exams";

export type Subject = "1과목(데이터 이해)" | "2과목(데이터 분석 기획)" | "3과목(데이터 분석)";

export interface Question {
  id: string;
  subject: Subject;
  question: string;
  options: string[];
  answer: number; // 0-indexed
  explanation: string;
  // 그림 키. 실제 이미지는 data/question-images.ts(앱 전용)에서 매핑한다.
  image?: string;
}

export const SUBJECTS: Subject[] = ["1과목(데이터 이해)", "2과목(데이터 분석 기획)", "3과목(데이터 분석)"];

export const SUBJECT_COLORS: Record<Subject, string> = {
  "1과목(데이터 이해)": "#2563EB",
  "2과목(데이터 분석 기획)": "#7C3AED",
  "3과목(데이터 분석)": "#16A34A",
};

export const SUBJECT_ICONS: Record<Subject, string> = {
  "1과목(데이터 이해)": "database",
  "2과목(데이터 분석 기획)": "analytics",
  "3과목(데이터 분석)": "bar-chart",
};

const baseQuestions: Question[] = [
  // ─── 1과목(데이터 이해) ───────────────────────────────────────────────
  {
    id: "di-001",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스의 특징으로 올바르지 않은 것은?",
    options: [
      "실시간 접근성",
      "계속적인 변화",
      "동시 공유",
      "데이터 중복 허용",
    ],
    answer: 3,
    explanation:
      "데이터베이스의 특징은 실시간 접근성, 계속적인 변화, 동시 공유, 내용에 의한 참조이며, 데이터 중복을 최소화하는 것이 목적입니다.",
  },
  {
    id: "di-002",
    subject: "1과목(데이터 이해)",
    question: "다음 중 정형 데이터에 해당하는 것은?",
    options: [
      "SNS 게시글",
      "동영상 파일",
      "관계형 데이터베이스 테이블",
      "이메일 본문",
    ],
    answer: 2,
    explanation:
      "정형 데이터는 미리 정해진 형식과 구조를 가진 데이터로, 관계형 데이터베이스 테이블이 대표적입니다. SNS 게시글, 이메일 본문은 비정형 데이터이며, 동영상 파일도 비정형 데이터입니다.",
  },
  {
    id: "di-003",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 3V에 해당하지 않는 것은?",
    options: ["Volume(양)", "Velocity(속도)", "Variety(다양성)", "Veracity(정확성)"],
    answer: 3,
    explanation:
      "빅데이터의 3V는 Volume(양), Velocity(속도), Variety(다양성)입니다. Veracity(정확성)는 이후 추가된 특성으로 3V에는 포함되지 않습니다.",
  },
  {
    id: "di-004",
    subject: "1과목(데이터 이해)",
    question: "데이터 거버넌스의 구성 요소로 올바르지 않은 것은?",
    options: [
      "원칙(Principle)",
      "조직(Organization)",
      "프로세스(Process)",
      "기술(Technology)",
    ],
    answer: 3,
    explanation:
      "데이터 거버넌스의 3대 구성 요소는 원칙(Principle), 조직(Organization), 프로세스(Process)입니다. 기술(Technology)은 데이터 거버넌스의 구성 요소가 아닙니다.",
  },
  {
    id: "di-005",
    subject: "1과목(데이터 이해)",
    question: "DIKW 피라미드에서 가장 상위 단계는?",
    options: ["Data(데이터)", "Information(정보)", "Knowledge(지식)", "Wisdom(지혜)"],
    answer: 3,
    explanation:
      "DIKW 피라미드는 Data → Information → Knowledge → Wisdom 순으로 구성되며, 가장 상위 단계는 Wisdom(지혜)입니다.",
  },
  {
    id: "di-006",
    subject: "1과목(데이터 이해)",
    question: "다음 중 메타데이터(Metadata)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "대용량 데이터를 의미한다",
      "데이터에 대한 데이터이다",
      "정형화된 데이터만을 의미한다",
      "실시간으로 생성되는 데이터이다",
    ],
    answer: 1,
    explanation:
      "메타데이터(Metadata)는 '데이터에 대한 데이터'로, 데이터의 속성, 구조, 생성 일시 등 데이터를 설명하는 정보입니다.",
  },
  {
    id: "di-007",
    subject: "1과목(데이터 이해)",
    question: "데이터 사이언티스트의 핵심 역량으로 가장 거리가 먼 것은?",
    options: [
      "통계 및 수학적 지식",
      "프로그래밍 능력",
      "비즈니스 이해",
      "법률 전문 지식",
    ],
    answer: 3,
    explanation:
      "데이터 사이언티스트의 핵심 역량은 통계/수학, 프로그래밍, 비즈니스 이해, 커뮤니케이션 능력입니다. 법률 전문 지식은 핵심 역량에 해당하지 않습니다.",
  },
  {
    id: "di-008",
    subject: "1과목(데이터 이해)",
    question: "다음 중 개인정보 비식별화 기법이 아닌 것은?",
    options: ["가명처리", "총계처리", "데이터 삭제", "데이터 복원"],
    answer: 3,
    explanation:
      "개인정보 비식별화 기법에는 가명처리, 총계처리, 데이터 삭제, 범주화, 데이터 마스킹 등이 있습니다. 데이터 복원은 비식별화 기법이 아닙니다.",
  },
  {
    id: "di-009",
    subject: "1과목(데이터 이해)",
    question: "마스터 데이터(Master Data)에 대한 설명으로 옳은 것은?",
    options: [
      "특정 시점의 트랜잭션 데이터이다",
      "기업의 핵심 비즈니스 객체에 대한 공유 데이터이다",
      "임시로 저장되는 데이터이다",
      "로그 파일에 기록되는 데이터이다",
    ],
    answer: 1,
    explanation:
      "마스터 데이터는 기업의 핵심 비즈니스 객체(고객, 제품, 공급업체 등)에 대한 공유 참조 데이터로, 여러 시스템에서 공통으로 사용됩니다.",
  },
  {
    id: "di-010",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스(Data Warehouse)의 특성으로 올바르지 않은 것은?",
    options: [
      "주제 지향적(Subject-Oriented)",
      "통합적(Integrated)",
      "시계열적(Time-Variant)",
      "휘발성(Volatile)",
    ],
    answer: 3,
    explanation:
      "데이터 웨어하우스의 4가지 특성은 주제 지향적, 통합적, 시계열적, 비휘발성(Non-Volatile)입니다. 데이터 웨어하우스는 한번 저장된 데이터가 삭제되지 않는 비휘발성 특성을 가집니다.",
  },

  {
    id: "di-011",
    subject: "1과목(데이터 이해)",
    question: "데이터(Data)와 정보(Information)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "데이터는 정보를 가공하여 얻은 결과물이다",
      "정보는 데이터를 가공・처리하여 의미를 부여한 것이다",
      "데이터와 정보는 완전히 동일한 개념이다",
      "정보는 가공되지 않은 순수한 사실이다",
    ],
    answer: 1,
    explanation:
      "데이터는 객관적 사실이나 값 그 자체이며, 정보는 데이터를 가공・처리하여 특정 상황에서 의미를 갖도록 만든 것입니다. DIKW 피라미드에서도 Data 다음 단계가 Information입니다.",
  },
  {
    id: "di-012",
    subject: "1과목(데이터 이해)",
    question: "빅데이터가 등장하게 된 배경으로 가장 거리가 먼 것은?",
    options: [
      "저장 기술의 발전과 저장 비용 감소",
      "인터넷・모바일 기기의 보급 확산",
      "데이터 생성 속도와 양의 폭발적 증가",
      "정형 데이터만을 저장하는 관행 확대",
    ],
    answer: 3,
    explanation:
      "빅데이터는 저장 비용 감소, 인터넷・모바일 보급, 데이터 생성량 폭증 등을 배경으로 등장했습니다. 오히려 비정형・반정형 데이터의 비중이 커진 것이 특징이며, 정형 데이터만 저장하는 관행은 빅데이터 등장 배경과 반대되는 설명입니다.",
  },
  {
    id: "di-013",
    subject: "1과목(데이터 이해)",
    question:
      "데이터베이스의 3단계 스키마(ANSI/SPARC) 중 사용자 관점에서 필요한 데이터베이스의 일부를 정의하는 것은?",
    options: [
      "외부 스키마(External Schema)",
      "개념 스키마(Conceptual Schema)",
      "내부 스키마(Internal Schema)",
      "물리 스키마(Physical Schema)",
    ],
    answer: 0,
    explanation:
      "외부 스키마는 개별 사용자나 응용 프로그램 관점에서 필요한 데이터베이스의 논리적 구조를 정의합니다. 개념 스키마는 조직 전체 관점의 통합된 구조, 내부 스키마는 물리적 저장 구조를 정의합니다.",
  },
  {
    id: "di-014",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스 정규화(Normalization)의 주된 목적으로 가장 적절한 것은?",
    options: [
      "데이터 조회 속도를 무조건 빠르게 하기 위해",
      "데이터 중복을 최소화하고 이상 현상을 방지하기 위해",
      "저장 공간을 늘리기 위해",
      "테이블 수를 최대한 줄이기 위해",
    ],
    answer: 1,
    explanation:
      "정규화는 데이터 중복을 최소화하고 삽입・삭제・갱신 이상(Anomaly)을 방지하기 위해 테이블을 분해하는 과정입니다. 오히려 테이블 수는 늘어나는 경우가 많습니다.",
  },
  {
    id: "di-015",
    subject: "1과목(데이터 이해)",
    question: "제1정규형(1NF)을 만족하기 위한 조건은?",
    options: [
      "모든 속성이 원자값(Atomic Value)을 가져야 한다",
      "기본키가 아닌 속성이 기본키 전체에 완전 함수 종속되어야 한다",
      "이행적 함수 종속이 없어야 한다",
      "다치 종속이 없어야 한다",
    ],
    answer: 0,
    explanation:
      "제1정규형은 테이블의 모든 속성 값이 더 이상 분해할 수 없는 원자값을 가져야 한다는 조건입니다. 완전 함수 종속은 제2정규형, 이행적 함수 종속 제거는 제3정규형의 조건입니다.",
  },
  {
    id: "di-016",
    subject: "1과목(데이터 이해)",
    question: "다음 중 OLAP(On-Line Analytical Processing)에 대한 설명으로 옳은 것은?",
    options: [
      "은행 창구의 실시간 입출금 처리에 주로 사용된다",
      "다차원적 집계와 분석에 특화된 처리 방식이다",
      "하나의 트랜잭션을 빠르게 처리하는 것이 목적이다",
      "정규화된 구조를 유지하는 것이 핵심 목표이다",
    ],
    answer: 1,
    explanation:
      "OLAP은 다차원 데이터를 다양한 각도에서 집계・분석하는 데 특화된 처리 방식으로 의사결정 지원에 활용됩니다. 실시간 트랜잭션 처리는 OLTP의 특징입니다.",
  },
  {
    id: "di-017",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시대의 사고방식 변화에 대한 설명으로 옳은 것은?",
    options: [
      "표본조사보다 전수조사에 대한 관심이 높아졌다",
      "상관관계보다 인과관계 분석이 더욱 중요해졌다",
      "질(Quality)보다 양(Quantity)에 대한 관심이 사라졌다",
      "사전 처리보다 사후 처리의 중요성이 완전히 사라졌다",
    ],
    answer: 0,
    explanation:
      "빅데이터 시대에는 전체 데이터를 다룰 수 있게 되면서 표본조사보다 전수조사, 인과관계보다 상관관계 분석에 대한 관심이 커졌다는 것이 대표적인 사고방식 변화입니다.",
  },
  {
    id: "di-018",
    subject: "1과목(데이터 이해)",
    question: "개인정보보호법상 '가명정보'에 대한 설명으로 가장 적절한 것은?",
    options: [
      "추가 정보 없이는 특정 개인을 알아볼 수 없도록 처리한 정보이다",
      "개인을 식별할 수 있는 모든 정보가 완전히 삭제된 정보이다",
      "개인정보와 전혀 관련이 없는 정보이다",
      "누구나 자유롭게 재식별할 수 있는 정보이다",
    ],
    answer: 0,
    explanation:
      "가명정보는 추가 정보의 사용・결합 없이는 특정 개인을 알아볼 수 없도록 개인정보의 일부를 삭제하거나 대체한 정보로, 데이터 3법 개정을 통해 도입된 개념입니다. 완전히 식별 불가능하게 만드는 것은 '익명정보'에 가깝습니다.",
  },
  {
    id: "di-019",
    subject: "1과목(데이터 이해)",
    question:
      "빅데이터로 인한 오남용 문제를 해결하기 위해 제시된 새로운 직업으로, 알고리즘의 부작용을 견제하고 소비자를 보호하는 역할을 하는 사람은?",
    options: [
      "데이터 스튜어드",
      "알고리즈미스트(Algorithmist)",
      "데이터 아키텍트",
      "그로스 해커",
    ],
    answer: 1,
    explanation:
      "알고리즈미스트는 빅데이터 분석 알고리즘의 부당한 영향이나 부작용을 감시하고 대응하는 새로운 직업으로 제시된 개념입니다.",
  },
  {
    id: "di-020",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스(Data Warehouse)와 데이터 마트(Data Mart)의 관계에 대한 설명으로 가장 적절한 것은?",
    options: [
      "데이터 마트는 전사적 데이터를 통합한 것이고, 데이터 웨어하우스는 특정 부서용이다",
      "데이터 웨어하우스는 전사적 관점의 통합 저장소이고, 데이터 마트는 특정 부서・주제 중심의 부분집합이다",
      "둘은 완전히 동일한 개념이다",
      "데이터 마트는 비정형 데이터만 저장한다",
    ],
    answer: 1,
    explanation:
      "데이터 웨어하우스는 조직 전체의 데이터를 통합한 저장소이며, 데이터 마트는 특정 부서나 주제 영역에 특화된 데이터 웨어하우스의 부분집합입니다.",
  },
  {
    id: "di-021",
    subject: "1과목(데이터 이해)",
    question:
      "전통적인 관계형 데이터베이스와 달리, 데이터를 저장할 때는 스키마를 유연하게 두고 실제로 읽어들일 때 스키마를 적용하는 빅데이터 처리 방식은?",
    options: [
      "스키마 온 라이트(Schema on Write)",
      "스키마 온 리드(Schema on Read)",
      "정규화(Normalization)",
      "인덱싱(Indexing)",
    ],
    answer: 1,
    explanation:
      "스키마 온 리드는 데이터 저장 시점에는 엄격한 스키마를 적용하지 않고, 데이터를 읽어서 사용할 때 스키마를 적용하는 방식으로 하둡 등 빅데이터 환경에서 주로 사용됩니다. 전통적 RDB는 저장 시점에 스키마를 정의하는 스키마 온 라이트 방식입니다.",
  },
  {
    id: "di-022",
    subject: "1과목(데이터 이해)",
    question: "데이터 사이언스(Data Science)의 특징에 대한 설명으로 가장 적절한 것은?",
    options: [
      "통계학, 컴퓨터공학 등과 무관한 독립적인 학문이다",
      "분석적 기술과 함께 커뮤니케이션 등 예술적 요소도 요구되는 융합적 성격을 가진다",
      "정형 데이터만을 다루는 학문이다",
      "결과 도출 과정에서 비즈니스 이해는 필요하지 않다",
    ],
    answer: 1,
    explanation:
      "데이터 사이언스는 통계, 수학, 프로그래밍 등 분석적 스킬(Science)뿐 아니라 결과를 효과적으로 전달하는 커뮤니케이션 능력(Art)까지 요구되는 융합적 성격의 학문입니다.",
  },
  {
    id: "di-023",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시대의 위기 요인과 그 통제 방안을 짝지은 것으로 옳지 않은 것은?",
    options: [
      "사생활 침해 - 개인정보 익명화/가명화",
      "책임 원칙 훼손 - 알고리즘 책임 강화",
      "데이터 오용 - 결과 기반 책임 원칙 강화",
      "정보 격차 심화 - 데이터 생성량을 인위적으로 축소",
    ],
    answer: 3,
    explanation:
      "빅데이터의 대표적 위기 요인은 사생활 침해, 책임 원칙 훼손, 데이터 오용이며, 각각 익명화 등 개인정보 보호 조치, 알고리즘에 대한 책임 강화, 결과 기반 책임 원칙 등으로 대응합니다. '데이터 생성량을 인위적으로 축소'하는 것은 실질적인 통제 방안으로 제시되지 않습니다.",
  },
  {
    id: "di-024",
    subject: "1과목(데이터 이해)",
    question:
      "2020년 개정되어 가명정보의 개념을 도입하고 데이터 활용의 법적 근거를 마련한 '데이터 3법'에 해당하지 않는 것은?",
    options: ["개인정보보호법", "정보통신망법", "신용정보법", "전자상거래법"],
    answer: 3,
    explanation:
      "데이터 3법은 개인정보보호법, 정보통신망법, 신용정보법 개정을 통칭하는 표현으로, 가명정보 개념 도입 등을 통해 데이터 활용의 법적 근거를 마련했습니다. 전자상거래법은 데이터 3법에 포함되지 않습니다.",
  },
  {
    id: "di-025",
    subject: "1과목(데이터 이해)",
    question: "다음 중 정성적 데이터(Qualitative Data)에 해당하는 것은?",
    options: [
      "특정 제품의 판매 수량",
      "고객 만족도 설문의 서술형 응답",
      "일별 웹사이트 방문자 수",
      "월별 매출액",
    ],
    answer: 1,
    explanation:
      "정성적 데이터는 수치로 측정하기 어려운 언어・문자 형태의 데이터로, 서술형 설문 응답이 대표적입니다. 판매 수량, 방문자 수, 매출액은 수치로 측정되는 정량적 데이터입니다.",
  },
  {
    id: "di-026",
    subject: "1과목(데이터 이해)",
    question: "데이터의 생성부터 폐기까지 전 생애주기를 관리하여 저장 비용을 최적화하는 것을 목표로 하는 관리 기법은?",
    options: [
      "정보 수명주기 관리(ILM, Information Lifecycle Management)",
      "데이터 마이닝(Data Mining)",
      "데이터 웨어하우징(Data Warehousing)",
      "데이터 시각화(Data Visualization)",
    ],
    answer: 0,
    explanation:
      "정보 수명주기 관리(ILM)는 데이터의 가치와 활용도에 따라 생성부터 저장, 활용, 폐기까지의 전 과정을 관리하여 저장 비용과 활용 효율을 최적화하는 기법입니다.",
  },
  {
    id: "di-027",
    subject: "1과목(데이터 이해)",
    question: "데이터 표준화에 대한 설명으로 가장 적절한 것은?",
    options: [
      "데이터 표준 용어, 정의, 형식 등을 조직 전체에서 일관되게 정하는 활동이다",
      "특정 부서만 사용하는 임시 용어를 자유롭게 만드는 것이다",
      "데이터베이스의 물리적 저장 위치를 결정하는 것이다",
      "데이터 분석 알고리즘의 정확도를 높이는 기법이다",
    ],
    answer: 0,
    explanation:
      "데이터 표준화는 데이터 표준 용어, 정의, 형식, 규칙 등을 조직 전체에서 일관되게 정의하고 관리하는 활동으로, 데이터 거버넌스의 핵심 구성 요소 중 하나입니다.",
  },
  {
    id: "di-028",
    subject: "1과목(데이터 이해)",
    question: "조직 내에서 수집・저장되지만 분석되거나 활용되지 않고 방치되는 데이터를 가리키는 용어는?",
    options: ["다크 데이터(Dark Data)", "메타데이터(Metadata)", "마스터 데이터(Master Data)", "레퍼런스 데이터(Reference Data)"],
    answer: 0,
    explanation:
      "다크 데이터는 기업이 수집・저장은 하지만 실제로는 분석이나 의사결정에 활용되지 않고 방치되는 데이터를 의미합니다.",
  },
  {
    id: "di-029",
    subject: "1과목(데이터 이해)",
    question:
      "코드성 데이터처럼 다른 데이터를 분류하거나 참조하는 데 사용되는, 비교적 변경이 적은 데이터를 가리키는 용어는?",
    options: ["트랜잭션 데이터(Transaction Data)", "레퍼런스 데이터(Reference Data)", "로그 데이터(Log Data)", "센서 데이터(Sensor Data)"],
    answer: 1,
    explanation:
      "레퍼런스 데이터는 국가 코드, 성별 코드처럼 다른 데이터를 분류・참조하는 데 사용되며 변경 빈도가 낮은 데이터입니다. 트랜잭션 데이터는 거래 발생 시마다 생성되는 데이터입니다.",
  },
  {
    id: "di-030",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 가치 산정이 어려운 이유로 가장 적절한 것은?",
    options: [
      "데이터를 재사용・재조합하는 것이 불가능하기 때문이다",
      "동일한 데이터라도 어떻게 활용하느냐에 따라 그 가치가 달라지기 때문이다",
      "빅데이터는 항상 정형 데이터로만 구성되기 때문이다",
      "빅데이터는 한 번 사용하면 즉시 소멸되기 때문이다",
    ],
    answer: 1,
    explanation:
      "빅데이터는 재사용・재조합이 가능하고 다양한 목적으로 활용될 수 있어, 동일한 데이터라도 활용 방식에 따라 창출되는 가치가 달라지기 때문에 가치 산정이 어렵습니다.",
  },
  {
    id: "di-031",
    subject: "1과목(데이터 이해)",
    question: "트랜잭션(Transaction)이 갖추어야 할 성질(ACID)에 해당하지 않는 것은?",
    options: ["원자성(Atomicity)", "일관성(Consistency)", "고립성(Isolation)", "확장성(Scalability)"],
    answer: 3,
    explanation:
      "트랜잭션의 ACID 성질은 원자성, 일관성, 고립성(Isolation), 지속성(Durability)입니다. 확장성(Scalability)은 ACID에 해당하지 않습니다.",
  },
  {
    id: "di-032",
    subject: "1과목(데이터 이해)",
    question: "트랜잭션의 성질 중 '트랜잭션의 연산은 모두 실행되거나, 전혀 실행되지 않아야 한다'는 성질은?",
    options: ["원자성(Atomicity)", "일관성(Consistency)", "고립성(Isolation)", "지속성(Durability)"],
    answer: 0,
    explanation:
      "원자성(Atomicity)은 트랜잭션에 포함된 연산들이 모두 성공적으로 완료되거나, 하나라도 실패하면 전혀 실행되지 않은 상태로 되돌려야(All or Nothing) 한다는 성질입니다.",
  },
  {
    id: "di-033",
    subject: "1과목(데이터 이해)",
    question: "관계형 데이터베이스의 무결성 제약 중, 기본키는 NULL 값이나 중복 값을 가질 수 없다는 제약은?",
    options: ["개체 무결성(Entity Integrity)", "참조 무결성(Referential Integrity)", "도메인 무결성(Domain Integrity)", "사용자 정의 무결성"],
    answer: 0,
    explanation:
      "개체 무결성은 기본키를 구성하는 속성은 NULL 값이나 중복된 값을 가질 수 없다는 제약으로, 각 튜플(행)을 유일하게 식별하기 위한 조건입니다.",
  },
  {
    id: "di-034",
    subject: "1과목(데이터 이해)",
    question: "외래키(Foreign Key) 값은 참조하는 테이블에 존재하는 값이거나 NULL이어야 한다는 제약의 이름은?",
    options: ["개체 무결성", "참조 무결성", "도메인 무결성", "키 무결성"],
    answer: 1,
    explanation:
      "참조 무결성(Referential Integrity)은 외래키 값이 참조 대상 테이블에 실제로 존재하는 기본키 값이거나 NULL이어야 한다는 제약으로, 테이블 간 관계의 일관성을 보장합니다.",
  },
  {
    id: "di-035",
    subject: "1과목(데이터 이해)",
    question: "후보키(Candidate Key), 기본키(Primary Key), 대체키(Alternate Key)의 관계에 대한 설명으로 옳은 것은?",
    options: [
      "대체키는 후보키 중 기본키로 선택된 키를 의미한다",
      "기본키는 후보키 중에서 선정되며, 후보키 중 기본키로 선택되지 않은 나머지가 대체키이다",
      "후보키는 항상 하나의 테이블에 하나만 존재한다",
      "대체키는 반드시 여러 속성으로 구성되어야 한다",
    ],
    answer: 1,
    explanation:
      "후보키는 유일성과 최소성을 만족하는 키들의 집합이며, 그 중 하나가 기본키로 선정됩니다. 기본키로 선택되지 않은 나머지 후보키는 대체키(Alternate Key)라고 합니다.",
  },
  {
    id: "di-036",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스에서 인덱스(Index)를 사용하는 주된 목적은?",
    options: [
      "데이터의 검색 속도를 향상시키기 위해",
      "데이터의 중복을 완전히 제거하기 위해",
      "테이블 간의 관계를 정의하기 위해",
      "데이터의 무결성을 보장하기 위해",
    ],
    answer: 0,
    explanation:
      "인덱스는 특정 열을 기준으로 별도의 정렬된 구조를 만들어 데이터 검색 속도를 크게 향상시킵니다. 다만 인덱스가 많아지면 삽입・삭제・갱신 시 유지 비용(오버헤드)이 증가합니다.",
  },
  {
    id: "di-037",
    subject: "1과목(데이터 이해)",
    question: "뷰(View)에 대한 설명으로 옳은 것은?",
    options: [
      "뷰는 실제 데이터를 물리적으로 저장하는 테이블이다",
      "하나 이상의 테이블로부터 유도된 가상의 테이블이다",
      "뷰는 반드시 하나의 테이블에서만 생성할 수 있다",
      "뷰는 삭제할 수 없다",
    ],
    answer: 1,
    explanation:
      "뷰(View)는 하나 이상의 기본 테이블로부터 유도되어 만들어지는 가상 테이블로, 실제 데이터를 저장하지 않고 조회 시점에 정의된 쿼리를 실행하여 결과를 보여줍니다.",
  },
  {
    id: "di-038",
    subject: "1과목(데이터 이해)",
    question: "SQL 명령어 중 DDL(Data Definition Language)에 해당하는 것은?",
    options: ["SELECT", "CREATE", "INSERT", "GRANT"],
    answer: 1,
    explanation:
      "DDL(데이터 정의어)에는 CREATE, ALTER, DROP이 있습니다. SELECT/INSERT/UPDATE/DELETE는 DML, GRANT/REVOKE는 DCL에 해당합니다.",
  },
  {
    id: "di-039",
    subject: "1과목(데이터 이해)",
    question: "SQL에서 사용자에게 권한을 부여하거나 회수하는 명령어가 속한 언어군은?",
    options: ["DDL", "DML", "DCL", "TCL"],
    answer: 2,
    explanation:
      "DCL(Data Control Language)은 데이터베이스 접근 권한을 제어하는 언어로, GRANT(권한 부여)와 REVOKE(권한 회수) 명령어가 대표적입니다.",
  },
  {
    id: "di-040",
    subject: "1과목(데이터 이해)",
    question: "두 테이블에서 조인 조건을 만족하는 행만 결과로 반환하는 조인 방식은?",
    options: ["INNER JOIN", "LEFT OUTER JOIN", "RIGHT OUTER JOIN", "FULL OUTER JOIN"],
    answer: 0,
    explanation:
      "INNER JOIN(내부 조인)은 두 테이블에서 조인 조건을 만족하는 행만을 결과로 반환합니다. OUTER JOIN 계열은 조건을 만족하지 않는 행도 NULL을 채워 포함시킵니다.",
  },
  {
    id: "di-041",
    subject: "1과목(데이터 이해)",
    question: "왼쪽 테이블의 모든 행을 결과에 포함하고, 오른쪽 테이블에 일치하는 값이 없으면 NULL로 채우는 조인은?",
    options: ["INNER JOIN", "LEFT OUTER JOIN", "CROSS JOIN", "SELF JOIN"],
    answer: 1,
    explanation:
      "LEFT OUTER JOIN은 왼쪽(기준) 테이블의 모든 행을 결과에 포함시키고, 오른쪽 테이블에 일치하는 값이 없는 경우 해당 열을 NULL로 채웁니다.",
  },
  {
    id: "di-042",
    subject: "1과목(데이터 이해)",
    question: "하나의 SQL문 안에 포함되어 실행되는 또 다른 SELECT문을 무엇이라 하는가?",
    options: ["트리거(Trigger)", "서브쿼리(Subquery)", "저장 프로시저(Stored Procedure)", "인덱스(Index)"],
    answer: 1,
    explanation:
      "서브쿼리(Subquery)는 하나의 SQL문 내부에 포함되어 먼저 처리되는 다른 SELECT문으로, WHERE절이나 FROM절 등에서 활용됩니다.",
  },
  {
    id: "di-043",
    subject: "1과목(데이터 이해)",
    question: "테이블에 특정 이벤트(INSERT, UPDATE, DELETE 등)가 발생했을 때 자동으로 실행되도록 정의된 데이터베이스 객체는?",
    options: ["뷰(View)", "트리거(Trigger)", "인덱스(Index)", "커서(Cursor)"],
    answer: 1,
    explanation:
      "트리거(Trigger)는 테이블에 대한 특정 이벤트가 발생할 때 자동으로 실행되도록 데이터베이스에 등록해 둔 프로시저입니다.",
  },
  {
    id: "di-044",
    subject: "1과목(데이터 이해)",
    question: "제2정규형(2NF)이 만족되기 위한 조건으로 옳은 것은?",
    options: [
      "모든 속성이 원자값을 가져야 한다",
      "제1정규형을 만족하고, 기본키가 아닌 속성이 기본키에 완전 함수 종속되어야 한다",
      "이행적 함수 종속이 존재하지 않아야 한다",
      "모든 결정자가 후보키여야 한다",
    ],
    answer: 1,
    explanation:
      "제2정규형은 1NF를 만족한 상태에서, 기본키가 아닌 모든 속성이 기본키 전체에 완전 함수 종속되어야 합니다(부분 함수 종속 제거). 모든 속성의 원자값은 1NF, 이행적 종속 제거는 3NF의 조건입니다.",
  },
  {
    id: "di-045",
    subject: "1과목(데이터 이해)",
    question: "제3정규형(3NF)에서 제거해야 하는 종속 관계는?",
    options: ["부분 함수 종속", "이행적 함수 종속", "다치 종속", "결합 종속"],
    answer: 1,
    explanation:
      "제3정규형은 2NF를 만족한 상태에서 이행적 함수 종속(A→B, B→C이면 A→C가 성립하는 관계)을 제거하는 정규형입니다.",
  },
  {
    id: "di-046",
    subject: "1과목(데이터 이해)",
    question: "BCNF(보이스-코드 정규형)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "모든 결정자가 후보키가 되도록 하는, 3NF보다 강화된 정규형이다",
      "정규화 이전 단계로 되돌리는 것을 의미한다",
      "인덱스를 생성하는 규칙을 의미한다",
      "속성의 개수를 무조건 늘리는 정규형이다",
    ],
    answer: 0,
    explanation:
      "BCNF(Boyce-Codd Normal Form)는 테이블 내의 모든 결정자가 후보키가 되도록 요구하는 정규형으로, 3NF보다 좀 더 엄격한 조건을 가집니다.",
  },
  {
    id: "di-047",
    subject: "1과목(데이터 이해)",
    question: "반정규화(De-normalization)를 수행하는 주된 목적은?",
    options: [
      "데이터 중복을 완전히 제거하기 위해",
      "조회 성능을 향상시키기 위해 의도적으로 중복을 허용하기 위해",
      "이상 현상(Anomaly)을 새로 만들어내기 위해",
      "테이블의 개수를 무조건 늘리기 위해",
    ],
    answer: 1,
    explanation:
      "반정규화는 정규화로 인해 조인이 많아져 조회 성능이 저하되는 것을 막기 위해, 의도적으로 데이터 중복을 허용하거나 테이블을 통합하는 기법입니다.",
  },
  {
    id: "di-048",
    subject: "1과목(데이터 이해)",
    question: "속성 X의 값이 결정되면 속성 Y의 값이 유일하게 하나로 결정되는 관계(X→Y)를 무엇이라 하는가?",
    options: ["함수적 종속성(Functional Dependency)", "역함수 관계", "상관관계", "인과관계"],
    answer: 0,
    explanation:
      "함수적 종속성은 어떤 속성 집합 X의 값이 정해지면 다른 속성 집합 Y의 값이 유일하게 결정되는 관계(X→Y)로, 정규화 이론의 핵심 개념입니다.",
  },
  {
    id: "di-049",
    subject: "1과목(데이터 이해)",
    question: "ERD(Entity Relationship Diagram)에서 일반적으로 마름모(◇) 도형으로 표현하는 요소는?",
    options: ["엔터티(Entity)", "속성(Attribute)", "관계(Relationship)", "도메인(Domain)"],
    answer: 2,
    explanation:
      "ERD에서 사각형은 엔터티, 타원은 속성, 마름모는 엔터티 간의 관계(Relationship)를 표현하는 것이 전통적인 표기법입니다.",
  },
  {
    id: "di-050",
    subject: "1과목(데이터 이해)",
    question: "데이터 모델링 단계 중, 특정 DBMS에 종속되지 않고 업무 중심으로 핵심 엔터티와 관계를 도출하는 단계는?",
    options: ["개념적 데이터 모델링", "논리적 데이터 모델링", "물리적 데이터 모델링", "운영적 데이터 모델링"],
    answer: 0,
    explanation:
      "개념적 데이터 모델링은 특정 DBMS에 종속되지 않고 업무 영역의 핵심 엔터티와 관계를 추상적으로 도출하는 단계입니다. 논리적 모델링은 이를 정규화해 상세화하고, 물리적 모델링은 실제 DBMS에 맞춰 구현합니다.",
  },
  {
    id: "di-051",
    subject: "1과목(데이터 이해)",
    question: "데이터 모델링의 3가지 구성요소로 옳은 것은?",
    options: [
      "구조(Structure), 연산(Operation), 제약조건(Constraint)",
      "저장(Storage), 백업(Backup), 복구(Recovery)",
      "수집(Collection), 정제(Cleansing), 분석(Analysis)",
      "속도(Velocity), 용량(Volume), 다양성(Variety)",
    ],
    answer: 0,
    explanation:
      "데이터 모델링은 데이터 구조(Structure), 구조에 따른 처리(Operation), 데이터 무결성을 유지하기 위한 제약조건(Constraint)의 3요소로 구성됩니다.",
  },
  {
    id: "di-052",
    subject: "1과목(데이터 이해)",
    question: "엔터티의 속성 중, 하나의 속성이 여러 개의 값을 가질 수 있는 속성을 무엇이라 하는가?",
    options: ["단일값 속성", "다중값 속성", "유도 속성", "복합 속성"],
    answer: 1,
    explanation:
      "다중값 속성(Multi-valued Attribute)은 하나의 엔터티 인스턴스가 하나의 속성에 대해 여러 개의 값을 가질 수 있는 속성입니다(예: 한 사람이 여러 개의 전화번호를 가지는 경우).",
  },
  {
    id: "di-053",
    subject: "1과목(데이터 이해)",
    question: "부모 엔터티의 기본키가 자식 엔터티의 기본키 일부로 포함되는 관계를 무엇이라 하는가?",
    options: ["식별자 관계(Identifying Relationship)", "비식별자 관계(Non-Identifying Relationship)", "재귀 관계(Recursive Relationship)", "베타 관계"],
    answer: 0,
    explanation:
      "식별자 관계는 부모 엔터티의 기본키가 자식 엔터티의 기본키의 일부(또는 전부)로 상속되는 관계이며, 자식 엔터티의 존재가 부모 엔터티에 의존적입니다.",
  },
  {
    id: "di-054",
    subject: "1과목(데이터 이해)",
    question: "하둡(Hadoop)을 구성하는 핵심 요소로 짝지어진 것은?",
    options: [
      "HDFS와 MapReduce",
      "MySQL과 Oracle",
      "Tableau와 Power BI",
      "Python과 R",
    ],
    answer: 0,
    explanation:
      "하둡의 핵심 구성요소는 분산 파일 시스템인 HDFS(Hadoop Distributed File System)와 분산 처리 프레임워크인 MapReduce입니다.",
  },
  {
    id: "di-055",
    subject: "1과목(데이터 이해)",
    question: "HDFS(Hadoop Distributed File System)의 특징으로 옳은 것은?",
    options: [
      "파일을 하나의 서버에만 저장한다",
      "대용량 파일을 블록 단위로 나누어 여러 노드에 분산 저장하고 복제한다",
      "실시간 트랜잭션 처리에 최적화되어 있다",
      "반드시 정형 데이터만 저장할 수 있다",
    ],
    answer: 1,
    explanation:
      "HDFS는 대용량 파일을 일정 크기의 블록으로 나누어 여러 대의 서버(노드)에 분산 저장하며, 블록을 복제하여 장애 발생 시에도 데이터 손실을 방지합니다.",
  },
  {
    id: "di-056",
    subject: "1과목(데이터 이해)",
    question: "맵리듀스(MapReduce)의 처리 단계를 순서대로 나열한 것은?",
    options: [
      "Map(분할 처리) → Reduce(집계)",
      "Reduce(집계) → Map(분할 처리)",
      "Sort(정렬) → Map(분할 처리)",
      "Load(적재) → Map(분할 처리)",
    ],
    answer: 0,
    explanation:
      "맵리듀스는 데이터를 여러 조각으로 나누어 병렬로 처리하는 Map 단계와, Map의 결과를 모아 최종 결과로 집계하는 Reduce 단계로 구성됩니다.",
  },
  {
    id: "di-057",
    subject: "1과목(데이터 이해)",
    question: "하둡 기반의 데이터를 SQL과 유사한 문법(HiveQL)으로 조회할 수 있게 해주는 데이터 웨어하우징 도구는?",
    options: ["Hive", "Sqoop", "Flume", "Zookeeper"],
    answer: 0,
    explanation:
      "하이브(Hive)는 하둡 위에서 동작하는 데이터 웨어하우징 인프라로, SQL과 유사한 HiveQL을 사용해 대용량 데이터를 조회・분석할 수 있게 해줍니다.",
  },
  {
    id: "di-058",
    subject: "1과목(데이터 이해)",
    question: "관계형 데이터베이스(RDBMS)와 하둡 간에 대용량 데이터를 import/export하는 데 사용되는 도구는?",
    options: ["Sqoop", "Hive", "Pig", "Kafka"],
    answer: 0,
    explanation:
      "스쿱(Sqoop)은 관계형 데이터베이스와 하둡(HDFS) 사이에서 대용량 데이터를 효율적으로 전송(import/export)하기 위한 도구입니다.",
  },
  {
    id: "di-059",
    subject: "1과목(데이터 이해)",
    question: "여러 서버에서 발생하는 로그성 데이터를 실시간으로 수집하여 HDFS 등으로 전송하는 데 특화된 도구는?",
    options: ["Flume", "Hive", "Pig", "HBase"],
    answer: 0,
    explanation:
      "플럼(Flume)은 로그 데이터와 같이 스트림 형태로 발생하는 데이터를 실시간으로 수집하여 HDFS 등 저장소로 전송하는 데 특화된 도구입니다.",
  },
  {
    id: "di-060",
    subject: "1과목(데이터 이해)",
    question: "분산 시스템에서 여러 서버 간의 상태 정보를 관리하고 동기화(코디네이션)를 담당하는 하둡 에코시스템 도구는?",
    options: ["Zookeeper", "Sqoop", "Flume", "Hive"],
    answer: 0,
    explanation:
      "주키퍼(Zookeeper)는 분산 시스템을 구성하는 여러 서버 간의 설정 정보 공유, 상태 관리, 동기화 등 코디네이션 기능을 담당합니다.",
  },
  {
    id: "di-061",
    subject: "1과목(데이터 이해)",
    question: "인메모리(In-Memory) 방식으로 데이터를 처리하여 하둡 맵리듀스보다 반복적인 연산 속도가 빠른 분산 처리 프레임워크는?",
    options: ["Spark", "Pig", "Sqoop", "Flume"],
    answer: 0,
    explanation:
      "스파크(Spark)는 데이터를 메모리(RAM)에 올려 처리하는 인메모리 연산을 지원하여, 디스크 기반의 하둡 맵리듀스보다 반복적인 연산에서 훨씬 빠른 속도를 보입니다.",
  },
  {
    id: "di-062",
    subject: "1과목(데이터 이해)",
    question: "대용량의 실시간 데이터 스트림을 발행-구독(Publish-Subscribe) 방식으로 처리하는 분산 메시징 시스템은?",
    options: ["Kafka", "Hive", "Sqoop", "HBase"],
    answer: 0,
    explanation:
      "카프카(Kafka)는 대용량 실시간 데이터를 발행-구독 방식의 메시지 큐 형태로 처리하는 분산 스트리밍 플랫폼입니다.",
  },
  {
    id: "di-063",
    subject: "1과목(데이터 이해)",
    question: "NoSQL 데이터 모델 유형 중, 하나의 키(Key)에 하나의 값(Value)을 저장하는 가장 단순한 구조는?",
    options: ["Key-Value 모델", "Document 모델", "Column-Family 모델", "Graph 모델"],
    answer: 0,
    explanation:
      "Key-Value 모델은 고유한 키에 값을 매핑하여 저장하는 가장 단순한 형태의 NoSQL 데이터 모델로, Redis 등이 대표적입니다.",
  },
  {
    id: "di-064",
    subject: "1과목(데이터 이해)",
    question: "MongoDB로 대표되는, JSON과 유사한 형식으로 데이터를 저장하는 NoSQL 데이터 모델은?",
    options: ["Key-Value 모델", "Document 모델", "Column-Family 모델", "Graph 모델"],
    answer: 1,
    explanation:
      "Document 모델은 JSON, BSON 등과 유사한 문서(Document) 형태로 데이터를 저장하는 방식으로, 스키마가 유연하며 MongoDB가 대표적입니다.",
  },
  {
    id: "di-065",
    subject: "1과목(데이터 이해)",
    question: "HBase, Cassandra로 대표되는, 데이터를 컬럼 단위로 묶어 저장하는 NoSQL 데이터 모델은?",
    options: ["Key-Value 모델", "Document 모델", "Column-Family 모델", "Graph 모델"],
    answer: 2,
    explanation:
      "Column-Family 모델은 데이터를 행이 아닌 컬럼(열) 단위로 묶어 저장하는 방식으로, 대용량 데이터에 대한 특정 컬럼 조회 성능이 뛰어나며 HBase, Cassandra가 대표적입니다.",
  },
  {
    id: "di-066",
    subject: "1과목(데이터 이해)",
    question: "노드와 노드 사이의 관계(Edge)를 중심으로 데이터를 저장하여 소셜 네트워크 분석 등에 적합한 NoSQL 모델은?",
    options: ["Key-Value 모델", "Document 모델", "Column-Family 모델", "Graph 모델"],
    answer: 3,
    explanation:
      "Graph 모델은 노드(개체)와 그 사이의 관계(Edge)를 중심으로 데이터를 저장하는 방식으로, 소셜 네트워크나 추천 시스템 등 관계 분석에 적합하며 Neo4j가 대표적입니다.",
  },
  {
    id: "di-067",
    subject: "1과목(데이터 이해)",
    question: "분산 시스템 설계 시 일관성(Consistency), 가용성(Availability), 분할 내성(Partition Tolerance) 중 최대 2가지만 동시에 만족할 수 있다는 정리는?",
    options: ["CAP 정리", "중심극한정리", "베이즈 정리", "최소제곱 정리"],
    answer: 0,
    explanation:
      "CAP 정리는 분산 데이터 저장 시스템이 일관성(Consistency), 가용성(Availability), 분할 내성(Partition Tolerance)을 동시에 모두 만족할 수 없고, 최대 두 가지만 만족할 수 있다는 정리입니다.",
  },
  {
    id: "di-068",
    subject: "1과목(데이터 이해)",
    question: "많은 NoSQL 시스템이 지향하는 BASE 특성에 해당하지 않는 것은?",
    options: ["Basically Available(기본적 가용성)", "Soft state(유연한 상태)", "Eventually consistent(최종적 일관성)", "Strictly consistent(엄격한 일관성)"],
    answer: 3,
    explanation:
      "BASE는 Basically Available, Soft state, Eventually consistent의 약자로, 엄격한 일관성(ACID)보다 가용성을 중시하는 NoSQL의 특성을 나타냅니다. Strictly consistent는 BASE에 포함되지 않습니다.",
  },
  {
    id: "di-069",
    subject: "1과목(데이터 이해)",
    question: "서버, 스토리지, 네트워크 등 IT 인프라 자체를 서비스 형태로 제공하는 클라우드 서비스 모델은?",
    options: ["IaaS", "PaaS", "SaaS", "DaaS"],
    answer: 0,
    explanation:
      "IaaS(Infrastructure as a Service)는 서버, 스토리지, 네트워크 등의 물리적 인프라를 가상화하여 서비스 형태로 제공하는 클라우드 모델입니다(예: AWS EC2).",
  },
  {
    id: "di-070",
    subject: "1과목(데이터 이해)",
    question: "완성된 소프트웨어 애플리케이션 자체를 인터넷을 통해 서비스 형태로 제공하는 클라우드 모델은?",
    options: ["IaaS", "PaaS", "SaaS", "온프레미스"],
    answer: 2,
    explanation:
      "SaaS(Software as a Service)는 사용자가 별도의 설치 없이 웹 브라우저 등을 통해 바로 이용할 수 있는 완성된 소프트웨어를 서비스로 제공하는 모델입니다(예: 구글 문서).",
  },
  {
    id: "di-071",
    subject: "1과목(데이터 이해)",
    question: "애플리케이션 개발과 실행에 필요한 개발 환경 및 플랫폼을 서비스로 제공하는 클라우드 모델은?",
    options: ["IaaS", "PaaS", "SaaS", "온프레미스"],
    answer: 1,
    explanation:
      "PaaS(Platform as a Service)는 애플리케이션을 개발・배포・실행할 수 있는 플랫폼(운영체제, 미들웨어, 런타임 등)을 서비스로 제공하는 클라우드 모델입니다.",
  },
  {
    id: "di-072",
    subject: "1과목(데이터 이해)",
    question: "정형・비정형 데이터를 가공하지 않은 원본 형태 그대로 저장해두는 대용량 저장소를 무엇이라 하는가?",
    options: ["데이터 레이크(Data Lake)", "데이터 마트(Data Mart)", "데이터 웨어하우스(Data Warehouse)", "데이터 큐브(Data Cube)"],
    answer: 0,
    explanation:
      "데이터 레이크는 정형, 반정형, 비정형 데이터를 가공하지 않은 원본(Raw) 상태 그대로 저장해두는 대용량 저장소로, 필요할 때 목적에 맞게 가공하여 사용합니다.",
  },
  {
    id: "di-073",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 조직에 필요한 인력의 역량 중 '소프트 스킬(Soft Skill)'에 해당하는 것은?",
    options: [
      "머신러닝 알고리즘 구현 능력",
      "통계학 이론에 대한 지식",
      "통찰력 있는 분석과 설득력 있는 커뮤니케이션 능력",
      "프로그래밍 언어 문법 숙지",
    ],
    answer: 2,
    explanation:
      "소프트 스킬은 통찰력 있는 분석, 설득력 있는 전달(커뮤니케이션), 협업 능력 등을 의미하며, 통계・프로그래밍 지식과 같은 하드 스킬(Hard Skill)과 함께 데이터 사이언티스트에게 요구됩니다.",
  },
  {
    id: "di-074",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 분석 결과를 통해 기업이 새로운 가치를 창출하는 비즈니스 모델을 체계적으로 설계할 때 활용되는, 9개의 블록으로 구성된 도구는?",
    options: ["비즈니스 모델 캔버스(Business Model Canvas)", "SWOT 분석", "포트폴리오 매트릭스", "간트 차트"],
    answer: 0,
    explanation:
      "비즈니스 모델 캔버스는 고객 세그먼트, 가치 제안, 채널, 수익원 등 9개 블록으로 비즈니스 모델을 체계적으로 설계・분석하는 도구로, 데이터 기반 비즈니스 모델 설계에도 활용됩니다.",
  },
  {
    id: "di-075",
    subject: "1과목(데이터 이해)",
    question: "IoT(사물인터넷)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "사람이 직접 입력한 데이터만을 수집하는 기술이다",
      "사물에 부착된 센서를 통해 실시간으로 데이터를 수집하고 인터넷으로 주고받는 기술이다",
      "오직 통신사만 사용할 수 있는 폐쇄형 네트워크이다",
      "정형 데이터만을 생성하는 기술이다",
    ],
    answer: 1,
    explanation:
      "IoT(Internet of Things)는 각종 사물에 부착된 센서를 통해 데이터를 실시간으로 수집하고 인터넷을 통해 주고받는 기술로, 빅데이터의 주요 발생 원천 중 하나입니다.",
  },
  {
    id: "di-076",
    subject: "1과목(데이터 이해)",
    question: "인공지능(AI), 머신러닝(ML), 딥러닝(DL)의 포함 관계로 옳은 것은?",
    options: [
      "머신러닝이 가장 큰 개념이고 그 안에 인공지능과 딥러닝이 포함된다",
      "인공지능이 가장 큰 개념이고, 그 하위에 머신러닝, 다시 그 하위에 딥러닝이 포함된다",
      "셋은 서로 전혀 관련이 없는 독립적인 개념이다",
      "딥러닝이 가장 큰 개념이고 그 안에 인공지능과 머신러닝이 포함된다",
    ],
    answer: 1,
    explanation:
      "인공지능(AI)이 가장 포괄적인 개념이며, 머신러닝(ML)은 AI를 구현하는 방법론 중 하나이고, 딥러닝(DL)은 인공신경망을 기반으로 한 머신러닝의 한 분야입니다.",
  },
  {
    id: "di-077",
    subject: "1과목(데이터 이해)",
    question: "웹사이트 등에서 데이터를 자동으로 수집하는 프로그램/기법을 가리키는 용어는?",
    options: ["크롤링(Crawling)", "샤딩(Sharding)", "리팩토링(Refactoring)", "파티셔닝(Partitioning)"],
    answer: 0,
    explanation:
      "크롤링(Crawling)은 웹사이트를 자동으로 순회하며 웹 페이지의 데이터를 수집하는 기법으로, 비정형/반정형 데이터 수집에 널리 사용됩니다.",
  },
  {
    id: "di-078",
    subject: "1과목(데이터 이해)",
    question: "ELT(Extract-Load-Transform) 방식이 전통적인 ETL(Extract-Transform-Load) 방식과 다른 점은?",
    options: [
      "변환(Transform)을 적재(Load)보다 먼저 수행한다",
      "데이터를 적재한 이후에 필요한 시점에 변환을 수행한다",
      "추출(Extract) 단계를 생략한다",
      "정형 데이터만 처리할 수 있다",
    ],
    answer: 1,
    explanation:
      "ELT는 데이터를 추출한 뒤 변환 없이 먼저 저장소(데이터 레이크 등)에 적재하고, 필요한 시점에 목적에 맞게 변환을 수행하는 방식으로, 대용량・비정형 데이터 처리에 유리합니다.",
  },
  {
    id: "di-079",
    subject: "1과목(데이터 이해)",
    question: "전사적 아키텍처(EA, Enterprise Architecture)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "특정 부서 하나의 서버 구성도만을 의미한다",
      "조직의 비즈니스, 데이터, 애플리케이션, 기술을 통합적 관점에서 설계하는 체계이다",
      "개인용 컴퓨터의 하드웨어 사양을 의미한다",
      "특정 프로그래밍 언어의 문법 체계를 의미한다",
    ],
    answer: 1,
    explanation:
      "전사적 아키텍처(EA)는 조직의 비즈니스 전략과 이를 지원하는 데이터, 애플리케이션, 기술 인프라를 통합적인 관점에서 설계하고 관리하기 위한 체계입니다.",
  },
  {
    id: "di-080",
    subject: "1과목(데이터 이해)",
    question: "마스터 데이터 관리(MDM, Master Data Management)의 주된 목적으로 가장 적절한 것은?",
    options: [
      "여러 시스템에 흩어진 핵심 데이터를 일관성 있게 통합・관리하기 위해서이다",
      "임시로 생성되는 로그 데이터를 빠르게 삭제하기 위해서이다",
      "웹사이트의 디자인을 통일하기 위해서이다",
      "네트워크 트래픽을 암호화하기 위해서이다",
    ],
    answer: 0,
    explanation:
      "MDM은 고객, 상품 등 여러 시스템에 중복・분산되어 있는 핵심(마스터) 데이터를 하나의 기준으로 통합하고 일관되게 관리하기 위한 체계입니다.",
  },
  {
    id: "di-081",
    subject: "1과목(데이터 이해)",
    question: "데이터 거버넌스가 궁극적으로 달성하고자 하는 목표로 가장 적절한 것은?",
    options: [
      "데이터를 조직의 자산으로 인식하고 품질과 보안을 확보하여 데이터 활용 가치를 극대화하는 것",
      "가능한 한 많은 데이터를 무조건 수집하여 저장 공간을 늘리는 것",
      "특정 부서만 데이터를 독점적으로 사용하게 하는 것",
      "데이터베이스 서버의 물리적 대수를 늘리는 것",
    ],
    answer: 0,
    explanation:
      "데이터 거버넌스는 원칙, 조직, 프로세스를 통해 데이터를 조직의 핵심 자산으로 관리하고, 데이터 품질과 보안을 확보하여 데이터 활용의 가치를 극대화하는 것을 목표로 합니다.",
  },
  {
    id: "di-082",
    subject: "1과목(데이터 이해)",
    question: "데이터 표준화 과정에서 일반적으로 정의하는 대상으로 가장 거리가 먼 것은?",
    options: ["표준 용어", "표준 도메인", "표준 코드", "직원의 개인 성과 등급"],
    answer: 3,
    explanation:
      "데이터 표준화에서는 조직 전체에서 일관되게 사용할 표준 용어, 표준 도메인, 표준 코드 등을 정의합니다. 직원 개인의 성과 등급은 데이터 표준화의 대상이 아닙니다.",
  },
  {
    id: "di-083",
    subject: "1과목(데이터 이해)",
    question: "데이터의 값, 구조, 패턴 등을 분석하여 데이터의 현재 상태와 품질 수준을 파악하는 활동을 무엇이라 하는가?",
    options: ["데이터 프로파일링(Data Profiling)", "데이터 마이닝(Data Mining)", "데이터 시각화(Data Visualization)", "데이터 마스킹(Data Masking)"],
    answer: 0,
    explanation:
      "데이터 프로파일링은 데이터의 값 분포, 형식, 구조, 관계 등을 분석하여 데이터 품질 수준과 현황을 파악하는 활동으로, 데이터 품질 개선의 첫 단계로 활용됩니다.",
  },
  {
    id: "di-084",
    subject: "1과목(데이터 이해)",
    question: "데이터에서 오류, 중복, 누락 등을 찾아 수정하거나 제거하는 활동을 무엇이라 하는가?",
    options: ["데이터 클렌징(Data Cleansing)", "데이터 마이닝(Data Mining)", "데이터 웨어하우징(Data Warehousing)", "데이터 마트 구축"],
    answer: 0,
    explanation:
      "데이터 클렌징(정제)은 데이터에 존재하는 오류, 중복, 결측, 형식 불일치 등을 찾아내어 수정하거나 제거함으로써 데이터 품질을 높이는 활동입니다.",
  },
  {
    id: "di-085",
    subject: "1과목(데이터 이해)",
    question: "개인정보보호법에서 정의하는 '개인정보'에 해당하는 것은?",
    options: [
      "살아있는 개인을 알아볼 수 있는 정보",
      "법인의 재무제표 정보",
      "특정 지역의 평균 기온 정보",
      "익명 처리되어 더 이상 개인을 알아볼 수 없는 정보",
    ],
    answer: 0,
    explanation:
      "개인정보보호법상 개인정보란 살아있는 개인에 관한 정보로서 성명, 주민등록번호 등을 통해 특정 개인을 알아볼 수 있는 정보(다른 정보와 결합하여 알아볼 수 있는 것 포함)를 말합니다.",
  },
  {
    id: "di-086",
    subject: "1과목(데이터 이해)",
    question: "개인정보보호법상 정보주체의 별도 동의 없이도 가명정보를 활용할 수 있도록 허용된 목적으로 가장 적절한 것은?",
    options: [
      "통계작성, 과학적 연구, 공익적 기록보존 등의 목적",
      "특정 개인에게 표적 광고를 발송하기 위한 목적",
      "제3자에게 무단으로 판매하기 위한 목적",
      "개인을 특정하여 신용을 평가하기 위한 목적",
    ],
    answer: 0,
    explanation:
      "데이터 3법 개정으로 가명정보는 통계작성, 과학적 연구, 공익적 기록보존 등의 목적으로는 정보주체의 별도 동의 없이도 활용할 수 있도록 근거가 마련되었습니다.",
  },
  {
    id: "di-087",
    subject: "1과목(데이터 이해)",
    question: "'시간, 비용, 노력이 지나치게 소요되어 더 이상 다른 정보를 사용해도 특정 개인을 알아볼 수 없는 정보'를 가리키는 용어는?",
    options: ["익명정보", "가명정보", "고유식별정보", "민감정보"],
    answer: 0,
    explanation:
      "익명정보는 개인을 알아볼 수 없도록 처리되어, 시간・비용・노력 등을 고려할 때 다른 정보를 사용하더라도 더 이상 특정 개인을 재식별할 수 없는 정보로, 개인정보보호법의 적용을 받지 않습니다.",
  },
  {
    id: "di-088",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 위기요인 중 '책임 원칙 훼손' 문제에 대한 통제 방안으로 가장 적절한 것은?",
    options: [
      "데이터 수집 자체를 전면 금지한다",
      "알고리즘 설계자와 사용자에게 결과에 대한 책임을 강화한다",
      "모든 데이터를 익명 처리하여 폐기한다",
      "빅데이터 분석을 통계학자에게만 허용한다",
    ],
    answer: 1,
    explanation:
      "책임 원칙 훼손(예측 알고리즘에 의한 불이익 발생)에 대한 통제 방안으로는, 특정 행동을 예측・판단한 알고리즘 설계자와 사용자에게 그 결과에 대한 책임을 강화하는 '책임 원칙'이 제시됩니다.",
  },
  {
    id: "di-089",
    subject: "1과목(데이터 이해)",
    question: "데이터 오용으로 인한 피해 문제에 대응하기 위해 제시되는 통제 방안은?",
    options: [
      "사전 동의를 받았는지 여부와 무관하게 결과에 대한 책임을 묻는 결과 기반 책임 원칙",
      "데이터의 수집 자체를 원천적으로 봉쇄",
      "정보 주체의 알 권리를 축소",
      "분석 알고리즘을 절대 공개하지 않음",
    ],
    answer: 0,
    explanation:
      "데이터 오용 문제에 대해서는 사전 동의라는 절차보다, 실제로 데이터가 어떻게 활용되었고 그 결과가 어떠했는지에 따라 책임을 묻는 '결과 기반 책임 원칙'으로의 전환이 대안으로 제시됩니다.",
  },
  {
    id: "di-090",
    subject: "1과목(데이터 이해)",
    question: "2020년 개정된 데이터 3법 시행의 의의로 가장 적절한 것은?",
    options: [
      "개인정보의 상업적 활용을 전면 금지하였다",
      "가명정보 개념을 도입하여 데이터 활용의 법적 근거를 마련하였다",
      "모든 데이터의 국외 반출을 의무화하였다",
      "빅데이터 분석 자체를 규제 대상으로 신설하였다",
    ],
    answer: 1,
    explanation:
      "데이터 3법 개정은 가명정보라는 개념을 새롭게 도입하여, 개인을 식별할 수 없도록 처리한 정보를 일정 목적 하에 활용할 수 있는 법적 근거를 마련한 데 큰 의의가 있습니다.",
  },
  {
    id: "di-091",
    subject: "1과목(데이터 이해)",
    question: "일반적인 빅데이터 플랫폼의 데이터 처리 흐름을 순서대로 나열한 것은?",
    options: [
      "수집 → 저장 → 처리 → 분석 → 시각화/활용",
      "분석 → 수집 → 시각화 → 저장 → 처리",
      "시각화 → 저장 → 수집 → 분석 → 처리",
      "저장 → 분석 → 수집 → 처리 → 시각화",
    ],
    answer: 0,
    explanation:
      "빅데이터 플랫폼은 일반적으로 다양한 소스에서 데이터를 수집하고, 저장소에 적재한 뒤, 처리 및 분석을 거쳐 그 결과를 시각화하고 활용하는 흐름으로 구성됩니다.",
  },
  {
    id: "di-092",
    subject: "1과목(데이터 이해)",
    question: "비정형 텍스트 데이터에서 의미 있는 정보와 패턴을 추출하는 분석 기법은?",
    options: ["텍스트 마이닝(Text Mining)", "웹 마이닝(Web Mining)", "프로세스 마이닝(Process Mining)", "그래프 마이닝(Graph Mining)"],
    answer: 0,
    explanation:
      "텍스트 마이닝은 비정형 텍스트 데이터로부터 자연어 처리 기술 등을 활용해 유용한 정보, 패턴, 관계를 추출하는 분석 기법입니다.",
  },
  {
    id: "di-093",
    subject: "1과목(데이터 이해)",
    question: "SNS 게시글이나 리뷰 등에 나타난 글쓴이의 감정・의견・태도를 분석하는 기법은?",
    options: ["오피니언 마이닝(Opinion Mining, 감성분석)", "소셜 네트워크 분석(SNA)", "리얼리티 마이닝", "프로세스 마이닝"],
    answer: 0,
    explanation:
      "오피니언 마이닝(감성분석)은 텍스트에 나타난 글쓴이의 긍정・부정・중립 등의 감정이나 의견, 태도를 분석하는 기법입니다.",
  },
  {
    id: "di-094",
    subject: "1과목(데이터 이해)",
    question: "소셜 미디어 상에서 개인이나 그룹 간의 관계 구조와 영향력을 분석하는 기법은?",
    options: ["소셜 네트워크 분석(SNA, Social Network Analysis)", "텍스트 마이닝", "오피니언 마이닝", "군집 분석"],
    answer: 0,
    explanation:
      "소셜 네트워크 분석(SNA)은 소셜 미디어 등에서 개인, 그룹 간의 연결 관계와 네트워크 구조, 영향력의 중심성 등을 분석하는 기법입니다.",
  },
  {
    id: "di-095",
    subject: "1과목(데이터 이해)",
    question: "스마트폰 등 모바일 기기에서 수집되는 위치, 통화, 행동 로그 데이터를 바탕으로 인간관계와 행동 패턴을 추론하는 기법은?",
    options: ["리얼리티 마이닝(Reality Mining)", "웹 마이닝", "프로세스 마이닝", "옵티마이제이션"],
    answer: 0,
    explanation:
      "리얼리티 마이닝은 모바일 기기에서 수집되는 위치, 통화 기록 등 현실 세계의 행동 데이터를 분석하여 인간관계나 행동 패턴을 추론하는 기법입니다.",
  },
  {
    id: "di-096",
    subject: "1과목(데이터 이해)",
    question: "다음 중 반정형 데이터(Semi-Structured Data)에 해당하는 것은?",
    options: ["XML 문서", "관계형 데이터베이스 테이블", "음성 파일", "동영상 파일"],
    answer: 0,
    explanation:
      "반정형 데이터는 완전한 스키마는 없지만 태그나 구조를 가지는 데이터로 XML, JSON, HTML 등이 해당합니다. 관계형 테이블은 정형, 음성・동영상은 비정형 데이터입니다.",
  },
  {
    id: "di-097",
    subject: "1과목(데이터 이해)",
    question: "다음 중 비정형 데이터(Unstructured Data)에 해당하지 않는 것은?",
    options: ["동영상 파일", "이미지 파일", "음성 파일", "JSON 파일"],
    answer: 3,
    explanation:
      "동영상, 이미지, 음성 파일은 정해진 구조가 없는 비정형 데이터입니다. JSON은 태그(키-값) 구조를 가진 반정형 데이터로 분류됩니다.",
  },
  {
    id: "di-098",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 3V(Volume, Velocity, Variety)에 'Value(가치)'를 추가하여 설명하는 모델을 무엇이라 하는가?",
    options: ["4V 모델", "3C 모델", "DIKW 모델", "SWOT 모델"],
    answer: 0,
    explanation:
      "빅데이터의 특성을 설명할 때 3V(Volume, Velocity, Variety)에 데이터가 창출하는 실질적 가치를 의미하는 Value를 추가하여 4V로 설명하기도 합니다.",
  },
  {
    id: "di-099",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 5V 모델에서 3V와 Value 외에 추가로 포함되는 특성은?",
    options: ["Veracity(신뢰성/정확성)", "Vision(비전)", "Vector(벡터)", "Virtue(미덕)"],
    answer: 0,
    explanation:
      "5V 모델은 Volume, Velocity, Variety, Value에 데이터의 정확성과 신뢰성을 의미하는 Veracity를 추가한 모델입니다.",
  },
  {
    id: "di-100",
    subject: "1과목(데이터 이해)",
    question: "DBMS(Database Management System)를 사용함으로써 얻을 수 있는 장점으로 가장 거리가 먼 것은?",
    options: [
      "데이터 중복을 최소화하고 일관성을 유지할 수 있다",
      "여러 사용자가 동시에 데이터를 공유할 수 있다",
      "데이터 보안과 무결성을 체계적으로 관리할 수 있다",
      "전문 인력이나 시스템 자원이 전혀 필요하지 않다",
    ],
    answer: 3,
    explanation:
      "DBMS는 데이터 중복 최소화, 데이터 공유, 보안・무결성 관리 등의 장점이 있지만, 오히려 도입・운영을 위한 전문 인력과 시스템 자원이 필요하다는 것이 단점입니다.",
  },
  {
    id: "di-101",
    subject: "1과목(데이터 이해)",
    question: "DBMS 도입 시 발생할 수 있는 단점으로 가장 적절한 것은?",
    options: [
      "데이터 중복이 심각하게 증가한다",
      "시스템 도입 및 유지보수에 상대적으로 많은 비용과 전문 인력이 필요하다",
      "여러 사용자의 동시 접근이 원천적으로 불가능해진다",
      "데이터 일관성을 유지할 수 없게 된다",
    ],
    answer: 1,
    explanation:
      "DBMS는 여러 장점에도 불구하고 도입 비용, 전문 인력 확보, 시스템 복잡도 증가 등의 단점을 수반합니다.",
  },
  {
    id: "di-102",
    subject: "1과목(데이터 이해)",
    question: "전통적인 파일 시스템과 비교했을 때 DBMS의 가장 큰 차별점은?",
    options: [
      "데이터를 여러 애플리케이션이 프로그램 종속 없이 공유하고 무결성을 유지할 수 있다는 점",
      "데이터를 하드디스크가 아닌 메모리에만 저장한다는 점",
      "반드시 하나의 프로그램에서만 데이터를 사용할 수 있다는 점",
      "데이터베이스는 항상 비정형 데이터만 다룬다는 점",
    ],
    answer: 0,
    explanation:
      "파일 시스템은 프로그램마다 개별적으로 데이터를 관리해 중복과 불일치가 발생하기 쉬운 반면, DBMS는 데이터를 통합 관리하여 여러 프로그램이 공유하면서도 일관성과 무결성을 유지할 수 있습니다.",
  },
  {
    id: "di-103",
    subject: "1과목(데이터 이해)",
    question: "여러 트랜잭션이 동시에 데이터베이스에 접근할 때 데이터의 일관성을 유지하기 위한 제어를 무엇이라 하는가?",
    options: ["동시성 제어(Concurrency Control)", "정규화(Normalization)", "인덱싱(Indexing)", "샤딩(Sharding)"],
    answer: 0,
    explanation:
      "동시성 제어는 여러 트랜잭션이 같은 데이터에 동시에 접근할 때 발생할 수 있는 갱신 손실 등의 문제를 방지하여 데이터의 일관성을 유지하기 위한 기법입니다.",
  },
  {
    id: "di-104",
    subject: "1과목(데이터 이해)",
    question: "시스템 장애 발생 시, 트랜잭션 로그를 이용해 데이터베이스를 장애 이전 상태로 되돌리는 기법은?",
    options: ["로그 기반 회복(Log-based Recovery)", "정규화", "인덱싱", "샤딩(Sharding)"],
    answer: 0,
    explanation:
      "로그 기반 회복 기법은 트랜잭션이 수행한 연산 내용을 로그로 기록해두고, 장애 발생 시 이 로그를 이용해 REDO(재실행) 또는 UNDO(취소) 연산을 수행하여 데이터베이스를 정상 상태로 복구합니다.",
  },
  {
    id: "di-105",
    subject: "1과목(데이터 이해)",
    question: "물리적으로 여러 곳에 분산된 데이터베이스를 논리적으로는 하나의 데이터베이스처럼 사용할 수 있게 하는 것은?",
    options: ["분산 데이터베이스(Distributed Database)", "데이터 마트", "데이터 웨어하우스", "데이터 레이크"],
    answer: 0,
    explanation:
      "분산 데이터베이스는 물리적으로 네트워크를 통해 여러 지역에 분산 저장되어 있지만, 사용자에게는 논리적으로 하나의 통합된 데이터베이스처럼 보이도록 관리되는 시스템입니다.",
  },
  {
    id: "di-106",
    subject: "1과목(데이터 이해)",
    question: "도메인 무결성이나 개체・참조 무결성으로 표현할 수 없는, 업무 규칙에 따라 사용자가 별도로 정의하는 무결성 제약은?",
    options: ["사용자 정의 무결성(User-Defined Integrity)", "개체 무결성", "참조 무결성", "도메인 무결성"],
    answer: 0,
    explanation:
      "사용자 정의 무결성은 특정 업무 규칙(예: 급여는 최저임금 이상이어야 한다)처럼, 표준화된 무결성 제약만으로는 표현할 수 없는 조건을 사용자가 직접 정의하는 제약입니다.",
  },
  {
    id: "di-107",
    subject: "1과목(데이터 이해)",
    question: "ANSI/SPARC 3단계 스키마 중, 데이터가 저장 장치에 실제로 저장되는 방식을 정의하는 스키마는?",
    options: ["내부 스키마(Internal Schema)", "외부 스키마(External Schema)", "개념 스키마(Conceptual Schema)", "논리 스키마(Logical Schema)"],
    answer: 0,
    explanation:
      "내부 스키마는 데이터가 물리적 저장 장치에 실제로 어떻게 저장되는지(파일 구조, 인덱스, 저장 방법 등)를 정의하는 스키마입니다.",
  },
  {
    id: "di-108",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스에 저장된 테이블, 컬럼, 인덱스 등에 대한 정보(메타데이터)를 관리하는 시스템 요소는?",
    options: ["데이터 사전(Data Dictionary)", "트랜잭션 로그", "쿼리 옵티마이저", "트리거"],
    answer: 0,
    explanation:
      "데이터 사전(시스템 카탈로그)은 데이터베이스에 존재하는 테이블, 컬럼, 인덱스, 사용자 권한 등에 대한 메타데이터를 저장하고 관리하는 시스템입니다.",
  },
  {
    id: "di-109",
    subject: "1과목(데이터 이해)",
    question: "SQL이 '어떻게(How) 처리할지'가 아니라 '무엇을(What) 원하는지'를 명시하는 방식의 언어라는 특징을 가리키는 용어는?",
    options: ["선언형(비절차적) 언어", "객체지향 언어", "함수형 언어", "어셈블리 언어"],
    answer: 0,
    explanation:
      "SQL은 처리 절차를 명시하는 절차적 언어가 아니라, 원하는 결과가 무엇인지만 선언하면 DBMS 내부의 옵티마이저가 실행 방법을 결정하는 선언형(비절차적) 언어입니다.",
  },
  {
    id: "di-110",
    subject: "1과목(데이터 이해)",
    question: "서로 다른 원천의 데이터를 하나의 일관된 형태로 결합하는 작업을 무엇이라 하는가?",
    options: ["데이터 통합(Data Integration)", "데이터 마이닝", "데이터 시각화", "데이터 백업"],
    answer: 0,
    explanation:
      "데이터 통합은 서로 다른 시스템이나 형식으로 존재하는 데이터를 하나의 일관된 뷰로 결합하는 작업으로, ETL 과정의 핵심 활동 중 하나입니다.",
  },
  {
    id: "di-111",
    subject: "1과목(데이터 이해)",
    question: "조직 내 데이터를 자산으로 관리하는 최고 책임자를 가리키는 용어로 가장 적절한 것은?",
    options: ["CDO(Chief Data Officer)", "CFO(Chief Financial Officer)", "CMO(Chief Marketing Officer)", "COO(Chief Operating Officer)"],
    answer: 0,
    explanation:
      "CDO(최고데이터책임자)는 조직 내에서 데이터를 전략적 자산으로 관리하고, 데이터 거버넌스와 데이터 기반 의사결정을 총괄하는 최고 책임자입니다.",
  },
  {
    id: "di-112",
    subject: "1과목(데이터 이해)",
    question: "데이터를 올바르게 이해하고, 해석하고, 이를 근거로 논리적으로 의사소통할 수 있는 능력을 무엇이라 하는가?",
    options: ["데이터 리터러시(Data Literacy)", "데이터 마이닝", "데이터 거버넌스", "데이터 웨어하우징"],
    answer: 0,
    explanation:
      "데이터 리터러시는 데이터를 읽고 해석하며, 이를 근거로 논리적으로 의사소통하고 활용할 수 있는 역량을 의미하며, 빅데이터 시대에 조직 구성원 전반에게 요구되는 능력입니다.",
  },
  {
    id: "di-113",
    subject: "1과목(데이터 이해)",
    question: "특정 분야에 대한 깊이 있는 전문성과 함께, 다른 분야와 폭넓게 소통・협업할 수 있는 능력을 함께 갖춘 인재를 가리키는 용어는?",
    options: ["T자형 인재", "I자형 인재", "一자형 인재", "N자형 인재"],
    answer: 0,
    explanation:
      "T자형 인재는 한 분야에 대한 깊이 있는 전문성(T의 세로획)과 함께, 여러 분야를 폭넓게 이해하고 협업할 수 있는 능력(T의 가로획)을 함께 갖춘 인재를 의미하며, 데이터 사이언티스트에게 요구되는 인재상으로 자주 언급됩니다.",
  },
  {
    id: "di-114",
    subject: "1과목(데이터 이해)",
    question: "경영진의 직관이나 경험이 아닌, 데이터 분석 결과를 근거로 의사결정을 내리는 방식을 무엇이라 하는가?",
    options: ["데이터 기반 의사결정(Data-Driven Decision Making)", "직관적 의사결정", "관행적 의사결정", "권위적 의사결정"],
    answer: 0,
    explanation:
      "데이터 기반 의사결정은 개인의 경험이나 직관이 아니라, 데이터 분석을 통해 도출된 객관적 근거를 바탕으로 의사결정을 내리는 방식으로, 빅데이터 시대의 핵심적인 사고방식 변화입니다.",
  },
  {
    id: "di-115",
    subject: "1과목(데이터 이해)",
    question: "신용정보의 이용 및 보호에 관한 법률(신용정보법) 개정과 관련된 데이터 3법의 내용으로 가장 적절한 것은?",
    options: [
      "가명정보를 신용정보 분야에서 통계작성 등 목적으로 활용할 수 있는 근거를 마련하였다",
      "모든 신용정보의 활용을 전면 금지하였다",
      "신용평가 업무를 개인이 직접 수행하도록 의무화하였다",
      "금융 데이터의 해외 반출을 의무화하였다",
    ],
    answer: 0,
    explanation:
      "데이터 3법 개정 중 신용정보법 개정을 통해 가명・익명처리된 신용정보를 통계작성, 연구 등의 목적으로 활용할 수 있는 법적 근거가 마련되었고, 이는 마이데이터 산업 활성화의 기반이 되었습니다.",
  },
  {
    id: "di-116",
    subject: "1과목(데이터 이해)",
    question: "개인이 자신에 관한 정보를 적극적으로 관리・통제하고, 이를 신용・자산 관리 등에 주도적으로 활용할 수 있도록 하는 산업/제도를 무엇이라 하는가?",
    options: ["마이데이터(MyData)", "빅데이터 플랫폼", "데이터 레이크", "오픈뱅킹"],
    answer: 0,
    explanation:
      "마이데이터는 개인이 자신과 관련된 데이터에 대한 권리를 가지고 이를 능동적으로 관리하며, 신용・자산 관리 등 필요한 곳에 직접 제공하고 활용할 수 있게 하는 산업 및 제도입니다.",
  },
  {
    id: "di-117",
    subject: "1과목(데이터 이해)",
    question: "데이터의 생산, 거래 및 활용을 촉진하기 위한 기반을 조성할 목적으로 제정된 법률은?",
    options: ["데이터 산업진흥 및 이용촉진에 관한 기본법(데이터기본법)", "저작권법", "전자상거래법", "특허법"],
    answer: 0,
    explanation:
      "데이터기본법(데이터 산업진흥 및 이용촉진에 관한 기본법)은 데이터의 생산・거래・활용을 촉진하고 관련 산업 발전의 기반을 조성하기 위해 제정된 법률입니다.",
  },
  {
    id: "di-118",
    subject: "1과목(데이터 이해)",
    question: "인공지능 모델의 학습을 위해 원본 데이터에 정답(태그)을 부여하는 작업을 무엇이라 하는가?",
    options: ["데이터 라벨링(Data Labeling)", "데이터 마스킹", "데이터 익명화", "데이터 압축"],
    answer: 0,
    explanation:
      "데이터 라벨링은 이미지, 텍스트 등 원본 데이터에 정답에 해당하는 태그(레이블)를 부여하는 작업으로, 지도학습 기반 인공지능 모델 학습에 필수적인 전처리 과정입니다.",
  },
  {
    id: "di-119",
    subject: "1과목(데이터 이해)",
    question: "원하는 결과를 얻기 위해 필요한 연산의 절차를 순서대로 명시하는 절차적 관계형 데이터베이스 질의 언어는?",
    options: ["관계대수(Relational Algebra)", "관계해석(Relational Calculus)", "정규화", "SQL 표준"],
    answer: 0,
    explanation:
      "관계대수는 SELECT, PROJECT, JOIN 등의 연산자를 이용해 원하는 결과를 얻기까지의 처리 절차를 명시적으로 나타내는 절차적 질의어입니다.",
  },
  {
    id: "di-120",
    subject: "1과목(데이터 이해)",
    question: "처리 절차보다는 원하는 결과가 무엇인지를 수학적 논리에 기반하여 기술하는 비절차적 질의 언어는?",
    options: ["관계해석(Relational Calculus)", "관계대수(Relational Algebra)", "플로우차트", "의사코드"],
    answer: 0,
    explanation:
      "관계해석은 원하는 결과를 어떤 절차로 얻을지가 아니라, 술어 논리를 바탕으로 결과가 만족해야 하는 조건이 무엇인지를 기술하는 비절차적 질의어입니다.",
  },
  {
    id: "di-121",
    subject: "1과목(데이터 이해)",
    question: "1976년 개체와 관계를 이용해 데이터를 모델링하는 E-R(Entity-Relationship) 모델을 최초로 제안한 사람은?",
    options: ["피터 첸(Peter Chen)", "에드거 커드(Edgar Codd)", "도널드 커누스(Donald Knuth)", "존 매카시(John McCarthy)"],
    answer: 0,
    explanation:
      "E-R(개체-관계) 모델은 1976년 피터 첸(Peter Chen)이 제안한 데이터 모델링 기법으로, 현실 세계를 엔터티와 그들 사이의 관계로 표현합니다.",
  },
  {
    id: "di-122",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스 설계의 일반적인 진행 순서로 가장 적절한 것은?",
    options: [
      "요구사항 분석 → 개념적 설계 → 논리적 설계 → 물리적 설계 → 구현",
      "물리적 설계 → 논리적 설계 → 개념적 설계 → 요구사항 분석 → 구현",
      "구현 → 요구사항 분석 → 개념적 설계 → 논리적 설계 → 물리적 설계",
      "논리적 설계 → 물리적 설계 → 요구사항 분석 → 개념적 설계 → 구현",
    ],
    answer: 0,
    explanation:
      "데이터베이스 설계는 일반적으로 요구사항 분석 → 개념적 설계 → 논리적 설계 → 물리적 설계 → 구현 및 실제 시스템 반영의 순서로 진행됩니다.",
  },
  {
    id: "di-123",
    subject: "1과목(데이터 이해)",
    question: "SQL에서 조회 결과를 특정 열을 기준으로 오름차순 또는 내림차순으로 정렬할 때 사용하는 절은?",
    options: ["ORDER BY", "GROUP BY", "HAVING", "WHERE"],
    answer: 0,
    explanation:
      "ORDER BY 절은 SELECT문의 조회 결과를 특정 열을 기준으로 오름차순(ASC, 기본값) 또는 내림차순(DESC)으로 정렬할 때 사용합니다.",
  },
  {
    id: "di-124",
    subject: "1과목(데이터 이해)",
    question: "GROUP BY로 그룹화된 결과에 대해 조건을 지정하여 필터링할 때 사용하는 SQL 절은?",
    options: ["HAVING", "WHERE", "ORDER BY", "LIMIT"],
    answer: 0,
    explanation:
      "HAVING 절은 GROUP BY로 그룹화된 이후의 집계 결과에 대해 조건을 지정하여 필터링할 때 사용합니다. WHERE는 그룹화 이전의 개별 행을 필터링합니다.",
  },
  {
    id: "di-125",
    subject: "1과목(데이터 이해)",
    question: "SQL에서 UNION과 UNION ALL의 차이점으로 옳은 것은?",
    options: [
      "UNION은 중복된 행을 제거하고, UNION ALL은 중복된 행을 그대로 포함한다",
      "UNION ALL만 두 개의 SELECT 결과를 합칠 수 있다",
      "UNION은 반드시 하나의 열만 조회할 때 사용할 수 있다",
      "둘 사이에는 아무런 차이가 없다",
    ],
    answer: 0,
    explanation:
      "UNION은 두 SELECT문의 결과를 합치면서 중복된 행을 제거하고, UNION ALL은 중복 여부와 관계없이 모든 행을 그대로 합칩니다.",
  },
  {
    id: "di-126",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스와 데이터 마이닝의 관계에 대한 설명으로 가장 적절한 것은?",
    options: [
      "데이터베이스는 데이터를 저장・관리하는 시스템이고, 데이터 마이닝은 그 데이터에서 유용한 패턴과 지식을 추출하는 활동이다",
      "데이터베이스와 데이터 마이닝은 완전히 동일한 개념이다",
      "데이터 마이닝은 데이터를 저장하는 하드웨어 장치를 의미한다",
      "데이터베이스가 없어도 데이터 마이닝은 항상 가능하다",
    ],
    answer: 0,
    explanation:
      "데이터베이스는 데이터를 체계적으로 저장하고 관리하는 시스템이며, 데이터 마이닝은 이러한 데이터(또는 데이터 웨어하우스 등)로부터 통계적・수학적 기법을 활용해 유용한 패턴과 지식을 찾아내는 활동입니다.",
  },
  {
    id: "di-127",
    subject: "1과목(데이터 이해)",
    question: "2020년 데이터 3법 개정으로 개인정보 보호에 관한 감독 기구가 어떻게 재편되었는가?",
    options: [
      "개인정보보호위원회로 감독 기능이 일원화되었다",
      "감독 기능이 여러 부처로 더욱 세분화・분산되었다",
      "개인정보 감독 기구가 완전히 폐지되었다",
      "감독 권한이 민간 기업으로 완전히 이양되었다",
    ],
    answer: 0,
    explanation:
      "데이터 3법 개정을 통해 그동안 여러 부처에 분산되어 있던 개인정보 보호 감독 기능이 개인정보보호위원회로 일원화되었습니다.",
  },
  {
    id: "di-128",
    subject: "1과목(데이터 이해)",
    question: "빅데이터를 활용한 비즈니스 모델 혁신 유형으로 가장 거리가 먼 것은?",
    options: [
      "기존 프로세스의 효율화 및 최적화",
      "고객 데이터 분석을 통한 신규 서비스 발견",
      "데이터 기반의 새로운 수익 모델 창출",
      "데이터 분석 결과를 무시한 채 관행대로 의사결정",
    ],
    answer: 3,
    explanation:
      "빅데이터 기반 비즈니스 모델 혁신에는 프로세스 효율화, 신규 서비스 발견, 새로운 수익 모델 창출 등이 있습니다. 분석 결과를 무시하고 관행대로 의사결정하는 것은 빅데이터 활용과 반대되는 사례입니다.",
  },
  {
    id: "di-129",
    subject: "1과목(데이터 이해)",
    question: "데이터 산업의 일반적인 가치사슬(Value Chain) 단계를 순서대로 나열한 것은?",
    options: [
      "데이터 생성 → 수집 → 저장・처리 → 분석 → 활용・서비스",
      "분석 → 활용・서비스 → 데이터 생성 → 수집 → 저장・처리",
      "활용・서비스 → 저장・처리 → 분석 → 데이터 생성 → 수집",
      "저장・처리 → 데이터 생성 → 수집 → 활용・서비스 → 분석",
    ],
    answer: 0,
    explanation:
      "데이터 산업의 가치사슬은 일반적으로 데이터가 생성되고, 이를 수집하여 저장・처리한 뒤, 분석을 거쳐 최종적으로 서비스나 의사결정에 활용되는 흐름으로 이어집니다.",
  },
  {
    id: "di-130",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시대 데이터 사이언티스트에게 요구되는 역량 중 '비판적 사고(Critical Thinking)'가 필요한 이유로 가장 적절한 것은?",
    options: [
      "분석 결과를 무비판적으로 그대로 신뢰하고 보고하기 위해서이다",
      "데이터와 분석 결과의 이면에 숨겨진 가정과 한계를 파악하여 올바른 통찰을 도출하기 위해서이다",
      "통계 프로그램의 사용법을 암기하기 위해서이다",
      "고객의 요구사항을 무조건 수용하기 위해서이다",
    ],
    answer: 1,
    explanation:
      "비판적 사고는 데이터의 수집 과정, 분석 방법, 결과 해석에 내재된 가정과 한계를 점검하여, 잘못된 결론에 이르지 않고 타당한 통찰을 도출하기 위해 데이터 사이언티스트에게 요구되는 핵심 역량입니다.",
  },
  {
    id: "di-131",
    subject: "1과목(데이터 이해)",
    question: "데이터 품질 관리 차원 중, 반드시 필요한 데이터 항목이 누락되지 않고 존재하는 정도를 의미하는 것은?",
    options: ["완전성(Completeness)", "정확성(Accuracy)", "일관성(Consistency)", "유일성(Uniqueness)"],
    answer: 0,
    explanation:
      "완전성(Completeness)은 반드시 필요한 데이터 항목이 누락 없이 존재하는 정도를 의미하는 데이터 품질 차원입니다.",
  },
  {
    id: "di-132",
    subject: "1과목(데이터 이해)",
    question: "데이터 품질 차원 중, 데이터가 실제 값과 얼마나 일치하는지를 나타내는 것은?",
    options: ["정확성(Accuracy)", "적시성(Timeliness)", "유효성(Validity)", "유일성(Uniqueness)"],
    answer: 0,
    explanation:
      "정확성(Accuracy)은 저장된 데이터 값이 실제 세계의 참값과 얼마나 일치하는지를 나타내는 데이터 품질 차원입니다.",
  },
  {
    id: "di-133",
    subject: "1과목(데이터 이해)",
    question: "동일한 데이터가 여러 시스템에 저장되어 있을 때, 서로 모순 없이 일치하는 정도를 의미하는 데이터 품질 차원은?",
    options: ["일관성(Consistency)", "완전성(Completeness)", "적시성(Timeliness)", "유효성(Validity)"],
    answer: 0,
    explanation:
      "일관성(Consistency)은 동일한 데이터가 여러 시스템이나 위치에 중복 저장되어 있을 때, 그 값들이 서로 모순되지 않고 일치하는 정도를 의미합니다.",
  },
  {
    id: "di-134",
    subject: "1과목(데이터 이해)",
    question: "데이터 품질 차원 중, 필요한 시점에 데이터를 사용할 수 있는 정도를 의미하는 것은?",
    options: ["적시성(Timeliness)", "정확성(Accuracy)", "유일성(Uniqueness)", "일관성(Consistency)"],
    answer: 0,
    explanation:
      "적시성(Timeliness)은 데이터가 필요한 시점에 지연 없이 사용 가능한 정도를 의미하는 데이터 품질 차원입니다.",
  },
  {
    id: "di-135",
    subject: "1과목(데이터 이해)",
    question: "데이터 품질 차원 중, 동일한 개체에 대한 데이터가 중복 없이 유일하게 존재하는 정도를 의미하는 것은?",
    options: ["유일성(Uniqueness)", "정확성(Accuracy)", "적시성(Timeliness)", "유효성(Validity)"],
    answer: 0,
    explanation:
      "유일성(Uniqueness)은 동일한 개체에 대한 데이터가 중복되지 않고 유일하게 존재하는 정도를 의미하는 품질 차원입니다.",
  },
  {
    id: "di-136",
    subject: "1과목(데이터 이해)",
    question: "데이터 값이 정의된 형식, 규칙, 도메인 범위를 충족하는 정도를 의미하는 데이터 품질 차원은?",
    options: ["유효성(Validity)", "완전성(Completeness)", "일관성(Consistency)", "적시성(Timeliness)"],
    answer: 0,
    explanation:
      "유효성(Validity)은 데이터가 사전에 정의된 형식, 규칙, 도메인(값의 범위)을 충족하는 정도를 의미합니다.",
  },
  {
    id: "di-137",
    subject: "1과목(데이터 이해)",
    question: "헬스케어 분야에서 빅데이터를 활용하는 사례로 가장 적절한 것은?",
    options: [
      "환자의 진료 기록과 생체 신호 데이터를 분석하여 질병을 조기에 예측한다",
      "모든 환자의 데이터를 분석 없이 그대로 폐기한다",
      "빅데이터를 활용하지 않고 의료진의 직관에만 전적으로 의존한다",
      "환자 데이터를 암호화하지 않고 공개된 웹사이트에 게시한다",
    ],
    answer: 0,
    explanation:
      "헬스케어 분야에서는 전자의무기록(EMR), 웨어러블 기기의 생체 신호 등 다양한 데이터를 분석하여 질병을 조기에 예측하거나 맞춤형 치료를 제공하는 데 빅데이터가 활용됩니다.",
  },
  {
    id: "di-138",
    subject: "1과목(데이터 이해)",
    question: "금융 분야에서 거래 패턴 데이터를 분석하여 비정상적인 거래를 실시간으로 탐지하는 시스템을 무엇이라 하는가?",
    options: ["이상거래탐지시스템(FDS, Fraud Detection System)", "고객관계관리(CRM) 시스템", "전사적자원관리(ERP) 시스템", "공급망관리(SCM) 시스템"],
    answer: 0,
    explanation:
      "FDS(이상거래탐지시스템)는 금융 거래 패턴 데이터를 실시간으로 분석하여 평소와 다른 이상 거래(부정 사용 등)를 탐지하는 빅데이터 활용 사례입니다.",
  },
  {
    id: "di-139",
    subject: "1과목(데이터 이해)",
    question: "제조업에서 설비의 센서 데이터를 분석하여 고장이 발생하기 전에 미리 정비 시점을 예측하는 기법은?",
    options: ["예지보전(Predictive Maintenance)", "사후보전(Breakdown Maintenance)", "정기보전(Preventive Maintenance)", "무보전(No Maintenance)"],
    answer: 0,
    explanation:
      "예지보전은 설비에 부착된 센서 데이터를 실시간으로 분석하여 고장 징후를 사전에 탐지하고, 고장이 발생하기 전에 정비 시점을 예측하는 빅데이터 활용 기법입니다.",
  },
  {
    id: "di-140",
    subject: "1과목(데이터 이해)",
    question: "이커머스(전자상거래)에서 고객의 구매・검색 이력을 분석하여 관심 있을 만한 상품을 제안하는 시스템은?",
    options: ["추천 시스템(Recommender System)", "재고관리 시스템", "결제 게이트웨이", "물류 배송 시스템"],
    answer: 0,
    explanation:
      "추천 시스템은 고객의 구매・검색・클릭 이력 등 빅데이터를 분석하여 개인화된 상품이나 콘텐츠를 제안하는 시스템으로, 이커머스와 미디어 서비스에서 널리 활용됩니다.",
  },
  {
    id: "di-141",
    subject: "1과목(데이터 이해)",
    question: "공공 부문에서 대중교통 이용 데이터를 분석하여 노선을 개편하거나 배차 간격을 조정하는 것은 어떤 활용 사례에 해당하는가?",
    options: [
      "빅데이터를 활용한 공공 정책 수립 및 최적화",
      "개인정보의 불법적인 매매",
      "빅데이터 분석을 완전히 배제한 정책 결정",
      "민간 기업의 영업 비밀 침해",
    ],
    answer: 0,
    explanation:
      "대중교통 이용 데이터, 유동인구 데이터 등을 분석하여 노선 개편, 배차 간격 조정 등 정책을 최적화하는 것은 공공 부문의 대표적인 빅데이터 활용 사례입니다.",
  },
  {
    id: "di-142",
    subject: "1과목(데이터 이해)",
    question: "데이터 사이언스와 통계학의 관계에 대한 설명으로 가장 적절한 것은?",
    options: [
      "통계학은 데이터 사이언스에서 활용되는 핵심 기반 학문 중 하나이다",
      "통계학과 데이터 사이언스는 서로 전혀 관련이 없다",
      "데이터 사이언스는 통계학을 완전히 대체하여 통계학이 필요 없게 되었다",
      "통계학은 정형 데이터만 다루고, 데이터 사이언스는 비정형 데이터만 다룬다",
    ],
    answer: 0,
    explanation:
      "통계학은 데이터로부터 의미 있는 정보를 추출하는 데이터 사이언스의 핵심 기반 학문 중 하나로, 컴퓨터공학, 도메인 지식 등과 결합되어 데이터 사이언스를 구성합니다.",
  },
  {
    id: "di-143",
    subject: "1과목(데이터 이해)",
    question: "여러 회사의 관계형 데이터베이스 제품이 공통적으로 지원하는, SQL 언어에 대한 국제 표준을 제정하는 기구는?",
    options: ["ANSI(American National Standards Institute)", "IEEE", "W3C", "ICANN"],
    answer: 0,
    explanation:
      "ANSI는 SQL 언어에 대한 표준(ANSI SQL)을 제정하는 대표적인 표준화 기구로, 대부분의 관계형 데이터베이스 제품은 이 표준을 기반으로 SQL을 지원합니다.",
  },
  {
    id: "di-144",
    subject: "1과목(데이터 이해)",
    question: "다음 중 대표적인 관계형 데이터베이스 관리시스템(RDBMS) 제품이 아닌 것은?",
    options: ["Oracle", "MySQL", "PostgreSQL", "MongoDB"],
    answer: 3,
    explanation:
      "Oracle, MySQL, PostgreSQL은 대표적인 관계형 데이터베이스(RDBMS) 제품입니다. MongoDB는 문서(Document) 기반의 NoSQL 데이터베이스입니다.",
  },
  {
    id: "di-145",
    subject: "1과목(데이터 이해)",
    question: "NoSQL 데이터베이스 제품과 데이터 모델의 연결로 옳지 않은 것은?",
    options: [
      "Redis - Key-Value 모델",
      "MongoDB - Document 모델",
      "Neo4j - Graph 모델",
      "Oracle - Column-Family 모델",
    ],
    answer: 3,
    explanation:
      "Redis는 Key-Value, MongoDB는 Document, Neo4j는 Graph 모델의 대표적인 NoSQL 제품입니다. Oracle은 NoSQL이 아닌 대표적인 관계형 데이터베이스(RDBMS) 제품입니다.",
  },
  {
    id: "di-146",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 분석 프로젝트에서 '스폰서(Sponsor)'의 역할로 가장 적절한 것은?",
    options: [
      "프로젝트에 필요한 예산과 자원을 지원하고 의사결정 권한을 행사한다",
      "실제 코드를 작성하고 모델을 구현한다",
      "데이터베이스의 물리적 저장 구조를 설계한다",
      "회사의 청소와 시설 관리를 담당한다",
    ],
    answer: 0,
    explanation:
      "스폰서는 분석 프로젝트에 필요한 예산과 자원을 지원하고, 프로젝트의 방향에 대한 주요 의사결정 권한을 가지는 경영진 또는 책임자를 의미합니다.",
  },
  {
    id: "di-147",
    subject: "1과목(데이터 이해)",
    question: "데이터 3법 개정의 근본적인 취지로 가장 적절한 것은?",
    options: [
      "데이터의 활용과 개인정보 보호 사이의 균형을 도모하는 것",
      "데이터의 활용을 전면 금지하는 것",
      "개인정보 보호를 완전히 포기하는 것",
      "빅데이터 산업 자체를 규제하여 위축시키는 것",
    ],
    answer: 0,
    explanation:
      "데이터 3법 개정은 가명정보 개념 도입 등을 통해 데이터의 산업적 활용을 촉진하면서도, 동시에 개인정보 보호 감독 체계를 강화하여 활용과 보호 사이의 균형을 도모하는 데 취지가 있습니다.",
  },
  {
    id: "di-148",
    subject: "1과목(데이터 이해)",
    question: "도시의 다양한 인프라에서 발생하는 데이터를 실시간으로 수집・분석하여 교통, 에너지, 안전 등을 효율적으로 관리하는 도시 모델은?",
    options: ["스마트시티(Smart City)", "레거시시티", "슬럼시티", "그린벨트"],
    answer: 0,
    explanation:
      "스마트시티는 IoT 센서 등을 통해 도시의 교통, 에너지, 안전 등과 관련된 데이터를 실시간으로 수집・분석하여 도시 운영을 효율화하는 모델입니다.",
  },
  {
    id: "di-149",
    subject: "1과목(데이터 이해)",
    question: "빅데이터의 부정적 영향 중 '프라이버시 침해'의 대표적인 사례로 가장 적절한 것은?",
    options: [
      "개인의 동의 없이 수집된 위치 정보를 결합하여 사생활을 추적하는 것",
      "공개된 통계 자료를 활용해 사회 현상을 분석하는 것",
      "익명화된 데이터를 통계 목적으로만 활용하는 것",
      "기업이 자사 제품의 품질 데이터를 분석하는 것",
    ],
    answer: 0,
    explanation:
      "여러 출처의 개인 데이터(특히 위치 정보 등)를 동의 없이 결합해 개인의 사생활을 추적하거나 프로파일링하는 것은 빅데이터로 인한 대표적인 프라이버시 침해 사례입니다.",
  },
  {
    id: "di-150",
    subject: "1과목(데이터 이해)",
    question: "통계 질의 결과에 의도적으로 노이즈(잡음)를 추가하여, 특정 개인의 데이터 포함 여부를 알 수 없게 하면서도 전체 통계적 유용성은 유지하는 프라이버시 보호 기법은?",
    options: ["차분 프라이버시(Differential Privacy)", "k-익명성", "l-다양성", "빅데이터 3V"],
    answer: 0,
    explanation:
      "차분 프라이버시는 통계 질의 결과에 수학적으로 계산된 노이즈를 추가함으로써, 특정 개인의 데이터가 포함되었는지 여부를 알 수 없게 하면서도 전체 데이터셋의 통계적 유용성은 유지하는 프라이버시 보호 기법입니다.",
  },
  {
    id: "di-151",
    subject: "1과목(데이터 이해)",
    question: "개인정보 비식별화 기법 중, 원본 데이터의 일부 문자를 다른 기호(예: *)로 가려서 식별을 어렵게 하는 기법은?",
    options: ["데이터 마스킹(Data Masking)", "데이터 결합(Data Combination)", "데이터 정규화", "데이터 웨어하우징"],
    answer: 0,
    explanation:
      "데이터 마스킹은 주민등록번호나 전화번호의 일부 자리를 '*'와 같은 문자로 가려서 식별 정보를 숨기는 비식별화 기법입니다.",
  },
  {
    id: "di-152",
    subject: "1과목(데이터 이해)",
    question: "개인정보 비식별화 기법 중, 데이터를 평균, 합계 등 통계 값으로 변환하여 개별 값을 알 수 없게 하는 기법은?",
    options: ["총계처리(Aggregation)", "범주화(Generalization)", "데이터 마스킹", "가명처리"],
    answer: 0,
    explanation:
      "총계처리는 개별 데이터를 평균, 합계 등의 통계 값으로 변환하여, 특정 개인의 개별 값을 알 수 없도록 하는 비식별화 기법입니다.",
  },
  {
    id: "di-153",
    subject: "1과목(데이터 이해)",
    question: "개인정보 비식별화 기법 중, 구체적인 값을 더 넓은 범주(예: 나이를 연령대로)로 일반화하는 기법은?",
    options: ["범주화(Generalization)", "총계처리", "데이터 삭제", "가명처리"],
    answer: 0,
    explanation:
      "범주화는 만 나이를 '20대', '30대'와 같이, 또는 상세 주소를 '시/도' 단위로 구체적인 값을 넓은 범주로 일반화하여 식별 가능성을 낮추는 비식별화 기법입니다.",
  },
  {
    id: "di-154",
    subject: "1과목(데이터 이해)",
    question: "개인정보 비식별화 기법 중, 식별 가능성이 있는 값 자체를 완전히 삭제하는 기법은?",
    options: ["데이터 삭제(Suppression)", "범주화", "가명처리", "총계처리"],
    answer: 0,
    explanation:
      "데이터 삭제(Suppression)는 개인 식별에 사용될 수 있는 값이나 컬럼 자체를 삭제하여 원천적으로 식별할 수 없게 만드는 비식별화 기법입니다.",
  },
  {
    id: "di-155",
    subject: "1과목(데이터 이해)",
    question: "동일한 준식별자 값을 가진 레코드가 데이터셋 내에 최소 k개 이상 존재하도록 하여 개인 식별 가능성을 낮추는 비식별화 모델은?",
    options: ["k-익명성(k-anonymity)", "3V 모델", "CAP 정리", "BASE 특성"],
    answer: 0,
    explanation:
      "k-익명성은 나이, 성별, 지역 등 준식별자(Quasi-identifier)의 조합이 동일한 레코드가 데이터셋 내에 최소 k개 이상 존재하도록 하여, 특정 개인을 다른 (k-1)명과 구분할 수 없게 만드는 비식별화 모델입니다.",
  },
  {
    id: "di-156",
    subject: "1과목(데이터 이해)",
    question: "예측 알고리즘이 특정 집단에 불리한 결과를 반복적으로 산출하여 발생하는 빅데이터의 위기요인은?",
    options: ["새로운 유형의 차별", "프라이버시 침해", "저장 공간 부족", "네트워크 속도 저하"],
    answer: 0,
    explanation:
      "예측 알고리즘이 과거 데이터의 편향을 학습하여 특정 집단에 불리한 결과를 반복적으로 산출할 경우, 이는 빅데이터가 초래할 수 있는 '새로운 유형의 차별'이라는 위기요인에 해당합니다.",
  },
  {
    id: "di-157",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스 아키텍처의 일반적인 구성 요소로 가장 거리가 먼 것은?",
    options: ["ETL 프로세스", "데이터 웨어하우스(DW) 저장소", "OLAP 및 데이터 마트", "웹 브라우저의 렌더링 엔진"],
    answer: 3,
    explanation:
      "데이터 웨어하우스 아키텍처는 일반적으로 ETL, 데이터 웨어하우스 저장소, OLAP 엔진, 데이터 마트 등으로 구성됩니다. 웹 브라우저의 렌더링 엔진은 이와 무관한 구성 요소입니다.",
  },
  {
    id: "di-158",
    subject: "1과목(데이터 이해)",
    question: "하나의 팩트 테이블을 중심으로 여러 차원 테이블이 방사형으로 직접 연결된, 단순한 구조의 데이터 웨어하우스 스키마는?",
    options: ["스타 스키마(Star Schema)", "스노우플레이크 스키마(Snowflake Schema)", "정규화 스키마", "네트워크 스키마"],
    answer: 0,
    explanation:
      "스타 스키마는 하나의 중심 팩트 테이블과, 이를 둘러싼 여러 차원 테이블이 별 모양으로 직접 연결된 단순한 구조의 데이터 웨어하우스 스키마입니다.",
  },
  {
    id: "di-159",
    subject: "1과목(데이터 이해)",
    question: "스타 스키마의 차원 테이블을 추가로 정규화하여 세부 테이블로 분할한 형태의 데이터 웨어하우스 스키마는?",
    options: ["스노우플레이크 스키마(Snowflake Schema)", "스타 스키마", "은하 스키마(Galaxy Schema)만 해당", "1차원 스키마"],
    answer: 0,
    explanation:
      "스노우플레이크 스키마는 스타 스키마의 차원 테이블을 정규화하여 여러 개의 세부 테이블로 분할한 구조로, 데이터 중복은 줄지만 조인이 늘어나 조회 복잡도가 증가할 수 있습니다.",
  },
  {
    id: "di-160",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스의 스타 스키마에서, 매출액과 같이 측정 가능한 수치 데이터와 차원 테이블을 참조하는 외래키를 저장하는 테이블은?",
    options: ["팩트 테이블(Fact Table)", "차원 테이블(Dimension Table)", "메타 테이블", "로그 테이블"],
    answer: 0,
    explanation:
      "팩트 테이블은 매출액, 수량 등 분석 대상이 되는 측정 가능한 수치(Measure)와, 각 차원 테이블을 참조하는 외래키를 저장하는 데이터 웨어하우스의 중심 테이블입니다.",
  },
  {
    id: "di-161",
    subject: "1과목(데이터 이해)",
    question: "OLAP 연산 중, 요약된 데이터를 더 상세한 수준으로 세분화하여 살펴보는 연산은?",
    options: ["드릴다운(Drill-down)", "롤업(Roll-up)", "슬라이싱(Slicing)", "피벗(Pivot)"],
    answer: 0,
    explanation:
      "드릴다운(Drill-down)은 요약된 상위 수준의 데이터에서 더 상세하고 구체적인 하위 수준의 데이터로 파고들어 살펴보는 OLAP 연산입니다.",
  },
  {
    id: "di-162",
    subject: "1과목(데이터 이해)",
    question: "OLAP 연산 중, 상세한 데이터를 더 상위 수준으로 요약・집계하는 연산은?",
    options: ["롤업(Roll-up)", "드릴다운(Drill-down)", "다이싱(Dicing)", "피벗(Pivot)"],
    answer: 0,
    explanation:
      "롤업(Roll-up)은 드릴다운과 반대로, 상세한 수준의 데이터를 더 상위 차원(예: 일별 → 월별)으로 요약・집계하는 OLAP 연산입니다.",
  },
  {
    id: "di-163",
    subject: "1과목(데이터 이해)",
    question: "다차원 데이터 큐브에서 특정 차원의 값을 하나로 고정하여 부분 집합을 조회하는 OLAP 연산은?",
    options: ["슬라이싱(Slicing)", "롤업", "드릴다운", "피벗"],
    answer: 0,
    explanation:
      "슬라이싱(Slicing)은 다차원 데이터 큐브에서 하나의 차원 값을 고정시켜 특정 단면(부분 집합)만을 잘라내어 보는 OLAP 연산입니다.",
  },
  {
    id: "di-164",
    subject: "1과목(데이터 이해)",
    question: "다차원 데이터 큐브의 축(차원)을 회전시켜 다른 관점에서 데이터를 재구성해 보는 OLAP 연산은?",
    options: ["피벗(Pivot)", "슬라이싱", "드릴다운", "롤업"],
    answer: 0,
    explanation:
      "피벗(Pivot)은 다차원 데이터 큐브의 축을 회전시켜, 동일한 데이터를 다른 관점(행과 열을 바꾸는 등)에서 재구성하여 보여주는 OLAP 연산입니다.",
  },
  {
    id: "di-165",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시스템을 구축・운영하는 인력 중, 데이터 파이프라인 구축과 인프라 관리에 주로 집중하는 역할은?",
    options: ["데이터 엔지니어(Data Engineer)", "데이터 애널리스트(Data Analyst)", "프로덕트 매니저", "그래픽 디자이너"],
    answer: 0,
    explanation:
      "데이터 엔지니어는 데이터를 수집・저장・처리하는 파이프라인과 인프라를 설계・구축・운영하는 역할을 주로 담당합니다.",
  },
  {
    id: "di-166",
    subject: "1과목(데이터 이해)",
    question: "데이터 애널리스트(Data Analyst)와 데이터 사이언티스트(Data Scientist)의 일반적인 차이로 가장 적절한 것은?",
    options: [
      "데이터 애널리스트는 주로 기존 데이터를 바탕으로 현황 분석과 리포팅에 집중하고, 데이터 사이언티스트는 예측 모델링 등 더 폭넓은 범위를 다루는 경향이 있다",
      "두 역할은 완전히 동일하며 아무런 차이가 없다",
      "데이터 애널리스트만 통계 지식이 필요하다",
      "데이터 사이언티스트는 데이터베이스를 전혀 다루지 않는다",
    ],
    answer: 0,
    explanation:
      "일반적으로 데이터 애널리스트는 기존 데이터를 활용한 현황 분석과 리포팅, 대시보드 구축에 집중하는 경향이 있고, 데이터 사이언티스트는 여기에 더해 예측 모델링, 머신러닝 등 더 폭넓은 분석 범위를 다루는 경향이 있습니다.",
  },
  {
    id: "di-167",
    subject: "1과목(데이터 이해)",
    question: "다음 중 빅데이터 오픈소스 생태계의 도구와 주된 역할을 잘못 짝지은 것은?",
    options: [
      "HDFS - 분산 파일 저장",
      "Kafka - 실시간 메시지 스트리밍",
      "Zookeeper - 분산 코디네이션",
      "Tableau - 분산 파일 저장",
    ],
    answer: 3,
    explanation:
      "HDFS는 분산 파일 저장, Kafka는 실시간 메시지 스트리밍, Zookeeper는 분산 코디네이션을 담당합니다. Tableau는 분산 파일 저장이 아니라 데이터 시각화 도구입니다.",
  },
  {
    id: "di-168",
    subject: "1과목(데이터 이해)",
    question: "클라우드 인프라 환경에 최적화되도록 설계된 데이터 아키텍처 방식을 무엇이라 하는가?",
    options: ["클라우드 네이티브(Cloud Native) 아키텍처", "온프레미스(On-Premise) 아키텍처", "메인프레임 아키텍처", "레거시 아키텍처"],
    answer: 0,
    explanation:
      "클라우드 네이티브 아키텍처는 컨테이너, 마이크로서비스 등 클라우드 환경의 특성을 최대한 활용하도록 설계된 데이터/애플리케이션 아키텍처 방식입니다.",
  },
  {
    id: "di-169",
    subject: "1과목(데이터 이해)",
    question: "데이터를 소스로부터 수집하여 처리, 저장, 목적지로 전달하는 일련의 자동화된 흐름을 무엇이라 하는가?",
    options: ["데이터 파이프라인(Data Pipeline)", "데이터 사전", "데이터 마스킹", "데이터 마이닝"],
    answer: 0,
    explanation:
      "데이터 파이프라인은 데이터가 생성되는 소스로부터 수집, 변환, 저장, 최종 목적지로의 전달까지 이어지는 일련의 자동화된 데이터 처리 흐름을 의미합니다.",
  },
  {
    id: "di-170",
    subject: "1과목(데이터 이해)",
    question: "정해진 주기(예: 하루에 한 번)마다 데이터를 모아서 한꺼번에 처리하는 방식을 무엇이라 하는가?",
    options: ["배치 처리(Batch Processing)", "실시간 처리(Real-time Processing)", "스트림 처리(Stream Processing)", "인메모리 처리"],
    answer: 0,
    explanation:
      "배치 처리는 데이터를 일정 기간 모아두었다가 정해진 주기에 한꺼번에 처리하는 방식으로, 데이터 발생 즉시 처리하는 실시간/스트림 처리와 대비됩니다.",
  },
  {
    id: "di-171",
    subject: "1과목(데이터 이해)",
    question: "데이터가 발생하는 즉시 지연 없이 처리하는 방식과 관련이 없는 기술은?",
    options: ["Spark Streaming", "Kafka Streams", "Apache Storm", "일 배치 스케줄러"],
    answer: 3,
    explanation:
      "Spark Streaming, Kafka Streams, Apache Storm은 데이터를 실시간(스트림)으로 처리하는 대표적인 기술입니다. 일 배치 스케줄러는 정해진 주기로 실행되는 배치 처리 방식과 관련됩니다.",
  },
  {
    id: "di-172",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스 구축 방법론 중, 인먼(Inmon)이 제시한 방식에 대한 설명으로 가장 적절한 것은?",
    options: [
      "전사적 통합 데이터 모델을 먼저 구축한 뒤 이를 기반으로 부서별 데이터 마트를 구성하는 하향식 접근이다",
      "개별 부서의 데이터 마트를 먼저 만든 후 이를 통합하는 상향식 접근이다",
      "데이터 웨어하우스를 아예 구축하지 않는 방법론이다",
      "반드시 NoSQL만을 사용해야 하는 방법론이다",
    ],
    answer: 0,
    explanation:
      "인먼(Inmon)의 방법론은 전사적 관점의 통합된 데이터 웨어하우스를 먼저 구축한 뒤, 이를 기반으로 부서별 데이터 마트를 구성해 나가는 하향식(Top-down) 접근 방식입니다.",
  },
  {
    id: "di-173",
    subject: "1과목(데이터 이해)",
    question: "데이터 웨어하우스 구축 방법론 중, 킴볼(Kimball)이 제시한 방식에 대한 설명으로 가장 적절한 것은?",
    options: [
      "부서별 데이터 마트를 먼저 구축하고 이를 버스 구조로 점진적으로 통합해 나가는 상향식 접근이다",
      "전사적 데이터 모델을 완성한 후에만 데이터 마트를 만들 수 있는 방식이다",
      "OLAP을 전혀 사용하지 않는 방법론이다",
      "반드시 클라우드 환경에서만 적용 가능한 방법론이다",
    ],
    answer: 0,
    explanation:
      "킴볼(Kimball)의 방법론은 개별 부서의 데이터 마트를 먼저 구축하고, 공통 차원(Conformed Dimension)을 통해 이들을 점진적으로 통합해 나가는 상향식(Bottom-up) 접근 방식입니다.",
  },
  {
    id: "di-174",
    subject: "1과목(데이터 이해)",
    question: "데이터 품질에 관한 국제 표준으로, 데이터 품질의 특성과 측정 방법 등을 규정하는 표준은?",
    options: ["ISO 8000", "ISO 9001", "ISO 27001", "ISO 14001"],
    answer: 0,
    explanation:
      "ISO 8000은 데이터 품질(Data Quality)에 관한 국제 표준으로, 데이터 품질의 특성과 관리 방법 등을 규정합니다. ISO 27001은 정보보안, ISO 9001은 품질경영에 관한 표준입니다.",
  },
  {
    id: "di-175",
    subject: "1과목(데이터 이해)",
    question: "개인정보를 활용하는 사업이나 시스템 도입 전에, 그것이 개인정보에 미치는 영향을 사전에 조사・예측・검토하는 절차를 무엇이라 하는가?",
    options: ["개인정보 영향평가(PIA, Privacy Impact Assessment)", "재무제표 감사", "품질 인증 심사", "환경 영향평가"],
    answer: 0,
    explanation:
      "개인정보 영향평가(PIA)는 개인정보를 활용하는 새로운 사업이나 시스템을 도입하기 전에, 그것이 개인정보 보호에 미치는 영향을 사전에 조사・예측・검토하는 절차입니다.",
  },
  {
    id: "di-176",
    subject: "1과목(데이터 이해)",
    question: "정부가 중소기업 등에게 데이터 구매・가공에 필요한 비용을 지원하여 데이터 활용을 촉진하는 사업의 명칭으로 가장 적절한 것은?",
    options: ["데이터바우처 지원사업", "데이터 삭제 지원사업", "개인정보 폐기 지원사업", "네트워크 차단 지원사업"],
    answer: 0,
    explanation:
      "데이터바우처 지원사업은 중소기업, 소상공인 등이 필요한 데이터를 구매하거나 가공하는 데 드는 비용을 정부가 지원하여 데이터 기반 비즈니스를 활성화하기 위한 사업입니다.",
  },
  {
    id: "di-177",
    subject: "1과목(데이터 이해)",
    question: "공공기관이 생성・취득하여 관리하는 데이터를 국민이 자유롭게 활용할 수 있도록 개방하는 것을 무엇이라 하는가?",
    options: ["공공데이터 개방", "공공데이터 폐기", "공공데이터 암호화", "공공데이터 독점"],
    answer: 0,
    explanation:
      "공공데이터 개방은 공공기관이 보유한 데이터를 국민, 기업 등이 자유롭게 접근하고 활용할 수 있도록 공개하는 정책으로, 데이터 기반 혁신과 투명한 행정을 목표로 합니다.",
  },
  {
    id: "di-178",
    subject: "1과목(데이터 이해)",
    question: "누구나 자유롭게 접근, 활용, 재배포할 수 있도록 공개된 데이터를 무엇이라 하는가?",
    options: ["오픈데이터(Open Data)", "다크데이터(Dark Data)", "마스터데이터(Master Data)", "레퍼런스데이터(Reference Data)"],
    answer: 0,
    explanation:
      "오픈데이터는 저작권, 특허 등 다른 통제 수단에 의한 제한 없이 누구나 자유롭게 접근하고 활용, 재배포할 수 있도록 공개된 데이터를 의미합니다.",
  },
  {
    id: "di-179",
    subject: "1과목(데이터 이해)",
    question: "외부 개발자나 기업이 특정 서비스의 데이터나 기능을 자신의 애플리케이션에서 활용할 수 있도록 공개한 인터페이스를 무엇이라 하는가?",
    options: ["오픈 API(Open API)", "폐쇄형 프로토콜", "방화벽", "프록시 서버"],
    answer: 0,
    explanation:
      "오픈 API는 특정 서비스가 제공하는 데이터나 기능을, 외부 개발자가 정해진 규격에 따라 자신의 애플리케이션에서 호출・활용할 수 있도록 공개한 인터페이스입니다.",
  },
  {
    id: "di-180",
    subject: "1과목(데이터 이해)",
    question: "데이터 3법 중 정보통신망법 개정과 관련된 내용으로 가장 적절한 것은?",
    options: [
      "온라인상의 개인정보 보호에 관한 규제를 개인정보보호법 체계로 이관하며 감독 주체를 일원화하였다",
      "인터넷 이용 자체를 전면 금지하였다",
      "모든 온라인 서비스에 실명제를 의무화하였다",
      "온라인 광고를 전면 금지하였다",
    ],
    answer: 0,
    explanation:
      "정보통신망법 개정을 통해 그동안 별도로 규율되던 온라인상의 개인정보 보호에 관한 규정들이 개인정보보호법 체계로 이관되어 감독 주체가 개인정보보호위원회로 일원화되었습니다.",
  },
  {
    id: "di-181",
    subject: "1과목(데이터 이해)",
    question: "조직의 데이터 구조, 흐름, 표준을 전체적인 관점에서 설계하는 역할을 담당하는 전문가는?",
    options: ["데이터 아키텍트(Data Architect)", "웹 디자이너", "네트워크 케이블 설치기사", "고객 상담원"],
    answer: 0,
    explanation:
      "데이터 아키텍트는 조직 전체의 데이터 구조, 흐름, 표준, 저장 방식 등을 설계하여 데이터가 일관되고 효율적으로 관리될 수 있도록 하는 역할을 담당합니다.",
  },
  {
    id: "di-182",
    subject: "1과목(데이터 이해)",
    question: "데이터베이스의 설치, 운영, 백업, 성능 관리, 보안 등을 담당하는 전문가를 무엇이라 하는가?",
    options: ["DBA(DataBase Administrator)", "UX 디자이너", "네트워크 엔지니어", "영업 담당자"],
    answer: 0,
    explanation:
      "DBA(데이터베이스 관리자)는 데이터베이스 시스템의 설치, 운영, 백업, 성능 튜닝, 보안 관리 등 전반적인 관리 업무를 담당하는 전문가입니다.",
  },
  {
    id: "di-183",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시대에 통계학의 역할이 변화한 방향으로 가장 적절한 것은?",
    options: [
      "제한된 표본으로부터의 추론뿐 아니라, 전체 데이터를 직접 다루는 방향으로 그 역할과 활용 범위가 확대되었다",
      "통계학은 빅데이터 시대에 완전히 쓸모 없어졌다",
      "통계학은 오직 소규모 설문조사에만 사용할 수 있게 되었다",
      "통계학적 개념은 빅데이터 분석에서 전혀 활용되지 않는다",
    ],
    answer: 0,
    explanation:
      "빅데이터 시대에는 컴퓨팅 파워의 발전으로 표본이 아닌 전체(모집단) 데이터를 직접 다루는 것이 가능해지면서, 통계학의 역할과 활용 범위가 데이터 사이언스 전반으로 확대되었습니다.",
  },
  {
    id: "di-184",
    subject: "1과목(데이터 이해)",
    question: "사전에 세운 가설을 데이터로 검증하는 데 초점을 맞춘 데이터 분석 접근 방식은?",
    options: ["확증적 데이터 분석(CDA, Confirmatory Data Analysis)", "탐색적 데이터 분석(EDA, Exploratory Data Analysis)", "비지도 학습", "군집 분석"],
    answer: 0,
    explanation:
      "확증적 데이터 분석(CDA)은 분석 이전에 세운 가설이 데이터를 통해 통계적으로 유의하게 뒷받침되는지를 검증하는 데 초점을 맞춘 접근 방식입니다. 이와 달리 탐색적 데이터 분석(EDA)은 데이터를 다양한 각도로 살펴보며 패턴이나 가설 자체를 발견하는 데 중점을 둡니다.",
  },
  {
    id: "di-185",
    subject: "1과목(데이터 이해)",
    question: "데이터 3법 개정 이전, 우리나라 개인정보 관련 법령 체계가 안고 있던 대표적인 문제점으로 지적된 것은?",
    options: [
      "개인정보 보호 관련 법률이 여러 부처에 나뉘어 있어 규제가 중복되고 감독 체계가 비효율적이었다",
      "개인정보 보호에 관한 법률이 전혀 존재하지 않았다",
      "모든 개인정보의 상업적 활용이 이미 완전히 자유로웠다",
      "빅데이터라는 용어 자체가 법적으로 정의되어 있지 않아 아무 문제도 없었다",
    ],
    answer: 0,
    explanation:
      "데이터 3법 개정 이전에는 개인정보보호법, 정보통신망법, 신용정보법 등에 개인정보 관련 규정이 분산되어 있어, 감독 기구가 여러 곳으로 나뉘고 규제가 중복・상충하는 문제가 지적되었습니다.",
  },
  {
    id: "di-186",
    subject: "1과목(데이터 이해)",
    question: "데이터가 한 번 생성된 이후 여러 목적으로 반복해서 재사용될 수 있는 특성을 무엇이라 하는가?",
    options: ["재사용성(Reusability)", "휘발성(Volatility)", "유한성", "소모성"],
    answer: 0,
    explanation:
      "데이터는 물리적 재화와 달리 한 번 사용해도 소멸되지 않고, 다양한 목적과 맥락에서 반복적으로 재사용・재조합될 수 있는 재사용성을 가지며, 이는 빅데이터의 가치를 사전에 산정하기 어려운 이유 중 하나입니다.",
  },
  {
    id: "di-187",
    subject: "1과목(데이터 이해)",
    question: "한 사람이 데이터를 사용해도 다른 사람이 동시에 그 데이터를 사용하는 데 지장이 없는 특성을 무엇이라 하는가?",
    options: ["비경합성(Non-rivalry)", "경합성(Rivalry)", "배제성(Excludability)", "고갈성"],
    answer: 0,
    explanation:
      "데이터는 한 사람이 사용한다고 해서 다른 사람의 사용 가능성이 줄어들지 않는 비경합성(Non-rivalry)을 가지며, 이러한 특성은 물리적 재화와 구분되는 데이터의 경제적 특성 중 하나입니다.",
  },
  {
    id: "di-188",
    subject: "1과목(데이터 이해)",
    question: "여러 원천으로부터 개인정보 등 데이터를 수집・가공하여 제3자에게 판매하는 것을 주된 사업으로 하는 사업자를 무엇이라 하는가?",
    options: ["데이터 브로커(Data Broker)", "데이터 아키텍트", "데이터 사이언티스트", "데이터베이스 관리자"],
    answer: 0,
    explanation:
      "데이터 브로커는 여러 출처에서 수집한 개인정보 등의 데이터를 가공하여 제3자에게 판매하는 것을 주요 사업으로 하는 사업자로, 프라이버시 침해 우려와 관련해 자주 언급됩니다.",
  },
  {
    id: "di-189",
    subject: "1과목(데이터 이해)",
    question: "시스템이나 서비스를 설계하는 초기 단계부터 개인정보 보호 요소를 내재화해야 한다는 원칙을 무엇이라 하는가?",
    options: ["프라이버시 바이 디자인(Privacy by Design)", "애자일(Agile) 개발", "워터폴(Waterfall) 개발", "TDD(Test-Driven Development)"],
    answer: 0,
    explanation:
      "프라이버시 바이 디자인은 시스템이나 서비스를 사후에 보완하는 것이 아니라, 설계 단계부터 개인정보 보호 요소를 기본적으로 내재화해야 한다는 원칙입니다.",
  },
  {
    id: "di-190",
    subject: "1과목(데이터 이해)",
    question: "특정 국가에서 생성된 데이터는 해당 국가의 법과 통제를 따라야 한다는 개념을 무엇이라 하는가?",
    options: ["데이터 주권(Data Sovereignty)", "데이터 웨어하우징", "데이터 마이닝", "데이터 시각화"],
    answer: 0,
    explanation:
      "데이터 주권은 특정 국가 또는 관할권 내에서 생성・저장된 데이터가 그 국가의 법률과 규제, 통제를 따라야 한다는 개념으로, 국가 간 데이터 이전 규제와 관련하여 논의됩니다.",
  },
  {
    id: "di-191",
    subject: "1과목(데이터 이해)",
    question: "유럽연합(EU)이 시행 중인 개인정보보호 규정으로, 정보주체의 권리를 강화하고 역외 기업에도 적용될 수 있는 것은?",
    options: ["GDPR(General Data Protection Regulation)", "CCPA만 해당", "HIPAA", "SOX법"],
    answer: 0,
    explanation:
      "GDPR(일반개인정보보호규정)은 EU가 시행 중인 개인정보보호 법령으로, 정보주체의 권리를 강화하고, EU 시민의 정보를 처리하는 역외(EU 밖) 기업에도 적용될 수 있는 강력한 규제로 알려져 있습니다.",
  },
  {
    id: "di-192",
    subject: "1과목(데이터 이해)",
    question: "정보주체가 자신에 관한 개인정보를 본인 또는 지정한 제3자에게 이전받을 수 있는 권리를 무엇이라 하는가?",
    options: ["개인정보 이동권(Data Portability)", "저작권", "특허권", "상표권"],
    answer: 0,
    explanation:
      "개인정보 이동권은 정보주체가 본인에 관한 개인정보를 체계적이고 통용되는 형식으로 본인 또는 제3자에게 이전받을 수 있는 권리로, 마이데이터 산업의 핵심 근거가 되는 권리입니다.",
  },
  {
    id: "di-193",
    subject: "1과목(데이터 이해)",
    question: "파일 대신 고유 식별자와 메타데이터를 부여한 객체 단위로 데이터를 저장하여, 대용량 비정형 데이터 저장에 적합한 스토리지 방식은?",
    options: ["오브젝트 스토리지(Object Storage)", "블록 스토리지", "테이프 스토리지", "휘발성 캐시"],
    answer: 0,
    explanation:
      "오브젝트 스토리지는 데이터를 파일 시스템의 계층 구조가 아닌, 고유 ID와 메타데이터가 부여된 객체(Object) 단위로 저장하는 방식으로, 대용량의 비정형 데이터를 확장성 있게 저장하는 데 적합합니다.",
  },
  {
    id: "di-194",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 환경에서 데이터 압축 기술을 사용하는 주된 목적은?",
    options: [
      "저장 공간을 절약하고 네트워크 전송 효율을 높이기 위해서이다",
      "데이터의 값을 임의로 변경하기 위해서이다",
      "데이터의 무결성을 훼손하기 위해서이다",
      "데이터를 영구적으로 삭제하기 위해서이다",
    ],
    answer: 0,
    explanation:
      "데이터 압축은 데이터의 크기를 줄여 저장 공간을 절약하고, 네트워크를 통한 전송 시간과 대역폭 사용을 줄이기 위해 사용됩니다.",
  },
  {
    id: "di-195",
    subject: "1과목(데이터 이해)",
    question: "시스템 장애나 재해 발생 시에도 데이터를 안전하게 지키고 서비스를 신속히 복구할 수 있도록 하는 체계를 무엇이라 하는가?",
    options: ["백업 및 재해복구(DR, Disaster Recovery) 체계", "데이터 마이닝 체계", "데이터 시각화 체계", "인덱싱 체계"],
    answer: 0,
    explanation:
      "백업 및 재해복구(DR) 체계는 데이터의 복사본을 안전하게 보관하고, 재해나 장애 발생 시 신속하게 시스템과 데이터를 복구할 수 있도록 마련하는 체계입니다.",
  },
  {
    id: "di-196",
    subject: "1과목(데이터 이해)",
    question: "시스템이 장애 없이 지속적으로 서비스를 제공할 수 있는 능력을 무엇이라 하는가?",
    options: ["고가용성(High Availability)", "저장 효율성", "확장성(Scalability)", "탄력성(Elasticity)"],
    answer: 0,
    explanation:
      "고가용성(HA)은 시스템이 장애나 중단 없이 지속적으로 서비스를 제공할 수 있는 능력을 의미하며, 이중화, 장애 조치(Failover) 등을 통해 확보합니다.",
  },
  {
    id: "di-197",
    subject: "1과목(데이터 이해)",
    question: "여러 대의 서버에 트래픽(작업 부하)을 고르게 분산시켜 특정 서버에 부하가 집중되지 않도록 하는 기술은?",
    options: ["로드 밸런싱(Load Balancing)", "데이터 마스킹", "데이터 정규화", "데이터 클렌징"],
    answer: 0,
    explanation:
      "로드 밸런싱은 여러 대의 서버에 요청(트래픽)을 고르게 분산시켜 특정 서버에 과부하가 걸리지 않도록 하고, 전체 시스템의 가용성과 처리 성능을 높이는 기술입니다.",
  },
  {
    id: "di-198",
    subject: "1과목(데이터 이해)",
    question: "서버, 스토리지, 네트워크 장비 등을 안전하게 운영하기 위해 구축된 전용 시설을 무엇이라 하는가?",
    options: ["데이터센터(Data Center)", "데이터 마트", "데이터 사전", "데이터 카탈로그"],
    answer: 0,
    explanation:
      "데이터센터는 서버, 스토리지, 네트워크 장비 등 IT 인프라를 안전하게 설치하고 운영하기 위해 전력, 냉각, 보안 설비를 갖춘 전용 시설입니다.",
  },
  {
    id: "di-199",
    subject: "1과목(데이터 이해)",
    question: "에너지 효율을 높이고 환경 부담을 최소화하도록 설계된 데이터센터를 무엇이라 하는가?",
    options: ["그린 데이터센터(Green Data Center)", "레거시 데이터센터", "다크 데이터센터", "가상 데이터센터"],
    answer: 0,
    explanation:
      "그린 데이터센터는 냉각 방식 개선, 재생에너지 사용 등을 통해 에너지 효율을 높이고 탄소 배출과 같은 환경 부담을 최소화하도록 설계된 데이터센터입니다.",
  },
  {
    id: "di-200",
    subject: "1과목(데이터 이해)",
    question: "빅데이터 시대의 특성에 대한 설명으로 가장 거리가 먼 것은?",
    options: [
      "정형 데이터뿐 아니라 반정형, 비정형 데이터의 비중이 크게 증가하였다",
      "표본조사보다 전수조사에 가까운 분석이 가능해졌다",
      "데이터의 가치보다 데이터의 저장 매체(하드웨어) 자체가 항상 더 중요하다",
      "데이터를 다양한 목적으로 재사용・재조합하여 새로운 가치를 창출할 수 있다",
    ],
    answer: 2,
    explanation:
      "빅데이터 시대에는 비정형 데이터 비중 증가, 전수조사에 가까운 분석, 데이터의 재사용을 통한 가치 창출이 핵심 특징입니다. 데이터를 담는 하드웨어 자체보다 그 안에 담긴 데이터의 가치와 활용이 더 중요하다는 것이 빅데이터 시대의 관점입니다.",
  },

  // ─── 2과목(데이터 분석 기획) ───────────────────────────────────────────────
  {
    id: "da-001",
    subject: "2과목(데이터 분석 기획)",
    question: "다음 중 지도학습(Supervised Learning)에 해당하는 알고리즘은?",
    options: ["K-Means 클러스터링", "주성분 분석(PCA)", "의사결정나무", "연관규칙 분석"],
    answer: 2,
    explanation:
      "지도학습은 레이블이 있는 데이터를 사용하여 학습하는 방법으로, 의사결정나무, 회귀분석, SVM 등이 해당됩니다. K-Means, PCA, 연관규칙 분석은 비지도학습입니다.",
  },
  {
    id: "da-002",
    subject: "2과목(데이터 분석 기획)",
    question: "회귀분석에서 결정계수(R²)의 범위는?",
    options: ["0 ≤ R² ≤ 1", "-1 ≤ R² ≤ 1", "0 ≤ R² ≤ 100", "-∞ ≤ R² ≤ ∞"],
    answer: 0,
    explanation:
      "결정계수(R²)는 회귀모델이 데이터를 얼마나 잘 설명하는지를 나타내는 지표로, 0에서 1 사이의 값을 가집니다. 1에 가까울수록 모델의 설명력이 높습니다.",
  },
  {
    id: "da-003",
    subject: "2과목(데이터 분석 기획)",
    question: "K-Means 클러스터링 알고리즘에서 K의 의미는?",
    options: [
      "반복 횟수",
      "클러스터(군집)의 수",
      "데이터 포인트의 수",
      "차원의 수",
    ],
    answer: 1,
    explanation:
      "K-Means에서 K는 사전에 지정하는 클러스터(군집)의 수를 의미합니다. 알고리즘은 데이터를 K개의 군집으로 분류합니다.",
  },
  {
    id: "da-004",
    subject: "2과목(데이터 분석 기획)",
    question: "다음 중 과적합(Overfitting)을 방지하는 방법으로 적절하지 않은 것은?",
    options: [
      "정규화(Regularization)",
      "드롭아웃(Dropout)",
      "훈련 데이터 증가",
      "모델 복잡도 증가",
    ],
    answer: 3,
    explanation:
      "과적합 방지 방법에는 정규화, 드롭아웃, 훈련 데이터 증가, 교차검증, 조기종료 등이 있습니다. 모델 복잡도를 증가시키면 오히려 과적합이 심해집니다.",
  },
  {
    id: "da-005",
    subject: "2과목(데이터 분석 기획)",
    question: "혼동행렬(Confusion Matrix)에서 실제 양성을 양성으로 예측한 경우는?",
    options: ["True Positive (TP)", "True Negative (TN)", "False Positive (FP)", "False Negative (FN)"],
    answer: 0,
    explanation:
      "혼동행렬에서 TP(True Positive)는 실제 양성(Positive)을 양성으로 올바르게 예측한 경우입니다. TN은 실제 음성을 음성으로, FP는 실제 음성을 양성으로, FN은 실제 양성을 음성으로 예측한 경우입니다.",
  },
  {
    id: "da-006",
    subject: "2과목(데이터 분석 기획)",
    question: "다음 중 시계열 분석 방법이 아닌 것은?",
    options: ["ARIMA 모델", "지수평활법", "로지스틱 회귀", "이동평균법"],
    answer: 2,
    explanation:
      "시계열 분석 방법에는 ARIMA 모델, 지수평활법, 이동평균법, 분해법 등이 있습니다. 로지스틱 회귀는 분류 문제에 사용되는 방법으로 시계열 분석 방법이 아닙니다.",
  },
  {
    id: "da-007",
    subject: "2과목(데이터 분석 기획)",
    question: "주성분 분석(PCA)의 주요 목적은?",
    options: [
      "데이터 분류",
      "차원 축소",
      "이상치 탐지",
      "연관 규칙 발견",
    ],
    answer: 1,
    explanation:
      "주성분 분석(PCA, Principal Component Analysis)은 고차원 데이터를 저차원으로 변환하는 차원 축소 기법입니다. 데이터의 분산을 최대한 보존하면서 차원을 줄입니다.",
  },
  {
    id: "da-008",
    subject: "2과목(데이터 분석 기획)",
    question: "랜덤 포레스트(Random Forest)에 대한 설명으로 옳은 것은?",
    options: [
      "단일 의사결정나무를 사용한다",
      "여러 의사결정나무를 앙상블한 모델이다",
      "비지도학습 알고리즘이다",
      "회귀 문제에만 사용 가능하다",
    ],
    answer: 1,
    explanation:
      "랜덤 포레스트는 여러 개의 의사결정나무를 앙상블(Ensemble)하여 예측하는 알고리즘입니다. 분류와 회귀 모두에 사용 가능하며 지도학습에 해당합니다.",
  },
  {
    id: "da-009",
    subject: "2과목(데이터 분석 기획)",
    question: "정밀도(Precision)의 계산식으로 올바른 것은?",
    options: [
      "TP / (TP + FN)",
      "TP / (TP + FP)",
      "TN / (TN + FP)",
      "(TP + TN) / (TP + TN + FP + FN)",
    ],
    answer: 1,
    explanation:
      "정밀도(Precision) = TP / (TP + FP)로, 양성으로 예측한 것 중 실제 양성의 비율입니다. 재현율(Recall) = TP / (TP + FN), 정확도(Accuracy) = (TP + TN) / 전체입니다.",
  },
  {
    id: "da-010",
    subject: "2과목(데이터 분석 기획)",
    question: "교차검증(Cross Validation)의 목적으로 가장 적절한 것은?",
    options: [
      "모델의 학습 속도 향상",
      "데이터 전처리 자동화",
      "모델의 일반화 성능 평가",
      "특성 선택 자동화",
    ],
    answer: 2,
    explanation:
      "교차검증은 데이터를 여러 폴드로 나누어 반복 학습/검증함으로써 모델의 일반화 성능을 보다 신뢰성 있게 평가하기 위한 방법입니다.",
  },

  {
    id: "da-011",
    subject: "2과목(데이터 분석 기획)",
    question: "KDD(Knowledge Discovery in Databases) 분석 방법론의 진행 순서로 옳은 것은?",
    options: [
      "데이터셋 선택 → 데이터 전처리 → 데이터 변환 → 데이터 마이닝 → 결과 평가",
      "데이터 마이닝 → 데이터 전처리 → 데이터셋 선택 → 데이터 변환 → 결과 평가",
      "데이터 전처리 → 데이터셋 선택 → 결과 평가 → 데이터 변환 → 데이터 마이닝",
      "데이터 변환 → 데이터셋 선택 → 데이터 마이닝 → 데이터 전처리 → 결과 평가",
    ],
    answer: 0,
    explanation:
      "KDD는 데이터셋 선택(Selection) → 전처리(Preprocessing) → 변환(Transformation) → 데이터 마이닝(Data Mining) → 해석/평가(Interpretation/Evaluation) 순으로 진행됩니다.",
  },
  {
    id: "da-012",
    subject: "2과목(데이터 분석 기획)",
    question: "SAS사가 제시한 SEMMA 방법론의 단계를 순서대로 나열한 것은?",
    options: [
      "추출(Sample) → 탐색(Explore) → 수정(Modify) → 모델링(Model) → 평가(Assess)",
      "탐색(Explore) → 추출(Sample) → 모델링(Model) → 수정(Modify) → 평가(Assess)",
      "평가(Assess) → 추출(Sample) → 탐색(Explore) → 수정(Modify) → 모델링(Model)",
      "수정(Modify) → 탐색(Explore) → 추출(Sample) → 평가(Assess) → 모델링(Model)",
    ],
    answer: 0,
    explanation:
      "SEMMA는 Sample(추출) → Explore(탐색) → Modify(수정) → Model(모델링) → Assess(평가) 순으로 진행되는, SAS사가 제시한 통계 중심 데이터마이닝 방법론입니다.",
  },
  {
    id: "da-013",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론의 5단계 중 분석 과제를 정의하고 수행 계획을 수립하는 단계는?",
    options: ["분석 기획", "데이터 준비", "시스템 구현", "평가 및 전개"],
    answer: 0,
    explanation:
      "빅데이터 분석 방법론은 일반적으로 분석 기획 → 데이터 준비 → 데이터 분석 → 시스템 구현 → 평가 및 전개의 5단계로 구성되며, 분석 기획 단계에서 과제 정의와 수행 계획 수립이 이루어집니다.",
  },
  {
    id: "da-014",
    subject: "2과목(데이터 분석 기획)",
    question:
      "분석 대상(What)과 분석 방법(How)을 아는지 모르는지에 따라 분석 과제 유형을 나눌 때, 분석 대상과 방법을 모두 알고 있는 경우에 해당하는 유형은?",
    options: ["최적화(Optimization)", "솔루션(Solution)", "통찰(Insight)", "발견(Discovery)"],
    answer: 0,
    explanation:
      "분석 대상(What)과 분석 방법(How)을 모두 아는 경우는 '최적화(Optimization)' 유형에 해당합니다. 대상은 모르지만 방법을 아는 경우는 통찰(Insight), 대상은 알지만 방법을 모르는 경우는 솔루션(Solution), 둘 다 모르는 경우는 발견(Discovery) 유형입니다.",
  },
  {
    id: "da-015",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 발굴을 위한 하향식 접근법(Top-Down Approach)의 절차를 순서대로 나열한 것은?",
    options: [
      "문제 탐색 → 문제 정의 → 해결 방안 탐색 → 타당성 검토",
      "문제 정의 → 타당성 검토 → 문제 탐색 → 해결 방안 탐색",
      "해결 방안 탐색 → 문제 탐색 → 타당성 검토 → 문제 정의",
      "타당성 검토 → 해결 방안 탐색 → 문제 정의 → 문제 탐색",
    ],
    answer: 0,
    explanation:
      "하향식 접근법은 문제 탐색(Problem Discovery) → 문제 정의(Problem Definition) → 해결 방안 탐색(Solution Search) → 타당성 검토(Feasibility Study)의 순서로 진행됩니다.",
  },
  {
    id: "da-016",
    subject: "2과목(데이터 분석 기획)",
    question: "상향식 접근법(Bottom-Up Approach)에 대한 설명으로 가장 적절한 것은?",
    options: [
      "문제 정의가 명확하지 않을 때 데이터를 기반으로 문제 자체를 탐색하고 발견해 나가는 방식이다",
      "이미 알고 있는 정답을 향해 하향식으로 문제를 세분화하는 방식이다",
      "반드시 지도학습 알고리즘만을 사용해야 하는 방식이다",
      "경영진의 하향 지시에 따라 과제를 수행하는 방식이다",
    ],
    answer: 0,
    explanation:
      "상향식 접근법은 문제의 정의 자체가 어려운 경우 데이터를 다양한 각도로 탐색・분석하며 새로운 문제를 발견해 나가는 방식으로, 비지도 학습 등과 함께 활용됩니다.",
  },
  {
    id: "da-017",
    subject: "2과목(데이터 분석 기획)",
    question: "디자인 씽킹(Design Thinking) 프로세스의 단계를 순서대로 나열한 것은?",
    options: [
      "공감 → 문제 정의 → 아이디어 도출 → 프로토타입 → 테스트",
      "문제 정의 → 공감 → 테스트 → 아이디어 도출 → 프로토타입",
      "아이디어 도출 → 프로토타입 → 공감 → 문제 정의 → 테스트",
      "테스트 → 프로토타입 → 아이디어 도출 → 문제 정의 → 공감",
    ],
    answer: 0,
    explanation:
      "디자인 씽킹은 공감(Empathize) → 문제 정의(Define) → 아이디어 도출(Ideate) → 프로토타입(Prototype) → 테스트(Test)의 5단계로 이루어지며, 상향식 접근법에서 문제를 탐색하는 데 활용됩니다.",
  },
  {
    id: "da-018",
    subject: "2과목(데이터 분석 기획)",
    question:
      "분석 마스터플랜 수립 시 과제의 우선순위를 결정하는 포트폴리오 사분면 분석에서, 우선순위 설정의 기준으로 가장 먼저 고려해야 하는 요소는?",
    options: ["시급성(전략적 중요도)", "난이도", "담당 부서의 선호도", "개발 도구의 종류"],
    answer: 0,
    explanation:
      "포트폴리오 사분면 분석은 시급성(전략적 중요도)과 난이도를 두 축으로 과제 우선순위를 정하는데, 일반적으로 시급성을 난이도보다 우선적인 판단 기준으로 삼습니다.",
  },
  {
    id: "da-019",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 성숙도 모델의 4단계에 해당하지 않는 것은?",
    options: ["도입 단계", "활용 단계", "확산 단계", "폐기 단계"],
    answer: 3,
    explanation:
      "분석 성숙도 모델은 도입 → 활용 → 확산 → 최적화의 4단계로 구성되며, 비즈니스・조직역량・IT의 3개 부문에서 수준을 진단합니다. '폐기 단계'는 해당하지 않습니다.",
  },
  {
    id: "da-020",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도(Analytics Readiness) 평가 영역에 해당하지 않는 것은?",
    options: ["분석 업무 파악", "분석 데이터", "IT 인프라", "경쟁사 매출 규모"],
    answer: 3,
    explanation:
      "분석 준비도는 분석 업무 파악, 인력 및 조직, 분석 기법, 분석 데이터, 분석 문화, IT 인프라의 6개 영역으로 평가하며, 경쟁사의 매출 규모는 평가 영역에 해당하지 않습니다.",
  },
  {
    id: "da-021",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 과제의 프로젝트 관리 영역에 해당하지 않는 것은?",
    options: ["범위(Scope) 관리", "일정(Time) 관리", "위험(Risk) 관리", "브랜드 이미지 관리"],
    answer: 3,
    explanation:
      "분석 과제의 프로젝트 관리 영역에는 범위, 일정, 예산, 자원, 위험(리스크), 품질, 의사소통 관리 등이 포함되며, '브랜드 이미지 관리'는 해당하지 않습니다.",
  },
  {
    id: "da-022",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 조직 구조 유형 중 전사 분석 업무를 별도의 분석 전담 조직에서 담당하는 형태는?",
    options: [
      "집중형(Consolidated) 구조",
      "기능형(Functional) 구조",
      "분산형(Distributed) 구조",
      "하이브리드(Hybrid) 구조",
    ],
    answer: 0,
    explanation:
      "집중형(Consolidated) 구조는 전사 분석 업무를 별도의 전담 조직에서 담당하여 중복 투자를 방지하고 우선순위를 조정하기 용이하지만, 현업부서와의 소통이 어려울 수 있습니다.",
  },
  {
    id: "da-023",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 기획 시 고려해야 할 사항으로 가장 거리가 먼 것은?",
    options: [
      "분석에 필요한 데이터의 확보 가능 여부",
      "유즈케이스(적용 가능 사례) 탐색",
      "발생 가능한 장애요소에 대한 사전 계획 수립",
      "분석 결과를 활용할 부서의 사무실 위치",
    ],
    answer: 3,
    explanation:
      "분석 과제 기획 시에는 가용 데이터 확보 여부, 유즈케이스 탐색, 장애요소에 대한 사전 계획, 조직의 분석 역량 등을 고려해야 하며, 부서의 물리적 위치는 고려 대상이 아닙니다.",
  },
  {
    id: "da-024",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 로드맵 수립 시 우선순위를 정하는 데 고려하는 요소로 가장 적절하지 않은 것은?",
    options: ["전략적 중요도", "비즈니스 성과 및 ROI", "실행 용이성", "담당자의 입사 연차"],
    answer: 3,
    explanation:
      "로드맵 수립 시에는 전략적 중요도, 비즈니스 성과(ROI), 실행 용이성 등을 종합적으로 고려하여 우선순위를 정하며, 담당자의 입사 연차는 고려 요소가 아닙니다.",
  },
  {
    id: "da-025",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론이 필요한 이유로 가장 적절한 것은?",
    options: [
      "절차, 산출물, 기법 등을 표준화하여 일관된 품질의 분석을 가능하게 하기 위해서이다",
      "데이터 분석가 개인의 직관에만 의존하는 것을 장려하기 위해서이다",
      "분석 과제의 예산을 무조건 최소화하기 위해서이다",
      "데이터 수집을 생략할 수 있게 하기 위해서이다",
    ],
    answer: 0,
    explanation:
      "분석 방법론은 절차, 방법, 도구와 기법, 템플릿과 산출물을 체계화하여 프로젝트를 효율적으로 수행하고 일관된 품질을 확보하기 위해 필요합니다.",
  },
  {
    id: "da-026",
    subject: "2과목(데이터 분석 기획)",
    question: "프로토타이핑(Prototyping) 접근법에 대한 설명으로 옳은 것은?",
    options: [
      "분석 목표를 명확히 규정하기 어려울 때, 프로토타입을 신속히 만들고 결과를 보며 반복적으로 문제를 보완해 나가는 방식이다",
      "반드시 모든 요구사항을 사전에 확정한 뒤에만 사용할 수 있는 방식이다",
      "하향식 접근법에서만 사용되는 절차이다",
      "데이터 수집 없이 이론적 모델링만으로 완료되는 방식이다",
    ],
    answer: 0,
    explanation:
      "프로토타이핑 접근법은 문제를 명확히 정의하기 어려운 상황에서 일단 시제품(프로토타입)을 만들어 검증하고 그 결과를 반영해 점진적으로 개선해 나가는 상향식 접근 방식입니다.",
  },
  {
    id: "da-027",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제를 발굴하여 마스터플랜을 수립하기까지의 일반적인 절차로 가장 적절한 것은?",
    options: [
      "분석 기회 발굴 및 과제 정의 → 과제 우선순위 평가 → 이행 로드맵(마스터플랜) 수립",
      "마스터플랜 수립 → 과제 우선순위 평가 → 분석 기회 발굴",
      "이행 로드맵 수립 → 분석 기회 발굴 → 과제 정의",
      "과제 우선순위 평가 → 마스터플랜 수립 → 분석 기회 발굴 및 정의",
    ],
    answer: 0,
    explanation:
      "일반적으로 분석 기회를 발굴하고 과제를 정의한 뒤, 과제별 우선순위를 평가하고, 이를 바탕으로 이행 순서를 담은 마스터플랜(로드맵)을 수립하는 절차로 진행됩니다.",
  },
  {
    id: "da-028",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 기획자에게 요구되는 역량으로 가장 거리가 먼 것은?",
    options: [
      "해당 비즈니스 도메인에 대한 이해력",
      "분석 기술 및 방법론에 대한 이해",
      "이해관계자를 조율하는 프로젝트 관리 역량",
      "특정 프로그래밍 언어의 문법을 암기하는 능력",
    ],
    answer: 3,
    explanation:
      "분석 기획자에게는 비즈니스 이해력, 분석 기술에 대한 이해, 프로젝트 관리 역량, 관련 인력 간 조율 능력 등 균형 잡힌 역량이 요구되며, 특정 언어 문법의 암기력은 핵심 역량이 아닙니다.",
  },
  {
    id: "da-029",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 정의서(Analytics Problem Definition)에 일반적으로 포함되는 항목으로 가장 거리가 먼 것은?",
    options: [
      "필요한 데이터(소스 데이터) 및 데이터 입수 방법",
      "적용할 분석 방법 및 분석 수행 주기",
      "상세한 예상 분석 결과물",
      "담당자의 개인 취미",
    ],
    answer: 3,
    explanation:
      "과제 정의서에는 소스 데이터, 데이터 입수 방법, 적용 분석 방법, 예상 분석 결과, 분석 수행 주기 등이 포함되며, 담당자 개인 취미와 같은 무관한 정보는 포함되지 않습니다.",
  },
  {
    id: "da-030",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도 평가 영역 중 '분석 문화'가 의미하는 바로 가장 적절한 것은?",
    options: [
      "사실과 데이터에 근거하여 의사결정을 내리는 조직 문화가 정착되어 있는 정도",
      "사무실 인테리어와 복지 제도의 수준",
      "회사의 매출 규모",
      "보유한 서버의 물리적 대수",
    ],
    answer: 0,
    explanation:
      "'분석 문화' 영역은 조직 구성원들이 직관이 아닌 사실과 데이터에 근거하여 의사결정을 내리는 문화가 얼마나 정착되어 있는지를 평가하는 영역입니다.",
  },
  {
    id: "da-031",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 유형 중, 분석의 대상(What)이 무엇인지는 모르지만 기존에 알고 있던 방법(How)을 새로운 대상에 적용하여 인사이트를 도출하는 경우에 해당하는 유형은?",
    options: ["통찰(Insight)", "솔루션(Solution)", "발견(Discovery)", "최적화(Optimization)"],
    answer: 0,
    explanation:
      "분석 대상(What)을 모르지만 분석 방법(How)을 아는 경우는 '통찰(Insight)' 유형에 해당하며, 기존에 알고 있던 분석 방법을 새로운 대상에 적용하여 새로운 통찰을 도출하는 것이 특징입니다.",
  },
  {
    id: "da-032",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 유형 중, 이미 분석 대상은 명확히 정의되어 있지만 이를 해결할 적절한 분석 방법을 알지 못해 이를 찾아 나가야 하는 경우에 해당하는 유형은?",
    options: ["솔루션(Solution)", "통찰(Insight)", "발견(Discovery)", "최적화(Optimization)"],
    answer: 0,
    explanation:
      "분석 대상(What)은 알지만 분석 방법(How)을 모르는 경우는 '솔루션(Solution)' 유형에 해당하며, 이미 정의된 문제를 해결할 새로운 분석 방법을 찾는 것이 핵심입니다.",
  },
  {
    id: "da-033",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 유형 중, 분석 대상과 분석 방법을 모두 알지 못해 데이터 탐색을 통해 새로운 문제 자체를 발굴해야 하는 경우에 해당하는 유형은?",
    options: ["발견(Discovery)", "솔루션(Solution)", "통찰(Insight)", "최적화(Optimization)"],
    answer: 0,
    explanation:
      "분석 대상(What)과 분석 방법(How)을 모두 모르는 경우는 '발견(Discovery)' 유형에 해당하며, 상향식 접근법을 통해 데이터를 탐색하며 문제 자체를 새롭게 발굴해야 합니다.",
  },
  {
    id: "da-034",
    subject: "2과목(데이터 분석 기획)",
    question: "이미 잘 알려진 문제와 해결 방법을 가지고, 기존 방식의 성능이나 효율을 개선하는 데 초점을 맞춘 분석 과제 유형은?",
    options: ["최적화(Optimization)", "발견(Discovery)", "통찰(Insight)", "솔루션(Solution)"],
    answer: 0,
    explanation:
      "분석 대상(What)과 분석 방법(How)을 모두 아는 경우는 '최적화(Optimization)' 유형으로, 기존에 잘 알려진 문제와 방법론을 바탕으로 성능이나 효율을 개선하는 데 초점을 둡니다.",
  },
  {
    id: "da-035",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 우선순위를 정하는 포트폴리오 사분면에서, 시급성이 높고 난이도가 낮아 가장 먼저 추진해야 하는 영역을 흔히 무엇이라 부르는가?",
    options: ["Quick Win(퀵윈) 영역", "장기 검토 영역", "보류 영역", "폐기 영역"],
    answer: 0,
    explanation:
      "시급성이 높고 난이도가 낮은 과제는 적은 노력으로 빠르게 성과를 낼 수 있어 'Quick Win(퀵윈)' 영역으로 분류되며, 우선적으로 추진하는 것이 일반적입니다.",
  },
  {
    id: "da-036",
    subject: "2과목(데이터 분석 기획)",
    question: "포트폴리오 사분면 분석에서 시급성은 높지만 난이도도 높은 과제에 대한 일반적인 접근 방식으로 가장 적절한 것은?",
    options: [
      "전략적 중요도를 고려하여 경영진의 판단 하에 중장기 관점에서 단계적으로 추진한다",
      "난이도가 높으므로 무조건 영구히 폐기한다",
      "시급하므로 실행 계획 없이 곧바로 전사에 적용한다",
      "난이도만 보고 시급성은 전혀 고려하지 않는다",
    ],
    answer: 0,
    explanation:
      "시급성과 난이도가 모두 높은 과제는 전략적 중요도가 큰 경우가 많아, 경영진의 의사결정 하에 단계적・중장기적으로 접근하는 것이 일반적으로 권장됩니다.",
  },
  {
    id: "da-037",
    subject: "2과목(데이터 분석 기획)",
    question: "포트폴리오 사분면 분석에서 시급성과 난이도가 모두 낮은 과제에 대한 일반적인 접근으로 가장 적절한 것은?",
    options: [
      "상대적으로 여유를 가지고 자원이 확보되는 시점에 추진을 검토한다",
      "다른 어떤 과제보다도 최우선으로 즉시 착수한다",
      "절대로 검토하지 않고 영구히 배제한다",
      "가장 많은 예산을 우선 투입한다",
    ],
    answer: 0,
    explanation:
      "시급성과 난이도가 모두 낮은 과제는 급하게 추진할 필요는 없으므로, 상대적으로 여유를 두고 자원이 확보되는 시점에 추진 여부를 검토하는 것이 일반적입니다.",
  },
  {
    id: "da-038",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제의 우선순위를 정할 때, 시급성이 낮지만 난이도가 높은 과제에 대한 설명으로 가장 적절한 것은?",
    options: [
      "일반적으로 우선순위가 상대적으로 낮게 평가되어 후순위로 밀리는 경향이 있다",
      "반드시 다른 모든 과제보다 먼저 수행해야 한다",
      "난이도가 높으므로 오히려 우선순위가 가장 높다",
      "시급성과 무관하게 항상 즉시 실행된다",
    ],
    answer: 0,
    explanation:
      "시급성이 낮으면서 난이도까지 높은 과제는 투입 대비 효과가 낮게 평가되어, 일반적으로 우선순위가 상대적으로 낮게 책정되고 후순위로 미뤄지는 경향이 있습니다.",
  },
  {
    id: "da-039",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 우선순위 평가 시, '시급성'을 '난이도'보다 우선적인 기준으로 삼아야 하는 이유로 가장 적절한 것은?",
    options: [
      "당장 시급하게 해결해야 하는 비즈니스의 문제나 전략적 요구가 존재하는 경우가 많기 때문이다",
      "난이도는 어차피 측정할 수 없는 개념이기 때문이다",
      "시급성은 항상 난이도보다 측정하기 쉽기 때문이다",
      "실제로는 시급성이 전혀 중요하지 않기 때문이다",
    ],
    answer: 0,
    explanation:
      "분석 과제 우선순위 평가에서는 당장 해결해야 할 비즈니스의 시급한 문제나 전략적 요구를 반영하기 위해, 일반적으로 시급성(전략적 중요도)을 난이도보다 먼저 고려하는 것을 권장합니다.",
  },
  {
    id: "da-040",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제의 우선순위를 ROI 관점에서 평가할 때 고려하는 두 가지 요소로 가장 적절한 것은?",
    options: [
      "투자비용 요소(예산, 인력, 기간)와 비즈니스 효과 요소(비용 절감, 매출 증대 등)",
      "담당자의 개인 취향과 사무실 위치",
      "회사의 창립 연도와 로고 디자인",
      "직원 수와 회의실 개수",
    ],
    answer: 0,
    explanation:
      "ROI(투자 대비 효과) 관점의 우선순위 평가는 예산, 인력, 기간 등 투자 비용 요소와, 비용 절감・매출 증대 등 비즈니스 효과 요소를 함께 고려하여 판단합니다.",
  },
  {
    id: "da-041",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 마스터플랜의 이행계획을 수립할 때, 과제의 성격에 따라 적용 우선순위를 조정하기 위해 고려하는 요소로 가장 적절한 것은?",
    options: [
      "업무 내재화 적용 수준(전사 vs 부분 적용)과 분석 데이터 적용 수준",
      "담당자의 출퇴근 거리",
      "회사 창업자의 개인적 취미",
      "사무실 파티션의 색상",
    ],
    answer: 0,
    explanation:
      "이행계획 수립 시에는 분석 결과를 업무에 어느 정도까지 내재화할 것인지(전사 적용 vs 일부 부서 우선 적용), 어떤 수준의 데이터를 우선 적용할지 등을 고려하여 적용 우선순위를 조정합니다.",
  },
  {
    id: "da-042",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 마스터플랜과 정보전략계획(ISP, Information Strategy Planning)의 관계에 대한 설명으로 가장 적절한 것은?",
    options: [
      "분석 마스터플랜은 ISP와 유사한 절차를 거치되, 전사 정보시스템이 아닌 분석 과제에 특화되어 수립된다",
      "분석 마스터플랜과 ISP는 전혀 관련이 없는 별개의 개념이다",
      "ISP는 항상 분석 마스터플랜보다 나중에 수립되어야 한다",
      "분석 마스터플랜은 IT 인프라와는 무관하게 수립된다",
    ],
    answer: 0,
    explanation:
      "분석 마스터플랜은 전사적인 정보시스템 전략을 수립하는 ISP와 유사한 방법론적 절차를 거치되, 분석 과제와 그 실행 로드맵에 특화되어 구체화된다는 점에서 관련이 있습니다.",
  },
  {
    id: "da-043",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 로드맵의 세부 실행 계획에 일반적으로 포함되는 항목으로 가장 거리가 먼 것은?",
    options: [
      "데이터 확보 및 정비 계획",
      "분석 시스템 구축 계획",
      "분석 조직 및 인력 방안",
      "담당자 개인의 휴가 일정",
    ],
    answer: 3,
    explanation:
      "분석 로드맵의 세부 실행 계획에는 데이터 확보 계획, 시스템 구축 계획, 조직 및 인력 방안 등이 포함됩니다. 담당자 개인의 휴가 일정은 이에 해당하지 않습니다.",
  },
  {
    id: "da-044",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론 5단계 중 '데이터 준비' 단계에서 수행하는 활동으로 가장 적절한 것은?",
    options: [
      "필요 데이터 정의, 데이터 저장소 설계, 데이터 수집 및 정합성 검증",
      "최종 모델의 상용 시스템 배포",
      "경영진 대상 프로젝트 최종 성과 보고",
      "분석 과제 자체의 타당성 최초 검토",
    ],
    answer: 0,
    explanation:
      "'데이터 준비' 단계에서는 분석에 필요한 데이터를 정의하고, 데이터를 저장할 저장소를 설계하며, 데이터를 수집하고 정합성을 검증하는 활동을 수행합니다.",
  },
  {
    id: "da-045",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론 5단계 중 '데이터 분석' 단계에서 수행하는 활동으로 가장 적절한 것은?",
    options: [
      "분석용 데이터 준비, 탐색적 데이터 분석, 모델링 및 모델 검증・평가",
      "시스템 설계 및 물리적 구현",
      "시스템 운영 및 유지보수",
      "분석 과제 정의서 최초 작성",
    ],
    answer: 0,
    explanation:
      "'데이터 분석' 단계에서는 분석용 데이터를 준비하고, 탐색적 데이터 분석(EDA)과 모델링을 수행한 뒤, 모델을 검증・평가하는 활동을 진행합니다.",
  },
  {
    id: "da-046",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론 5단계 중 '시스템 구현' 단계에서 수행하는 활동으로 가장 적절한 것은?",
    options: [
      "분석 모델을 실제 운영 환경에 반영하기 위한 설계, 구현 및 시스템 테스트",
      "분석 과제의 최초 발굴 및 타당성 검토",
      "필요 데이터의 최초 정의",
      "탐색적 데이터 분석 수행",
    ],
    answer: 0,
    explanation:
      "'시스템 구현' 단계에서는 검증된 분석 모델을 실제 운영 시스템에 반영하기 위한 설계와 구현, 그리고 시스템 테스트 및 운영 준비 활동을 수행합니다.",
  },
  {
    id: "da-047",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 방법론 5단계 중 '평가 및 전개' 단계에서 수행하는 활동으로 가장 적절한 것은?",
    options: [
      "모델의 향후 발전 계획 수립과 프로젝트 성과에 대한 평가・보고",
      "필요 데이터의 최초 수집",
      "탐색적 데이터 분석의 최초 수행",
      "시스템의 최초 설계",
    ],
    answer: 0,
    explanation:
      "'평가 및 전개' 단계에서는 구축된 모델의 향후 발전 방향에 대한 계획을 수립하고, 프로젝트 전반의 성과를 평가하여 보고하는 활동을 수행합니다.",
  },
  {
    id: "da-048",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 방법론이 일반적으로 갖추어야 할 구성 요소로 가장 거리가 먼 것은?",
    options: [
      "절차(Procedure), 방법(Method), 도구와 기법(Tools & Techniques), 템플릿과 산출물(Templates & Outputs)",
      "담당자 개인의 취미 목록",
      "프로젝트 조직 구성원의 개인 연락처만",
      "사무실 인테리어 설계도",
    ],
    answer: 0,
    explanation:
      "데이터 분석 방법론은 일관된 절차, 방법, 도구와 기법, 그리고 각 단계의 산출물을 담는 템플릿으로 구성됩니다.",
  },
  {
    id: "da-049",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트에서 수행해야 할 작업의 범위를 정의하고 통제하는 영역은?",
    options: ["범위관리(Scope Management)", "일정관리", "원가관리", "품질관리"],
    answer: 0,
    explanation:
      "범위관리는 프로젝트에서 수행해야 할 작업의 범위를 명확히 정의하고, 그 범위가 임의로 확대되거나 축소되지 않도록 통제하는 프로젝트 관리 지식영역입니다.",
  },
  {
    id: "da-050",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트의 각 활동에 필요한 기간을 산정하고 전체 일정을 계획・통제하는 영역은?",
    options: ["일정관리(Time/Schedule Management)", "범위관리", "조달관리", "이해관계자관리"],
    answer: 0,
    explanation:
      "일정관리는 프로젝트를 구성하는 각 활동의 소요 기간을 산정하고, 전체 프로젝트 일정을 계획하고 통제하는 지식영역입니다.",
  },
  {
    id: "da-051",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트 수행에 필요한 예산을 산정하고 통제하는 영역은?",
    options: ["원가관리(Cost Management)", "품질관리", "범위관리", "인적자원관리"],
    answer: 0,
    explanation:
      "원가관리는 프로젝트 수행에 필요한 예산을 산정하고, 실제 지출이 계획된 예산 범위 내에서 이루어지도록 통제하는 지식영역입니다.",
  },
  {
    id: "da-052",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 산출물이 요구되는 품질 기준을 충족하는지 관리하는 영역은?",
    options: ["품질관리(Quality Management)", "일정관리", "조달관리", "통합관리"],
    answer: 0,
    explanation:
      "품질관리는 프로젝트의 산출물과 결과가 사전에 정의된 품질 기준과 요구사항을 충족하는지를 계획, 보증, 통제하는 지식영역입니다.",
  },
  {
    id: "da-053",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트 팀원의 역할과 책임을 정의하고 팀을 구성・관리하는 영역은?",
    options: ["인적자원관리(HR Management)", "리스크관리", "조달관리", "범위관리"],
    answer: 0,
    explanation:
      "인적자원관리는 프로젝트에 필요한 팀원의 역할과 책임을 정의하고, 팀을 구성하고 개발하며 관리하는 지식영역입니다.",
  },
  {
    id: "da-054",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트 정보를 이해관계자에게 적시에 적절하게 전달하는 것을 관리하는 영역은?",
    options: ["의사소통관리(Communication Management)", "품질관리", "원가관리", "조달관리"],
    answer: 0,
    explanation:
      "의사소통관리는 프로젝트와 관련된 정보를 이해관계자들에게 적시에, 적절한 방식으로 생성・수집・배포・관리하는 지식영역입니다.",
  },
  {
    id: "da-055",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트에 영향을 줄 수 있는 불확실한 사건을 식별하고 대응 계획을 수립하는 영역은?",
    options: ["리스크관리(Risk Management)", "범위관리", "품질관리", "인적자원관리"],
    answer: 0,
    explanation:
      "리스크관리는 프로젝트에 긍정적・부정적 영향을 미칠 수 있는 불확실한 사건(위험)을 식별, 분석하고 이에 대한 대응 계획을 수립・실행하는 지식영역입니다.",
  },
  {
    id: "da-056",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 외부 업체로부터 필요한 제품이나 서비스를 구매・계약하는 것을 관리하는 영역은?",
    options: ["조달관리(Procurement Management)", "통합관리", "이해관계자관리", "일정관리"],
    answer: 0,
    explanation:
      "조달관리는 프로젝트 수행에 필요한 제품이나 서비스를 외부 업체로부터 구매하거나 계약하는 과정을 계획하고 관리하는 지식영역입니다.",
  },
  {
    id: "da-057",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 프로젝트에 영향을 미치는 개인이나 조직을 식별하고 그들의 요구와 기대를 관리하는 영역은?",
    options: ["이해관계자관리(Stakeholder Management)", "조달관리", "품질관리", "범위관리"],
    answer: 0,
    explanation:
      "이해관계자관리는 프로젝트에 영향을 주거나 영향을 받는 개인, 그룹, 조직을 식별하고 이들의 요구사항과 기대치를 파악하여 적절히 관리하는 지식영역입니다.",
  },
  {
    id: "da-058",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 기준 프로젝트 관리 지식영역 중, 다른 모든 지식영역의 활동들을 하나로 통합・조정하는 역할을 하는 영역은?",
    options: ["통합관리(Integration Management)", "조달관리", "품질관리", "인적자원관리"],
    answer: 0,
    explanation:
      "통합관리는 프로젝트 헌장 개발부터 종료까지, 다른 모든 지식영역에서 이루어지는 활동들을 하나로 통합하고 조정하는 지식영역으로, 프로젝트 전체를 총괄하는 역할을 합니다.",
  },
  {
    id: "da-059",
    subject: "2과목(데이터 분석 기획)",
    question: "위험 대응 전략 중, 위험이 발생할 원인 자체를 제거하여 위험을 피하는 전략은?",
    options: ["회피(Avoid)", "전이(Transfer)", "완화(Mitigate)", "수용(Accept)"],
    answer: 0,
    explanation:
      "회피(Avoid)는 위험을 유발하는 원인이나 활동 자체를 프로젝트 계획에서 제거하여 위험 발생 가능성을 원천적으로 없애는 대응 전략입니다.",
  },
  {
    id: "da-060",
    subject: "2과목(데이터 분석 기획)",
    question: "위험 대응 전략 중, 보험 가입이나 외주 계약 등을 통해 위험에 대한 책임을 제3자에게 넘기는 전략은?",
    options: ["전이(Transfer)", "회피(Avoid)", "완화(Mitigate)", "수용(Accept)"],
    answer: 0,
    explanation:
      "전이(Transfer)는 위험 발생 시의 재정적 책임이나 영향을 보험, 외주 계약 등을 통해 제3자에게 이전시키는 대응 전략입니다.",
  },
  {
    id: "da-061",
    subject: "2과목(데이터 분석 기획)",
    question: "위험 대응 전략 중, 위험의 발생 확률이나 영향력을 수용 가능한 수준으로 낮추는 전략은?",
    options: ["완화(Mitigate)", "회피(Avoid)", "전이(Transfer)", "수용(Accept)"],
    answer: 0,
    explanation:
      "완화(Mitigate)는 위험을 완전히 제거하지는 못하더라도, 사전 조치를 통해 위험의 발생 확률이나 발생 시의 영향력을 줄이는 대응 전략입니다.",
  },
  {
    id: "da-062",
    subject: "2과목(데이터 분석 기획)",
    question: "위험 대응 전략 중, 위험의 영향이 크지 않다고 판단하여 별다른 조치 없이 위험 발생 시에만 대응하기로 하는 전략은?",
    options: ["수용(Accept)", "회피(Avoid)", "전이(Transfer)", "완화(Mitigate)"],
    answer: 0,
    explanation:
      "수용(Accept)은 위험의 영향력이 크지 않거나 대응 비용이 더 클 것으로 판단될 때, 별도의 사전 조치 없이 위험을 받아들이고 실제 발생 시에만 대응하는 전략입니다.",
  },
  {
    id: "da-063",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도 평가 영역 중 '인력 및 조직' 항목에서 주로 평가하는 내용으로 가장 적절한 것은?",
    options: [
      "분석 전문 인력의 확보 여부와 관련 교육 및 마인드 수준",
      "회사의 매출 규모",
      "사무실의 층수",
      "직원들의 평균 출퇴근 시간",
    ],
    answer: 0,
    explanation:
      "'인력 및 조직' 영역은 분석 기획과 실행을 담당할 전문 인력이 확보되어 있는지, 관련 교육 체계와 데이터 기반 사고 마인드가 갖추어져 있는지를 평가합니다.",
  },
  {
    id: "da-064",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도 평가 영역 중 '분석 기법' 항목에서 주로 평가하는 내용으로 가장 적절한 것은?",
    options: [
      "업무에 적합한 분석 기법과 알고리즘을 보유하고 지속적으로 개선하고 있는지 여부",
      "회사가 보유한 부동산의 가치",
      "직원들의 평균 재직 연수",
      "사무실 내 화분의 개수",
    ],
    answer: 0,
    explanation:
      "'분석 기법' 영역은 업무 영역별로 적합한 분석 기법과 알고리즘을 보유하고 있는지, 그리고 이를 지속적으로 검증하고 개선해 나가고 있는지를 평가합니다.",
  },
  {
    id: "da-065",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 성숙도 모델을 진단하는 3가지 부문으로 가장 적절한 것은?",
    options: [
      "비즈니스 부문, 조직・역량 부문, IT 부문",
      "매출 부문, 인사 부문, 총무 부문",
      "영업 부문, 마케팅 부문, 생산 부문",
      "국내 부문, 해외 부문, 온라인 부문",
    ],
    answer: 0,
    explanation:
      "분석 성숙도 모델은 일반적으로 비즈니스 부문, 조직・역량 부문, IT 부문의 3가지 관점에서 조직의 분석 수준을 진단합니다.",
  },
  {
    id: "da-066",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 성숙도 4단계 중 '도입 단계'에 대한 설명으로 가장 적절한 것은?",
    options: [
      "분석을 시작하여 환경과 시스템을 구축하는 단계",
      "전사적으로 분석 문화가 완전히 정착되어 최적화가 완료된 단계",
      "분석에 대한 관심이 전혀 없는 무관심 단계",
      "분석 조직이 완전히 해체된 단계",
    ],
    answer: 0,
    explanation:
      "'도입 단계'는 조직이 분석을 시작하려는 관심을 가지고, 이를 위한 시스템과 환경을 구축해 나가는 초기 단계입니다.",
  },
  {
    id: "da-067",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 성숙도 4단계 중 '활용 단계'에 대한 설명으로 가장 적절한 것은?",
    options: [
      "구축된 분석 시스템과 기법을 실제 업무 프로세스에 적용하여 사용하는 단계",
      "분석 자체를 전혀 고려하지 않는 단계",
      "이미 모든 분석이 완전히 최적화되어 더 이상 개선할 부분이 없는 단계",
      "회사가 분석 조직을 해체하기로 결정한 단계",
    ],
    answer: 0,
    explanation:
      "'활용 단계'는 도입된 분석 시스템과 기법을 실제 업무 프로세스에 적용하여 분석 결과를 실무에 활용하기 시작하는 단계입니다.",
  },
  {
    id: "da-068",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 성숙도 4단계 중 '확산 단계'에 대한 설명으로 가장 적절한 것은?",
    options: [
      "일부 부서에 국한되었던 분석 활용을 전사적인 범위로 확대해 나가는 단계",
      "분석 프로젝트를 이제 막 검토하기 시작한 단계",
      "분석에 대한 어떠한 투자도 이루어지지 않는 단계",
      "분석 조직의 예산을 전액 삭감한 단계",
    ],
    answer: 0,
    explanation:
      "'확산 단계'는 특정 부서나 영역에 국한되어 있던 분석의 활용 범위를 조직 전체로 넓혀 나가는 단계입니다.",
  },
  {
    id: "da-069",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 성숙도 4단계 중 가장 마지막 단계인 '최적화 단계'에 대한 설명으로 가장 적절한 것은?",
    options: [
      "분석이 조직 문화로 완전히 정착되어 지속적으로 고도화되는 단계",
      "분석을 이제 막 시작하려는 관심 단계",
      "분석 결과를 업무에 전혀 반영하지 않는 단계",
      "분석 조직이 아직 구성되지 않은 단계",
    ],
    answer: 0,
    explanation:
      "'최적화 단계'는 분석이 조직의 문화이자 경쟁력의 핵심으로 완전히 정착되어, 지속적으로 고도화되고 새로운 가치를 창출해 나가는 가장 성숙한 단계입니다.",
  },
  {
    id: "da-070",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도와 분석 성숙도를 함께 진단하여 조직의 현재 상태를 유형화하는 주된 목적으로 가장 적절한 것은?",
    options: [
      "조직에 맞는 적절한 분석 도입・확산 전략을 수립하기 위해서이다",
      "조직을 해체할 명분을 찾기 위해서이다",
      "직원 개개인의 급여를 산정하기 위해서이다",
      "특정 소프트웨어의 라이선스 비용을 절감하기 위해서이다",
    ],
    answer: 0,
    explanation:
      "분석 준비도와 성숙도를 함께 진단하여 조직의 현재 상태를 파악하는 것은, 그 수준에 맞는 적절한 분석 도입 및 확산 전략을 수립하기 위한 목적입니다.",
  },
  {
    id: "da-071",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도와 성숙도가 모두 낮게 진단되어, 분석 환경 조성과 기초 역량 확보가 우선적으로 필요한 조직 유형을 무엇이라 하는가?",
    options: ["준비형", "정착형", "확산형", "도입형"],
    answer: 0,
    explanation:
      "분석 준비도와 성숙도가 모두 낮은 조직은 '준비형'으로 분류되며, 본격적인 분석 도입에 앞서 데이터, 인력, 문화 등 기본적인 분석 환경을 조성하는 것이 우선적으로 필요합니다.",
  },
  {
    id: "da-072",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 준비도와 성숙도가 모두 높게 진단되어, 이미 정착된 분석 역량을 지속적으로 고도화해 나가는 조직 유형을 무엇이라 하는가?",
    options: ["정착형", "준비형", "도입형", "확산형"],
    answer: 0,
    explanation:
      "분석 준비도와 성숙도가 모두 높은 조직은 '정착형'으로 분류되며, 이미 갖춰진 분석 역량과 문화를 바탕으로 지속적인 고도화와 혁신을 추구하는 단계에 있습니다.",
  },
  {
    id: "da-073",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직 구조 유형 중, 별도의 분석 전담 조직 없이 각 현업 부서가 자체적으로 필요한 분석 업무를 수행하는 형태는?",
    options: ["기능형(Functional) 구조", "집중형(Consolidated) 구조", "분산형(Distributed) 구조", "매트릭스 구조"],
    answer: 0,
    explanation:
      "기능형(Functional) 구조는 별도의 전담 분석 조직을 두지 않고, 각 현업 부서가 자체적인 필요에 따라 분석 업무를 수행하는 형태로, 전사적인 우선순위 조정이 어렵다는 단점이 있습니다.",
  },
  {
    id: "da-074",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직 구조 유형 중, 분석 전담 인력을 현업 부서에 배치하면서도 조직 차원의 협업 체계를 함께 운영하는 형태는?",
    options: ["분산형(Distributed) 구조", "기능형 구조", "집중형 구조", "폐쇄형 구조"],
    answer: 0,
    explanation:
      "분산형(Distributed) 구조는 분석 전담 인력을 현업 부서에 배치해 부서의 요구에 신속히 대응하면서도, 조직 차원의 협업 체계를 통해 중복 투자를 조정하려는 형태입니다.",
  },
  {
    id: "da-075",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직을 집중형(Consolidated) 구조로 운영할 때 발생할 수 있는 단점으로 가장 적절한 것은?",
    options: [
      "현업 부서와의 소통이 부족해 실제 업무 요구를 신속히 반영하기 어려울 수 있다",
      "전사적인 우선순위 조정이 전혀 불가능하다",
      "중복 투자가 반드시 발생한다",
      "분석 전담 인력을 아예 둘 수 없다",
    ],
    answer: 0,
    explanation:
      "집중형(Consolidated) 구조는 전사적 우선순위 조정과 중복 투자 방지에는 유리하지만, 분석 조직과 현업 부서 간의 물리적・업무적 거리로 인해 소통이 원활하지 않아 실제 요구사항 반영이 늦어질 수 있다는 단점이 있습니다.",
  },
  {
    id: "da-076",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 거버넌스 체계를 구성하는 요소로 가장 거리가 먼 것은?",
    options: [
      "분석 업무를 위한 원칙과 조직, 프로세스",
      "분석 관련 표준화 및 관리 체계",
      "분석을 수행할 인력과 교육 체계",
      "분석과 무관한 사내 동호회 운영 규정",
    ],
    answer: 3,
    explanation:
      "분석 거버넌스 체계는 원칙, 조직, 프로세스와 함께 표준화, 관리 체계, 인력 및 교육 체계 등으로 구성됩니다. 사내 동호회 운영 규정은 분석 거버넌스와 무관합니다.",
  },
  {
    id: "da-077",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 중 문제 정의 자체가 명확하지 않아 반복적인 시행착오를 통해 점진적으로 결과물을 완성해가야 하는 경우, 상대적으로 더 적합한 프로젝트 관리 방식론은?",
    options: ["애자일(Agile) 방법론", "전통적 폭포수(Waterfall) 방법론", "PERT/CPM 단독 활용", "간트차트만 활용"],
    answer: 0,
    explanation:
      "문제 정의가 명확하지 않고 반복적인 탐색과 개선이 필요한 분석 과제(발견형, 통찰형 등)에는, 짧은 주기로 점진적으로 결과물을 완성해가는 애자일(Agile) 방법론이 상대적으로 더 적합합니다.",
  },
  {
    id: "da-078",
    subject: "2과목(데이터 분석 기획)",
    question: "요구사항과 목표가 처음부터 명확하게 정의되어 있는 분석 과제(예: 최적화형 과제)에 상대적으로 더 적합한 프로젝트 관리 방식은?",
    options: ["순차적인 폭포수(Waterfall) 방식", "짧은 스프린트 단위의 애자일 방식만 사용 가능", "아무 계획 없이 즉흥적으로 진행", "요구사항을 수집하지 않고 바로 구현"],
    answer: 0,
    explanation:
      "요구사항과 목표가 명확한 분석 과제는 계획 → 분석 → 설계 → 구현 → 테스트의 각 단계를 순차적으로 진행하는 폭포수(Waterfall) 방식으로도 효율적으로 관리할 수 있습니다.",
  },
  {
    id: "da-079",
    subject: "2과목(데이터 분석 기획)",
    question: "애자일(Agile) 방법론의 특징으로 가장 적절한 것은?",
    options: [
      "짧은 반복 주기(스프린트)로 점진적으로 결과물을 개발하며 변화에 유연하게 대응한다",
      "모든 요구사항을 프로젝트 착수 시점에 완벽하게 확정한 뒤 착수한다",
      "고객과의 소통 없이 개발자가 독자적으로 결과물을 완성한다",
      "중간 산출물 없이 프로젝트 종료 시점에만 결과물을 제공한다",
    ],
    answer: 0,
    explanation:
      "애자일 방법론은 짧은 반복 주기(스프린트) 동안 일부 기능을 개발・검증하는 과정을 반복하며, 고객과 지속적으로 소통하면서 변화하는 요구사항에 유연하게 대응하는 것이 특징입니다.",
  },
  {
    id: "da-080",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 정의서에 명시하는 '분석 수행 주기'가 의미하는 바로 가장 적절한 것은?",
    options: [
      "해당 분석을 얼마나 자주(예: 매일, 매주, 매월) 반복 수행할 것인지에 대한 기준",
      "담당자가 휴가를 사용하는 주기",
      "회사의 회계연도 결산 주기",
      "서버를 재부팅하는 주기",
    ],
    answer: 0,
    explanation:
      "분석 수행 주기는 해당 분석 과제를 1회성으로 수행할 것인지, 혹은 매일・매주・매월 등 정기적으로 반복 수행할 것인지를 정의하는 항목입니다.",
  },
  {
    id: "da-081",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 방법론을 특정 프로젝트의 상황에 맞게 절차나 산출물을 조정하는 것을 무엇이라 하는가?",
    options: ["방법론의 테일러링(Tailoring)", "방법론의 폐기", "방법론의 표준화", "방법론의 특허 등록"],
    answer: 0,
    explanation:
      "테일러링(Tailoring)은 표준화된 분석 방법론을 프로젝트의 규모, 특성, 조직 성숙도 등에 맞게 절차나 산출물을 적절히 조정하여 적용하는 것을 의미합니다.",
  },
  {
    id: "da-082",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 방법론 테일러링(Tailoring) 시 고려해야 할 요소로 가장 거리가 먼 것은?",
    options: [
      "프로젝트의 규모와 특성, 조직의 분석 성숙도",
      "구성원의 방법론 이해 수준",
      "가용한 데이터의 특성",
      "담당자 개인의 반려동물 유무",
    ],
    answer: 3,
    explanation:
      "방법론 테일러링 시에는 프로젝트 규모와 특성, 조직의 성숙도, 구성원의 방법론 이해도, 데이터 특성 등을 고려합니다. 담당자 개인의 반려동물 유무는 전혀 관련이 없습니다.",
  },
  {
    id: "da-083",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트에서 각 업무에 대한 담당자의 역할(실무 수행, 최종 승인, 자문, 결과 통보)을 명확히 구분하여 정의하는 책임 배정 매트릭스를 무엇이라 하는가?",
    options: ["RACI 매트릭스", "SWOT 매트릭스", "BCG 매트릭스", "간트 차트"],
    answer: 0,
    explanation:
      "RACI 매트릭스는 각 업무에 대해 실무 수행(Responsible), 최종 승인(Accountable), 자문(Consulted), 결과 통보(Informed) 역할을 명확히 구분하여 이해관계자의 책임을 정의하는 도구입니다.",
  },
  {
    id: "da-084",
    subject: "2과목(데이터 분석 기획)",
    question: "RACI 매트릭스에서 특정 업무를 실제로 수행할 책임이 있는 역할을 가리키는 것은?",
    options: ["Responsible(실무 담당자)", "Accountable(최종 승인자)", "Consulted(자문 대상)", "Informed(정보 통보 대상)"],
    answer: 0,
    explanation:
      "RACI에서 Responsible은 해당 업무를 실제로 수행할 책임이 있는 담당자를 의미하며, Accountable은 그 업무의 결과에 대해 최종적으로 책임지고 승인하는 역할을 의미합니다.",
  },
  {
    id: "da-085",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 이해관계자별로 소통 주기, 방식, 보고 체계 등을 사전에 정의해두는 계획을 무엇이라 하는가?",
    options: ["커뮤니케이션 계획(Communication Plan)", "리스크 관리 계획", "품질 관리 계획", "조달 관리 계획"],
    answer: 0,
    explanation:
      "커뮤니케이션 계획은 프로젝트 이해관계자별로 어떤 정보를, 언제, 어떤 방식으로, 누구에게 전달할 것인지에 대한 소통 체계를 사전에 정의해두는 계획입니다.",
  },
  {
    id: "da-086",
    subject: "2과목(데이터 분석 기획)",
    question: "유사한 문제를 이미 해결한 다른 기업이나 산업의 사례를 조사하여 분석 과제의 방향성을 설정하는 데 참고하는 기법은?",
    options: ["벤치마킹(Benchmarking)", "회귀분석", "군집분석", "감성분석"],
    answer: 0,
    explanation:
      "벤치마킹은 유사한 문제를 이미 해결한 타 기업이나 산업의 우수 사례를 조사・분석하여, 자사의 분석 과제 방향성을 설정하는 데 참고하는 기법입니다.",
  },
  {
    id: "da-087",
    subject: "2과목(데이터 분석 기획)",
    question: "여러 평가 기준(전략적 중요도, 실행 용이성, 비즈니스 효과 등)에 가중치를 부여하여 점수화한 뒤 분석 과제의 우선순위를 정하는 방식은?",
    options: ["스코어카드(Scorecard) 방식", "브레인스토밍 방식", "SWOT 분석 방식", "포커스 그룹 인터뷰 방식"],
    answer: 0,
    explanation:
      "스코어카드 방식은 전략적 중요도, 실행 용이성, 비즈니스 효과 등 여러 평가 기준에 각각 가중치를 부여해 점수를 산출하고, 이를 합산하여 과제의 우선순위를 정하는 정량적 평가 방법입니다.",
  },
  {
    id: "da-088",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트의 위험 요소를 식별하기 위해 여러 사람이 자유롭게 아이디어를 제시하는 기법은?",
    options: ["브레인스토밍(Brainstorming)", "회귀분석", "군집분석", "주성분분석"],
    answer: 0,
    explanation:
      "브레인스토밍은 여러 참여자가 자유롭게 아이디어를 제시하며 프로젝트에 잠재된 위험 요소나 새로운 아이디어를 폭넓게 발굴하는 데 활용되는 기법입니다.",
  },
  {
    id: "da-089",
    subject: "2과목(데이터 분석 기획)",
    question: "여러 전문가의 의견을 반복적으로 수집하고 정리하여 합의된 결론에 도달하는 위험 식별・예측 기법은?",
    options: ["델파이 기법(Delphi Technique)", "SWOT 분석", "K-Means 클러스터링", "회귀분석"],
    answer: 0,
    explanation:
      "델파이 기법은 익명의 여러 전문가에게 설문을 반복적으로 실시하고 그 결과를 정리하여 피드백함으로써, 점진적으로 합의된 결론(예측, 위험 요소 등)에 도달하는 기법입니다.",
  },
  {
    id: "da-090",
    subject: "2과목(데이터 분석 기획)",
    question: "새로운 분석 문화 도입에 대한 조직 구성원들의 저항을 극복하기 위한 방안으로 가장 적절한 것은?",
    options: [
      "경영진의 지속적인 관심과 지원, 조기 성공 사례(Quick Win) 공유, 지속적인 교육",
      "구성원들에게 어떠한 설명도 없이 일방적으로 시스템을 강제 도입한다",
      "저항하는 구성원을 즉시 인사 조치한다",
      "분석 관련 교육을 전면 중단한다",
    ],
    answer: 0,
    explanation:
      "조직 문화 저항을 극복하기 위해서는 경영진의 지속적인 관심과 지원(스폰서십), 작은 성공 사례(Quick Win)의 공유를 통한 신뢰 확보, 지속적인 교육과 커뮤니케이션이 효과적인 방안으로 제시됩니다.",
  },
  {
    id: "da-091",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트에서 예산과 자원을 지원하고 주요 의사결정 권한을 가지는 '스폰서'와, 일정・범위・자원을 관리하는 '프로젝트 관리자(PM)'의 역할 구분으로 가장 적절한 것은?",
    options: [
      "스폰서는 예산 지원과 전략적 의사결정을, PM은 일정・범위・자원 등 실행 관리를 담당한다",
      "스폰서와 PM은 항상 동일한 한 사람이 맡아야 한다",
      "PM은 예산을 책정할 권한이 전혀 없어야 하며 스폰서가 모든 실무를 대신한다",
      "스폰서는 프로젝트가 시작된 이후에는 어떠한 역할도 하지 않는다",
    ],
    answer: 0,
    explanation:
      "스폰서는 프로젝트에 필요한 예산과 자원을 지원하고 전략적 의사결정 권한을 가지는 반면, 프로젝트 관리자(PM)는 일정, 범위, 자원 등 프로젝트의 실질적인 실행을 관리하는 역할을 담당합니다.",
  },
  {
    id: "da-092",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK에서 제시하는 5개의 프로세스 그룹을 순서대로 나열한 것은?",
    options: [
      "착수(Initiating) → 계획(Planning) → 실행(Executing) → 감시 및 통제(Monitoring&Controlling) → 종료(Closing)",
      "계획 → 착수 → 종료 → 실행 → 감시 및 통제",
      "실행 → 감시 및 통제 → 착수 → 계획 → 종료",
      "종료 → 실행 → 계획 → 착수 → 감시 및 통제",
    ],
    answer: 0,
    explanation:
      "PMBOK의 5개 프로세스 그룹은 착수(Initiating), 계획(Planning), 실행(Executing), 감시 및 통제(Monitoring & Controlling), 종료(Closing) 순으로 진행되며, 감시 및 통제는 계획・실행 단계와 병행하여 지속적으로 이루어집니다.",
  },
  {
    id: "da-093",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 프로세스 그룹 중, 프로젝트를 공식적으로 승인하고 프로젝트 헌장을 작성하는 단계는?",
    options: ["착수(Initiating)", "계획(Planning)", "실행(Executing)", "종료(Closing)"],
    answer: 0,
    explanation:
      "착수(Initiating) 프로세스 그룹은 프로젝트나 단계를 공식적으로 승인하고 프로젝트 헌장(Project Charter)을 작성하는 단계입니다.",
  },
  {
    id: "da-094",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 프로세스 그룹 중, 프로젝트의 범위, 일정, 원가 등 세부 계획을 수립하는 단계는?",
    options: ["계획(Planning)", "착수(Initiating)", "실행(Executing)", "종료(Closing)"],
    answer: 0,
    explanation:
      "계획(Planning) 프로세스 그룹은 프로젝트의 범위, 일정, 원가, 품질, 리스크 등 프로젝트를 수행하기 위한 세부적인 계획을 수립하는 단계입니다.",
  },
  {
    id: "da-095",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 프로세스 그룹 중, 계획된 작업을 실제로 수행하고 프로젝트 산출물을 만들어내는 단계는?",
    options: ["실행(Executing)", "착수(Initiating)", "종료(Closing)", "계획(Planning)"],
    answer: 0,
    explanation:
      "실행(Executing) 프로세스 그룹은 계획 단계에서 수립한 내용에 따라 실제 작업을 수행하고 프로젝트의 산출물을 만들어내는 단계입니다.",
  },
  {
    id: "da-096",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 프로세스 그룹 중, 프로젝트의 진행 상황을 추적하고 계획 대비 차이를 검토하여 필요한 시정 조치를 취하는 단계는?",
    options: ["감시 및 통제(Monitoring & Controlling)", "착수(Initiating)", "종료(Closing)", "계획(Planning)"],
    answer: 0,
    explanation:
      "감시 및 통제 프로세스 그룹은 프로젝트 진행 상황을 지속적으로 추적하고, 계획 대비 차이가 발생할 경우 이를 파악하여 필요한 시정 조치를 취하는 단계로, 다른 프로세스 그룹과 병행하여 진행됩니다.",
  },
  {
    id: "da-097",
    subject: "2과목(데이터 분석 기획)",
    question: "PMBOK 프로세스 그룹 중, 프로젝트나 단계를 공식적으로 마무리하고 최종 산출물을 인도하는 단계는?",
    options: ["종료(Closing)", "착수(Initiating)", "계획(Planning)", "실행(Executing)"],
    answer: 0,
    explanation:
      "종료(Closing) 프로세스 그룹은 프로젝트나 프로젝트의 한 단계를 공식적으로 마무리하고, 최종 산출물을 이해관계자에게 인도하는 단계입니다.",
  },
  {
    id: "da-098",
    subject: "2과목(데이터 분석 기획)",
    question: "전사적 아키텍처(EA)와 데이터 분석 과제의 관계에 대한 설명으로 가장 적절한 것은?",
    options: [
      "EA가 정의한 전사 데이터 및 시스템 구조를 참고하여 분석 과제를 조직 전체 관점에서 일관성 있게 설계할 수 있다",
      "EA와 분석 과제는 완전히 독립적이어서 서로 전혀 참고할 필요가 없다",
      "EA는 반드시 분석 과제가 모두 끝난 이후에만 수립해야 한다",
      "EA는 오직 하드웨어 조달 계약에만 사용되는 개념이다",
    ],
    answer: 0,
    explanation:
      "전사적 아키텍처(EA)는 조직의 비즈니스, 데이터, 애플리케이션, 기술 구조를 통합적으로 정의하므로, 이를 참고하면 개별 분석 과제를 전사적 관점에서 일관성 있게 설계하는 데 도움이 됩니다.",
  },
  {
    id: "da-099",
    subject: "2과목(데이터 분석 기획)",
    question: "당장 해결이 필요한 단기적인 문제에 대응하기 위해, 마스터플랜보다 개별 과제 해결에 집중하는 분석 기획 접근 방식은?",
    options: ["과제 중심적인(Quick-Win 위주) 접근 방식", "중장기 마스터플랜 기반 접근 방식", "전사 아키텍처 기반 접근 방식", "데이터 거버넌스 우선 접근 방식"],
    answer: 0,
    explanation:
      "당면한 단기적 문제 해결이 시급한 경우에는, 전사적인 마스터플랜 수립보다 개별 과제 자체의 신속한 해결(Quick-Win 방식)에 집중하는 과제 중심적 접근 방식이 활용됩니다.",
  },
  {
    id: "da-100",
    subject: "2과목(데이터 분석 기획)",
    question: "장기적인 관점에서 전사적인 분석 체계를 단계적으로 구축해 나가고자 할 때 적합한 분석 기획 접근 방식은?",
    options: ["중장기 마스터플랜 기반 접근 방식", "단발성 과제 해결 위주의 접근 방식", "즉흥적인 접근 방식", "예산 없는 접근 방식"],
    answer: 0,
    explanation:
      "장기적인 관점에서 전사적인 분석 체계와 역량을 단계적으로 확보해 나가고자 하는 경우에는, 로드맵을 기반으로 한 중장기 마스터플랜 접근 방식이 적합합니다.",
  },
  {
    id: "da-101",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직의 인력을 구성할 때, 통계/분석 전문성과 비즈니스 도메인 지식을 모두 고려해야 하는 이유로 가장 적절한 것은?",
    options: [
      "분석 결과가 실제 비즈니스 문제 해결로 이어지기 위해서는 두 역량이 모두 필요하기 때문이다",
      "비즈니스 지식은 분석 업무에 전혀 필요하지 않기 때문이다",
      "통계 전문성은 분석 업무와 무관하기 때문이다",
      "두 역량 중 하나만 있으면 항상 충분하기 때문이다",
    ],
    answer: 0,
    explanation:
      "분석 결과가 실질적인 비즈니스 가치로 이어지려면, 통계・분석 기법에 대한 전문성뿐 아니라 해당 비즈니스 도메인에 대한 이해가 함께 필요하기 때문에 두 역량을 균형 있게 갖춘 인력 구성이 중요합니다.",
  },
  {
    id: "da-102",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 중 예상치 못한 이슈가 발생했을 때, 이를 기록하고 해결 상태를 추적 관리하는 문서를 무엇이라 하는가?",
    options: ["이슈 관리대장(Issue Log)", "회의록", "명함", "휴가 신청서"],
    answer: 0,
    explanation:
      "이슈 관리대장(Issue Log)은 프로젝트 수행 중 발생한 문제(이슈)를 기록하고, 담당자와 해결 상태를 지속적으로 추적・관리하기 위한 문서입니다.",
  },
  {
    id: "da-103",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 진행 상황과 각 작업의 시작일・종료일을 막대 형태로 시각화하여 나타내는 일정 관리 도구는?",
    options: ["간트 차트(Gantt Chart)", "혼동행렬", "산점도", "덴드로그램"],
    answer: 0,
    explanation:
      "간트 차트는 프로젝트를 구성하는 각 작업의 시작일과 종료일, 진행 상황을 가로 막대 형태로 시각화하여 전체 일정을 한눈에 파악할 수 있게 해주는 대표적인 일정 관리 도구입니다.",
  },
  {
    id: "da-104",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트를 구성하는 작업들 간의 선후 관계를 네트워크로 표현하여, 프로젝트 전체 완료에 가장 큰 영향을 미치는 경로를 찾아내는 기법은?",
    options: ["주경로법(CPM, Critical Path Method)", "간트 차트", "SWOT 분석", "브레인스토밍"],
    answer: 0,
    explanation:
      "주경로법(CPM)은 프로젝트를 구성하는 작업들의 선후 관계를 네트워크로 표현하고, 이 중 프로젝트 전체 완료 기간을 결정짓는 가장 긴 경로(주경로, Critical Path)를 찾아내는 일정 관리 기법입니다.",
  },
  {
    id: "da-105",
    subject: "2과목(데이터 분석 기획)",
    question: "조직의 강점, 약점, 기회, 위협 요인을 분석하여 분석 과제의 전략적 방향을 설정하는 데 활용하는 기법은?",
    options: ["SWOT 분석", "회귀분석", "K-Means 클러스터링", "덴드로그램"],
    answer: 0,
    explanation:
      "SWOT 분석은 조직의 내부 강점(Strength)・약점(Weakness), 외부 기회(Opportunity)・위협(Threat) 요인을 분석하여 전략적 방향을 설정하는 데 활용되는 기법으로, 분석 과제 발굴 시에도 참고할 수 있습니다.",
  },
  {
    id: "da-106",
    subject: "2과목(데이터 분석 기획)",
    question: "SWOT 분석에서 조직 내부의 강점을 활용해 외부의 기회를 포착하는 전략을 무엇이라 하는가?",
    options: ["SO(강점-기회) 전략", "ST(강점-위협) 전략", "WO(약점-기회) 전략", "WT(약점-위협) 전략"],
    answer: 0,
    explanation:
      "SO(강점-기회) 전략은 조직이 보유한 내부 강점을 적극 활용하여 외부 환경의 기회를 포착하고 극대화하는 공격적 전략입니다.",
  },
  {
    id: "da-107",
    subject: "2과목(데이터 분석 기획)",
    question: "SWOT 분석에서 조직 내부의 약점을 보완하면서 외부의 위협에도 대응해야 하는 전략을 무엇이라 하는가?",
    options: ["WT(약점-위협) 전략", "SO(강점-기회) 전략", "ST(강점-위협) 전략", "WO(약점-기회) 전략"],
    answer: 0,
    explanation:
      "WT(약점-위협) 전략은 조직 내부의 약점과 외부의 위협이 동시에 존재하는 가장 어려운 상황에서, 사업의 축소나 철수 등 방어적인 전략을 취하는 것을 의미합니다.",
  },
  {
    id: "da-108",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 중 결과물의 품질을 사전에 정의된 기준과 지속적으로 비교・점검하는 활동을 무엇이라 하는가?",
    options: ["품질 통제(Quality Control)", "위험 회피", "일정 단축", "예산 삭감"],
    answer: 0,
    explanation:
      "품질 통제(Quality Control)는 프로젝트의 산출물이 사전에 정의된 품질 기준을 충족하는지를 지속적으로 점검하고 개선하는 활동입니다.",
  },
  {
    id: "da-109",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트 착수 전, 프로젝트의 목적과 범위, 주요 이해관계자, 최고 관리자의 승인 등을 명시하여 공식적으로 프로젝트를 승인하는 문서는?",
    options: ["프로젝트 헌장(Project Charter)", "이슈 관리대장", "회의록", "명함"],
    answer: 0,
    explanation:
      "프로젝트 헌장은 프로젝트의 목적, 범위, 주요 이해관계자, 프로젝트 관리자의 권한 등을 명시하여, 프로젝트의 존재를 공식적으로 승인하는 최초 문서입니다.",
  },
  {
    id: "da-110",
    subject: "2과목(데이터 분석 기획)",
    question: "빅데이터 분석 과제를 관리할 때, 일반적인 소프트웨어 개발 프로젝트와 비교하여 추가로 더 고려해야 할 특성으로 가장 적절한 것은?",
    options: [
      "대용량 데이터 처리, 비정형 데이터의 다양성, 분석 알고리즘의 반복적 검증과 같은 특성",
      "예산 관리가 전혀 필요하지 않다는 특성",
      "일정 관리가 전혀 필요하지 않다는 특성",
      "이해관계자가 전혀 존재하지 않는다는 특성",
    ],
    answer: 0,
    explanation:
      "빅데이터 분석 과제는 일반 소프트웨어 개발과 달리 대용량・다양한 형태의 데이터를 처리해야 하고, 분석 모델의 성능을 반복적으로 검증・개선해야 하는 특성이 있어 이에 대한 추가적인 관리가 필요합니다.",
  },
  {
    id: "da-111",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 조직이 현업 부서와 협업할 때, 분석 요구사항을 명확히 하기 위해 가장 먼저 수행해야 할 활동으로 가장 적절한 것은?",
    options: [
      "현업의 비즈니스 문제와 목표를 충분히 청취하고 이해하는 활동",
      "곧바로 알고리즘 코드를 작성하는 활동",
      "서버의 물리적 위치를 변경하는 활동",
      "예산을 우선 전액 소진하는 활동",
    ],
    answer: 0,
    explanation:
      "분석 요구사항을 명확히 하기 위해서는 먼저 현업 부서가 실제로 해결하고자 하는 비즈니스 문제와 목표를 충분히 청취하고 이해하는 과정이 선행되어야 합니다.",
  },
  {
    id: "da-112",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 후 결과를 현업에 적용하는 단계에서, 실제 성과를 지속적으로 모니터링해야 하는 이유로 가장 적절한 것은?",
    options: [
      "시간이 지나면서 데이터의 특성이나 비즈니스 환경이 변해 모델의 성능이 저하될 수 있기 때문이다",
      "모니터링은 법적으로 아무 의미가 없기 때문이다",
      "한 번 배포된 모델은 절대 성능이 변하지 않기 때문이다",
      "모니터링을 하면 오히려 모델 성능이 나빠지기 때문이다",
    ],
    answer: 0,
    explanation:
      "시간이 지나면서 데이터의 분포나 비즈니스 환경이 변화하면 기존 모델의 예측 성능이 저하되는 현상(모델 드리프트)이 발생할 수 있으므로, 배포 이후에도 지속적인 성과 모니터링과 재학습이 필요합니다.",
  },
  {
    id: "da-113",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 마스터플랜 수립 시, 향후 데이터 분석 관련 사업을 어떤 순서로 추진할지 정리한 다년간의 계획을 무엇이라 하는가?",
    options: ["이행 로드맵(Implementation Roadmap)", "일일 업무일지", "개인 성과 평가표", "회식 계획표"],
    answer: 0,
    explanation:
      "이행 로드맵은 분석 마스터플랜에서 도출된 여러 과제들을 우선순위에 따라 어떤 순서와 일정으로 추진할지를 정리한 다년간의 실행 계획입니다.",
  },
  {
    id: "da-114",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 프로젝트 수행 시, 분석 결과의 신뢰성을 높이기 위해 결과를 다른 데이터셋이나 방법으로 재검증하는 활동을 무엇이라 하는가?",
    options: ["검증(Validation)", "삭제(Deletion)", "폐기(Disposal)", "은닉(Concealment)"],
    answer: 0,
    explanation:
      "검증(Validation)은 분석 결과나 모델의 신뢰성과 타당성을 확인하기 위해, 별도의 데이터셋이나 다른 방법을 통해 재차 확인하는 활동입니다.",
  },
  {
    id: "da-115",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트에서 최종 산출물이 처음 정의한 요구사항과 목표를 충족하는지 공식적으로 확인받는 절차를 무엇이라 하는가?",
    options: ["검수(Acceptance) 절차", "예산 편성 절차", "채용 절차", "휴가 승인 절차"],
    answer: 0,
    explanation:
      "검수(Acceptance) 절차는 프로젝트의 최종 산출물이 처음에 합의된 요구사항과 품질 기준을 충족하는지를 스폰서 또는 고객이 공식적으로 확인하고 승인하는 절차입니다.",
  },
  {
    id: "da-116",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 계획 수립 시, 일정 지연이나 예산 초과와 같은 문제를 조기에 발견하기 위해 활용하는 관리 기법은?",
    options: ["진척도 관리(Progress Management)", "데이터 마이닝", "인덱싱", "정규화"],
    answer: 0,
    explanation:
      "진척도 관리는 프로젝트의 실제 진행 상황을 계획과 비교하여 일정 지연이나 예산 초과 등의 문제를 조기에 발견하고 대응하기 위한 관리 활동입니다.",
  },
  {
    id: "da-117",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직에 필요한 교육 체계를 설계할 때 고려해야 할 요소로 가장 거리가 먼 것은?",
    options: [
      "구성원의 현재 역량 수준과 필요한 분석 기법",
      "비즈니스 도메인 지식 습득 필요성",
      "지속적인 재교육 및 역량 강화 계획",
      "직원 개인의 혈액형",
    ],
    answer: 3,
    explanation:
      "분석 조직의 교육 체계는 구성원의 현재 역량, 필요 기법, 도메인 지식, 지속적 재교육 계획 등을 고려하여 설계합니다. 직원 개인의 혈액형은 전혀 관련이 없습니다.",
  },
  {
    id: "da-118",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 프로젝트의 예산을 산정할 때 일반적으로 고려하는 항목으로 가장 거리가 먼 것은?",
    options: [
      "인건비, 데이터 확보 비용, 인프라 및 시스템 구축 비용",
      "프로젝트와 무관한 임원의 개인 차량 유지비",
      "외부 컨설팅 및 아웃소싱 비용",
      "소프트웨어 라이선스 비용",
    ],
    answer: 1,
    explanation:
      "프로젝트 예산에는 인건비, 데이터 확보 비용, 인프라・시스템 구축 비용, 외부 컨설팅 비용, 라이선스 비용 등이 포함됩니다. 프로젝트와 무관한 임원의 개인 차량 유지비는 포함되지 않습니다.",
  },
  {
    id: "da-119",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 시, 외부 전문 업체에 일부 업무를 위탁하는 것을 검토할 때 우선적으로 고려해야 할 사항으로 가장 적절한 것은?",
    options: [
      "내부 역량으로 수행하기 어려운 전문 영역인지와 비용 대비 효과",
      "위탁 업체 직원의 개인 취미",
      "위탁 업체의 사무실 인테리어",
      "위탁 업체 대표의 출신 학교",
    ],
    answer: 0,
    explanation:
      "외부 위탁(아웃소싱) 여부를 검토할 때는 내부 역량만으로 수행하기 어려운 전문적인 영역인지, 그리고 위탁했을 때의 비용 대비 효과를 우선적으로 고려해야 합니다.",
  },
  {
    id: "da-120",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 결과를 경영진에게 보고할 때, 기술적인 세부 사항보다 우선적으로 강조해야 할 내용으로 가장 적절한 것은?",
    options: [
      "분석 결과가 비즈니스에 주는 의미와 실행 가능한 시사점(Actionable Insight)",
      "사용한 알고리즘의 수학적 유도 과정 전체",
      "사용한 프로그래밍 언어의 문법 세부 사항",
      "데이터베이스 서버의 하드웨어 사양",
    ],
    answer: 0,
    explanation:
      "경영진 대상 보고에서는 기술적인 세부 구현보다, 분석 결과가 비즈니스에 어떤 의미를 가지며 실제로 실행 가능한 시사점(Actionable Insight)이 무엇인지를 명확하고 이해하기 쉽게 전달하는 것이 우선입니다.",
  },
  {
    id: "da-121",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트가 종료된 후, 프로젝트 진행 과정에서 얻은 교훈과 개선점을 문서화하여 향후 프로젝트에 참고하도록 남기는 것을 무엇이라 하는가?",
    options: ["교훈 사항(Lessons Learned) 정리", "예산 폐기", "인력 즉시 해산", "데이터 영구 삭제"],
    answer: 0,
    explanation:
      "교훈 사항(Lessons Learned) 정리는 프로젝트 종료 후 진행 과정에서 얻은 성공 요인과 실패 요인, 개선점 등을 문서화하여 향후 유사 프로젝트에 참고 자료로 활용하기 위한 활동입니다.",
  },
  {
    id: "da-122",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제의 범위(Scope)가 프로젝트 진행 중 통제 없이 점점 확대되는 현상을 무엇이라 하는가?",
    options: ["스코프 크립(Scope Creep)", "데이터 크롤링", "데이터 마이닝", "데이터 클렌징"],
    answer: 0,
    explanation:
      "스코프 크립(Scope Creep)은 프로젝트 진행 중 공식적인 변경 관리 절차 없이 요구사항이나 범위가 점진적으로 확대되는 현상으로, 일정 지연과 예산 초과의 주요 원인이 됩니다.",
  },
  {
    id: "da-123",
    subject: "2과목(데이터 분석 기획)",
    question: "스코프 크립(Scope Creep)을 예방하기 위한 관리 방안으로 가장 적절한 것은?",
    options: [
      "요구사항 변경 시 공식적인 변경 관리 절차를 거치도록 통제한다",
      "요구사항이 들어올 때마다 검토 없이 무조건 즉시 반영한다",
      "프로젝트 범위를 아예 정의하지 않는다",
      "이해관계자와의 소통을 차단한다",
    ],
    answer: 0,
    explanation:
      "스코프 크립을 예방하기 위해서는 요구사항 변경이 발생할 때마다 영향도를 분석하고 승인 절차를 거치는 공식적인 변경 관리(Change Control) 프로세스를 운영해야 합니다.",
  },
  {
    id: "da-124",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제 수행 초기에 문제 정의가 모호할 경우, 문제를 명확히 하기 위해 활용할 수 있는 접근 방식으로 가장 적절한 것은?",
    options: [
      "이해관계자 인터뷰와 데이터 탐색을 병행하며 점진적으로 문제를 구체화하는 방식",
      "문제 정의 없이 바로 최종 보고서를 작성하는 방식",
      "데이터를 전혀 살펴보지 않고 가설만으로 결론을 내리는 방식",
      "다른 회사의 보고서를 그대로 복사하는 방식",
    ],
    answer: 0,
    explanation:
      "문제 정의가 모호한 경우에는 이해관계자 인터뷰와 데이터 탐색적 분석(EDA)을 병행하며 점진적으로 문제를 구체화해 나가는 접근 방식이 효과적입니다.",
  },
  {
    id: "da-125",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제의 최종 결과물을 현업에 이관할 때, 지속적인 운영을 위해 함께 전달해야 할 산출물로 가장 거리가 먼 것은?",
    options: [
      "운영 매뉴얼과 모델 관리 가이드",
      "담당자 인수인계 문서",
      "모델의 한계와 재학습 주기에 대한 안내",
      "담당자의 개인 신용카드 명세서",
    ],
    answer: 3,
    explanation:
      "현업 이관 시에는 운영 매뉴얼, 인수인계 문서, 모델의 한계와 재학습 주기 안내 등이 함께 전달되어야 지속적인 운영이 가능합니다. 담당자 개인의 신용카드 명세서는 전혀 관련이 없습니다.",
  },
  {
    id: "da-126",
    subject: "2과목(데이터 분석 기획)",
    question: "조직의 소프트웨어 및 프로젝트 관리 프로세스의 성숙도를 여러 단계로 평가하는 모델은?",
    options: ["CMMI(Capability Maturity Model Integration)", "SWOT", "RACI", "PMBOK"],
    answer: 0,
    explanation:
      "CMMI는 조직이 프로젝트와 프로세스를 얼마나 체계적이고 성숙하게 관리하고 있는지를 여러 단계(초기~최적화)로 평가하는 프로세스 성숙도 모델입니다.",
  },
  {
    id: "da-127",
    subject: "2과목(데이터 분석 기획)",
    question: "계약 시점에 프로젝트의 총 대금을 미리 고정하여 체결하는 계약 방식은?",
    options: ["고정가 계약(Fixed-price Contract)", "실비정산 계약(Cost-reimbursable Contract)", "무상 계약", "구두 계약"],
    answer: 0,
    explanation:
      "고정가 계약은 프로젝트 범위와 요구사항이 명확할 때, 계약 시점에 총 대금을 미리 고정하여 체결하는 계약 방식으로, 예산 초과의 위험을 공급자가 주로 부담합니다.",
  },
  {
    id: "da-128",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 수행 과정에서 실제로 발생한 비용에 일정 수수료를 더해 정산하는 계약 방식은?",
    options: ["실비정산 계약(Cost-reimbursable Contract)", "고정가 계약", "성과급 계약만 해당", "무상 계약"],
    answer: 0,
    explanation:
      "실비정산 계약은 프로젝트 수행 중 실제로 발생한 비용에 합의된 수수료나 이윤을 더해 정산하는 방식으로, 요구사항이 불확실하거나 자주 변경될 것으로 예상되는 프로젝트에 활용됩니다.",
  },
  {
    id: "da-129",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 조직의 성과지표(KPI)를 설정할 때 따르는 SMART 원칙에 해당하지 않는 것은?",
    options: [
      "구체적(Specific)이고 측정 가능(Measurable)해야 한다",
      "달성 가능(Achievable)하고 관련성(Relevant)이 있어야 한다",
      "명확한 기한(Time-bound)이 설정되어야 한다",
      "지표는 반드시 담당자 개인의 주관적인 느낌으로만 평가되어야 한다",
    ],
    answer: 3,
    explanation:
      "SMART 원칙은 Specific(구체적), Measurable(측정 가능), Achievable(달성 가능), Relevant(관련성), Time-bound(기한 설정)의 5가지 기준으로 목표를 설정하는 원칙입니다. 주관적인 느낌만으로 평가하는 것은 SMART 원칙에 부합하지 않습니다.",
  },
  {
    id: "da-130",
    subject: "2과목(데이터 분석 기획)",
    question: "SMART 원칙에서 'M'이 의미하는 것은?",
    options: ["Measurable(측정 가능한)", "Manageable(관리 가능한)", "Marketable(시장성 있는)", "Modifiable(수정 가능한)"],
    answer: 0,
    explanation:
      "SMART 원칙에서 M은 Measurable, 즉 목표의 달성 여부를 구체적인 수치나 지표로 측정할 수 있어야 함을 의미합니다.",
  },
  {
    id: "da-131",
    subject: "2과목(데이터 분석 기획)",
    question: "핵심 주제를 중심에 두고 관련 아이디어를 가지로 뻗어나가듯 시각적으로 구조화하여 정리하는 아이디어 발상 기법은?",
    options: ["마인드맵(Mind Map)", "회귀분석", "군집분석", "혼동행렬"],
    answer: 0,
    explanation:
      "마인드맵은 핵심 주제를 중심에 놓고 관련된 아이디어들을 가지 형태로 뻗어나가며 시각적으로 구조화하는 기법으로, 분석 과제 발굴을 위한 아이디어 정리에 활용됩니다.",
  },
  {
    id: "da-132",
    subject: "2과목(데이터 분석 기획)",
    question: "브레인스토밍 등을 통해 도출된 다양한 아이디어를 유사한 성격끼리 그룹화하여 정리하는 기법은?",
    options: ["친화도법(Affinity Diagram)", "회귀분석", "다중공선성 진단", "K-Means 클러스터링"],
    answer: 0,
    explanation:
      "친화도법(Affinity Diagram)은 브레인스토밍 등으로 도출된 많은 아이디어를 유사한 주제나 성격끼리 그룹화하여 구조화하는 기법입니다.",
  },
  {
    id: "da-133",
    subject: "2과목(데이터 분석 기획)",
    question: "고객이 제품이나 서비스를 이용하는 전체 과정에서 겪는 경험과 접점을 단계별로 시각화한 것을 무엇이라 하는가?",
    options: ["고객 여정 지도(Customer Journey Map)", "혼동행렬", "간트 차트", "산점도"],
    answer: 0,
    explanation:
      "고객 여정 지도는 고객이 서비스를 인지하고 이용, 재구매에 이르는 전체 과정에서 겪는 경험과 접점(터치포인트)을 단계별로 시각화한 것으로, 상향식 접근에서 문제를 발견하는 데 활용됩니다.",
  },
  {
    id: "da-134",
    subject: "2과목(데이터 분석 기획)",
    question: "실제 고객 데이터를 바탕으로 가상의 대표 고객 인물상을 구체적으로 설정하여 분석 및 기획에 활용하는 기법은?",
    options: ["페르소나(Persona) 기법", "덴드로그램", "지지도 분석", "인덱싱"],
    answer: 0,
    explanation:
      "페르소나 기법은 실제 고객 데이터를 바탕으로 특정 유형을 대표하는 가상의 인물(이름, 특성, 니즈 등)을 구체적으로 설정하여, 고객 관점의 분석 및 서비스 기획에 활용하는 기법입니다.",
  },
  {
    id: "da-135",
    subject: "2과목(데이터 분석 기획)",
    question: "고객의 핵심 요구를 검증하기 위해 최소한의 기능만을 갖춘 형태로 신속하게 만들어보는 결과물을 무엇이라 하는가?",
    options: ["MVP(Minimum Viable Product)", "완제품(Final Product)", "정규분포", "혼동행렬"],
    answer: 0,
    explanation:
      "MVP(최소 기능 제품)는 고객의 핵심 요구사항을 검증하기 위해 필수적인 최소한의 기능만을 구현한 결과물로, 이를 통해 빠르게 시장의 반응을 확인하고 개선해 나갑니다.",
  },
  {
    id: "da-136",
    subject: "2과목(데이터 분석 기획)",
    question: "폭포수(Waterfall) 개발 모델의 일반적인 단계 순서로 옳은 것은?",
    options: [
      "요구사항 분석 → 설계 → 구현 → 테스트 → 유지보수",
      "테스트 → 구현 → 설계 → 요구사항 분석 → 유지보수",
      "유지보수 → 요구사항 분석 → 설계 → 구현 → 테스트",
      "구현 → 테스트 → 요구사항 분석 → 설계 → 유지보수",
    ],
    answer: 0,
    explanation:
      "폭포수 모델은 요구사항 분석 → 설계 → 구현 → 테스트 → 유지보수의 순서로 각 단계를 순차적으로 진행하며, 이전 단계로 돌아가기 어려운 것이 특징입니다.",
  },
  {
    id: "da-137",
    subject: "2과목(데이터 분석 기획)",
    question: "개발 단계와 테스트 단계를 서로 대응시켜, 각 개발 산출물에 대응하는 테스트를 계획하는 개발 모델은?",
    options: ["V모델", "폭포수 모델", "애자일 모델", "나선형 모델"],
    answer: 0,
    explanation:
      "V모델은 요구사항 분석은 인수 테스트, 설계는 시스템/통합 테스트와 같이 개발 단계와 테스트 단계를 서로 대응시켜, 개발 초기부터 테스트 계획을 함께 수립하는 개발 모델입니다.",
  },
  {
    id: "da-138",
    subject: "2과목(데이터 분석 기획)",
    question: "조직이나 팀이 달성하고자 하는 목표(Objective)와, 그 달성 정도를 측정하는 핵심 결과(Key Result)를 함께 설정하는 목표 관리 기법은?",
    options: ["OKR(Objectives and Key Results)", "SWOT 분석", "RACI 매트릭스", "PERT/CPM"],
    answer: 0,
    explanation:
      "OKR은 조직이 달성하고자 하는 목표(Objective)와, 그 목표의 달성 정도를 정량적으로 측정하는 핵심 결과(Key Result)를 함께 설정하고 추적하는 목표 관리 기법입니다.",
  },
  {
    id: "da-139",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 윤리 원칙 중, 분석의 목적과 데이터 활용 방식을 이해관계자에게 명확히 공개해야 한다는 원칙은?",
    options: ["투명성(Transparency)", "확장성(Scalability)", "이식성(Portability)", "휘발성(Volatility)"],
    answer: 0,
    explanation:
      "투명성(Transparency)은 데이터가 어떤 목적으로 어떻게 수집・활용되는지를 이해관계자(특히 정보주체)에게 명확하게 공개해야 한다는 데이터 분석 윤리 원칙입니다.",
  },
  {
    id: "da-140",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 윤리 원칙 중, 특정 집단에 대한 편향(Bias) 없이 공평한 분석 결과를 도출해야 한다는 원칙은?",
    options: ["공정성(Fairness)", "저장성(Storability)", "휘발성", "탄력성"],
    answer: 0,
    explanation:
      "공정성(Fairness)은 분석 모델이나 알고리즘이 특정 집단에 불리하게 작용하는 편향(Bias) 없이 공평한 결과를 산출해야 한다는 데이터 분석 윤리 원칙입니다.",
  },
  {
    id: "da-141",
    subject: "2과목(데이터 분석 기획)",
    question: "학습 데이터에 내재된 편향이 모델의 예측 결과에 반영되어 특정 집단에게 불리한 결과를 초래하는 문제를 무엇이라 하는가?",
    options: ["알고리즘 편향(Algorithmic Bias)", "다중공선성", "과적합", "정규화"],
    answer: 0,
    explanation:
      "알고리즘 편향은 학습에 사용된 데이터 자체에 내재된 편향이 모델에 그대로 학습되어, 특정 집단에게 불리하거나 차별적인 예측 결과를 초래하는 문제를 의미합니다.",
  },
  {
    id: "da-142",
    subject: "2과목(데이터 분석 기획)",
    question: "복잡한 인공지능 모델의 예측 근거를 사람이 이해할 수 있는 형태로 설명하고자 하는 접근을 무엇이라 하는가?",
    options: ["XAI(설명 가능한 인공지능, eXplainable AI)", "블랙박스 모델", "다크데이터", "레거시 시스템"],
    answer: 0,
    explanation:
      "XAI(설명 가능한 인공지능)는 복잡한 모델의 내부 작동 방식이나 예측 근거를, 사람이 이해하고 신뢰할 수 있는 형태로 설명하고자 하는 연구 및 기술 접근입니다.",
  },
  {
    id: "da-143",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 결과를 청중이 공감하고 이해하기 쉽도록 이야기 구조로 전달하는 기법을 무엇이라 하는가?",
    options: ["데이터 스토리텔링(Data Storytelling)", "데이터 마이닝", "데이터 마스킹", "데이터 클렌징"],
    answer: 0,
    explanation:
      "데이터 스토리텔링은 분석 결과를 단순히 수치로 나열하는 것이 아니라, 청중이 공감하고 기억하기 쉬운 이야기 구조로 구성하여 전달하는 커뮤니케이션 기법입니다.",
  },
  {
    id: "da-144",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석 기법을 활용하여 사회적으로 의미 있는 사실을 발굴하고 이를 보도 형태로 전달하는 저널리즘의 한 분야는?",
    options: ["데이터 저널리즘(Data Journalism)", "탐사 저널리즘만 해당", "옐로 저널리즘", "가짜 뉴스"],
    answer: 0,
    explanation:
      "데이터 저널리즘은 방대한 데이터를 분석하여 사회적으로 의미 있는 사실이나 패턴을 발굴하고, 이를 기사나 시각화 형태로 대중에게 전달하는 저널리즘의 한 분야입니다.",
  },
  {
    id: "da-145",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 산출물(코드, 문서 등)의 버전과 변경 이력을 체계적으로 관리하는 활동을 무엇이라 하는가?",
    options: ["형상관리(Configuration Management)", "인력관리", "예산관리", "회계관리"],
    answer: 0,
    explanation:
      "형상관리는 프로젝트 진행 중 생성되는 코드, 문서 등 산출물의 버전과 변경 이력을 체계적으로 기록하고 관리하여, 일관성을 유지하고 필요시 이전 버전으로 되돌릴 수 있게 하는 활동입니다.",
  },
  {
    id: "da-146",
    subject: "2과목(데이터 분석 기획)",
    question: "여러 개발자가 협업하며 코드의 변경 이력을 추적하고 관리할 수 있게 해주는 대표적인 버전관리 시스템은?",
    options: ["Git", "Excel", "PowerPoint", "메모장"],
    answer: 0,
    explanation:
      "Git은 여러 개발자가 동시에 협업하면서도 코드의 변경 이력을 추적하고, 필요시 이전 버전으로 되돌리거나 여러 작업 흐름(브랜치)을 병합할 수 있게 해주는 대표적인 분산 버전관리 시스템입니다.",
  },
  {
    id: "da-147",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 모델을 정해진 시점(예: 매일 새벽)에 대량의 데이터에 일괄 적용하여 결과를 산출하는 배포 방식은?",
    options: ["배치(Batch) 배포 방식", "실시간 API 배포 방식", "수동 엑셀 입력 방식", "종이 문서 방식"],
    answer: 0,
    explanation:
      "배치 배포 방식은 모델을 정해진 주기(예: 매일 새벽)마다 대량의 데이터에 일괄 적용하여 결과를 산출하는 방식으로, 실시간성이 상대적으로 낮지만 대용량 처리에 효율적입니다.",
  },
  {
    id: "da-148",
    subject: "2과목(데이터 분석 기획)",
    question: "사용자의 요청이 있을 때마다 즉시 모델의 예측 결과를 반환하는 배포 방식은?",
    options: ["실시간 API 배포 방식", "배치 배포 방식", "종이 보고서 방식", "월간 인쇄물 방식"],
    answer: 0,
    explanation:
      "실시간 API 배포 방식은 사용자나 애플리케이션의 요청이 있을 때마다 모델이 즉시 예측 결과를 반환하는 방식으로, 추천 시스템이나 이상거래탐지처럼 즉각적인 응답이 필요한 경우에 사용됩니다.",
  },
  {
    id: "da-149",
    subject: "2과목(데이터 분석 기획)",
    question: "머신러닝 모델의 개발, 배포, 운영, 모니터링을 자동화하고 체계적으로 관리하는 방법론/문화를 무엇이라 하는가?",
    options: ["MLOps", "DevOps만 해당", "SecOps", "NoOps"],
    answer: 0,
    explanation:
      "MLOps는 머신러닝 모델의 개발부터 배포, 운영, 성능 모니터링, 재학습에 이르는 전체 생애주기를 자동화하고 체계적으로 관리하기 위한 방법론이자 조직 문화입니다.",
  },
  {
    id: "da-150",
    subject: "2과목(데이터 분석 기획)",
    question: "운영 중인 예측 모델을 언제 다시 학습(재학습)시킬지 결정할 때 고려하는 기준으로 가장 적절한 것은?",
    options: [
      "모델 성능의 저하 정도와 데이터 분포 변화의 정도",
      "담당자의 개인적인 기분",
      "회사 창립기념일",
      "사무실 이전 여부",
    ],
    answer: 0,
    explanation:
      "모델 재학습 시점은 일반적으로 모델의 예측 성능이 얼마나 저하되었는지, 그리고 실제 데이터의 분포가 학습 당시와 얼마나 달라졌는지(데이터 드리프트)를 모니터링하여 결정합니다.",
  },
  {
    id: "da-151",
    subject: "2과목(데이터 분석 기획)",
    question: "특정 처리(Treatment)가 결과에 미치는 인과적 효과를 검증하기 위해 실험군과 대조군을 구성하여 진행하는 방법론을 무엇이라 하는가?",
    options: ["실험 설계(Design of Experiment)", "데이터 마이닝", "데이터 클렌징", "데이터 웨어하우징"],
    answer: 0,
    explanation:
      "실험 설계는 특정 처리(예: 새로운 UI, 마케팅 문구 등)가 결과에 미치는 인과적 효과를 검증하기 위해, 처리를 적용하는 실험군과 적용하지 않는 대조군을 구성하여 비교하는 방법론입니다.",
  },
  {
    id: "da-152",
    subject: "2과목(데이터 분석 기획)",
    question: "실험 설계에서 처리를 적용하지 않고 비교 기준이 되는 집단을 무엇이라 하는가?",
    options: ["통제집단(Control Group)", "실험집단(Treatment Group)", "표본집단", "모집단"],
    answer: 0,
    explanation:
      "통제집단(대조군)은 실험에서 처리(Treatment)를 적용하지 않고 그대로 두어, 처리를 적용한 실험집단과 비교하기 위한 기준이 되는 집단입니다.",
  },
  {
    id: "da-153",
    subject: "2과목(데이터 분석 기획)",
    question: "새로운 분석 체계나 프로세스를 조직에 도입할 때, 구성원의 수용을 이끌어내기 위한 체계적인 절차를 무엇이라 하는가?",
    options: ["변화관리(Change Management)", "재무제표 작성", "정기 감사", "재고관리"],
    answer: 0,
    explanation:
      "변화관리는 새로운 시스템, 프로세스, 문화를 조직에 도입할 때 발생할 수 있는 구성원의 저항을 최소화하고, 원활한 수용과 정착을 이끌어내기 위한 체계적인 절차와 활동입니다.",
  },
  {
    id: "da-154",
    subject: "2과목(데이터 분석 기획)",
    question: "변화관리 모델 중, 인식(Awareness) → 열망(Desire) → 지식(Knowledge) → 능력(Ability) → 강화(Reinforcement)의 5단계로 구성된 모델은?",
    options: ["ADKAR 모델", "CRISP-DM", "SEMMA", "KDD"],
    answer: 0,
    explanation:
      "ADKAR 모델은 개인 차원의 변화관리를 위해 인식, 열망, 지식, 능력, 강화의 5단계를 제시하는 대표적인 변화관리 모델입니다.",
  },
  {
    id: "da-155",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 과제가 성공적으로 완료된 이후, 그 결과를 별도의 상품이나 서비스로 발전시킬 수 있는지 검토하는 활동을 무엇이라 하는가?",
    options: ["사업화 검토", "예산 폐기", "인력 즉시 해산", "데이터 영구 삭제"],
    answer: 0,
    explanation:
      "사업화 검토는 분석 과제의 성공적인 결과물을 바탕으로, 이를 신규 상품이나 서비스, 또는 다른 사업 영역으로 확장할 수 있는지를 검토하는 활동입니다.",
  },
  {
    id: "da-156",
    subject: "2과목(데이터 분석 기획)",
    question: "시스템의 성능을 높이기 위해 기존 서버 한 대의 사양(CPU, 메모리 등)을 강화하는 인프라 확장 방식은?",
    options: ["스케일업(Scale-up)", "스케일아웃(Scale-out)", "스케일다운", "스케일인"],
    answer: 0,
    explanation:
      "스케일업(Scale-up)은 기존 한 대의 서버의 CPU, 메모리 등 사양 자체를 강화하여 성능을 높이는 수직적 확장 방식입니다.",
  },
  {
    id: "da-157",
    subject: "2과목(데이터 분석 기획)",
    question: "시스템의 처리 용량을 늘리기 위해 서버의 대수를 추가하는 인프라 확장 방식은?",
    options: ["스케일아웃(Scale-out)", "스케일업(Scale-up)", "스케일다운", "스케일인"],
    answer: 0,
    explanation:
      "스케일아웃(Scale-out)은 기존 서버의 사양을 높이는 대신, 여러 대의 서버를 추가하여 부하를 분산시키는 수평적 확장 방식으로, 분산 처리 환경에서 널리 활용됩니다.",
  },
  {
    id: "da-158",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트의 표준 산출물로 일반적으로 포함되지 않는 것은?",
    options: [
      "분석과제 정의서",
      "데이터 정의서 및 모델링 보고서",
      "담당자 개인의 사적인 일기장",
      "최종 보고서",
    ],
    answer: 2,
    explanation:
      "분석 프로젝트의 대표적인 표준 산출물에는 분석과제 정의서, 데이터 정의서, 모델링 보고서, 최종 보고서 등이 있습니다. 담당자 개인의 사적인 일기장은 프로젝트 산출물에 해당하지 않습니다.",
  },
  {
    id: "da-159",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트의 산출물 중 '데이터 정의서'에 일반적으로 포함되는 내용으로 가장 적절한 것은?",
    options: [
      "분석에 사용되는 데이터 항목의 명칭, 정의, 형식, 출처",
      "담당자의 개인 연봉 정보",
      "회사의 주가 정보",
      "경쟁사의 인사 정보",
    ],
    answer: 0,
    explanation:
      "데이터 정의서에는 분석에 사용되는 각 데이터 항목의 명칭, 의미(정의), 데이터 형식, 데이터의 출처 등이 명시되어, 데이터에 대한 공통된 이해를 돕습니다.",
  },
  {
    id: "da-160",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트의 산출물 중 '모델링 보고서'에 일반적으로 포함되는 내용으로 가장 적절한 것은?",
    options: [
      "사용한 분석 기법, 모델의 구조와 파라미터, 검증 결과 및 성능 지표",
      "담당자의 개인 취미 목록",
      "사무실 임대 계약서",
      "직원 복지 제도 안내",
    ],
    answer: 0,
    explanation:
      "모델링 보고서에는 사용된 분석 기법과 알고리즘, 모델의 구조 및 주요 파라미터, 검증 결과와 성능 지표 등 모델링 과정 전반에 대한 내용이 포함됩니다.",
  },
  {
    id: "da-161",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트를 종료하며 작성하는 '최종 보고서'에 일반적으로 포함되는 내용으로 가장 거리가 먼 것은?",
    options: [
      "프로젝트 개요, 주요 분석 결과, 비즈니스 시사점, 향후 계획",
      "담당자 개인의 신용카드 사용 내역",
      "프로젝트 수행 과정에서의 주요 이슈와 해결 방안",
      "프로젝트를 통해 얻은 교훈 사항",
    ],
    answer: 1,
    explanation:
      "최종 보고서에는 프로젝트 개요, 주요 분석 결과, 비즈니스 시사점, 이슈 및 해결 방안, 교훈 사항, 향후 계획 등이 포함됩니다. 담당자 개인의 신용카드 사용 내역은 포함되지 않습니다.",
  },
  {
    id: "da-162",
    subject: "2과목(데이터 분석 기획)",
    question: "주요 이해관계자와 경영진으로 구성되어 분석 과제의 방향성과 주요 의사결정을 심의・검토하는 기구를 무엇이라 하는가?",
    options: ["스티어링 커미티(Steering Committee)", "동호회", "노동조합", "사내 식당 운영위원회"],
    answer: 0,
    explanation:
      "스티어링 커미티(운영위원회)는 프로젝트 스폰서, 주요 이해관계자, 경영진 등으로 구성되어 프로젝트의 방향성과 주요 의사결정 사항을 심의・검토하는 최고 의사결정 기구입니다.",
  },
  {
    id: "da-163",
    subject: "2과목(데이터 분석 기획)",
    question: "조직이 데이터 거버넌스 및 분석 관련 표준을 잘 준수하고 있는지를 점검하는 활동을 무엇이라 하는가?",
    options: ["감사(Audit)", "홍보(PR)", "채용(Recruiting)", "마케팅(Marketing)"],
    answer: 0,
    explanation:
      "감사(Audit)는 조직이 정해진 데이터 거버넌스 원칙과 표준, 프로세스를 잘 준수하고 있는지를 정기적 또는 비정기적으로 점검하는 활동입니다.",
  },
  {
    id: "da-164",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 착수 시 이해관계자의 요구사항을 파악하기 위해 담당자와 직접 대화를 나누며 정보를 수집하는 기법은?",
    options: ["인터뷰(Interview)", "회귀분석", "군집분석", "다중공선성 진단"],
    answer: 0,
    explanation:
      "인터뷰는 이해관계자와 직접 대화를 나누며 요구사항, 기대사항, 우려사항 등을 심층적으로 파악하는 대표적인 요구사항 수집 기법입니다.",
  },
  {
    id: "da-165",
    subject: "2과목(데이터 분석 기획)",
    question: "다수의 이해관계자로부터 정형화된 문항을 통해 의견을 폭넓게 수집하는 요구사항 수집 기법은?",
    options: ["설문조사(Survey)", "인터뷰", "관찰", "워크숍"],
    answer: 0,
    explanation:
      "설문조사는 정형화된 문항을 다수의 이해관계자에게 배포하여, 짧은 시간 안에 폭넓은 의견과 데이터를 수집할 수 있는 요구사항 수집 기법입니다.",
  },
  {
    id: "da-166",
    subject: "2과목(데이터 분석 기획)",
    question: "여러 이해관계자를 한 자리에 모아 토의를 통해 요구사항에 대한 합의를 이끌어내는 요구사항 수집 기법은?",
    options: ["워크숍(Workshop)", "설문조사", "인터뷰", "문헌 조사"],
    answer: 0,
    explanation:
      "워크숍은 여러 이해관계자를 한 자리에 모아 자유로운 토의를 진행함으로써, 서로 다른 의견을 조율하고 요구사항에 대한 합의를 신속하게 이끌어내는 기법입니다.",
  },
  {
    id: "da-167",
    subject: "2과목(데이터 분석 기획)",
    question: "실제 업무 현장에서 사용자의 행동을 직접 지켜봄으로써 명시적으로 드러나지 않는 요구사항을 파악하는 기법은?",
    options: ["관찰(Observation)", "설문조사", "워크숍", "델파이 기법"],
    answer: 0,
    explanation:
      "관찰(Observation)은 실제 업무 현장에서 사용자의 행동을 직접 지켜봄으로써, 사용자 스스로도 명확히 인식하지 못하거나 말로 표현하기 어려운 잠재적 요구사항까지 파악할 수 있는 기법입니다.",
  },
  {
    id: "da-168",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 계획서(Project Plan)에 일반적으로 포함되는 내용으로 가장 거리가 먼 것은?",
    options: [
      "프로젝트 범위, 일정, 예산, 품질 기준, 위험 관리 계획",
      "담당자 개인의 결혼기념일",
      "프로젝트 조직도와 역할 정의",
      "의사소통 계획",
    ],
    answer: 1,
    explanation:
      "프로젝트 계획서에는 범위, 일정, 예산, 품질 기준, 위험 관리 계획, 조직도, 의사소통 계획 등이 포함됩니다. 담당자 개인의 결혼기념일은 이에 해당하지 않습니다.",
  },
  {
    id: "da-169",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트의 일정과 원가 성과를 계획된 가치와 실제 가치로 비교・분석하는 기법은?",
    options: ["획득가치관리(EVM, Earned Value Management)", "SWOT 분석", "RACI 매트릭스", "회귀분석"],
    answer: 0,
    explanation:
      "획득가치관리(EVM)는 프로젝트의 일정과 원가 성과를 계획가치(PV), 획득가치(EV), 실제원가(AC)라는 세 가지 지표를 통해 통합적으로 측정하고 분석하는 기법입니다.",
  },
  {
    id: "da-170",
    subject: "2과목(데이터 분석 기획)",
    question: "EVM(획득가치관리)에서 특정 시점까지 계획상 완료했어야 할 작업의 예산 가치를 의미하는 지표는?",
    options: ["계획가치(PV, Planned Value)", "획득가치(EV, Earned Value)", "실제원가(AC, Actual Cost)", "예상완료원가(EAC)"],
    answer: 0,
    explanation:
      "계획가치(PV)는 특정 시점까지 계획상 완료되었어야 할 작업량에 대한 예산 가치를 의미하며, 실제 진척도(EV)와 비교하여 일정 성과를 측정하는 기준이 됩니다.",
  },
  {
    id: "da-171",
    subject: "2과목(데이터 분석 기획)",
    question: "EVM(획득가치관리)에서 특정 시점까지 실제로 완료한 작업량에 대한 예산 가치를 의미하는 지표는?",
    options: ["획득가치(EV, Earned Value)", "계획가치(PV)", "실제원가(AC)", "잔여예산(ETC)"],
    answer: 0,
    explanation:
      "획득가치(EV)는 특정 시점까지 실제로 완료한 작업량을 애초 계획된 예산 기준으로 환산한 가치로, 계획가치(PV) 및 실제원가(AC)와 비교하여 프로젝트의 성과를 측정하는 데 사용됩니다.",
  },
  {
    id: "da-172",
    subject: "2과목(데이터 분석 기획)",
    question: "EVM(획득가치관리)에서 특정 시점까지 실제로 투입된 비용을 의미하는 지표는?",
    options: ["실제원가(AC, Actual Cost)", "계획가치(PV)", "획득가치(EV)", "예산 총액(BAC)"],
    answer: 0,
    explanation:
      "실제원가(AC)는 특정 시점까지 프로젝트 수행을 위해 실제로 투입된 비용을 의미하며, 획득가치(EV)와 비교하여 원가 성과를 측정하는 기준이 됩니다.",
  },
  {
    id: "da-173",
    subject: "2과목(데이터 분석 기획)",
    question: "획득가치(EV)를 계획가치(PV)로 나누어 산출하며, 1보다 크면 일정이 계획보다 앞서 있음을 의미하는 지표는?",
    options: ["일정성과지수(SPI, Schedule Performance Index)", "원가성과지수(CPI)", "위험도지수", "품질지수"],
    answer: 0,
    explanation:
      "일정성과지수(SPI)는 EV를 PV로 나누어(EV/PV) 계산하며, 1보다 크면 계획보다 일정이 앞서 있고, 1보다 작으면 일정이 지연되고 있음을 의미합니다.",
  },
  {
    id: "da-174",
    subject: "2과목(데이터 분석 기획)",
    question: "획득가치(EV)를 실제원가(AC)로 나누어 산출하며, 1보다 크면 예산보다 비용을 적게 사용하고 있음을 의미하는 지표는?",
    options: ["원가성과지수(CPI, Cost Performance Index)", "일정성과지수(SPI)", "위험도지수", "품질지수"],
    answer: 0,
    explanation:
      "원가성과지수(CPI)는 EV를 AC로 나누어(EV/AC) 계산하며, 1보다 크면 계획된 예산보다 적은 비용으로 효율적으로 진행되고 있음을, 1보다 작으면 예산을 초과하고 있음을 의미합니다.",
  },
  {
    id: "da-175",
    subject: "2과목(데이터 분석 기획)",
    question: "진행 중인 분석 프로젝트를 계속 추진할 경우 실패 가능성이 매우 높다고 판단될 때, 손실을 최소화하기 위해 조기에 중단을 결정하는 것을 무엇이라 하는가?",
    options: ["프로젝트 조기 종료(Kill Decision)", "정규화", "인덱싱", "리팩토링"],
    answer: 0,
    explanation:
      "프로젝트 조기 종료(Kill Decision)는 진행 중인 프로젝트가 목표 달성이 어렵거나 더 이상 투자 가치가 없다고 판단될 때, 추가적인 손실을 막기 위해 프로젝트를 조기에 중단하기로 결정하는 것을 의미합니다.",
  },
  {
    id: "da-176",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 결과가 동일한 데이터와 절차로 다시 수행했을 때 동일하게 재현될 수 있는 성질을 무엇이라 하는가?",
    options: ["재현성(Reproducibility)", "휘발성", "탄력성", "모호성"],
    answer: 0,
    explanation:
      "재현성(Reproducibility)은 동일한 데이터와 분석 절차를 다시 수행했을 때 동일한 결과를 얻을 수 있는 성질로, 분석 결과의 신뢰성을 뒷받침하는 중요한 요소입니다.",
  },
  {
    id: "da-177",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 결과의 재현성을 확보하기 위한 방안으로 가장 적절한 것은?",
    options: [
      "사용한 코드, 데이터, 분석 환경(라이브러리 버전 등)을 체계적으로 버전 관리하고 문서화한다",
      "분석에 사용한 코드와 데이터를 분석 종료 즉시 모두 삭제한다",
      "분석 절차를 문서화하지 않고 담당자의 기억에만 의존한다",
      "분석 환경 정보는 기록할 필요가 전혀 없다",
    ],
    answer: 0,
    explanation:
      "재현성을 확보하려면 분석에 사용한 코드, 데이터, 라이브러리 버전 등 분석 환경 정보를 체계적으로 버전 관리하고 문서화하여, 언제든 동일한 절차로 결과를 재현할 수 있도록 해야 합니다.",
  },
  {
    id: "da-178",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 진행 과정과 의사결정 내용을 문서로 남기는 것이 중요한 이유로 가장 적절한 것은?",
    options: [
      "추후 유사 프로젝트나 감사, 인수인계 시 참고할 수 있는 근거 자료가 되기 때문이다",
      "문서화는 프로젝트 진행 속도를 항상 느리게 만들기만 하기 때문이다",
      "문서화된 내용은 법적으로 아무 효력이 없기 때문이다",
      "문서화를 하면 오히려 커뮤니케이션이 어려워지기 때문이다",
    ],
    answer: 0,
    explanation:
      "프로젝트의 진행 과정과 의사결정 내용을 문서화하면, 추후 유사한 프로젝트를 수행하거나 감사를 받을 때, 또는 담당자가 교체되어 인수인계할 때 중요한 근거 자료로 활용할 수 있습니다.",
  },
  {
    id: "da-179",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 진행 중 이해관계자가 지나치게 높은 기대를 갖지 않도록, 현실적인 목표와 진행 상황을 지속적으로 공유하는 활동을 무엇이라 하는가?",
    options: ["기대치 관리(Expectation Management)", "예산 삭감", "인력 감축", "일정 은폐"],
    answer: 0,
    explanation:
      "기대치 관리는 이해관계자가 프로젝트에 대해 비현실적으로 높은 기대를 갖지 않도록, 현실적인 목표와 제약사항, 진행 상황을 지속적이고 투명하게 공유하는 활동입니다.",
  },
  {
    id: "da-180",
    subject: "2과목(데이터 분석 기획)",
    question: "'분석과제 정의서'와 '프로젝트 계획서'의 일반적인 차이점으로 가장 적절한 것은?",
    options: [
      "분석과제 정의서는 무엇을, 왜 분석할지를 정의하고, 프로젝트 계획서는 이를 어떻게, 언제, 누가 수행할지를 구체화한다",
      "두 문서는 완전히 동일한 내용을 담고 있어 하나만 있으면 충분하다",
      "프로젝트 계획서는 분석과제 정의서보다 먼저 작성할 수 없다는 절대적인 규칙이 있다",
      "분석과제 정의서에는 예산 정보가 반드시 포함되어야 하고 프로젝트 계획서에는 포함될 수 없다",
    ],
    answer: 0,
    explanation:
      "분석과제 정의서는 분석의 대상과 목적, 즉 '무엇을 왜 분석하는지'를 정의하는 데 초점을 두는 반면, 프로젝트 계획서는 이를 실행하기 위한 구체적인 일정, 자원, 담당자, 즉 '어떻게 수행할지'를 계획하는 문서입니다.",
  },
  {
    id: "da-181",
    subject: "2과목(데이터 분석 기획)",
    question: "여러 부서에서 인력을 임시로 차출하여 특정 분석 마스터플랜 수립을 위해 한시적으로 운영하는 조직 형태는?",
    options: ["TF(Task Force) 조직", "상설 전담 부서", "노동조합", "이사회"],
    answer: 0,
    explanation:
      "TF(태스크포스) 조직은 특정 목표(예: 분석 마스터플랜 수립)를 달성하기 위해 여러 부서의 인력을 한시적으로 차출하여 구성하는 임시 조직 형태입니다.",
  },
  {
    id: "da-182",
    subject: "2과목(데이터 분석 기획)",
    question: "데이터 분석이 특별한 프로젝트가 아니라 조직의 일상적인 업무 프로세스의 일부로 자연스럽게 자리 잡는 것을 무엇이라 하는가?",
    options: ["분석의 내재화(Internalization)", "분석의 외주화", "분석의 폐기", "분석의 은닉화"],
    answer: 0,
    explanation:
      "분석의 내재화는 데이터 분석이 일회성 프로젝트에 그치지 않고, 조직 구성원의 일상적인 업무 프로세스와 의사결정 과정에 자연스럽게 녹아드는 것을 의미합니다.",
  },
  {
    id: "da-183",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 결과가 현업에서 실제로 얼마나 활용되고 있는지를 나타내는 '활용도'를 높이기 위한 방안으로 가장 적절한 것은?",
    options: [
      "분석 결과를 현업의 실제 업무 프로세스와 시스템에 통합하고, 사용자 관점의 지속적인 피드백을 반영한다",
      "분석 결과 보고서를 작성한 뒤 곧바로 폐기한다",
      "현업 부서와의 소통을 의도적으로 차단한다",
      "분석 결과를 아무도 볼 수 없도록 비공개로 숨긴다",
    ],
    answer: 0,
    explanation:
      "분석 결과의 활용도를 높이려면, 결과를 현업의 실제 업무 프로세스와 시스템에 통합하고 사용자의 피드백을 지속적으로 반영하여 실제로 사용하기 편리하게 만드는 것이 중요합니다.",
  },
  {
    id: "da-184",
    subject: "2과목(데이터 분석 기획)",
    question: "불확실성이 큰 분석 과제를 진행할 때, 작은 단위로 빠르게 시도해보고 성과가 없으면 신속히 방향을 전환하는 원칙을 무엇이라 하는가?",
    options: ["조기 실패(Fail Fast) 원칙", "완벽주의 원칙", "무조건 지속 원칙", "은폐 원칙"],
    answer: 0,
    explanation:
      "조기 실패(Fail Fast) 원칙은 불확실성이 큰 과제를 작은 단위로 빠르게 시도해보고, 성과가 나지 않을 경우 이를 신속히 파악하여 방향을 전환함으로써 자원 낭비를 최소화하는 원칙입니다.",
  },
  {
    id: "da-185",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트에 대한 투자를 정당화하기 위해 문제 정의, 기대 효과, 소요 비용, 리스크 등을 정리한 문서를 무엇이라 하는가?",
    options: ["비즈니스 케이스(Business Case)", "회의록", "명함", "휴가계획서"],
    answer: 0,
    explanation:
      "비즈니스 케이스는 분석 프로젝트에 대한 투자를 경영진에게 설득하고 정당화하기 위해, 해결하려는 문제, 기대되는 효과, 소요 비용, 예상되는 리스크 등을 종합적으로 정리한 문서입니다.",
  },
  {
    id: "da-186",
    subject: "2과목(데이터 분석 기획)",
    question: "비즈니스 케이스(Business Case)에 일반적으로 포함되는 내용으로 가장 거리가 먼 것은?",
    options: [
      "해결하고자 하는 문제 정의와 기대 효과, 소요 비용과 리스크",
      "담당자 개인의 반려동물 이름",
      "투자 대비 효과(ROI) 분석",
      "대안적 접근 방식과의 비교",
    ],
    answer: 1,
    explanation:
      "비즈니스 케이스에는 문제 정의, 기대 효과, 비용, 리스크, ROI 분석, 대안 비교 등이 포함됩니다. 담당자 개인의 반려동물 이름은 이에 해당하지 않습니다.",
  },
  {
    id: "da-187",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트에서 식별된 위험 요소와 그 발생 확률, 영향도, 대응 전략, 담당자 등을 기록하여 지속적으로 관리하는 문서는?",
    options: ["위험 관리대장(Risk Register)", "이슈 관리대장", "회의록", "명함첩"],
    answer: 0,
    explanation:
      "위험 관리대장(Risk Register)은 프로젝트에서 식별된 각 위험 요소에 대해 발생 확률, 영향도, 대응 전략, 담당자 등을 기록하여 지속적으로 추적・관리하는 문서입니다.",
  },
  {
    id: "da-188",
    subject: "2과목(데이터 분석 기획)",
    question: "위험의 발생 확률과 영향도를 곱하거나 조합하여 위험의 심각도 등급을 매기는 정성적 위험 분석 방법을 무엇이라 하는가?",
    options: ["정성적 위험분석(위험등급 산정)", "회귀분석", "군집분석", "주성분분석"],
    answer: 0,
    explanation:
      "정성적 위험분석은 각 위험의 발생 확률과 영향도를 상/중/하 등으로 평가하고 이를 조합하여 위험의 심각도 등급을 매김으로써, 우선적으로 대응할 위험을 선별하는 방법입니다.",
  },
  {
    id: "da-189",
    subject: "2과목(데이터 분석 기획)",
    question: "조직 내에서 축적된 분석 노하우와 경험을 체계적으로 저장하고 공유하는 체계를 무엇이라 하는가?",
    options: ["지식관리(Knowledge Management)", "재무관리", "인사관리", "시설관리"],
    answer: 0,
    explanation:
      "지식관리는 조직 구성원들이 분석 프로젝트를 수행하며 축적한 노하우와 경험을 체계적으로 저장, 공유, 재활용할 수 있도록 관리하는 체계로, 분석 역량의 조직적 지속성을 뒷받침합니다.",
  },
  {
    id: "da-190",
    subject: "2과목(데이터 분석 기획)",
    question: "분석에 관심 있는 구성원들이 부서를 넘어 자율적으로 모여 경험과 노하우를 공유하는 사내 모임을 무엇이라 하는가?",
    options: ["실행공동체(CoP, Community of Practice)", "이사회", "주주총회", "노동조합"],
    answer: 0,
    explanation:
      "실행공동체(CoP)는 특정 주제(예: 데이터 분석)에 관심 있는 구성원들이 부서 구분 없이 자율적으로 모여 경험과 지식을 공유하고 학습하는 사내 커뮤니티입니다.",
  },
  {
    id: "da-191",
    subject: "2과목(데이터 분석 기획)",
    question: "새로운 분석 모델이나 시스템을 전사에 적용하기 전, 일부 제한된 범위에서 먼저 시험적으로 적용해보는 것을 무엇이라 하는가?",
    options: ["파일럿(Pilot) 적용", "전면 롤아웃", "즉시 폐기", "무기한 보류"],
    answer: 0,
    explanation:
      "파일럿 적용은 새로운 분석 모델이나 시스템을 전사에 확대 적용하기에 앞서, 일부 제한된 부서나 대상에 먼저 시험적으로 적용하여 문제점을 파악하고 보완하는 활동입니다.",
  },
  {
    id: "da-192",
    subject: "2과목(데이터 분석 기획)",
    question: "파일럿 적용 결과를 바탕으로 전사 확산 여부를 결정할 때 고려해야 할 기준으로 가장 적절한 것은?",
    options: [
      "파일럿에서 나타난 실제 성과와 문제점, 확산 시 예상되는 리스크",
      "담당자의 개인적인 선호도",
      "경쟁사와 무관한 다른 산업의 유행",
      "회사의 창립기념일",
    ],
    answer: 0,
    explanation:
      "전사 확산 여부는 파일럿 적용에서 실제로 관찰된 성과와 문제점, 그리고 전사 확산 시 예상되는 추가적인 리스크와 비용을 종합적으로 고려하여 결정해야 합니다.",
  },
  {
    id: "da-193",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트 진행 상황을 비교하기 위한 기준이 되는, 최초 승인된 범위・일정・예산 계획을 무엇이라 하는가?",
    options: ["베이스라인(Baseline)", "임시방편", "잠정 결론", "가설"],
    answer: 0,
    explanation:
      "베이스라인은 프로젝트의 실제 진행 상황과 비교하기 위한 기준이 되는, 최초에 공식적으로 승인된 범위・일정・예산 계획을 의미합니다.",
  },
  {
    id: "da-194",
    subject: "2과목(데이터 분석 기획)",
    question: "프로젝트의 범위나 일정 등에 대한 변경 요청이 발생했을 때, 이를 공식적으로 검토하고 승인 여부를 결정하는 기구를 무엇이라 하는가?",
    options: ["변경통제위원회(CCB, Change Control Board)", "인사위원회", "노사협의회", "이사회만 해당"],
    answer: 0,
    explanation:
      "변경통제위원회(CCB)는 프로젝트 진행 중 발생하는 범위, 일정, 예산 등에 대한 변경 요청을 공식적으로 검토하고, 승인 또는 반려 여부를 결정하는 프로젝트 거버넌스 기구입니다.",
  },
  {
    id: "da-195",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 프로젝트의 성공 여부를 평가할 때 함께 고려해야 할 두 가지 관점으로 가장 적절한 것은?",
    options: [
      "정량적인 성과 지표(ROI, 정확도 등)와 이해관계자의 정성적인 만족도",
      "담당자의 개인적인 기분만",
      "회사 로고의 디자인 만족도만",
      "사무실의 청결도만",
    ],
    answer: 0,
    explanation:
      "분석 프로젝트의 성공 여부는 ROI, 정확도 향상 등 정량적인 성과 지표뿐 아니라, 이해관계자들이 실제로 느끼는 정성적인 만족도까지 함께 고려하여 종합적으로 평가해야 합니다.",
  },
  {
    id: "da-196",
    subject: "2과목(데이터 분석 기획)",
    question: "한 번 수립된 분석 마스터플랜을 정기적으로 재검토하고 갱신해야 하는 이유로 가장 적절한 것은?",
    options: [
      "비즈니스 환경, 기술, 우선순위가 시간에 따라 변화하기 때문이다",
      "마스터플랜은 한 번 수립하면 절대 변경할 수 없기 때문이다",
      "재검토는 법적으로 금지되어 있기 때문이다",
      "마스터플랜은 갱신할수록 오히려 정확도가 낮아지기 때문이다",
    ],
    answer: 0,
    explanation:
      "비즈니스 환경, 기술 트렌드, 조직의 우선순위는 시간이 지나면서 변화하기 때문에, 분석 마스터플랜도 이러한 변화를 반영하여 정기적으로 재검토하고 갱신할 필요가 있습니다.",
  },
  {
    id: "da-197",
    subject: "2과목(데이터 분석 기획)",
    question: "분석 기획 단계에서 필요한 데이터를 실제로 확보할 수 있는지를 사전에 검증하는 활동을 무엇이라 하는가?",
    options: ["데이터 타당성 검토(Feasibility Study)", "데이터 폐기", "데이터 압축", "데이터 암호화"],
    answer: 0,
    explanation:
      "데이터 타당성 검토는 분석 기획 단계에서, 계획한 분석에 필요한 데이터를 실제로 확보할 수 있는지(수집 가능성, 품질, 접근 권한 등)를 사전에 검증하는 활동입니다.",
  },
  {
    id: "da-198",
    subject: "2과목(데이터 분석 기획)",
    question: "타당성 검토의 종류 중, 현재 보유한 기술이나 인프라로 해당 분석 과제를 실제로 구현할 수 있는지를 검토하는 것은?",
    options: ["기술적 타당성(Technical Feasibility)", "경제적 타당성", "운영적 타당성", "법적 타당성"],
    answer: 0,
    explanation:
      "기술적 타당성은 현재 보유한 기술 수준, 인프라, 인력 역량으로 해당 분석 과제를 실제로 구현할 수 있는지를 검토하는 것입니다.",
  },
  {
    id: "da-199",
    subject: "2과목(데이터 분석 기획)",
    question: "타당성 검토의 종류 중, 분석 과제에 투입되는 비용 대비 기대되는 효과가 충분한지를 검토하는 것은?",
    options: ["경제적 타당성(Economic Feasibility)", "기술적 타당성", "운영적 타당성", "법적 타당성"],
    answer: 0,
    explanation:
      "경제적 타당성은 분석 과제에 투입되는 예산, 인력 등의 비용 대비, 기대되는 비즈니스 효과(수익 증대, 비용 절감 등)가 충분히 큰지를 검토하는 것입니다.",
  },
  {
    id: "da-200",
    subject: "2과목(데이터 분석 기획)",
    question: "타당성 검토의 종류 중, 분석 결과를 조직이 실제 업무 프로세스에서 지속적으로 운영・활용할 수 있는지를 검토하는 것은?",
    options: ["운영적 타당성(Operational Feasibility)", "기술적 타당성", "경제적 타당성", "법적 타당성만 해당"],
    answer: 0,
    explanation:
      "운영적 타당성은 도출된 분석 결과나 모델을 조직이 실제 업무 프로세스 안에서 지속적으로 운영하고 활용할 수 있는 여건(인력, 프로세스, 문화 등)이 되는지를 검토하는 것입니다.",
  },

  // ─── 3과목(데이터 분석) ───────────────────────────────────────────────
  {
    id: "du-001",
    subject: "3과목(데이터 분석)",
    question: "데이터 시각화 도구로 적절하지 않은 것은?",
    options: ["Tableau", "Power BI", "Hadoop", "D3.js"],
    answer: 2,
    explanation:
      "Tableau, Power BI, D3.js는 데이터 시각화 도구입니다. Hadoop은 대용량 데이터 처리를 위한 분산 처리 프레임워크로 시각화 도구가 아닙니다.",
  },
  {
    id: "du-002",
    subject: "3과목(데이터 분석)",
    question: "SQL에서 GROUP BY 절과 함께 사용되는 집계 함수가 아닌 것은?",
    options: ["COUNT()", "SUM()", "AVG()", "WHERE()"],
    answer: 3,
    explanation:
      "COUNT(), SUM(), AVG(), MAX(), MIN()은 GROUP BY와 함께 사용되는 집계 함수입니다. WHERE는 집계 함수가 아니라 조건을 지정하는 절(Clause)입니다.",
  },
  {
    id: "du-003",
    subject: "3과목(데이터 분석)",
    question: "R 언어에서 데이터 프레임을 생성하는 함수는?",
    options: ["data.frame()", "matrix()", "vector()", "list()"],
    answer: 0,
    explanation:
      "R 언어에서 데이터 프레임은 data.frame() 함수로 생성합니다. 데이터 프레임은 열마다 다른 데이터 타입을 가질 수 있는 2차원 데이터 구조입니다.",
  },
  {
    id: "du-004",
    subject: "3과목(데이터 분석)",
    question: "Python pandas에서 결측값을 처리하는 메서드로 올바른 것은?",
    options: ["dropna()", "fillna()", "isna()", "이 중 모두"],
    answer: 3,
    explanation:
      "pandas에서 dropna()는 결측값이 있는 행/열 제거, fillna()는 결측값을 특정 값으로 대체, isna()는 결측값 여부 확인에 사용됩니다. 모두 결측값 처리와 관련된 메서드입니다.",
  },
  {
    id: "du-005",
    subject: "3과목(데이터 분석)",
    question: "ETL 프로세스에서 'T'가 의미하는 것은?",
    options: ["Transfer(전송)", "Transform(변환)", "Test(테스트)", "Track(추적)"],
    answer: 1,
    explanation:
      "ETL은 Extract(추출), Transform(변환), Load(적재)의 약자입니다. Transform 단계에서는 추출된 데이터를 목적에 맞게 변환, 정제, 통합하는 작업을 수행합니다.",
  },
  {
    id: "du-006",
    subject: "3과목(데이터 분석)",
    question: "NoSQL 데이터베이스의 특징으로 옳은 것은?",
    options: [
      "고정된 스키마를 사용한다",
      "ACID 트랜잭션을 완전히 지원한다",
      "수평적 확장(Scale-out)이 용이하다",
      "SQL만을 사용하여 쿼리한다",
    ],
    answer: 2,
    explanation:
      "NoSQL 데이터베이스는 유연한 스키마, 수평적 확장(Scale-out) 용이성, 대용량 데이터 처리에 적합한 특징을 가집니다. ACID를 완전히 지원하지 않을 수 있으며, SQL 외의 다양한 쿼리 방식을 사용합니다.",
  },
  {
    id: "du-007",
    subject: "3과목(데이터 분석)",
    question: "데이터 분석 방법론 중 CRISP-DM의 단계 순서로 올바른 것은?",
    options: [
      "비즈니스 이해 → 데이터 이해 → 데이터 준비 → 모델링 → 평가 → 배포",
      "데이터 이해 → 비즈니스 이해 → 모델링 → 데이터 준비 → 평가 → 배포",
      "비즈니스 이해 → 모델링 → 데이터 준비 → 데이터 이해 → 평가 → 배포",
      "데이터 준비 → 데이터 이해 → 비즈니스 이해 → 모델링 → 평가 → 배포",
    ],
    answer: 0,
    explanation:
      "CRISP-DM(Cross Industry Standard Process for Data Mining)의 6단계는 비즈니스 이해 → 데이터 이해 → 데이터 준비 → 모델링 → 평가 → 배포 순서입니다.",
  },
  {
    id: "du-008",
    subject: "3과목(데이터 분석)",
    question: "다음 중 데이터 마이닝 기법이 아닌 것은?",
    options: ["연관 규칙 분석", "군집 분석", "의사결정나무", "ERD 설계"],
    answer: 3,
    explanation:
      "데이터 마이닝 기법에는 연관 규칙 분석, 군집 분석, 의사결정나무, 회귀분석, 신경망 등이 있습니다. ERD(Entity-Relationship Diagram) 설계는 데이터베이스 설계 기법입니다.",
  },
  {
    id: "du-009",
    subject: "3과목(데이터 분석)",
    question: "A/B 테스트에 대한 설명으로 가장 적절한 것은?",
    options: [
      "두 개의 데이터셋을 병합하는 방법",
      "두 가지 버전을 비교하여 더 나은 것을 선택하는 실험 방법",
      "데이터를 A와 B 두 그룹으로 암호화하는 방법",
      "두 개의 알고리즘을 순차적으로 적용하는 방법",
    ],
    answer: 1,
    explanation:
      "A/B 테스트는 두 가지 버전(A와 B)을 서로 다른 사용자 그룹에 노출시켜 어느 것이 더 나은 성과를 내는지 비교하는 실험 방법입니다.",
  },
  {
    id: "du-010",
    subject: "3과목(데이터 분석)",
    question: "데이터 품질 관리의 주요 차원(Dimension)으로 올바르지 않은 것은?",
    options: ["정확성(Accuracy)", "완전성(Completeness)", "일관성(Consistency)", "복잡성(Complexity)"],
    answer: 3,
    explanation:
      "데이터 품질 관리의 주요 차원에는 정확성, 완전성, 일관성, 적시성(Timeliness), 유일성(Uniqueness) 등이 있습니다. 복잡성(Complexity)은 데이터 품질 차원에 해당하지 않습니다.",
  },
  {
    id: "du-011",
    subject: "3과목(데이터 분석)",
    question: "모집단을 서로 이질적인 몇 개의 층(Stratum)으로 나눈 뒤, 각 층에서 표본을 추출하는 표본추출 방법은?",
    options: ["단순 무작위 추출", "층화 추출", "군집 추출", "계통 추출"],
    answer: 1,
    explanation:
      "층화 추출(Stratified Sampling)은 모집단을 동질적인 소집단(층)으로 나눈 뒤 각 층에서 표본을 추출하는 방법으로, 층 내부는 동질적, 층 간에는 이질적인 특성을 가집니다.",
  },
  {
    id: "du-012",
    subject: "3과목(데이터 분석)",
    question:
      "표본의 크기가 충분히 커지면 모집단의 분포와 관계없이 표본 평균의 분포가 정규분포에 가까워진다는 통계 정리는?",
    options: ["큰 수의 법칙(대수의 법칙)", "중심극한정리", "베이즈 정리", "최소제곱법"],
    answer: 1,
    explanation:
      "중심극한정리(Central Limit Theorem)는 모집단의 분포 형태와 무관하게 표본의 크기(n)가 충분히 크면 표본 평균의 분포가 정규분포에 근사한다는 정리입니다.",
  },
  {
    id: "du-013",
    subject: "3과목(데이터 분석)",
    question: "가설 검정에서 '차이가 없다' 또는 '효과가 없다'와 같이 기각을 전제로 세우는 가설은?",
    options: ["대립가설", "귀무가설", "확률가설", "표본가설"],
    answer: 1,
    explanation:
      "귀무가설(Null Hypothesis, H0)은 '차이가 없다', '효과가 없다'처럼 기본적으로 참이라고 가정하고 기각 여부를 검정하는 가설이며, 이를 기각할 때 채택되는 가설이 대립가설(H1)입니다.",
  },
  {
    id: "du-014",
    subject: "3과목(데이터 분석)",
    question: "실제로는 귀무가설이 참인데도 이를 기각하는 오류를 무엇이라 하는가?",
    options: ["제1종 오류", "제2종 오류", "표본 오류", "측정 오류"],
    answer: 0,
    explanation:
      "제1종 오류(Type I Error)는 참인 귀무가설을 잘못 기각하는 오류이며, 이 오류를 범할 확률의 최대 허용치가 유의수준(α)입니다. 반대로 거짓인 귀무가설을 기각하지 못하는 오류는 제2종 오류입니다.",
  },
  {
    id: "du-015",
    subject: "3과목(데이터 분석)",
    question: "가설 검정에서 유의확률(p-value)이 유의수준(α)보다 작을 때의 판단으로 옳은 것은?",
    options: [
      "귀무가설을 기각하고 대립가설을 채택한다",
      "귀무가설을 채택하고 검정을 종료한다",
      "표본의 크기를 무조건 두 배로 늘린다",
      "아무런 결론도 내릴 수 없다",
    ],
    answer: 0,
    explanation:
      "p-value가 유의수준(α)보다 작으면 귀무가설 하에서 이런 결과가 나올 확률이 매우 낮다는 의미이므로 귀무가설을 기각하고 대립가설을 채택합니다.",
  },
  {
    id: "du-016",
    subject: "3과목(데이터 분석)",
    question: "두 변수 간 피어슨(Pearson) 상관계수가 가질 수 있는 값의 범위는?",
    options: ["0 이상 1 이하", "-1 이상 1 이하", "-∞ 부터 +∞ 까지", "0 이상 100 이하"],
    answer: 1,
    explanation:
      "피어슨 상관계수는 -1(완전한 음의 상관)부터 +1(완전한 양의 상관) 사이의 값을 가지며, 0에 가까울수록 선형 상관관계가 약함을 의미합니다.",
  },
  {
    id: "du-017",
    subject: "3과목(데이터 분석)",
    question:
      "다중회귀분석에서 독립변수들 간에 강한 상관관계가 존재하여 회귀계수 추정이 불안정해지는 문제를 무엇이라 하는가?",
    options: ["다중공선성", "이분산성", "자기상관", "과적합"],
    answer: 0,
    explanation:
      "다중공선성(Multicollinearity)은 독립변수 간에 높은 상관관계가 존재하는 현상으로, 회귀계수 추정이 불안정해지는 문제를 일으키며 VIF(분산팽창계수) 등으로 진단합니다.",
  },
  {
    id: "du-018",
    subject: "3과목(데이터 분석)",
    question: "분산분석(ANOVA)을 사용하는 주된 목적은?",
    options: [
      "두 변수 간의 선형 상관관계 유무를 확인하기 위해",
      "세 개 이상의 집단 간 평균에 차이가 있는지를 검정하기 위해",
      "데이터를 여러 개의 군집으로 나누기 위해",
      "결측치를 대치하기 위해",
    ],
    answer: 1,
    explanation:
      "분산분석(ANOVA)은 세 개 이상 집단의 평균 간에 통계적으로 유의한 차이가 있는지를 검정하기 위해 사용됩니다.",
  },
  {
    id: "du-019",
    subject: "3과목(데이터 분석)",
    question: "의사결정나무(Decision Tree)에서 노드의 불순도(Impurity)를 측정하는 지표로 사용되는 것은?",
    options: ["지니 지수(Gini Index), 엔트로피(Entropy)", "결정계수(R²)", "카이제곱 통계량만", "다중공선성 지수"],
    answer: 0,
    explanation:
      "의사결정나무는 분할 기준을 정할 때 지니 지수(Gini Index)나 엔트로피(Entropy) 같은 불순도 지표를 활용해 노드가 얼마나 순수한(한 클래스로 집중된) 상태인지를 측정합니다.",
  },
  {
    id: "du-020",
    subject: "3과목(데이터 분석)",
    question: "종속변수가 이진(0 또는 1)의 범주형 변수일 때 사용하는 회귀 분석 기법은?",
    options: ["다중선형회귀", "로지스틱 회귀", "릿지 회귀", "주성분 회귀"],
    answer: 1,
    explanation:
      "로지스틱 회귀(Logistic Regression)는 종속변수가 이진 범주형일 때 사용하며, 시그모이드(로지스틱) 함수를 통해 결과를 0과 1 사이의 확률 값으로 변환합니다.",
  },
  {
    id: "du-021",
    subject: "3과목(데이터 분석)",
    question:
      "부트스트랩(Bootstrap)으로 여러 개의 표본을 만들어 각각 모델을 병렬로 학습시킨 뒤 그 결과를 평균 또는 투표로 결합하는 앙상블 기법은?",
    options: ["배깅(Bagging)", "부스팅(Boosting)", "계층적 군집분석", "주성분분석"],
    answer: 0,
    explanation:
      "배깅(Bagging, Bootstrap Aggregating)은 부트스트랩으로 만든 여러 표본에 대해 병렬적으로 모델을 학습시키고 결과를 평균・투표로 결합하는 기법이며, 랜덤 포레스트가 대표적인 예입니다.",
  },
  {
    id: "du-022",
    subject: "3과목(데이터 분석)",
    question:
      "이전 단계에서 잘못 예측된 데이터에 가중치를 더 부여하면서 모델을 순차적으로 학습시켜 나가는 앙상블 기법은?",
    options: ["배깅(Bagging)", "부스팅(Boosting)", "k-평균 군집분석", "주성분분석(PCA)"],
    answer: 1,
    explanation:
      "부스팅(Boosting)은 이전 모델이 잘못 분류한 데이터에 더 큰 가중치를 부여하여 다음 모델을 순차적으로 학습시키는 방식으로, AdaBoost와 그래디언트 부스팅(GBM) 등이 대표적입니다.",
  },
  {
    id: "du-023",
    subject: "3과목(데이터 분석)",
    question: "군집 분석 결과를 나무 형태의 그림으로 나타내어 군집이 형성되는 과정을 계층적으로 보여주는 시각화 도구는?",
    options: ["히스토그램", "산점도(Scatter Plot)", "덴드로그램(Dendrogram)", "박스플롯"],
    answer: 2,
    explanation:
      "덴드로그램(Dendrogram)은 계층적 군집분석(Hierarchical Clustering)의 결과를 나무 형태로 표현한 그림으로, 개체(또는 군집)가 유사도에 따라 단계적으로 결합되는 과정을 보여줍니다.",
  },
  {
    id: "du-024",
    subject: "3과목(데이터 분석)",
    question:
      "연관 규칙 분석(Association Rule)에서 전체 거래 중 항목 A와 항목 B가 동시에 포함된 거래의 비율을 나타내는 지표는?",
    options: ["지지도(Support)", "신뢰도(Confidence)", "향상도(Lift)", "정확도(Accuracy)"],
    answer: 0,
    explanation: "지지도(Support)는 전체 거래 중 항목 A와 B가 동시에 발생한 거래의 비율로, P(A∩B)로 계산됩니다.",
  },
  {
    id: "du-025",
    subject: "3과목(데이터 분석)",
    question: "연관 규칙 분석에서 향상도(Lift)가 1보다 큰 경우가 의미하는 바로 가장 적절한 것은?",
    options: [
      "항목 A와 B는 서로 아무런 관계가 없다",
      "항목 A를 구매했을 때 항목 B를 구매할 가능성이 우연히 기대되는 것보다 높다",
      "항목 A를 구매하면 반드시 항목 B를 구매하지 않는다",
      "지지도가 0이라는 뜻이다",
    ],
    answer: 1,
    explanation:
      "향상도(Lift)는 두 항목이 독립이라고 가정했을 때 대비 실제 연관 정도를 나타내며, 값이 1보다 크면 두 항목 간에 우연 이상의 양의 연관성이 있음을 의미합니다.",
  },
  {
    id: "du-026",
    subject: "3과목(데이터 분석)",
    question: "사분위수 범위(IQR)를 이용한 이상치 판별 기준으로 옳은 것은?",
    options: [
      "제1사분위수(Q1)에서 IQR의 1.5배를 뺀 값보다 작거나, 제3사분위수(Q3)에서 IQR의 1.5배를 더한 값보다 큰 데이터를 이상치로 본다",
      "평균에서 표준편차의 3배를 벗어나야만 이상치로 본다",
      "중앙값과 정확히 일치하지 않는 모든 데이터를 이상치로 본다",
      "데이터의 최댓값과 최솟값만을 이상치로 본다",
    ],
    answer: 0,
    explanation:
      "IQR(사분위수 범위) 기준 이상치 판별법은 일반적으로 Q1 - 1.5×IQR보다 작거나 Q3 + 1.5×IQR보다 큰 값을 이상치로 판단합니다.",
  },
  {
    id: "du-027",
    subject: "3과목(데이터 분석)",
    question: "시계열 데이터의 평균과 분산이 시간의 흐름에 따라 일정하게 유지되는 성질을 무엇이라 하는가?",
    options: ["정상성(Stationarity)", "계절성(Seasonality)", "추세성(Trend)", "자기상관성"],
    answer: 0,
    explanation:
      "정상성(Stationarity)은 시계열의 평균, 분산 등 통계적 성질이 시간에 관계없이 일정하게 유지되는 성질로, 많은 시계열 분석 기법(ARIMA 등)의 전제 조건이 됩니다.",
  },
  {
    id: "du-028",
    subject: "3과목(데이터 분석)",
    question: "R 언어에서 여러 개의 값을 하나의 벡터(Vector)로 결합할 때 사용하는 함수는?",
    options: ["c()", "sum()", "mean()", "length()"],
    answer: 0,
    explanation:
      "R에서 c() 함수는 'combine'의 약자로, 여러 개의 값을 하나의 벡터로 결합할 때 사용됩니다. 예를 들어 c(1, 2, 3)은 세 값을 담은 벡터를 만듭니다.",
  },
  {
    id: "du-029",
    subject: "3과목(데이터 분석)",
    question: "결측값이 있는 관측치를 대표적인 값(예: 평균, 중앙값, 최빈값)으로 채워 넣는 결측치 처리 방법은?",
    options: ["완전 분석법(Listwise Deletion)", "단순 대치법(Single Imputation)", "다중 대치법(Multiple Imputation)", "클러스터링 대치법"],
    answer: 1,
    explanation:
      "단순 대치법(Single Imputation)은 결측값을 평균, 중앙값, 최빈값 등 하나의 대표값으로 채워 넣는 방법입니다. 다중 대치법은 결측값을 여러 번 시뮬레이션하여 여러 개의 완전한 데이터셋을 생성한 후 결합하는 보다 정교한 방법입니다.",
  },
  {
    id: "du-030",
    subject: "3과목(데이터 분석)",
    question: "최솟값, 제1사분위수, 중앙값, 제3사분위수, 최댓값 등 데이터의 분포와 이상치를 한눈에 보여주는 시각화 도구는?",
    options: ["히스토그램", "박스플롯(Box Plot)", "산점도(Scatter Plot)", "파이 차트"],
    answer: 1,
    explanation:
      "박스플롯(Box Plot)은 최솟값, 제1사분위수(Q1), 중앙값, 제3사분위수(Q3), 최댓값 등 5가지 요약 통계량과 이상치를 함께 시각화하는 도구입니다.",
  },
  {
    id: "du-031",
    subject: "3과목(데이터 분석)",
    question: "R 언어에서 여러 개의 값을 담을 수 있지만, 서로 다른 자료형을 동시에 담을 수 있는 자료구조는?",
    options: ["벡터(Vector)", "리스트(List)", "행렬(Matrix)", "배열(Array)"],
    answer: 1,
    explanation:
      "리스트(List)는 숫자, 문자, 벡터, 데이터프레임 등 서로 다른 자료형을 하나의 객체 안에 함께 담을 수 있는 R의 자료구조입니다. 벡터, 행렬, 배열은 원칙적으로 동일한 자료형만 담을 수 있습니다.",
  },
  {
    id: "du-032",
    subject: "3과목(데이터 분석)",
    question: "R에서 결측값을 나타내는 특수한 값은?",
    options: ["NA", "NULL", "0", "빈 문자열"],
    answer: 0,
    explanation:
      "R에서 NA(Not Available)는 값이 존재해야 하지만 알 수 없는 결측값을 나타내는 특수한 값입니다. NULL은 아예 값이 존재하지 않음(길이가 0인 객체)을 의미합니다.",
  },
  {
    id: "du-033",
    subject: "3과목(데이터 분석)",
    question: "R에서 벡터나 데이터프레임의 각 값이 결측값(NA)인지 여부를 논리값으로 반환하는 함수는?",
    options: ["is.na()", "as.na()", "na.omit()", "which.na()"],
    answer: 0,
    explanation:
      "is.na() 함수는 벡터나 데이터프레임의 각 원소가 결측값(NA)인지 여부를 TRUE/FALSE의 논리값으로 반환합니다.",
  },
  {
    id: "du-034",
    subject: "3과목(데이터 분석)",
    question: "R에서 범주형(명목형/순서형) 데이터를 표현하기 위해 사용하는 자료형은?",
    options: ["factor(팩터)", "numeric", "character만 사용", "logical"],
    answer: 0,
    explanation:
      "R에서 factor(팩터)는 성별, 등급과 같은 범주형 데이터를 표현하기 위한 자료형으로, 내부적으로 각 범주에 정수 코드를 부여하여 관리합니다.",
  },
  {
    id: "du-035",
    subject: "3과목(데이터 분석)",
    question: "R의 dplyr 패키지에서 조건에 맞는 행(row)만 선택할 때 사용하는 함수는?",
    options: ["filter()", "select()", "mutate()", "arrange()"],
    answer: 0,
    explanation:
      "dplyr 패키지의 filter() 함수는 지정한 조건을 만족하는 행만을 선택하여 데이터프레임의 부분집합을 만드는 데 사용됩니다.",
  },
  {
    id: "du-036",
    subject: "3과목(데이터 분석)",
    question: "R의 dplyr 패키지에서 특정 열(column)만 선택할 때 사용하는 함수는?",
    options: ["select()", "filter()", "summarize()", "group_by()"],
    answer: 0,
    explanation:
      "dplyr 패키지의 select() 함수는 데이터프레임에서 필요한 특정 열(변수)만을 선택할 때 사용합니다.",
  },
  {
    id: "du-037",
    subject: "3과목(데이터 분석)",
    question: "R의 dplyr 패키지에서 기존 변수를 이용해 새로운 파생 변수를 추가할 때 사용하는 함수는?",
    options: ["mutate()", "filter()", "select()", "arrange()"],
    answer: 0,
    explanation:
      "dplyr 패키지의 mutate() 함수는 기존 변수를 연산하여 새로운 파생 변수를 데이터프레임에 추가할 때 사용합니다.",
  },
  {
    id: "du-038",
    subject: "3과목(데이터 분석)",
    question: "R의 dplyr 패키지에서 특정 기준으로 데이터를 그룹화한 뒤 그룹별 요약 통계량을 계산할 때 함께 사용하는 함수 조합은?",
    options: ["group_by()와 summarize()", "filter()와 select()", "mutate()와 arrange()", "rename()과 relocate()"],
    answer: 0,
    explanation:
      "group_by()로 특정 변수 기준으로 데이터를 그룹화한 뒤, summarize()를 통해 그룹별 평균, 합계 등 요약 통계량을 계산하는 것이 dplyr의 대표적인 사용 패턴입니다.",
  },
  {
    id: "du-039",
    subject: "3과목(데이터 분석)",
    question: "R에서 데이터를 특정 열의 값을 기준으로 정렬할 때 사용하는 dplyr 함수는?",
    options: ["arrange()", "filter()", "select()", "mutate()"],
    answer: 0,
    explanation:
      "dplyr의 arrange() 함수는 지정한 열의 값을 기준으로 데이터프레임의 행을 오름차순 또는 내림차순으로 정렬합니다.",
  },
  {
    id: "du-040",
    subject: "3과목(데이터 분석)",
    question: "R에서 데이터 시각화를 위해 널리 사용되는, 레이어를 겹겹이 쌓아 그래프를 구성하는 방식의 패키지는?",
    options: ["ggplot2", "dplyr", "tidyr", "readr"],
    answer: 0,
    explanation:
      "ggplot2는 데이터, 좌표축, 기하 객체(geom) 등의 레이어를 겹겹이 쌓아 그래프를 구성하는 '그래픽 문법(Grammar of Graphics)'에 기반한 R의 대표적인 시각화 패키지입니다.",
  },
  {
    id: "du-041",
    subject: "3과목(데이터 분석)",
    question: "R에서 벡터나 리스트의 각 원소에 동일한 함수를 반복 적용하기 위해 사용하는 apply 계열 함수가 아닌 것은?",
    options: ["sapply()", "lapply()", "apply()", "install.packages()"],
    answer: 3,
    explanation:
      "sapply(), lapply(), apply()는 벡터, 리스트, 행렬 등에 함수를 반복 적용하는 apply 계열 함수입니다. install.packages()는 패키지를 설치하는 함수로 apply 계열이 아닙니다.",
  },
  {
    id: "du-042",
    subject: "3과목(데이터 분석)",
    question: "R에서 데이터프레임이나 벡터의 구조(자료형, 크기 등)를 간략하게 요약하여 보여주는 함수는?",
    options: ["str()", "sum()", "mean()", "sort()"],
    answer: 0,
    explanation:
      "str() 함수는 데이터프레임이나 리스트 등 객체의 구조(변수의 자료형, 개수, 미리보기 값 등)를 간략하게 요약하여 보여줍니다.",
  },
  {
    id: "du-043",
    subject: "3과목(데이터 분석)",
    question: "R에서 벡터나 데이터프레임의 기술통계 요약(최솟값, 사분위수, 평균, 최댓값 등)을 한 번에 출력하는 함수는?",
    options: ["summary()", "str()", "length()", "class()"],
    answer: 0,
    explanation:
      "summary() 함수는 벡터나 데이터프레임에 대해 최솟값, 제1사분위수, 중앙값, 평균, 제3사분위수, 최댓값 등의 기술통계 요약을 한 번에 출력합니다.",
  },
  {
    id: "du-044",
    subject: "3과목(데이터 분석)",
    question: "Python pandas에서 데이터프레임의 처음 몇 개 행을 미리 확인할 때 사용하는 메서드는?",
    options: ["head()", "tail()", "describe()", "info()"],
    answer: 0,
    explanation:
      "pandas의 head() 메서드는 데이터프레임의 처음 몇 개(기본 5개) 행을 출력하여 데이터를 미리 확인하는 데 사용됩니다.",
  },
  {
    id: "du-045",
    subject: "3과목(데이터 분석)",
    question: "Python pandas에서 데이터프레임의 각 열에 대한 개수, 평균, 표준편차 등 기술통계를 요약해서 보여주는 메서드는?",
    options: ["describe()", "head()", "info()", "shape"],
    answer: 0,
    explanation:
      "pandas의 describe() 메서드는 수치형 열에 대한 개수, 평균, 표준편차, 최솟값, 사분위수, 최댓값 등의 기술통계 요약을 제공합니다.",
  },
  {
    id: "du-046",
    subject: "3과목(데이터 분석)",
    question: "정규분포(Normal Distribution)의 특징으로 옳은 것은?",
    options: [
      "평균을 중심으로 좌우 대칭인 종 모양의 분포이다",
      "항상 0과 1 사이의 값만을 가진다",
      "이산형 확률변수에만 적용되는 분포이다",
      "왜도(Skewness)가 항상 0이 아니다",
    ],
    answer: 0,
    explanation:
      "정규분포는 평균을 중심으로 좌우 대칭인 종 모양의 연속확률분포로, 평균과 중앙값, 최빈값이 모두 일치하며 왜도는 0입니다.",
  },
  {
    id: "du-047",
    subject: "3과목(데이터 분석)",
    question: "평균이 0이고 표준편차가 1인 정규분포를 특별히 무엇이라 하는가?",
    options: ["표준정규분포(Standard Normal Distribution)", "이항분포", "포아송분포", "균등분포"],
    answer: 0,
    explanation:
      "표준정규분포는 평균이 0, 표준편차가 1인 정규분포로, 임의의 정규분포를 표준화(Z-score 변환)하면 표준정규분포를 따르게 됩니다.",
  },
  {
    id: "du-048",
    subject: "3과목(데이터 분석)",
    question: "성공 확률이 p로 일정한 독립적인 시행을 n번 반복할 때, 성공 횟수가 따르는 이산확률분포는?",
    options: ["이항분포(Binomial Distribution)", "정규분포", "지수분포", "균등분포"],
    answer: 0,
    explanation:
      "이항분포는 성공 확률이 p로 일정한 베르누이 시행을 독립적으로 n번 반복했을 때, 성공한 횟수가 따르는 이산확률분포입니다.",
  },
  {
    id: "du-049",
    subject: "3과목(데이터 분석)",
    question: "일정한 시간이나 공간 내에서 특정 사건이 발생하는 횟수를 나타내는 데 주로 사용되는 이산확률분포는?",
    options: ["포아송분포(Poisson Distribution)", "정규분포", "t분포", "F분포"],
    answer: 0,
    explanation:
      "포아송분포는 일정한 시간이나 공간 내에서 어떤 사건이 발생하는 횟수를 모형화하는 데 사용되는 이산확률분포로, 콜센터 문의 건수, 특정 시간당 사고 발생 건수 등을 예로 들 수 있습니다.",
  },
  {
    id: "du-050",
    subject: "3과목(데이터 분석)",
    question: "표본의 크기가 작고 모분산을 알 수 없을 때 모평균을 추정하는 데 주로 사용되며, 정규분포보다 꼬리가 두꺼운 분포는?",
    options: ["t분포(t-distribution)", "이항분포", "포아송분포", "베르누이분포"],
    answer: 0,
    explanation:
      "t분포는 표본의 크기가 작고 모분산을 모를 때 모평균을 추정하거나 검정하는 데 사용되는 분포로, 자유도가 작을수록 정규분포보다 꼬리가 두꺼운 모양을 가집니다.",
  },
  {
    id: "du-051",
    subject: "3과목(데이터 분석)",
    question: "범주형 자료의 적합도 검정이나 독립성 검정에 주로 사용되는 확률분포는?",
    options: ["카이제곱분포(Chi-Square Distribution)", "정규분포", "t분포", "지수분포"],
    answer: 0,
    explanation:
      "카이제곱분포는 관찰된 빈도와 기대되는 빈도의 차이를 검정하는 적합도 검정이나, 두 범주형 변수 간의 독립성을 검정할 때 주로 사용되는 확률분포입니다.",
  },
  {
    id: "du-052",
    subject: "3과목(데이터 분석)",
    question: "두 집단 이상의 분산의 비(比)를 검정할 때, 그리고 분산분석(ANOVA)에서 활용되는 확률분포는?",
    options: ["F분포(F-distribution)", "정규분포", "이항분포", "포아송분포"],
    answer: 0,
    explanation:
      "F분포는 두 집단의 분산 비율을 검정하거나, 분산분석(ANOVA)에서 집단 간 분산과 집단 내 분산의 비율(F통계량)을 검정하는 데 사용되는 확률분포입니다.",
  },
  {
    id: "du-053",
    subject: "3과목(데이터 분석)",
    question: "데이터 분포의 좌우 비대칭 정도를 나타내는 통계량은?",
    options: ["왜도(Skewness)", "첨도(Kurtosis)", "분산(Variance)", "공분산(Covariance)"],
    answer: 0,
    explanation:
      "왜도(Skewness)는 데이터 분포가 평균을 기준으로 좌우로 얼마나 비대칭적으로 치우쳐 있는지를 나타내는 통계량입니다.",
  },
  {
    id: "du-054",
    subject: "3과목(데이터 분석)",
    question: "데이터 분포가 정규분포에 비해 얼마나 뾰족하거나 완만한지를 나타내는 통계량은?",
    options: ["첨도(Kurtosis)", "왜도(Skewness)", "표준편차", "중앙값"],
    answer: 0,
    explanation:
      "첨도(Kurtosis)는 데이터 분포의 뾰족한 정도를 나타내는 통계량으로, 정규분포에 비해 꼬리가 두껍고 뾰족하면 첨도가 크고, 완만하면 첨도가 작습니다.",
  },
  {
    id: "du-055",
    subject: "3과목(데이터 분석)",
    question: "표본평균의 표준편차로, 표본을 통해 추정한 모수의 정밀도를 나타내는 지표는?",
    options: ["표준오차(Standard Error)", "표준편차(Standard Deviation)", "분산(Variance)", "범위(Range)"],
    answer: 0,
    explanation:
      "표준오차(SE)는 표본평균과 같은 표본 통계량의 표준편차로, 표본을 통해 추정한 모수 값이 얼마나 정밀한지를 나타내는 지표이며, 표본 크기가 커질수록 작아집니다.",
  },
  {
    id: "du-056",
    subject: "3과목(데이터 분석)",
    question: "모수(예: 모평균)가 일정한 확률로 포함될 것으로 추정되는 범위를 무엇이라 하는가?",
    options: ["신뢰구간(Confidence Interval)", "유의수준", "표준오차", "왜도"],
    answer: 0,
    explanation:
      "신뢰구간은 표본 데이터를 바탕으로, 모수(예: 모평균)가 일정한 신뢰수준(예: 95%)으로 포함될 것으로 추정되는 값의 범위를 의미합니다.",
  },
  {
    id: "du-057",
    subject: "3과목(데이터 분석)",
    question: "회귀분석에서 회귀계수를 추정할 때, 실제값과 예측값의 차이(잔차)의 제곱합을 최소화하는 방법은?",
    options: ["최소제곱법(OLS, Ordinary Least Squares)", "최대우도법", "경사하강법만 해당", "베이즈 추정법"],
    answer: 0,
    explanation:
      "최소제곱법(OLS)은 실제 관측값과 회귀식에 의한 예측값의 차이(잔차)를 제곱하여 합한 값(잔차제곱합)이 최소가 되도록 회귀계수를 추정하는 방법입니다.",
  },
  {
    id: "du-058",
    subject: "3과목(데이터 분석)",
    question: "회귀분석에서 실제 관측값과 회귀모형에 의한 예측값의 차이를 무엇이라 하는가?",
    options: ["잔차(Residual)", "결정계수", "회귀계수", "상관계수"],
    answer: 0,
    explanation:
      "잔차(Residual)는 회귀분석에서 실제 관측된 종속변수 값과, 회귀모형이 예측한 값 사이의 차이를 의미합니다.",
  },
  {
    id: "du-059",
    subject: "3과목(데이터 분석)",
    question: "선형회귀분석의 기본 가정 중, 잔차들의 분산이 독립변수 값에 관계없이 일정해야 한다는 가정은?",
    options: ["등분산성(Homoscedasticity)", "정규성", "독립성", "선형성"],
    answer: 0,
    explanation:
      "등분산성은 회귀모형의 잔차들이 독립변수의 값과 관계없이 일정한 분산을 가져야 한다는 가정으로, 이 가정이 위배되면 이분산성(Heteroscedasticity) 문제가 발생합니다.",
  },
  {
    id: "du-060",
    subject: "3과목(데이터 분석)",
    question: "선형회귀분석의 기본 가정 중, 잔차들이 서로 상관되지 않아야 한다는 가정을 검정하는 데 사용되는 통계량은?",
    options: ["더빈-왓슨 통계량(Durbin-Watson Statistic)", "결정계수(R²)", "F통계량", "카이제곱 통계량"],
    answer: 0,
    explanation:
      "더빈-왓슨 통계량은 회귀모형의 잔차들 간에 자기상관(Autocorrelation)이 존재하는지를 검정하는 데 사용되며, 일반적으로 2에 가까울수록 자기상관이 없다고 판단합니다.",
  },
  {
    id: "du-061",
    subject: "3과목(데이터 분석)",
    question: "다중회귀분석에서 유의미한 독립변수만을 선택하기 위해, 변수를 하나씩 추가해 나가며 모형을 구축하는 변수 선택법은?",
    options: ["전진선택법(Forward Selection)", "후진제거법(Backward Elimination)", "주성분분석", "군집분석"],
    answer: 0,
    explanation:
      "전진선택법은 독립변수가 하나도 없는 모형에서 시작하여, 통계적으로 가장 유의미한 변수를 하나씩 추가해 나가며 최종 모형을 구축하는 변수 선택법입니다.",
  },
  {
    id: "du-062",
    subject: "3과목(데이터 분석)",
    question: "다중회귀분석에서 모든 독립변수를 포함한 모형에서 시작하여, 유의하지 않은 변수를 하나씩 제거해 나가는 변수 선택법은?",
    options: ["후진제거법(Backward Elimination)", "전진선택법", "K-Means 군집분석", "주성분분석"],
    answer: 0,
    explanation:
      "후진제거법은 모든 독립변수를 포함한 완전 모형에서 출발하여, 통계적으로 유의하지 않은 변수를 하나씩 제거해 나가며 최종 모형을 구축하는 변수 선택법입니다.",
  },
  {
    id: "du-063",
    subject: "3과목(데이터 분석)",
    question: "변수 선택법 중, 전진선택과 후진제거를 반복적으로 결합하여 변수를 추가하거나 제거하며 모형을 구축하는 방법은?",
    options: ["단계적 선택법(Stepwise Selection)", "주성분분석", "군집분석", "연관규칙분석"],
    answer: 0,
    explanation:
      "단계적 선택법은 전진선택과 후진제거 과정을 반복적으로 번갈아 수행하며, 매 단계마다 변수를 추가하거나 제거하여 최적의 모형을 찾아가는 변수 선택법입니다.",
  },
  {
    id: "du-064",
    subject: "3과목(데이터 분석)",
    question: "회귀계수를 각 변수의 단위에 관계없이 비교할 수 있도록 표준화한 계수를 무엇이라 하는가?",
    options: ["표준화 회귀계수(Standardized Coefficient)", "결정계수", "상관계수", "공분산"],
    answer: 0,
    explanation:
      "표준화 회귀계수는 독립변수와 종속변수를 표준화(평균 0, 표준편차 1)한 뒤 추정한 회귀계수로, 단위가 서로 다른 변수들 간의 상대적인 영향력을 비교하는 데 사용됩니다.",
  },
  {
    id: "du-065",
    subject: "3과목(데이터 분석)",
    question: "이진 분류를 위한 의사결정나무 알고리즘으로, 각 노드에서 데이터를 반드시 두 개의 자식 노드로만 분리하는 알고리즘은?",
    options: ["CART(Classification And Regression Tree)", "K-Means", "PCA", "SVM"],
    answer: 0,
    explanation:
      "CART는 각 분리 노드에서 데이터를 항상 이진(두 개)으로 분리하는 의사결정나무 알고리즘으로, 분류와 회귀 문제 모두에 사용할 수 있습니다.",
  },
  {
    id: "du-066",
    subject: "3과목(데이터 분석)",
    question: "의사결정나무 모델이 학습 데이터에 지나치게 맞춰져 과적합되는 것을 방지하기 위해, 트리의 크기를 사후에 줄이는 기법은?",
    options: ["가지치기(Pruning)", "부스팅", "정규화", "인코딩"],
    answer: 0,
    explanation:
      "가지치기(Pruning)는 완전히 성장한 의사결정나무의 일부 가지(하위 노드)를 제거하여 트리의 크기를 줄임으로써, 학습 데이터에 대한 과적합을 방지하고 일반화 성능을 높이는 기법입니다.",
  },
  {
    id: "du-067",
    subject: "3과목(데이터 분석)",
    question: "데이터를 분류할 때, 두 클래스를 가장 잘 구분하는 마진(여백)이 최대가 되는 초평면을 찾는 분류 알고리즘은?",
    options: ["서포트벡터머신(SVM, Support Vector Machine)", "K-Means", "선형회귀", "주성분분석"],
    answer: 0,
    explanation:
      "서포트벡터머신(SVM)은 두 클래스를 구분하는 여러 경계(초평면) 중, 클래스 간 마진(여백)이 최대가 되는 초평면을 찾아 분류하는 알고리즘입니다.",
  },
  {
    id: "du-068",
    subject: "3과목(데이터 분석)",
    question: "SVM에서 선형적으로 분리되지 않는 데이터를 고차원 공간으로 매핑하여 분리 가능하게 만드는 기법은?",
    options: ["커널 트릭(Kernel Trick)", "가지치기", "부스팅", "정규화"],
    answer: 0,
    explanation:
      "커널 트릭은 원래 공간에서 선형적으로 분리되지 않는 데이터를, 실제 계산 없이도 고차원 공간으로 매핑한 것과 같은 효과를 내어 비선형 분류를 가능하게 하는 SVM의 핵심 기법입니다.",
  },
  {
    id: "du-069",
    subject: "3과목(데이터 분석)",
    question: "새로운 데이터를 분류할 때, 학습 데이터 중 가장 가까운 K개의 이웃을 찾아 다수결로 클래스를 예측하는 알고리즘은?",
    options: ["K-최근접이웃(KNN, K-Nearest Neighbors)", "K-Means 클러스터링", "선형회귀", "주성분분석"],
    answer: 0,
    explanation:
      "KNN(K-최근접이웃)은 새로운 데이터 포인트로부터 가장 가까운 K개의 학습 데이터(이웃)를 찾아, 그 이웃들의 다수 클래스로 새로운 데이터를 분류하는 지도학습 알고리즘입니다.",
  },
  {
    id: "du-070",
    subject: "3과목(데이터 분석)",
    question: "인공신경망을 구성하는 가장 기본적인 단위로, 여러 입력값에 가중치를 곱해 합산한 뒤 활성화 함수를 적용하는 구조는?",
    options: ["퍼셉트론(Perceptron)", "의사결정나무", "군집", "연관규칙"],
    answer: 0,
    explanation:
      "퍼셉트론은 인공신경망의 가장 기본적인 단위로, 여러 입력값에 각각의 가중치를 곱해 합산한 뒤 활성화 함수를 통과시켜 출력값을 내보내는 구조입니다.",
  },
  {
    id: "du-071",
    subject: "3과목(데이터 분석)",
    question: "인공신경망에서 뉴런의 출력값이 다음 층으로 전달될지를 결정하기 위해 비선형성을 부여하는 함수를 무엇이라 하는가?",
    options: ["활성화 함수(Activation Function)", "손실 함수", "목적 함수", "커널 함수"],
    answer: 0,
    explanation:
      "활성화 함수는 뉴런에 입력된 가중합에 비선형성을 부여하여 신경망이 복잡한 패턴을 학습할 수 있게 해주는 함수로, 시그모이드, ReLU, tanh 등이 대표적입니다.",
  },
  {
    id: "du-072",
    subject: "3과목(데이터 분석)",
    question: "인공신경망 학습 시, 출력층에서 발생한 오차를 입력층 방향으로 전파하며 각 층의 가중치를 갱신하는 알고리즘은?",
    options: ["역전파(Backpropagation)", "순전파(Forward Propagation)만 해당", "가지치기", "부스팅"],
    answer: 0,
    explanation:
      "역전파(Backpropagation)는 신경망의 최종 출력값과 실제값의 오차를 출력층에서 입력층 방향으로 거꾸로 전파하면서, 각 층의 가중치를 오차가 줄어드는 방향으로 갱신하는 신경망 학습 알고리즘입니다.",
  },
  {
    id: "du-073",
    subject: "3과목(데이터 분석)",
    question: "계층적 군집분석에서, 두 군집 간의 거리를 각 군집에 속한 데이터 중 가장 가까운 두 점 사이의 거리로 정의하는 연결법은?",
    options: ["단일연결법(Single Linkage)", "완전연결법(Complete Linkage)", "평균연결법(Average Linkage)", "와드연결법(Ward's Method)"],
    answer: 0,
    explanation:
      "단일연결법(최단연결법)은 두 군집 간의 거리를, 각 군집에 속한 데이터들 중 가장 가까운 한 쌍의 거리로 정의하는 계층적 군집분석의 연결법입니다.",
  },
  {
    id: "du-074",
    subject: "3과목(데이터 분석)",
    question: "계층적 군집분석에서, 두 군집 간의 거리를 각 군집에 속한 데이터 중 가장 먼 두 점 사이의 거리로 정의하는 연결법은?",
    options: ["완전연결법(Complete Linkage)", "단일연결법", "평균연결법", "중심연결법"],
    answer: 0,
    explanation:
      "완전연결법(최장연결법)은 두 군집 간의 거리를, 각 군집에 속한 데이터들 중 가장 먼 한 쌍의 거리로 정의하는 계층적 군집분석의 연결법입니다.",
  },
  {
    id: "du-075",
    subject: "3과목(데이터 분석)",
    question: "K-Means 군집분석 알고리즘의 일반적인 수행 절차로 옳은 것은?",
    options: [
      "K개의 초기 중심 설정 → 각 데이터를 가장 가까운 중심에 할당 → 군집별 평균으로 중심 재계산 → 수렴할 때까지 반복",
      "군집 개수를 먼저 무한대로 설정 → 데이터를 무작위로 섞음 → 종료",
      "모든 데이터를 하나의 군집으로 병합 → 종료",
      "데이터를 정렬 → 중앙값을 기준으로 무조건 2개로 나눔 → 종료",
    ],
    answer: 0,
    explanation:
      "K-Means는 K개의 초기 중심(centroid)을 설정한 뒤, 각 데이터를 가장 가까운 중심의 군집에 할당하고, 각 군집의 평균으로 중심을 다시 계산하는 과정을 중심이 더 이상 변하지 않을 때까지 반복합니다.",
  },
  {
    id: "du-076",
    subject: "3과목(데이터 분석)",
    question: "고차원의 데이터를 저차원(주로 2차원)의 격자 형태로 매핑하여 시각화하는 비지도학습 기반의 인공신경망 기법은?",
    options: ["자기조직화지도(SOM, Self-Organizing Map)", "역전파 신경망", "합성곱 신경망(CNN)", "순환 신경망(RNN)"],
    answer: 0,
    explanation:
      "자기조직화지도(SOM)는 고차원의 입력 데이터를 저차원(주로 2차원)의 격자 형태 뉴런 배열에 매핑하여, 유사한 데이터가 가까운 위치에 놓이도록 시각화하는 비지도학습 신경망 기법입니다.",
  },
  {
    id: "du-077",
    subject: "3과목(데이터 분석)",
    question: "군집분석의 결과가 얼마나 잘 형성되었는지를 평가하기 위해, 개별 데이터가 자신이 속한 군집과 다른 군집에 얼마나 가까운지를 -1에서 1 사이의 값으로 나타내는 지표는?",
    options: ["실루엣 계수(Silhouette Coefficient)", "지지도", "신뢰도", "향상도"],
    answer: 0,
    explanation:
      "실루엣 계수는 -1부터 1까지의 값을 가지며, 개별 데이터가 자신이 속한 군집 내 다른 데이터와는 가깝고 다른 군집과는 먼 정도를 측정하여 군집화의 품질을 평가하는 지표입니다.",
  },
  {
    id: "du-078",
    subject: "3과목(데이터 분석)",
    question: "연관 규칙 분석에서 빈발 항목집합을 효율적으로 탐색하기 위해, 최소 지지도 이상인 항목집합만을 대상으로 탐색 범위를 줄여나가는 대표적인 알고리즘은?",
    options: ["Apriori 알고리즘", "K-Means 알고리즘", "CART 알고리즘", "SVM 알고리즘"],
    answer: 0,
    explanation:
      "Apriori 알고리즘은 '빈발 항목집합의 부분집합은 반드시 빈발하다'는 원리를 이용하여, 최소 지지도 이상인 항목집합만을 대상으로 탐색 범위를 효율적으로 줄여가며 연관 규칙을 생성하는 대표적인 알고리즘입니다.",
  },
  {
    id: "du-079",
    subject: "3과목(데이터 분석)",
    question: "연관 규칙 분석에서 '조건부 확률'의 개념으로, 항목 A를 구매한 거래 중에서 항목 B도 함께 구매한 거래의 비율을 나타내는 지표는?",
    options: ["신뢰도(Confidence)", "지지도(Support)", "향상도(Lift)", "정확도(Accuracy)"],
    answer: 0,
    explanation:
      "신뢰도(Confidence)는 항목 A를 포함하는 거래 중에서, 항목 B도 함께 포함된 거래의 비율(조건부 확률 P(B|A))을 나타내는 연관 규칙 분석의 지표입니다.",
  },
  {
    id: "du-080",
    subject: "3과목(데이터 분석)",
    question: "여러 개의 의사결정나무를 배깅(Bagging) 방식으로 학습시키되, 각 트리를 만들 때 후보 변수의 일부만 무작위로 선택하여 다양성을 높이는 앙상블 알고리즘은?",
    options: ["랜덤 포레스트(Random Forest)", "K-Means", "PCA", "SVM"],
    answer: 0,
    explanation:
      "랜덤 포레스트는 배깅 방식으로 여러 개의 의사결정나무를 학습시키되, 각 분할 시점마다 전체 변수 중 일부를 무작위로 선택하여 후보로 사용함으로써 트리 간의 상관성을 낮추고 예측 성능을 향상시키는 앙상블 알고리즘입니다.",
  },

  {
    id: "du-081",
    subject: "3과목(데이터 분석)",
    question: "여러 개의 약한 모델을 순차적으로 학습시키되, 이전 모델이 잘못 예측한 부분에 가중치를 두어 다음 모델을 학습시키는 방식으로 잔차를 줄여나가는 앙상블 기법은?",
    options: ["그래디언트 부스팅(Gradient Boosting)", "K-Means 군집분석", "주성분분석(PCA)", "선형판별분석"],
    answer: 0,
    explanation:
      "그래디언트 부스팅은 이전 단계 모델의 오차(잔차)를 다음 모델이 학습하도록 순차적으로 모델을 추가해 나가는 부스팅 계열의 앙상블 기법으로, 오차를 점진적으로 줄여나가는 것이 특징입니다.",
  },
  {
    id: "du-082",
    subject: "3과목(데이터 분석)",
    question: "그래디언트 부스팅을 병렬 처리와 정규화 기법 등으로 최적화하여 속도와 성능을 크게 개선한 대표적인 구현체는?",
    options: ["XGBoost", "K-Means", "Apriori", "SOM"],
    answer: 0,
    explanation:
      "XGBoost(Extreme Gradient Boosting)는 그래디언트 부스팅 알고리즘에 병렬 처리, 정규화 항 추가 등의 최적화를 적용하여 학습 속도와 예측 성능을 크게 개선한 대표적인 부스팅 라이브러리입니다.",
  },
  {
    id: "du-083",
    subject: "3과목(데이터 분석)",
    question: "분류 모델의 성능을 평가할 때, 민감도(재현율)와 (1-특이도)의 관계를 임계값 변화에 따라 그래프로 나타낸 것은?",
    options: ["ROC 곡선(Receiver Operating Characteristic Curve)", "박스플롯", "산점도", "덴드로그램"],
    answer: 0,
    explanation:
      "ROC 곡선은 분류 모델의 임계값(threshold)을 변화시켜 가며, 민감도(TPR)와 1-특이도(FPR)의 관계를 그래프로 나타낸 것으로, 분류 모델의 성능을 시각적으로 평가하는 데 사용됩니다.",
  },
  {
    id: "du-084",
    subject: "3과목(데이터 분석)",
    question: "ROC 곡선 아래의 면적으로, 1에 가까울수록 분류 모델의 성능이 우수함을 나타내는 지표는?",
    options: ["AUC(Area Under the Curve)", "지지도", "신뢰도", "향상도"],
    answer: 0,
    explanation:
      "AUC는 ROC 곡선 아래의 면적을 의미하며, 0.5에 가까우면 무작위 분류 수준, 1에 가까울수록 모델의 분류 성능이 우수함을 나타내는 지표입니다.",
  },
  {
    id: "du-085",
    subject: "3과목(데이터 분석)",
    question: "정밀도(Precision)와 재현율(Recall)의 조화평균으로 계산되는, 두 지표를 함께 고려하는 평가 지표는?",
    options: ["F1-score", "결정계수(R²)", "AUC", "실루엣 계수"],
    answer: 0,
    explanation:
      "F1-score는 정밀도와 재현율의 조화평균으로 계산되며, 두 지표 중 하나만 극단적으로 높은 경우를 방지하고 균형 잡힌 성능을 평가하는 데 사용되는 지표입니다.",
  },
  {
    id: "du-086",
    subject: "3과목(데이터 분석)",
    question: "전체 데이터를 K개의 폴드(fold)로 나누어, 그 중 하나를 검증용으로, 나머지를 학습용으로 사용하는 과정을 K번 반복하는 교차검증 방법은?",
    options: ["K-fold 교차검증", "홀드아웃(Holdout) 검증만 해당", "부트스트랩", "정규화"],
    answer: 0,
    explanation:
      "K-fold 교차검증은 전체 데이터를 K개의 폴드로 나눈 뒤, 매번 하나의 폴드를 검증 데이터로, 나머지 K-1개를 학습 데이터로 사용하는 과정을 K번 반복하여 모델의 일반화 성능을 평가하는 방법입니다.",
  },
  {
    id: "du-087",
    subject: "3과목(데이터 분석)",
    question: "전체 데이터 중 단 하나의 관측치만을 검증 데이터로 사용하고 나머지 전부를 학습에 사용하는 과정을, 데이터 개수만큼 반복하는 교차검증 방법은?",
    options: ["LOOCV(Leave-One-Out Cross Validation)", "K-fold 교차검증", "홀드아웃 검증", "부트스트랩"],
    answer: 0,
    explanation:
      "LOOCV는 데이터가 n개일 때, 매번 단 하나의 관측치만을 검증 데이터로 남기고 나머지 n-1개로 학습하는 과정을 n번 반복하는 교차검증 방법으로, 데이터가 적을 때 유용하지만 계산 비용이 큽니다.",
  },
  {
    id: "du-088",
    subject: "3과목(데이터 분석)",
    question: "시계열 데이터의 정상성(Stationarity) 여부를 통계적으로 검정하는 데 사용되는 대표적인 검정 방법은?",
    options: ["ADF 검정(Augmented Dickey-Fuller Test)", "카이제곱 검정", "T-검정", "F-검정"],
    answer: 0,
    explanation:
      "ADF 검정(확장 디키-풀러 검정)은 시계열 데이터가 정상성을 만족하는지(단위근이 존재하지 않는지)를 통계적으로 검정하는 데 널리 사용되는 방법입니다.",
  },
  {
    id: "du-089",
    subject: "3과목(데이터 분석)",
    question: "비정상 시계열을 정상 시계열로 변환하기 위해, 현재 시점의 값에서 이전 시점의 값을 빼는 처리를 무엇이라 하는가?",
    options: ["차분(Differencing)", "정규화", "표준화", "샘플링"],
    answer: 0,
    explanation:
      "차분(Differencing)은 현재 시점의 값에서 바로 이전 시점의 값을 빼는 처리로, 추세가 있는 비정상 시계열을 정상 시계열로 변환하는 데 사용됩니다.",
  },
  {
    id: "du-090",
    subject: "3과목(데이터 분석)",
    question: "ARIMA(p, d, q) 모형에서 'd'가 의미하는 것은?",
    options: ["정상성을 확보하기 위해 수행한 차분의 횟수", "자기회귀 차수", "이동평균 차수", "계절 주기"],
    answer: 0,
    explanation:
      "ARIMA(p, d, q) 모형에서 d는 시계열을 정상 시계열로 만들기 위해 수행한 차분(Differencing)의 횟수를 의미합니다. p는 자기회귀(AR) 차수, q는 이동평균(MA) 차수를 의미합니다.",
  },
  {
    id: "du-091",
    subject: "3과목(데이터 분석)",
    question: "시계열 데이터에서 특정 시차(lag)만큼 떨어진 값들 간의 상관관계를 나타내는 함수는?",
    options: ["자기상관함수(ACF, AutoCorrelation Function)", "결정계수", "신뢰도", "향상도"],
    answer: 0,
    explanation:
      "자기상관함수(ACF)는 시계열 데이터에서 특정 시차(lag)만큼 떨어진 두 시점의 값들 간의 상관관계를 나타내며, MA(이동평균) 모형의 차수를 결정하는 데 참고됩니다.",
  },
  {
    id: "du-092",
    subject: "3과목(데이터 분석)",
    question: "시계열 데이터에서 다른 시차의 영향을 제거한 후, 두 시점 간의 순수한 상관관계만을 나타내는 함수는?",
    options: ["편자기상관함수(PACF, Partial AutoCorrelation Function)", "자기상관함수(ACF)", "결정계수", "표준오차"],
    answer: 0,
    explanation:
      "편자기상관함수(PACF)는 중간 시차들의 영향을 제거한 후, 특정 시차만큼 떨어진 두 시점 간의 순수한 상관관계를 나타내며, AR(자기회귀) 모형의 차수를 결정하는 데 참고됩니다.",
  },
  {
    id: "du-093",
    subject: "3과목(데이터 분석)",
    question: "데이터의 값을 최솟값 0, 최댓값 1이 되도록 범위를 변환하는 전처리 기법은?",
    options: ["정규화(Normalization, Min-Max Scaling)", "표준화(Standardization)", "원-핫 인코딩", "라벨 인코딩"],
    answer: 0,
    explanation:
      "정규화(Min-Max 정규화)는 데이터의 최솟값을 0, 최댓값을 1로 맞추어 모든 값을 0과 1 사이의 범위로 변환하는 전처리 기법입니다.",
  },
  {
    id: "du-094",
    subject: "3과목(데이터 분석)",
    question: "데이터의 평균을 0, 표준편차를 1로 변환하는 전처리 기법을 무엇이라 하는가?",
    options: ["표준화(Standardization, Z-score Scaling)", "정규화(Min-Max Scaling)", "원-핫 인코딩", "이산화"],
    answer: 0,
    explanation:
      "표준화(Z-score 표준화)는 데이터에서 평균을 빼고 표준편차로 나누어, 변환된 데이터가 평균 0, 표준편차 1을 갖도록 만드는 전처리 기법입니다.",
  },
  {
    id: "du-095",
    subject: "3과목(데이터 분석)",
    question: "범주형 변수를 각 범주마다 0 또는 1의 값을 가지는 여러 개의 이진 변수로 변환하는 인코딩 기법은?",
    options: ["원-핫 인코딩(One-Hot Encoding)", "정규화", "표준화", "차분"],
    answer: 0,
    explanation:
      "원-핫 인코딩은 범주형 변수의 각 범주를 별도의 이진(0 또는 1) 변수로 변환하는 기법으로, 범주 간에 잘못된 순서나 크기 관계가 부여되는 것을 방지합니다.",
  },
  {
    id: "du-096",
    subject: "3과목(데이터 분석)",
    question: "기존 변수들 중 일부를 그대로 선택하여 사용하는 것을 무엇이라 하며, 기존 변수를 조합해 새로운 변수를 만들어내는 것과 구분하는가?",
    options: ["특성 선택(Feature Selection)과 특성 추출(Feature Extraction)", "정규화와 표준화", "차분과 이동평균", "지지도와 신뢰도"],
    answer: 0,
    explanation:
      "특성 선택(Feature Selection)은 기존 변수 중 유용한 일부만을 그대로 선택하는 것이고, 특성 추출(Feature Extraction, 예: PCA)은 기존 변수를 조합・변환하여 새로운 변수를 만들어내는 것으로 구분됩니다.",
  },
  {
    id: "du-097",
    subject: "3과목(데이터 분석)",
    question: "여러 독립변수 간의 상관관계가 높아 회귀계수 추정이 불안정해지는 다중공선성 문제를 진단할 때 사용하는 대표적인 지표는?",
    options: ["분산팽창계수(VIF, Variance Inflation Factor)", "실루엣 계수", "지지도", "카이제곱 통계량"],
    answer: 0,
    explanation:
      "분산팽창계수(VIF)는 독립변수 간의 상관관계로 인해 회귀계수의 분산이 얼마나 부풀려졌는지를 나타내는 지표로, 일반적으로 VIF가 10 이상이면 다중공선성이 심각하다고 판단합니다.",
  },
  {
    id: "du-098",
    subject: "3과목(데이터 분석)",
    question: "다중공선성 문제를 완화하기 위한 방법으로 가장 적절한 것은?",
    options: [
      "상관관계가 높은 변수 중 일부를 제거하거나, 주성분분석(PCA) 등으로 변수를 축소한다",
      "상관관계가 높은 변수를 오히려 더 많이 추가한다",
      "표본의 크기를 극단적으로 줄인다",
      "종속변수를 무작위로 섞는다",
    ],
    answer: 0,
    explanation:
      "다중공선성을 완화하기 위해서는 상관관계가 높은 변수 중 일부를 제거하거나, 주성분분석(PCA) 등을 통해 상관된 변수들을 서로 독립적인 소수의 변수로 축소하는 방법이 활용됩니다.",
  },
  {
    id: "du-099",
    subject: "3과목(데이터 분석)",
    question: "회귀모형에 페널티(penalty) 항을 추가하여 회귀계수의 크기를 축소시킴으로써 과적합과 다중공선성 문제를 완화하는 기법은?",
    options: ["릿지 회귀(Ridge Regression)", "K-Means 군집분석", "덴드로그램", "실루엣 계수 계산"],
    answer: 0,
    explanation:
      "릿지 회귀는 회귀계수 제곱합에 대한 페널티 항을 손실 함수에 추가하여, 회귀계수의 크기를 전반적으로 축소시킴으로써 과적합과 다중공선성 문제를 완화하는 정규화 회귀 기법입니다.",
  },
  {
    id: "du-100",
    subject: "3과목(데이터 분석)",
    question: "릿지 회귀와 달리, 일부 회귀계수를 정확히 0으로 만들어 자동으로 변수 선택 효과를 내는 정규화 회귀 기법은?",
    options: ["라쏘 회귀(Lasso Regression)", "릿지 회귀", "주성분회귀", "다항회귀"],
    answer: 0,
    explanation:
      "라쏘 회귀는 회귀계수 절댓값의 합에 대한 페널티를 부여하는 정규화 기법으로, 릿지 회귀와 달리 일부 계수를 정확히 0으로 만들어 자동으로 변수를 선택하는 효과를 냅니다.",
  },
  {
    id: "du-101",
    subject: "3과목(데이터 분석)",
    question: "종속변수와 여러 독립변수 사이의 선형 관계를 하나의 회귀식으로 나타내는 분석 기법을 무엇이라 하는가?",
    options: ["다중선형회귀분석(Multiple Linear Regression)", "군집분석", "연관규칙분석", "주성분분석"],
    answer: 0,
    explanation:
      "다중선형회귀분석은 하나의 종속변수와 두 개 이상의 독립변수 사이의 선형적인 관계를 하나의 회귀식으로 나타내어 예측 및 설명에 활용하는 통계 기법입니다.",
  },
  {
    id: "du-102",
    subject: "3과목(데이터 분석)",
    question: "서로 상관관계가 있는 여러 변수들을, 정보의 손실을 최소화하면서 서로 독립적인 소수의 새로운 변수(주성분)로 요약하는 기법은?",
    options: ["주성분분석(PCA, Principal Component Analysis)", "요인분석", "판별분석", "군집분석"],
    answer: 0,
    explanation:
      "주성분분석(PCA)은 서로 상관된 여러 변수들의 분산을 최대한 보존하면서, 서로 독립적인 소수의 새로운 변수(주성분)로 요약하여 차원을 축소하는 다변량 분석 기법입니다.",
  },
  {
    id: "du-103",
    subject: "3과목(데이터 분석)",
    question: "여러 변수들 사이에 내재된 공통적인 잠재 요인을 추출하여, 변수들 간의 상관관계를 설명하고자 하는 다변량 분석 기법은?",
    options: ["요인분석(Factor Analysis)", "K-Means 군집분석", "연관규칙분석", "시계열분석"],
    answer: 0,
    explanation:
      "요인분석은 여러 관측 변수들 사이에 내재되어 있는, 직접 관측되지 않는 공통적인 잠재 요인(Factor)을 추출하여 변수 간의 상관관계 구조를 설명하고자 하는 다변량 분석 기법입니다.",
  },
  {
    id: "du-104",
    subject: "3과목(데이터 분석)",
    question: "이미 알려진 집단(범주)들을 가장 잘 구분해주는 변수들의 선형 결합(판별함수)을 찾아, 새로운 관측치가 어느 집단에 속할지 분류하는 기법은?",
    options: ["판별분석(Discriminant Analysis)", "요인분석", "주성분분석", "군집분석"],
    answer: 0,
    explanation:
      "판별분석은 이미 소속 집단(범주)이 알려진 데이터를 이용해, 집단들을 가장 잘 구분하는 변수들의 선형 결합(판별함수)을 도출하고, 이를 새로운 관측치의 분류에 활용하는 다변량 분석 기법입니다.",
  },
  {
    id: "du-105",
    subject: "3과목(데이터 분석)",
    question: "종속변수가 3개 이상의 순서 없는 범주를 가질 때 사용하는 회귀분석 기법은?",
    options: ["다항 로지스틱 회귀(Multinomial Logistic Regression)", "단순선형회귀", "다중선형회귀", "릿지 회귀"],
    answer: 0,
    explanation:
      "다항 로지스틱 회귀는 종속변수가 순서가 없는 3개 이상의 범주(예: 브랜드 선택)를 가질 때, 각 범주에 속할 확률을 추정하기 위해 사용하는 로지스틱 회귀의 확장 기법입니다.",
  },
  {
    id: "du-106",
    subject: "3과목(데이터 분석)",
    question: "종속변수가 순서가 있는 범주형 변수(예: 만족도 1~5단계)일 때 사용하는 회귀분석 기법은?",
    options: ["순서형 로지스틱 회귀(Ordinal Logistic Regression)", "단순선형회귀", "다중공선성 분석", "K-Means"],
    answer: 0,
    explanation:
      "순서형 로지스틱 회귀는 종속변수가 순서 정보를 가지는 범주형 변수(예: 매우 불만족~매우 만족)일 때, 이 순서 정보를 반영하여 분석하는 로지스틱 회귀의 확장 기법입니다.",
  },
  {
    id: "du-107",
    subject: "3과목(데이터 분석)",
    question: "두 개의 범주형 변수 간에 통계적으로 유의한 관련성(독립성 여부)이 있는지를 검정하는 방법은?",
    options: ["카이제곱 독립성 검정(Chi-Square Test of Independence)", "T-검정", "분산분석(ANOVA)", "회귀분석"],
    answer: 0,
    explanation:
      "카이제곱 독립성 검정은 두 범주형 변수의 교차표(분할표)를 바탕으로, 두 변수가 서로 통계적으로 독립적인지 아니면 유의한 관련성이 있는지를 검정하는 방법입니다.",
  },
  {
    id: "du-108",
    subject: "3과목(데이터 분석)",
    question: "두 집단의 평균 차이가 통계적으로 유의한지를 검정하는 데 사용되는 대표적인 통계 검정 방법은?",
    options: ["T-검정(T-test)", "카이제곱 검정", "분산분석(ANOVA)만 해당", "F-검정만 해당"],
    answer: 0,
    explanation:
      "T-검정은 두 집단의 평균 차이가 우연에 의한 것인지, 통계적으로 유의한 차이인지를 검정하는 대표적인 방법으로, 표본의 크기가 작거나 모분산을 모를 때 주로 사용됩니다.",
  },
  {
    id: "du-109",
    subject: "3과목(데이터 분석)",
    question: "동일한 대상에 대해 사전-사후와 같이 서로 대응되는 두 측정값의 차이를 검정하는 T-검정의 종류는?",
    options: ["대응표본 T-검정(Paired T-test)", "독립표본 T-검정", "일표본 T-검정", "카이제곱 검정"],
    answer: 0,
    explanation:
      "대응표본 T-검정은 동일한 대상을 대상으로 사전-사후처럼 서로 대응되는 두 측정값의 차이가 통계적으로 유의한지를 검정하는 T-검정의 한 종류입니다.",
  },
  {
    id: "du-110",
    subject: "3과목(데이터 분석)",
    question: "서로 다른 두 독립적인 집단의 평균을 비교할 때 사용하는 T-검정의 종류는?",
    options: ["독립표본 T-검정(Independent Two-sample T-test)", "대응표본 T-검정", "일표본 T-검정", "카이제곱 검정"],
    answer: 0,
    explanation:
      "독립표본 T-검정은 서로 관련이 없는 두 개의 독립적인 집단(예: 남성 그룹과 여성 그룹)의 평균 차이를 비교하는 데 사용하는 T-검정의 한 종류입니다.",
  },
  {
    id: "du-111",
    subject: "3과목(데이터 분석)",
    question: "일원배치 분산분석(One-way ANOVA)이 세 개 이상 집단 간에 유의한 평균 차이가 있다고 판단했을 때, 구체적으로 어떤 집단들 사이에 차이가 있는지 확인하기 위해 추가로 수행하는 검정은?",
    options: ["사후검정(Post-hoc Test)", "정규성 검정", "등분산 검정", "다중공선성 검정"],
    answer: 0,
    explanation:
      "사후검정(Post-hoc Test)은 분산분석(ANOVA)에서 집단 간에 유의한 차이가 있다고 판단된 이후, 구체적으로 어느 집단들 사이에 차이가 있는지를 짝지어 추가로 비교하는 검정으로, Tukey 검정 등이 대표적입니다.",
  },
  {
    id: "du-112",
    subject: "3과목(데이터 분석)",
    question: "두 개의 범주형 독립변수가 하나의 연속형 종속변수에 미치는 영향과, 두 변수 간의 상호작용 효과까지 함께 검정하는 분산분석 기법은?",
    options: ["이원배치 분산분석(Two-way ANOVA)", "일원배치 분산분석", "카이제곱 검정", "T-검정"],
    answer: 0,
    explanation:
      "이원배치 분산분석은 두 개의 범주형 독립변수(요인)가 종속변수에 미치는 주효과뿐 아니라, 두 요인 간의 상호작용 효과까지 함께 검정할 수 있는 분산분석 기법입니다.",
  },
  {
    id: "du-113",
    subject: "3과목(데이터 분석)",
    question: "표본의 크기가 커질수록 표본평균이 모평균에 가까워진다는 통계 법칙은?",
    options: ["큰 수의 법칙(대수의 법칙, Law of Large Numbers)", "중심극한정리", "베이즈 정리", "최소제곱법"],
    answer: 0,
    explanation:
      "큰 수의 법칙(대수의 법칙)은 표본의 크기가 커질수록 표본평균이 모평균에 점점 가까워진다는 통계 법칙으로, 중심극한정리와 함께 통계적 추론의 이론적 기반이 됩니다.",
  },
  {
    id: "du-114",
    subject: "3과목(데이터 분석)",
    question: "사전 확률과 새로운 데이터(증거)를 결합하여 사후 확률을 갱신하는 확률 계산 방법을 무엇이라 하는가?",
    options: ["베이즈 정리(Bayes' Theorem)", "최소제곱법", "중심극한정리", "큰 수의 법칙"],
    answer: 0,
    explanation:
      "베이즈 정리는 어떤 사건에 대한 사전 확률(Prior)을 새로운 데이터(증거)를 이용해 갱신하여 사후 확률(Posterior)을 계산하는 방법으로, 나이브 베이즈 분류기 등의 이론적 기반이 됩니다.",
  },
  {
    id: "du-115",
    subject: "3과목(데이터 분석)",
    question: "베이즈 정리를 기반으로, 각 특성(feature)이 서로 독립이라고 가정하여 분류를 수행하는 확률 기반 분류 알고리즘은?",
    options: ["나이브 베이즈 분류(Naive Bayes Classifier)", "K-Means 군집분석", "주성분분석", "덴드로그램"],
    answer: 0,
    explanation:
      "나이브 베이즈 분류는 베이즈 정리를 기반으로, 각 특성(변수)들이 서로 조건부 독립이라는 가정(단순화 가정) 하에 클래스에 속할 확률을 계산하여 분류하는 알고리즘으로, 텍스트 분류(스팸 필터링)에 자주 활용됩니다.",
  },
  {
    id: "du-116",
    subject: "3과목(데이터 분석)",
    question: "표본을 원래 데이터에서 복원추출을 반복하여 여러 개의 표본 집합을 생성하는 방법을 무엇이라 하는가?",
    options: ["부트스트랩(Bootstrap)", "차분", "정규화", "표준화"],
    answer: 0,
    explanation:
      "부트스트랩은 원본 데이터에서 복원추출(중복 허용)을 반복하여 동일한 크기의 여러 표본 집합을 생성하는 방법으로, 배깅(Bagging)이나 통계량의 표본 분포 추정 등에 활용됩니다.",
  },
  {
    id: "du-117",
    subject: "3과목(데이터 분석)",
    question: "결측치를 하나의 대표값이 아니라, 여러 번의 시뮬레이션을 통해 생성한 여러 개의 완전한 데이터셋으로 대치한 뒤 결과를 결합하는 결측치 처리 방법은?",
    options: ["다중 대치법(Multiple Imputation)", "단순 대치법", "완전 분석법(Listwise Deletion)", "쌍별 삭제법(Pairwise Deletion)"],
    answer: 0,
    explanation:
      "다중 대치법은 결측치를 하나의 값으로 대치하는 대신, 여러 번의 시뮬레이션을 통해 서로 다른 값으로 채워진 여러 개의 완전한 데이터셋을 생성한 뒤, 각각 분석한 결과를 결합하여 결측으로 인한 불확실성까지 반영하는 정교한 처리 방법입니다.",
  },
  {
    id: "du-118",
    subject: "3과목(데이터 분석)",
    question: "결측치가 있는 행을 모두 제거하고 나머지 완전한 데이터만을 분석에 사용하는 결측치 처리 방법은?",
    options: ["완전 분석법(Listwise Deletion)", "다중 대치법", "단순 대치법", "회귀 대치법"],
    answer: 0,
    explanation:
      "완전 분석법(목록별 삭제법)은 하나라도 결측치가 있는 행(관측치)을 전부 제거하고, 결측이 없는 완전한 행들만을 분석에 사용하는 가장 단순한 결측치 처리 방법입니다.",
  },
  {
    id: "du-119",
    subject: "3과목(데이터 분석)",
    question: "이상치(Outlier)를 탐지하는 방법으로 가장 거리가 먼 것은?",
    options: [
      "박스플롯을 이용한 IQR 기준 판별",
      "평균과 표준편차를 이용한 Z-score 기준 판별",
      "산점도를 통한 시각적 확인",
      "데이터의 알파벳 순서로 무작위 정렬",
    ],
    answer: 3,
    explanation:
      "이상치 탐지에는 IQR 기준, Z-score 기준, 산점도를 통한 시각적 확인 등이 널리 사용됩니다. 데이터를 알파벳 순서로 무작위 정렬하는 것은 이상치 탐지와 관련이 없습니다.",
  },
  {
    id: "du-120",
    subject: "3과목(데이터 분석)",
    question: "관측치가 평균으로부터 표준편차의 몇 배 떨어져 있는지를 계산하여 이상치를 판별하는 표준화된 값은?",
    options: ["Z-score", "지지도", "신뢰도", "결정계수"],
    answer: 0,
    explanation:
      "Z-score는 개별 관측치가 평균으로부터 표준편차의 몇 배만큼 떨어져 있는지를 나타내는 표준화된 값으로, 일반적으로 절댓값이 2~3 이상이면 이상치로 판별하는 기준으로 활용됩니다.",
  },
  {
    id: "du-121",
    subject: "3과목(데이터 분석)",
    question: "텍스트 데이터를 분석 가능한 벡터 형태로 변환할 때, 각 단어가 문서에 등장하는 빈도를 그대로 사용하는 가장 단순한 방법은?",
    options: ["BoW(Bag of Words)", "워드투벡(Word2Vec)", "TF-IDF", "임베딩"],
    answer: 0,
    explanation:
      "BoW(Bag of Words)는 문서 내 단어의 순서는 고려하지 않고, 각 단어가 문서에 등장한 빈도만을 세어 벡터로 표현하는 가장 단순한 텍스트 벡터화 방법입니다.",
  },
  {
    id: "du-122",
    subject: "3과목(데이터 분석)",
    question: "특정 단어가 한 문서에는 자주 등장하지만 전체 문서 집합에서는 드물게 등장할수록 높은 가중치를 부여하는 텍스트 가중치 기법은?",
    options: ["TF-IDF(Term Frequency-Inverse Document Frequency)", "BoW", "원-핫 인코딩", "라벨 인코딩"],
    answer: 0,
    explanation:
      "TF-IDF는 특정 단어가 한 문서 내에서 등장하는 빈도(TF)는 높이 평가하되, 여러 문서에 공통적으로 자주 등장하는 단어(예: 조사)의 중요도는 낮추는(IDF) 방식으로 단어에 가중치를 부여하는 기법입니다.",
  },
  {
    id: "du-123",
    subject: "3과목(데이터 분석)",
    question: "단어를 고정된 크기의 밀집 벡터(dense vector)로 표현하여, 의미가 유사한 단어일수록 벡터 공간에서 가깝게 위치하도록 학습하는 기법은?",
    options: ["워드 임베딩(Word Embedding, 예: Word2Vec)", "BoW", "원-핫 인코딩", "지지도 계산"],
    answer: 0,
    explanation:
      "워드 임베딩(예: Word2Vec)은 각 단어를 고정된 크기의 밀집 벡터로 표현하여, 의미적으로 유사한 단어들이 벡터 공간 상에서 서로 가깝게 위치하도록 학습하는 기법입니다.",
  },
  {
    id: "du-124",
    subject: "3과목(데이터 분석)",
    question: "여러 문서로부터 잠재된 주제(토픽)들을 자동으로 추출하는 대표적인 텍스트 마이닝 기법은?",
    options: ["토픽 모델링(Topic Modeling, 예: LDA)", "K-Means 군집분석만 해당", "주성분분석", "덴드로그램"],
    answer: 0,
    explanation:
      "토픽 모델링(대표적으로 LDA, Latent Dirichlet Allocation)은 여러 문서 집합에 내재된 잠재적인 주제(토픽)들을 자동으로 추출하는 대표적인 텍스트 마이닝 기법입니다.",
  },
  {
    id: "du-125",
    subject: "3과목(데이터 분석)",
    question: "문장이나 문서를 형태소(의미를 가지는 가장 작은 언어 단위) 단위로 분리하는 자연어 처리 작업을 무엇이라 하는가?",
    options: ["형태소 분석(Morphological Analysis)", "군집분석", "회귀분석", "요인분석"],
    answer: 0,
    explanation:
      "형태소 분석은 문장을 의미를 가지는 가장 작은 언어 단위인 형태소로 분리하고, 각 형태소의 품사를 태깅하는 자연어 처리의 기초 작업으로, 한국어 텍스트 마이닝에서 특히 중요합니다.",
  },
  {
    id: "du-126",
    subject: "3과목(데이터 분석)",
    question: "실제값과 예측값의 차이(오차)를 제곱한 뒤 평균을 내어 회귀모형의 예측 오차를 평가하는 지표는?",
    options: ["평균제곱오차(MSE, Mean Squared Error)", "정밀도", "재현율", "지지도"],
    answer: 0,
    explanation:
      "평균제곱오차(MSE)는 실제값과 예측값의 차이(오차)를 제곱하여 평균을 낸 값으로, 회귀모형의 예측 오차 크기를 평가하는 대표적인 지표입니다.",
  },
  {
    id: "du-127",
    subject: "3과목(데이터 분석)",
    question: "평균제곱오차(MSE)에 제곱근을 취하여, 원래 데이터와 동일한 단위로 오차 크기를 해석할 수 있게 한 지표는?",
    options: ["평균제곱근오차(RMSE, Root Mean Squared Error)", "평균절대오차(MAE)", "결정계수(R²)", "F1-score"],
    answer: 0,
    explanation:
      "RMSE는 MSE에 제곱근을 취한 값으로, 오차의 단위를 원래 종속변수와 동일하게 맞춰 해석을 쉽게 해주는 회귀모형 평가 지표입니다.",
  },
  {
    id: "du-128",
    subject: "3과목(데이터 분석)",
    question: "실제값과 예측값의 차이(오차)의 절댓값을 평균 낸 회귀모형 평가 지표는?",
    options: ["평균절대오차(MAE, Mean Absolute Error)", "평균제곱오차(MSE)", "결정계수(R²)", "AUC"],
    answer: 0,
    explanation:
      "평균절대오차(MAE)는 실제값과 예측값의 차이(오차)에 절댓값을 취한 뒤 평균을 낸 값으로, MSE와 달리 오차를 제곱하지 않아 이상치에 상대적으로 덜 민감한 회귀모형 평가 지표입니다.",
  },
  {
    id: "du-129",
    subject: "3과목(데이터 분석)",
    question: "모델이 학습 데이터에 과도하게 맞춰져 새로운 데이터에 대한 일반화 성능이 떨어지는 현상을 무엇이라 하는가?",
    options: ["과적합(Overfitting)", "과소적합(Underfitting)", "정규화", "표준화"],
    answer: 0,
    explanation:
      "과적합(Overfitting)은 모델이 학습 데이터의 노이즈까지 지나치게 학습하여, 학습 데이터에서는 성능이 매우 좋지만 새로운(검증/테스트) 데이터에서는 성능이 크게 저하되는 현상입니다.",
  },
  {
    id: "du-130",
    subject: "3과목(데이터 분석)",
    question: "모델이 지나치게 단순하여 학습 데이터의 패턴조차 제대로 학습하지 못하는 현상을 무엇이라 하는가?",
    options: ["과소적합(Underfitting)", "과적합(Overfitting)", "다중공선성", "정상성"],
    answer: 0,
    explanation:
      "과소적합(Underfitting)은 모델의 구조나 복잡도가 지나치게 단순하여, 학습 데이터에 존재하는 패턴조차 충분히 학습하지 못해 학습 데이터에서도 성능이 낮게 나타나는 현상입니다.",
  },
  {
    id: "du-131",
    subject: "3과목(데이터 분석)",
    question: "다중회귀분석에서 독립변수의 개수가 늘어남에 따라 결정계수(R²)가 과대평가되는 것을 보정한 지표는?",
    options: ["수정된 결정계수(Adjusted R²)", "일반 결정계수(R²)", "상관계수", "공분산"],
    answer: 0,
    explanation:
      "수정된 결정계수(Adjusted R²)는 독립변수의 개수가 늘어날수록 단순 결정계수(R²)가 무의미하게 커지는 것을 보정한 지표로, 유의미하지 않은 변수를 추가하면 오히려 값이 감소할 수 있습니다.",
  },
  {
    id: "du-132",
    subject: "3과목(데이터 분석)",
    question: "다중회귀분석에서 독립변수를 추가할 때 일반 결정계수(R²)가 나타내는 경향으로 가장 적절한 것은?",
    options: [
      "유의미하지 않은 변수를 추가하더라도 R²은 감소하지 않고 유지되거나 증가한다",
      "변수를 추가하면 R²은 항상 감소한다",
      "변수의 개수는 R²에 어떠한 영향도 주지 않는다",
      "R²은 항상 음수가 된다",
    ],
    answer: 0,
    explanation:
      "일반 결정계수(R²)는 독립변수를 추가하면 그 변수가 통계적으로 유의미하지 않더라도 감소하지 않고 유지되거나 증가하는 경향이 있어, 모형 비교 시 수정된 결정계수(Adjusted R²)를 함께 참고합니다.",
  },
  {
    id: "du-133",
    subject: "3과목(데이터 분석)",
    question: "서포트벡터머신(SVM)에서 결정경계와 가장 가까운 데이터 포인트 사이의 거리를 무엇이라 하는가?",
    options: ["마진(Margin)", "지지도(Support)", "신뢰도(Confidence)", "향상도(Lift)"],
    answer: 0,
    explanation:
      "마진(Margin)은 SVM에서 두 클래스를 구분하는 결정경계(초평면)와, 이에 가장 가까운 데이터 포인트 사이의 거리를 의미하며, SVM은 이 마진을 최대화하는 방향으로 학습합니다.",
  },
  {
    id: "du-134",
    subject: "3과목(데이터 분석)",
    question: "서포트벡터머신(SVM)에서 결정경계에 가장 가까이 위치하여 마진을 결정짓는 데이터 포인트를 무엇이라 하는가?",
    options: ["서포트벡터(Support Vector)", "센트로이드", "이상치", "레퍼런스 포인트"],
    answer: 0,
    explanation:
      "서포트벡터(Support Vector)는 결정경계에 가장 가까이 위치하여 마진의 크기를 결정짓는 데이터 포인트들로, SVM이라는 이름 자체가 여기서 유래하였습니다.",
  },
  {
    id: "du-135",
    subject: "3과목(데이터 분석)",
    question: "인공신경망 구조에서 입력층과 출력층 사이에 위치하며, 실제 특징을 학습하는 계층을 무엇이라 하는가?",
    options: ["은닉층(Hidden Layer)", "입력층(Input Layer)", "출력층(Output Layer)", "커널층"],
    answer: 0,
    explanation:
      "은닉층(Hidden Layer)은 인공신경망에서 입력층과 출력층 사이에 위치하는 계층으로, 입력 데이터로부터 특징을 추출하고 변환하는 역할을 담당합니다.",
  },
  {
    id: "du-136",
    subject: "3과목(데이터 분석)",
    question: "은닉층을 여러 겹 깊게 쌓은 인공신경망을 기반으로 학습하는 머신러닝의 한 분야를 무엇이라 하는가?",
    options: ["딥러닝(Deep Learning)", "얕은 학습(Shallow Learning)", "군집분석", "연관규칙분석"],
    answer: 0,
    explanation:
      "딥러닝은 여러 개의 은닉층을 깊게(Deep) 쌓은 인공신경망 구조를 기반으로, 데이터로부터 복잡한 패턴과 특징을 자동으로 학습하는 머신러닝의 한 분야입니다.",
  },
  {
    id: "du-137",
    subject: "3과목(데이터 분석)",
    question: "합성곱(Convolution) 연산을 이용해 이미지의 공간적 특징을 효과적으로 추출하는 데 특화된 신경망 구조는?",
    options: ["합성곱 신경망(CNN, Convolutional Neural Network)", "순환 신경망(RNN)", "SOM", "퍼셉트론"],
    answer: 0,
    explanation:
      "합성곱 신경망(CNN)은 합성곱 필터를 이용해 이미지의 지역적인 패턴(모서리, 질감 등)과 공간적 특징을 효과적으로 추출하는 데 특화된 딥러닝 구조로, 이미지 인식 분야에서 널리 사용됩니다.",
  },
  {
    id: "du-138",
    subject: "3과목(데이터 분석)",
    question: "이전 시점의 정보를 현재 시점의 계산에 반영하는 순환 구조를 가지고 있어, 시계열이나 순차 데이터 처리에 적합한 신경망은?",
    options: ["순환 신경망(RNN, Recurrent Neural Network)", "합성곱 신경망(CNN)", "SOM", "K-Means"],
    answer: 0,
    explanation:
      "순환 신경망(RNN)은 이전 시점에서 처리한 정보를 은닉 상태로 저장하여 현재 시점의 계산에 반영하는 순환 구조를 가지고 있어, 순서가 중요한 시계열이나 텍스트 등의 순차 데이터 처리에 적합합니다.",
  },
  {
    id: "du-139",
    subject: "3과목(데이터 분석)",
    question: "신경망 학습 시, 매 학습 단계마다 일부 뉴런을 무작위로 비활성화하여 과적합을 방지하는 기법은?",
    options: ["드롭아웃(Dropout)", "역전파", "경사하강법", "정규분포화"],
    answer: 0,
    explanation:
      "드롭아웃은 신경망 학습 과정에서 매번 일부 뉴런을 무작위로 비활성화(제외)시킴으로써, 특정 뉴런에 과도하게 의존하는 것을 방지하고 과적합을 줄이는 정규화 기법입니다.",
  },
  {
    id: "du-140",
    subject: "3과목(데이터 분석)",
    question: "검증 데이터에 대한 모델의 성능이 더 이상 개선되지 않을 때, 학습을 미리 중단하여 과적합을 방지하는 기법은?",
    options: ["조기종료(Early Stopping)", "드롭아웃", "배깅", "부스팅"],
    answer: 0,
    explanation:
      "조기종료(Early Stopping)는 학습이 진행됨에 따라 검증 데이터에 대한 성능을 지속적으로 모니터링하다가, 성능이 더 이상 개선되지 않고 오히려 나빠지기 시작하면 학습을 중단하여 과적합을 방지하는 기법입니다.",
  },
  {
    id: "du-141",
    subject: "3과목(데이터 분석)",
    question: "경사하강법(Gradient Descent)에서 가중치를 한 번에 얼마나 갱신할지를 조절하는 하이퍼파라미터는?",
    options: ["학습률(Learning Rate)", "배치 크기", "에폭", "은닉층 개수"],
    answer: 0,
    explanation:
      "학습률(Learning Rate)은 경사하강법에서 손실 함수의 기울기를 따라 가중치를 갱신할 때, 한 번에 이동하는 정도(보폭)를 조절하는 하이퍼파라미터입니다.",
  },
  {
    id: "du-142",
    subject: "3과목(데이터 분석)",
    question: "손실 함수의 기울기(gradient)를 계산하여, 그 반대 방향으로 파라미터를 갱신하며 손실을 최소화해 나가는 최적화 알고리즘은?",
    options: ["경사하강법(Gradient Descent)", "카이제곱 검정", "주성분분석", "덴드로그램"],
    answer: 0,
    explanation:
      "경사하강법은 손실 함수의 기울기를 계산하여, 손실이 감소하는 방향(기울기의 반대 방향)으로 모델의 파라미터를 반복적으로 갱신해 나가며 손실을 최소화하는 대표적인 최적화 알고리즘입니다.",
  },
  {
    id: "du-143",
    subject: "3과목(데이터 분석)",
    question: "신경망 학습에서 한 번의 가중치 갱신에 사용되는 데이터 샘플의 개수를 무엇이라 하는가?",
    options: ["배치 크기(Batch Size)", "에폭(Epoch)", "학습률", "은닉층 수"],
    answer: 0,
    explanation:
      "배치 크기(Batch Size)는 신경망 학습 과정에서 한 번의 가중치 갱신(파라미터 업데이트)에 사용되는 학습 데이터 샘플의 개수를 의미합니다.",
  },
  {
    id: "du-144",
    subject: "3과목(데이터 분석)",
    question: "전체 학습 데이터셋을 한 번 모두 사용하여 학습을 완료한 횟수를 무엇이라 하는가?",
    options: ["에폭(Epoch)", "배치 크기", "학습률", "이터레이션"],
    answer: 0,
    explanation:
      "에폭(Epoch)은 전체 학습 데이터셋 전부를 한 번씩 모델 학습에 사용한 횟수를 의미하며, 여러 번의 에폭을 반복하며 모델의 성능을 점진적으로 향상시킵니다.",
  },
  {
    id: "du-145",
    subject: "3과목(데이터 분석)",
    question: "머신러닝 모델을 개발할 때, 데이터를 훈련(Train), 검증(Validation), 테스트(Test) 세트로 나누는 주된 목적으로 가장 적절한 것은?",
    options: [
      "모델 학습, 하이퍼파라미터 튜닝, 최종 성능 평가를 서로 독립된 데이터로 수행하기 위해서이다",
      "데이터를 무의미하게 여러 조각으로 쪼개기 위해서이다",
      "모델의 저장 공간을 줄이기 위해서이다",
      "데이터 수집 비용을 늘리기 위해서이다",
    ],
    answer: 0,
    explanation:
      "데이터를 훈련, 검증, 테스트 세트로 나누는 것은 각각 모델 학습, 하이퍼파라미터 튜닝 및 모델 선택, 그리고 최종적으로 편향 없는 성능 평가를 서로 독립적인 데이터로 수행하여 신뢰할 수 있는 결과를 얻기 위함입니다.",
  },
  {
    id: "du-146",
    subject: "3과목(데이터 분석)",
    question: "여러 후보 모델 중 하나를 선택하거나 하이퍼파라미터를 조정하는 데 주로 사용되는 데이터 세트는?",
    options: ["검증 세트(Validation Set)", "훈련 세트", "테스트 세트", "모집단 전체"],
    answer: 0,
    explanation:
      "검증 세트(Validation Set)는 여러 후보 모델의 성능을 비교하거나 하이퍼파라미터를 조정하는 데 사용되며, 최종 성능 평가는 이와 독립된 테스트 세트로 수행합니다.",
  },
  {
    id: "du-147",
    subject: "3과목(데이터 분석)",
    question: "모델 학습을 통해 자동으로 결정되는 값(예: 회귀계수, 가중치)과, 학습 전에 사람이 직접 설정해야 하는 값(예: 학습률)을 각각 무엇이라 하는가?",
    options: ["파라미터(Parameter)와 하이퍼파라미터(Hyperparameter)", "지지도와 신뢰도", "왜도와 첨도", "표본과 모집단"],
    answer: 0,
    explanation:
      "파라미터는 모델이 데이터를 학습하는 과정에서 자동으로 결정되는 값(회귀계수, 신경망 가중치 등)이며, 하이퍼파라미터는 학습을 시작하기 전에 사람이 직접 설정해야 하는 값(학습률, 트리 개수 등)입니다.",
  },
  {
    id: "du-148",
    subject: "3과목(데이터 분석)",
    question: "지정한 여러 하이퍼파라미터 값의 모든 조합을 하나씩 시도해보며 최적의 조합을 찾는 하이퍼파라미터 튜닝 기법은?",
    options: ["그리드 서치(Grid Search)", "랜덤 서치", "베이즈 최적화만 해당", "경사하강법"],
    answer: 0,
    explanation:
      "그리드 서치는 지정한 여러 하이퍼파라미터 값들의 가능한 모든 조합을 격자(grid) 형태로 만들어, 각 조합에 대해 모델 성능을 평가하며 최적의 조합을 찾는 튜닝 기법입니다.",
  },
  {
    id: "du-149",
    subject: "3과목(데이터 분석)",
    question: "하이퍼파라미터 값의 조합을 모두 시도하는 대신, 정해진 범위 내에서 무작위로 값을 샘플링하여 탐색하는 튜닝 기법은?",
    options: ["랜덤 서치(Random Search)", "그리드 서치", "완전 탐색법", "역전파"],
    answer: 0,
    explanation:
      "랜덤 서치는 하이퍼파라미터의 모든 조합을 전부 시도하는 그리드 서치와 달리, 정해진 범위 내에서 값을 무작위로 샘플링하여 상대적으로 적은 시도로도 효율적으로 좋은 조합을 찾는 튜닝 기법입니다.",
  },
  {
    id: "du-150",
    subject: "3과목(데이터 분석)",
    question: "분류 문제에서 특정 클래스의 데이터 수가 다른 클래스에 비해 극단적으로 적거나 많은 상태를 무엇이라 하는가?",
    options: ["데이터 불균형(Class Imbalance)", "다중공선성", "정상성", "등분산성"],
    answer: 0,
    explanation:
      "데이터 불균형(클래스 불균형)은 분류 문제에서 특정 클래스(예: 정상 거래)의 데이터가 다른 클래스(예: 사기 거래)에 비해 지나치게 많거나 적은 상태를 의미하며, 이를 고려하지 않으면 모델이 다수 클래스에 편향될 수 있습니다.",
  },
  {
    id: "du-151",
    subject: "3과목(데이터 분석)",
    question: "데이터 불균형 문제를 완화하기 위해, 소수 클래스의 데이터를 합성하여 인위적으로 늘리는 대표적인 오버샘플링 기법은?",
    options: ["SMOTE(Synthetic Minority Over-sampling Technique)", "언더샘플링", "정규화", "표준화"],
    answer: 0,
    explanation:
      "SMOTE는 소수 클래스에 속한 데이터들 사이를 보간하여 새로운 합성 데이터를 생성함으로써, 소수 클래스의 데이터 수를 인위적으로 늘리는 대표적인 오버샘플링 기법입니다.",
  },
  {
    id: "du-152",
    subject: "3과목(데이터 분석)",
    question: "데이터 불균형 문제를 완화하기 위해, 다수 클래스의 데이터 일부만을 무작위로 선택하여 사용하는 기법은?",
    options: ["언더샘플링(Under-sampling)", "오버샘플링", "정규화", "표준화"],
    answer: 0,
    explanation:
      "언더샘플링은 다수 클래스에 속한 데이터 중 일부만을 무작위로 선택하여, 소수 클래스와 데이터 수의 균형을 맞추는 기법입니다.",
  },
  {
    id: "du-153",
    subject: "3과목(데이터 분석)",
    question: "여러 모델의 예측 결과를 다수결이나 확률 평균으로 결합하여 최종 예측을 결정하는 앙상블 기법은?",
    options: ["보팅(Voting)", "배깅", "부스팅", "스태킹"],
    answer: 0,
    explanation:
      "보팅(Voting)은 서로 다른 여러 모델의 예측 결과를 다수결(Hard Voting)이나 예측 확률의 평균(Soft Voting)으로 결합하여 최종 예측을 결정하는 앙상블 기법입니다.",
  },
  {
    id: "du-154",
    subject: "3과목(데이터 분석)",
    question: "여러 개별 모델의 예측값을 입력으로 사용하여, 최종 예측을 수행하는 별도의 메타 모델을 학습시키는 앙상블 기법은?",
    options: ["스태킹(Stacking)", "보팅", "단일 의사결정나무", "K-Means"],
    answer: 0,
    explanation:
      "스태킹은 여러 개별(베이스) 모델의 예측 결과를 새로운 입력 변수로 사용하여, 이를 종합해 최종 예측을 수행하는 별도의 메타 모델(Meta Model)을 학습시키는 앙상블 기법입니다.",
  },
  {
    id: "du-155",
    subject: "3과목(데이터 분석)",
    question: "가설검정에서 두 집단 간에 차이가 있다는 방향성 없이, 단순히 '차이가 있다/없다'만을 검정하는 방식을 무엇이라 하는가?",
    options: ["양측검정(Two-tailed Test)", "단측검정(One-tailed Test)", "회귀분석", "군집분석"],
    answer: 0,
    explanation:
      "양측검정은 두 집단이나 값 사이에 '차이가 있는지 없는지'만을 검정할 뿐, 어느 쪽이 더 큰지와 같은 방향성은 고려하지 않는 가설검정 방식입니다.",
  },
  {
    id: "du-156",
    subject: "3과목(데이터 분석)",
    question: "가설검정에서 귀무가설이 실제로 참인데도 이를 잘못 기각할 확률의 최대 허용 한계를 무엇이라 하는가?",
    options: ["유의수준(α, Significance Level)", "검정력", "신뢰수준", "표준오차"],
    answer: 0,
    explanation:
      "유의수준(α)은 귀무가설이 실제로 참인데도 이를 잘못 기각하는 오류(제1종 오류)를 범할 확률의 최대 허용 한계로, 일반적으로 0.05(5%)나 0.01(1%)이 널리 사용됩니다.",
  },
  {
    id: "du-157",
    subject: "3과목(데이터 분석)",
    question: "대립가설이 실제로 참일 때, 이를 올바르게 채택(귀무가설을 올바르게 기각)할 확률을 무엇이라 하는가?",
    options: ["검정력(Power, 1-β)", "유의수준(α)", "신뢰수준", "표준오차"],
    answer: 0,
    explanation:
      "검정력(Power)은 대립가설이 실제로 참일 때, 검정을 통해 이를 올바르게 채택(즉, 거짓인 귀무가설을 올바르게 기각)할 확률로, 1에서 제2종 오류를 범할 확률(β)을 뺀 값(1-β)으로 계산됩니다.",
  },
  {
    id: "du-158",
    subject: "3과목(데이터 분석)",
    question: "실제로는 귀무가설이 거짓인데도 이를 기각하지 못하는 오류를 무엇이라 하는가?",
    options: ["제2종 오류(Type II Error)", "제1종 오류", "표본 오류", "측정 오류"],
    answer: 0,
    explanation:
      "제2종 오류(Type II Error)는 귀무가설이 실제로는 거짓(대립가설이 참)임에도 불구하고, 검정 결과 귀무가설을 기각하지 못하는 오류입니다.",
  },
  {
    id: "du-159",
    subject: "3과목(데이터 분석)",
    question: "모집단을 구성하는 모든 개체가 표본으로 선택될 확률이 동일하도록 무작위로 표본을 추출하는 방법은?",
    options: ["단순 무작위 추출(Simple Random Sampling)", "층화 추출", "군집 추출", "계통 추출"],
    answer: 0,
    explanation:
      "단순 무작위 추출은 모집단을 구성하는 모든 개체가 표본으로 선택될 확률이 동일하도록, 순수하게 무작위로 표본을 추출하는 가장 기본적인 표본추출 방법입니다.",
  },
  {
    id: "du-160",
    subject: "3과목(데이터 분석)",
    question: "모집단을 여러 개의 군집으로 나눈 뒤, 그 중 일부 군집을 무작위로 선택하여 선택된 군집 전체를 조사하는 표본추출 방법은?",
    options: ["군집 추출(Cluster Sampling)", "층화 추출", "단순 무작위 추출", "계통 추출"],
    answer: 0,
    explanation:
      "군집 추출은 모집단을 여러 개의 군집(집단)으로 나눈 뒤, 그 중 일부 군집을 무작위로 선택하여 선택된 군집에 속한 개체 전체를 조사하는 방법으로, 군집 내부는 이질적이고 군집 간에는 동질적인 것이 이상적입니다.",
  },
  {
    id: "du-161",
    subject: "3과목(데이터 분석)",
    question: "모집단의 개체에 일련번호를 부여한 뒤, 일정한 간격으로 표본을 추출하는 방법은?",
    options: ["계통 추출(Systematic Sampling)", "군집 추출", "층화 추출", "단순 무작위 추출"],
    answer: 0,
    explanation:
      "계통 추출은 모집단의 개체에 일련번호를 부여하고, 첫 표본을 무작위로 선택한 뒤 일정한 간격(k번째마다)으로 나머지 표본을 추출하는 방법입니다.",
  },
  {
    id: "du-162",
    subject: "3과목(데이터 분석)",
    question: "연구의 대상이 되는 전체 집단과, 그 집단에서 실제로 조사를 위해 뽑아낸 일부를 각각 무엇이라 하는가?",
    options: ["모집단(Population)과 표본(Sample)", "모수와 파라미터", "변수와 상수", "관측치와 통계량"],
    answer: 0,
    explanation:
      "모집단은 연구자가 알고자 하는 대상 전체를 의미하며, 표본은 시간과 비용의 제약으로 모집단 중 실제로 뽑아내어 조사하는 일부를 의미합니다.",
  },
  {
    id: "du-163",
    subject: "3과목(데이터 분석)",
    question: "모집단의 특성을 나타내는 값과, 표본으로부터 계산되어 모수를 추정하는 데 사용되는 값을 각각 무엇이라 하는가?",
    options: ["모수(Parameter)와 통계량(Statistic)", "변수와 상수", "표본과 모집단", "이산형과 연속형"],
    answer: 0,
    explanation:
      "모수(Parameter)는 모집단 전체의 특성(예: 모평균, 모분산)을 나타내는 값이며, 통계량(Statistic)은 표본으로부터 계산되어 모수를 추정하는 데 사용되는 값(예: 표본평균)입니다.",
  },
  {
    id: "du-164",
    subject: "3과목(데이터 분석)",
    question: "두 연속형 변수 간의 관계를 점(point)의 분포로 나타내어 시각적으로 파악하는 데 사용하는 그래프는?",
    options: ["산점도(Scatter Plot)", "히스토그램", "막대 그래프", "파이 차트"],
    answer: 0,
    explanation:
      "산점도는 두 연속형 변수의 값을 각각 x축과 y축으로 하여 점으로 나타낸 그래프로, 두 변수 간의 관계(선형, 비선형, 무관계 등)를 시각적으로 파악하는 데 사용됩니다.",
  },
  {
    id: "du-165",
    subject: "3과목(데이터 분석)",
    question: "연속형 데이터를 여러 구간(계급)으로 나누고, 각 구간에 속하는 데이터의 개수(도수)를 막대 형태로 나타낸 그래프는?",
    options: ["히스토그램(Histogram)", "산점도", "박스플롯", "덴드로그램"],
    answer: 0,
    explanation:
      "히스토그램은 연속형 데이터를 일정한 구간(계급)으로 나눈 뒤, 각 구간에 속하는 데이터의 빈도(도수)를 막대의 높이로 나타내어 데이터의 분포 형태를 파악하는 데 사용되는 그래프입니다.",
  },
  {
    id: "du-166",
    subject: "3과목(데이터 분석)",
    question: "두 변수가 함께 변화하는 방향과 정도를 나타내지만, 변수의 단위에 따라 값의 크기가 달라지는 통계량은?",
    options: ["공분산(Covariance)", "상관계수(Correlation Coefficient)", "결정계수", "왜도"],
    answer: 0,
    explanation:
      "공분산은 두 변수가 함께 변화하는 방향(양 또는 음)과 정도를 나타내는 통계량이지만, 변수의 측정 단위에 따라 값의 크기가 달라져 서로 다른 변수 쌍 간의 크기 비교가 어렵습니다.",
  },
  {
    id: "du-167",
    subject: "3과목(데이터 분석)",
    question: "공분산을 각 변수의 표준편차로 나누어 표준화함으로써, 단위에 관계없이 -1에서 1 사이의 값으로 상관 정도를 나타낸 지표는?",
    options: ["피어슨 상관계수(Pearson Correlation Coefficient)", "공분산", "결정계수", "분산"],
    answer: 0,
    explanation:
      "피어슨 상관계수는 두 변수의 공분산을 각각의 표준편차로 나누어 표준화한 값으로, 변수의 단위에 관계없이 -1에서 1 사이의 값으로 선형 상관 관계의 방향과 강도를 나타냅니다.",
  },
  {
    id: "du-168",
    subject: "3과목(데이터 분석)",
    question: "값 자체가 아니라 순위(rank)를 기반으로 계산되어, 비선형적인 단조 관계도 포착할 수 있는 상관계수는?",
    options: ["스피어만 상관계수(Spearman Correlation Coefficient)", "피어슨 상관계수", "공분산", "결정계수"],
    answer: 0,
    explanation:
      "스피어만 상관계수는 원래 값이 아닌 순위(rank)를 이용해 계산되는 상관계수로, 두 변수가 반드시 선형이 아니더라도 한쪽이 증가할 때 다른 쪽도 증가(또는 감소)하는 단조적인 관계를 포착할 수 있습니다.",
  },
  {
    id: "du-169",
    subject: "3과목(데이터 분석)",
    question: "제3의 변수의 영향을 통계적으로 통제한 상태에서, 두 변수 간의 순수한 상관관계만을 나타내는 지표는?",
    options: ["편상관계수(Partial Correlation Coefficient)", "피어슨 상관계수", "스피어만 상관계수", "공분산"],
    answer: 0,
    explanation:
      "편상관계수는 다른 변수(제3의 변수)가 미치는 영향을 통계적으로 통제한 상태에서, 두 변수 사이에 남아있는 순수한 상관관계의 크기를 나타내는 지표입니다.",
  },
  {
    id: "du-170",
    subject: "3과목(데이터 분석)",
    question: "시계열 데이터를 추세(Trend), 계절성(Seasonality), 불규칙 요인(Irregular)으로 나누어 분석하는 것을 무엇이라 하는가?",
    options: ["시계열 분해(Time Series Decomposition)", "군집분석", "연관규칙분석", "요인분석"],
    answer: 0,
    explanation:
      "시계열 분해는 시계열 데이터를 장기적인 추세(Trend), 일정 주기로 반복되는 계절성(Seasonality), 설명할 수 없는 불규칙 요인(Irregular)으로 나누어 각 구성 요소를 분석하는 기법입니다.",
  },
  {
    id: "du-171",
    subject: "3과목(데이터 분석)",
    question: "일정 기간 동안의 데이터 값들을 평균 내어, 단기적인 변동을 완화하고 추세를 파악하는 시계열 분석 기법은?",
    options: ["이동평균법(Moving Average)", "지수평활법", "ARIMA", "덴드로그램"],
    answer: 0,
    explanation:
      "이동평균법은 일정 기간(윈도우) 동안의 데이터 값들의 평균을 계산하여, 단기적인 변동을 완화하고 시계열의 전반적인 추세를 파악하는 기법입니다.",
  },
  {
    id: "du-172",
    subject: "3과목(데이터 분석)",
    question: "가장 최근의 관측값에 더 큰 가중치를 부여하고, 과거로 갈수록 가중치를 지수적으로 감소시켜 시계열을 평활하는 기법은?",
    options: ["지수평활법(Exponential Smoothing)", "이동평균법", "차분", "정규화"],
    answer: 0,
    explanation:
      "지수평활법은 가장 최근의 관측값에 상대적으로 큰 가중치를 부여하고, 시간이 지날수록(과거로 갈수록) 그 가중치를 지수적으로 감소시켜 시계열 데이터를 평활하고 예측하는 기법입니다.",
  },
  {
    id: "du-173",
    subject: "3과목(데이터 분석)",
    question: "일정한 주기(예: 매년 12월)로 반복적으로 나타나는 시계열의 패턴을 무엇이라 하는가?",
    options: ["계절성(Seasonality)", "추세(Trend)", "정상성(Stationarity)", "자기상관"],
    answer: 0,
    explanation:
      "계절성(Seasonality)은 특정 주기(예: 매년, 매월, 매주)로 반복해서 나타나는 시계열의 패턴을 의미하며, 예를 들어 매년 겨울철 난방용품 판매량이 증가하는 패턴이 이에 해당합니다.",
  },
  {
    id: "du-174",
    subject: "3과목(데이터 분석)",
    question: "ARIMA 모형이 활용되는 대표적인 사례로 가장 적절한 것은?",
    options: [
      "과거의 시계열 패턴을 학습하여 향후 매출액이나 수요를 예측하는 경우",
      "고객을 서로 유사한 그룹으로 나누는 경우",
      "두 범주형 변수의 독립성을 검정하는 경우",
      "이미지에서 객체를 인식하는 경우",
    ],
    answer: 0,
    explanation:
      "ARIMA 모형은 자기회귀와 이동평균, 차분을 결합하여 과거의 시계열 패턴을 학습하고, 이를 바탕으로 향후 매출액, 수요, 주가 등을 예측하는 대표적인 시계열 예측 기법입니다.",
  },
  {
    id: "du-175",
    subject: "3과목(데이터 분석)",
    question: "기존 순환 신경망(RNN)이 긴 시퀀스를 학습할 때 겪는 기울기 소실 문제를 게이트 구조로 완화한 딥러닝 기반 시계열 모델은?",
    options: ["LSTM(Long Short-Term Memory)", "K-Means", "SVM", "PCA"],
    answer: 0,
    explanation:
      "LSTM은 입력 게이트, 망각 게이트, 출력 게이트 등의 게이트 구조를 도입하여, 기존 RNN이 긴 시퀀스를 학습할 때 겪는 기울기 소실 문제를 완화하고 장기 의존성을 효과적으로 학습할 수 있게 한 신경망 구조입니다.",
  },
  {
    id: "du-176",
    subject: "3과목(데이터 분석)",
    question: "기존에 운영 중인 모델(챔피언)과 새롭게 개발한 후보 모델(챌린저)의 성능을 비교하여 교체 여부를 결정하는 모델 운영 방식은?",
    options: ["챔피언-챌린저(Champion-Challenger) 방식", "배깅 방식", "부스팅 방식", "군집분석 방식"],
    answer: 0,
    explanation:
      "챔피언-챌린저 방식은 현재 운영 중인 모델(챔피언)과 새롭게 개발된 후보 모델(챌린저)의 성능을 실제 데이터에서 비교 평가하여, 챌린저가 더 우수할 경우 이를 새로운 챔피언으로 교체하는 모델 운영 전략입니다.",
  },
  {
    id: "du-177",
    subject: "3과목(데이터 분석)",
    question: "A/B 테스트에서 두 그룹 간의 차이가 '통계적으로 유의하다'고 판단하는 일반적인 기준은?",
    options: [
      "검정 결과의 p-value가 사전에 정한 유의수준보다 작은 경우",
      "두 그룹의 표본 크기가 완전히 동일한 경우",
      "실험을 딱 한 번만 수행한 경우",
      "실험 기간이 정확히 하루인 경우",
    ],
    answer: 0,
    explanation:
      "A/B 테스트에서는 일반적으로 통계적 가설검정을 수행하여, 산출된 p-value가 사전에 정한 유의수준(예: 0.05)보다 작을 경우 두 그룹 간의 차이가 우연이 아닌 통계적으로 유의한 차이라고 판단합니다.",
  },
  {
    id: "du-178",
    subject: "3과목(데이터 분석)",
    question: "실험 설계에서 피험자를 실험군과 대조군에 무작위로 배정하는 '무작위 배정(Randomization)'의 주된 목적은?",
    options: [
      "관측되지 않은 교란변수의 영향을 두 집단에 고르게 분산시켜 인과관계 해석의 타당성을 높이기 위해서이다",
      "실험을 더 빨리 끝내기 위해서이다",
      "표본의 크기를 줄이기 위해서이다",
      "데이터 수집 비용을 늘리기 위해서이다",
    ],
    answer: 0,
    explanation:
      "무작위 배정은 피험자를 실험군과 대조군에 무작위로 나눔으로써, 관측되지 않은 다른 요인(교란변수)들이 두 집단에 고르게 분산되도록 하여, 처리 효과에 대한 인과관계 해석의 타당성을 높이기 위해 수행됩니다.",
  },
  {
    id: "du-179",
    subject: "3과목(데이터 분석)",
    question: "독립변수와 종속변수 모두에 영향을 미쳐, 두 변수 간의 관계를 왜곡시킬 수 있는 제3의 변수를 무엇이라 하는가?",
    options: ["교란변수(Confounding Variable)", "종속변수", "매개변수만 해당", "더미변수"],
    answer: 0,
    explanation:
      "교란변수는 관심 있는 독립변수와 종속변수 모두에 영향을 미쳐, 실제로는 인과관계가 없거나 다른 방향임에도 마치 관계가 있는 것처럼(혹은 왜곡되어) 보이게 만드는 제3의 변수입니다.",
  },
  {
    id: "du-180",
    subject: "3과목(데이터 분석)",
    question: "회귀분석을 통해 두 변수 사이에 통계적으로 유의한 관계가 발견되었을 때 주의해야 할 해석으로 가장 적절한 것은?",
    options: [
      "통계적 관계가 곧바로 인과관계를 의미하는 것은 아니므로 신중하게 해석해야 한다",
      "통계적으로 유의하면 무조건 하나가 다른 하나의 직접적인 원인이라고 확신할 수 있다",
      "회귀분석 결과는 인과관계 해석에 대한 고려가 전혀 필요 없다",
      "상관관계가 발견되면 반드시 실험 없이도 인과관계로 단정할 수 있다",
    ],
    answer: 0,
    explanation:
      "회귀분석이나 상관분석에서 통계적으로 유의한 관계가 발견되었다고 해서 반드시 인과관계를 의미하는 것은 아니며, 교란변수의 존재 가능성 등을 고려하여 신중하게 해석해야 합니다.",
  },
  {
    id: "du-181",
    subject: "3과목(데이터 분석)",
    question: "다변량 분석을 수행하기 전, 서로 다른 단위를 가진 변수들을 표준화해야 하는 이유로 가장 적절한 것은?",
    options: [
      "단위가 큰 변수가 분석 결과에 지나치게 큰 영향을 미치는 것을 방지하기 위해서이다",
      "표준화를 하면 모든 변수의 값이 항상 음수로 바뀌기 때문이다",
      "표준화는 결측치를 자동으로 채워주기 때문이다",
      "표준화를 하지 않으면 데이터가 자동으로 삭제되기 때문이다",
    ],
    answer: 0,
    explanation:
      "측정 단위가 서로 다른 변수들(예: 원 단위의 매출액과 %단위의 비율)을 그대로 분석에 사용하면, 값의 크기가 큰 변수가 분석 결과(특히 거리 기반 기법이나 PCA)에 부당하게 큰 영향을 미칠 수 있어, 이를 방지하기 위해 표준화를 수행합니다.",
  },
  {
    id: "du-182",
    subject: "3과목(데이터 분석)",
    question: "군집분석에서 두 데이터 포인트 사이의 거리를 계산할 때 사용하는 척도 중, 두 점을 잇는 직선 거리를 의미하는 것은?",
    options: ["유클리드 거리(Euclidean Distance)", "맨해튼 거리", "코사인 유사도", "자카드 유사도"],
    answer: 0,
    explanation:
      "유클리드 거리는 두 점 사이의 최단 직선 거리를 계산하는 방식으로, 군집분석이나 KNN 등에서 가장 널리 사용되는 거리 척도입니다.",
  },
  {
    id: "du-183",
    subject: "3과목(데이터 분석)",
    question: "두 점 사이의 거리를, 각 좌표축 방향으로 이동한 거리의 합으로 계산하는 거리 척도는?",
    options: ["맨해튼 거리(Manhattan Distance)", "유클리드 거리", "코사인 유사도", "자카드 유사도"],
    answer: 0,
    explanation:
      "맨해튼 거리는 바둑판식 도로망을 이동하듯, 두 점 사이의 거리를 각 좌표축 방향으로 이동한 거리의 절댓값의 합으로 계산하는 거리 척도입니다.",
  },
  {
    id: "du-184",
    subject: "3과목(데이터 분석)",
    question: "두 벡터 사이의 각도(방향)를 기준으로 유사도를 측정하며, 텍스트 데이터의 유사도 측정에 자주 사용되는 지표는?",
    options: ["코사인 유사도(Cosine Similarity)", "유클리드 거리", "맨해튼 거리", "자카드 유사도"],
    answer: 0,
    explanation:
      "코사인 유사도는 두 벡터 사이의 각도(코사인 값)를 이용해 방향의 유사성을 측정하는 지표로, 벡터의 크기보다 방향성이 중요한 텍스트 데이터(단어 빈도 벡터 등)의 유사도 측정에 널리 사용됩니다.",
  },
  {
    id: "du-185",
    subject: "3과목(데이터 분석)",
    question: "두 집합의 교집합 크기를 합집합 크기로 나누어, 두 집합이 얼마나 유사한지를 측정하는 지표는?",
    options: ["자카드 유사도(Jaccard Similarity)", "코사인 유사도", "유클리드 거리", "맨해튼 거리"],
    answer: 0,
    explanation:
      "자카드 유사도는 두 집합의 교집합 크기를 합집합 크기로 나눈 값으로, 두 집합(예: 두 사용자가 구매한 상품 목록)이 얼마나 겹치는지를 측정하는 유사도 지표입니다.",
  },
  {
    id: "du-186",
    subject: "3과목(데이터 분석)",
    question: "혼동행렬에서 실제 음성을 음성으로 올바르게 예측한 비율을 나타내는 지표는?",
    options: ["특이도(Specificity) = TN / (TN + FP)", "정밀도(Precision) = TP / (TP + FP)", "재현율(Recall) = TP / (TP + FN)", "정확도(Accuracy)"],
    answer: 0,
    explanation:
      "특이도(Specificity)는 실제 음성(Negative)인 것들 중에서, 모델이 이를 음성으로 올바르게 예측한 비율(TN / (TN + FP))을 나타내는 지표입니다.",
  },
  {
    id: "du-187",
    subject: "3과목(데이터 분석)",
    question: "혼동행렬에서 실제 양성인 것들 중, 모델이 이를 양성으로 올바르게 예측한 비율을 나타내는 지표는?",
    options: ["재현율(Recall, 민감도) = TP / (TP + FN)", "특이도 = TN / (TN + FP)", "정밀도 = TP / (TP + FP)", "정확도"],
    answer: 0,
    explanation:
      "재현율(Recall, 민감도)은 실제 양성(Positive)인 것들 중에서, 모델이 이를 양성으로 올바르게 예측해낸 비율(TP / (TP + FN))을 나타내는 지표입니다.",
  },
  {
    id: "du-188",
    subject: "3과목(데이터 분석)",
    question: "데이터 불균형이 심한 상황에서 '정확도(Accuracy)'만으로 모델을 평가할 때 발생할 수 있는 문제로 가장 적절한 것은?",
    options: [
      "다수 클래스만 예측해도 정확도가 매우 높게 나와, 실제 성능을 왜곡해서 보여줄 수 있다",
      "정확도는 항상 0에서 1 사이의 값만 가지므로 아무 문제가 없다",
      "정확도는 불균형 데이터에서 계산 자체가 불가능하다",
      "정확도가 높으면 반드시 모든 클래스를 완벽하게 예측한 것이다",
    ],
    answer: 0,
    explanation:
      "데이터 불균형이 심한 경우, 소수 클래스를 전혀 맞히지 못하고 다수 클래스만 예측해도 정확도가 매우 높게 나올 수 있어, 정확도만으로 모델을 평가하면 실제 성능이 왜곡되어 보일 수 있습니다. 이런 경우 정밀도, 재현율, F1-score 등을 함께 살펴봐야 합니다.",
  },
  {
    id: "du-189",
    subject: "3과목(데이터 분석)",
    question: "데이터마이닝(Data Mining)의 궁극적인 목적으로 가장 적절한 것은?",
    options: [
      "대용량 데이터로부터 숨겨진 유용한 패턴과 지식을 발견하여 의사결정에 활용하는 것",
      "데이터를 최대한 많이 수집하여 저장 공간을 채우는 것",
      "데이터를 무조건 암호화하여 아무도 볼 수 없게 만드는 것",
      "모든 데이터를 정기적으로 완전히 삭제하는 것",
    ],
    answer: 0,
    explanation:
      "데이터마이닝은 대용량의 데이터로부터 통계적, 수학적 기법을 활용하여 숨겨진 유용한 패턴, 규칙, 지식을 발견하고, 이를 실제 의사결정에 활용하는 것을 궁극적인 목적으로 합니다.",
  },
  {
    id: "du-190",
    subject: "3과목(데이터 분석)",
    question: "학습 데이터에 정답(레이블)이 주어지는지 여부에 따라 머신러닝을 구분할 때, 정답이 주어지지 않은 데이터에서 패턴이나 구조를 스스로 찾아내는 학습 방식은?",
    options: ["비지도학습(Unsupervised Learning)", "지도학습(Supervised Learning)", "강화학습", "준지도학습"],
    answer: 0,
    explanation:
      "비지도학습은 정답(레이블)이 주어지지 않은 데이터로부터, 군집이나 연관 규칙과 같은 숨겨진 패턴이나 구조를 스스로 찾아내는 학습 방식입니다.",
  },
  {
    id: "du-191",
    subject: "3과목(데이터 분석)",
    question: "레이블이 있는 소량의 데이터와, 레이블이 없는 대량의 데이터를 함께 사용하여 모델을 학습시키는 방식은?",
    options: ["준지도학습(Semi-supervised Learning)", "지도학습", "비지도학습", "강화학습"],
    answer: 0,
    explanation:
      "준지도학습은 레이블이 부여된 소량의 데이터와, 레이블이 없는 대량의 데이터를 함께 활용하여 모델을 학습시키는 방식으로, 레이블링 비용을 절감하면서도 성능을 향상시키고자 할 때 사용됩니다.",
  },
  {
    id: "du-192",
    subject: "3과목(데이터 분석)",
    question: "에이전트가 환경과 상호작용하며, 받는 보상을 최대화하는 방향으로 행동 전략을 학습해 나가는 머신러닝 방식은?",
    options: ["강화학습(Reinforcement Learning)", "지도학습", "비지도학습", "준지도학습"],
    answer: 0,
    explanation:
      "강화학습은 에이전트가 주어진 환경 속에서 행동을 하고 그에 따른 보상(또는 벌점)을 받으면서, 누적 보상을 최대화하는 최적의 행동 전략을 스스로 학습해 나가는 머신러닝 방식입니다.",
  },
  {
    id: "du-193",
    subject: "3과목(데이터 분석)",
    question: "특정 문제(도메인)에서 학습된 모델의 지식을, 관련된 다른 문제(도메인)에 적용하여 학습 효율을 높이는 기법은?",
    options: ["전이학습(Transfer Learning)", "강화학습", "군집분석", "연관규칙분석"],
    answer: 0,
    explanation:
      "전이학습은 대량의 데이터로 미리 학습된 모델의 지식(가중치 등)을, 데이터가 적은 관련된 다른 문제에 재사용함으로써 학습 시간을 줄이고 성능을 향상시키는 기법입니다.",
  },
  {
    id: "du-194",
    subject: "3과목(데이터 분석)",
    question: "여러 모델을 결합하는 앙상블 기법이 단일 모델보다 나은 성능을 보이는 일반적인 이유로 가장 적절한 것은?",
    options: [
      "여러 모델의 예측을 결합함으로써 개별 모델의 오차나 분산을 상쇄시켜 예측 성능과 안정성을 높일 수 있기 때문이다",
      "앙상블은 항상 계산 속도가 가장 빠르기 때문이다",
      "앙상블 기법은 데이터 전처리가 전혀 필요 없기 때문이다",
      "앙상블 기법은 항상 단 하나의 알고리즘만 사용하기 때문이다",
    ],
    answer: 0,
    explanation:
      "앙상블 기법은 서로 다른 특성을 가진 여러 모델의 예측 결과를 결합함으로써, 개별 모델이 가진 오차나 분산을 서로 상쇄시켜 전반적인 예측 성능과 안정성을 높이는 효과를 얻을 수 있습니다.",
  },
  {
    id: "du-195",
    subject: "3과목(데이터 분석)",
    question: "모델의 편향(Bias)을 줄이려고 복잡도를 높이면 분산(Variance)이 커지고, 반대로 분산을 줄이면 편향이 커지는 관계를 무엇이라 하는가?",
    options: ["편향-분산 트레이드오프(Bias-Variance Tradeoff)", "다중공선성", "과적합만 해당", "정상성"],
    answer: 0,
    explanation:
      "편향-분산 트레이드오프는 모델의 복잡도를 조절할 때, 편향(단순화로 인한 오차)과 분산(데이터 변화에 대한 민감도로 인한 오차) 사이에 존재하는 상충 관계를 의미하며, 적절한 균형점을 찾는 것이 모델링의 핵심 과제입니다.",
  },
  {
    id: "du-196",
    subject: "3과목(데이터 분석)",
    question: "편향(Bias)이 높은 모델이 일반적으로 보이는 경향으로 가장 적절한 것은?",
    options: [
      "모델이 지나치게 단순하여 데이터의 패턴을 충분히 학습하지 못하는 과소적합 경향을 보인다",
      "학습 데이터에 대해서는 항상 완벽한 성능을 보인다",
      "모델의 복잡도가 지나치게 높다",
      "새로운 데이터에 대해 항상 최고의 성능을 보인다",
    ],
    answer: 0,
    explanation:
      "편향(Bias)이 높은 모델은 지나치게 단순화된 가정을 사용하여, 데이터에 내재된 패턴을 충분히 포착하지 못하는 과소적합(Underfitting) 경향을 보이는 경우가 많습니다.",
  },
  {
    id: "du-197",
    subject: "3과목(데이터 분석)",
    question: "분산(Variance)이 높은 모델이 일반적으로 보이는 경향으로 가장 적절한 것은?",
    options: [
      "학습 데이터의 작은 변화에도 예측 결과가 크게 달라지며 과적합 경향을 보인다",
      "모델이 지나치게 단순하여 항상 과소적합된다",
      "학습 데이터와 테스트 데이터에서 항상 동일하게 낮은 성능을 보인다",
      "분산이 높으면 항상 모델의 성능이 완벽해진다",
    ],
    answer: 0,
    explanation:
      "분산(Variance)이 높은 모델은 학습 데이터의 작은 변화나 노이즈에도 민감하게 반응하여 예측 결과가 크게 달라지며, 학습 데이터에는 잘 맞지만 새로운 데이터에는 성능이 떨어지는 과적합(Overfitting) 경향을 보이는 경우가 많습니다.",
  },
  {
    id: "du-198",
    subject: "3과목(데이터 분석)",
    question: "데이터마이닝 프로젝트에서, 여러 후보 모델 중 최종 모델을 선정할 때 고려해야 할 기준으로 가장 거리가 먼 것은?",
    options: [
      "예측 성능, 해석 용이성, 운영 환경에서의 적용 가능성",
      "모델 개발자의 개인적인 선호도만을 유일한 기준으로 삼는 것",
      "모델의 계산 복잡도와 유지보수 용이성",
      "비즈니스 목적에 대한 부합성",
    ],
    answer: 1,
    explanation:
      "최종 모델 선정 시에는 예측 성능, 해석 용이성, 운영 환경 적용 가능성, 계산 복잡도, 비즈니스 목적 부합성 등을 종합적으로 고려해야 하며, 개발자 개인의 선호도만을 유일한 기준으로 삼아서는 안 됩니다.",
  },
  {
    id: "du-199",
    subject: "3과목(데이터 분석)",
    question: "정형 데이터마이닝의 대표적인 기법을 분류(Classification), 예측(Prediction), 군집화(Clustering), 연관분석(Association)으로 나눌 때, 종속변수가 연속형 수치일 경우에 해당하는 기법은?",
    options: [
      "예측(Prediction, 회귀분석 등)",
      "분류(Classification)만 해당",
      "군집화(Clustering)만 해당",
      "연관분석(Association)만 해당",
    ],
    answer: 0,
    explanation:
      "종속변수가 연속형 수치일 때는 회귀분석과 같은 예측(Prediction) 기법을 사용하며, 종속변수가 범주형일 때는 분류(Classification), 정답 없이 유사한 데이터를 묶을 때는 군집화, 항목 간의 관계를 찾을 때는 연관분석을 사용합니다.",
  },
  {
    id: "du-200",
    subject: "3과목(데이터 분석)",
    question: "데이터 분석 프로젝트에서 모델의 성능만큼이나 '해석 가능성(Interpretability)'이 중요하게 여겨지는 경우로 가장 적절한 것은?",
    options: [
      "대출 심사, 의료 진단과 같이 예측 근거를 이해관계자에게 설명할 책임이 있는 경우",
      "예측 결과를 아무도 확인하지 않는 완전히 자동화된 스팸 필터링만 해당하는 경우",
      "해석 가능성은 어떤 경우에도 전혀 중요하지 않다",
      "성능이 조금이라도 높으면 해석 가능성은 항상 무시해도 된다",
    ],
    answer: 0,
    explanation:
      "대출 심사나 의료 진단처럼 예측 결과가 개인에게 중대한 영향을 미치고, 그 판단 근거를 당사자나 규제 기관에 설명해야 할 책임이 있는 경우에는 모델의 예측 성능뿐 아니라 해석 가능성(Interpretability)도 매우 중요하게 고려됩니다.",
  },
];

// 과목별/전체/약점 풀기에 쓰는 기본 문제은행. 기출(data/past-exams.ts)은 섞지 않고 따로 출제한다.
export const questions: Question[] = baseQuestions;

// id로 문제를 찾을 때만 쓴다(오답노트·통계·검색·서버 채점). 기출을 풀었던 기록도 찾아야 하므로 둘 다 포함.
export const allQuestions: Question[] = [...baseQuestions, ...pastExamQuestions];

export function getQuestionsBySubject(subject: Subject | "전체"): Question[] {
  if (subject === "전체") return [...questions];
  return questions.filter((q) => q.subject === subject);
}

export function getRandomQuestions(subject: Subject | "전체", count: number): Question[] {
  const pool = getQuestionsBySubject(subject);
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, Math.min(count, shuffled.length));
}

// 실제 ADsP 시험 구성(1과목 10문항 · 2과목 10문항 · 3과목 30문항 · 총 50문항)과 동일하게
// 매번 기출 복원 문제(data/past-exams.ts)에서만 무작위로 뽑아 모의고사를 구성한다.
export const MOCK_EXAM_COUNTS: Record<Subject, number> = {
  "1과목(데이터 이해)": 10,
  "2과목(데이터 분석 기획)": 10,
  "3과목(데이터 분석)": 30,
};

export function getMockExamQuestions(): Question[] {
  return SUBJECTS.flatMap((subject) => {
    const pool = pastExamQuestions.filter((q) => q.subject === subject);
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, MOCK_EXAM_COUNTS[subject]);
  });
}

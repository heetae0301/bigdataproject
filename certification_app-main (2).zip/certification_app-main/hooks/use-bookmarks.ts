import { useCallback, useEffect, useState } from "react";
import { getBookmarks, toggleBookmark } from "@/lib/storage";

/** 북마크 목록을 불러오고, 토글은 화면에 먼저 반영한 뒤 서버에 저장한다(실패 시 되돌림). */
export function useBookmarks() {
  const [ids, setIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    getBookmarks()
      .then((list) => setIds(new Set(list)))
      .catch(() => {});
  }, []);

  const flip = useCallback((questionId: string) => {
    setIds((prev) => {
      const next = new Set(prev);
      if (next.has(questionId)) next.delete(questionId);
      else next.add(questionId);
      return next;
    });
  }, []);

  const toggle = useCallback(
    async (questionId: string) => {
      flip(questionId);
      try {
        await toggleBookmark(questionId);
      } catch (error) {
        console.warn("[Bookmark] toggle failed:", error);
        flip(questionId);
      }
    },
    [flip]
  );

  return { isBookmarked: (questionId: string) => ids.has(questionId), toggle };
}

import { useCallback, useEffect, useState } from "react";
import { getNotes, setNote } from "@/lib/storage";

/** 문제별 메모를 불러오고, 저장은 화면에 먼저 반영한 뒤 서버에 보낸다(실패 시 되돌림). */
export function useNotes() {
  const [notes, setNotes] = useState<Map<string, string>>(new Map());

  const reload = useCallback(() => {
    getNotes()
      .then((list) => setNotes(new Map(list.map((n) => [n.questionId, n.note]))))
      .catch(() => {});
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const put = useCallback((questionId: string, note: string) => {
    setNotes((prev) => {
      const next = new Map(prev);
      if (note) next.set(questionId, note);
      else next.delete(questionId);
      return next;
    });
  }, []);

  const save = useCallback(
    async (questionId: string, note: string) => {
      const previous = notes.get(questionId) ?? "";
      const trimmed = note.trim();
      put(questionId, trimmed);
      try {
        await setNote(questionId, trimmed);
      } catch (error) {
        console.warn("[Note] save failed:", error);
        put(questionId, previous);
      }
    },
    [notes, put]
  );

  return { get: (questionId: string) => notes.get(questionId) ?? "", save, reload };
}

import { useSyncExternalStore } from "react";
import { useThemeContext } from "@/lib/theme-provider";

const noopSubscribe = () => () => {};

/**
 * To support static rendering, this value needs to be re-calculated on the client side for web
 */
export function useColorScheme() {
  // 서버(정적 렌더링)와 hydration 중에는 false, 그 뒤 클라이언트에서는 true.
  // effect 안에서 setState로 한 번 더 그리던 방식을 대신한다.
  const hasHydrated = useSyncExternalStore(
    noopSubscribe,
    () => true,
    () => false,
  );

  // 네이티브와 똑같이 ThemeProvider의 값을 쓴다 - 그래야 설정에서 고른 테마(밝게/어둡게)가
  // 웹에서도 적용된다.
  const { colorScheme } = useThemeContext();

  if (hasHydrated) {
    return colorScheme;
  }

  return "light";
}

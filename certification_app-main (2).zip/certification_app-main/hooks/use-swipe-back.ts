import { useState } from "react";
import { PanResponder } from "react-native";
import { useRouter } from "expo-router";

// 화면 왼쪽 가장자리에서 시작해 오른쪽으로 미는 스와이프를 감지해서 뒤로가기를
// 실행한다. OS 레벨 스와이프 뒤로가기(iOS 기본, Android predictive back)는
// Expo Go 같은 사전 빌드된 셸에서는 프로젝트별 네이티브 설정이 반영되지 않으므로,
// 플랫폼/빌드 방식과 무관하게 항상 동작하도록 순수 JS 제스처로 구현한다.
const EDGE_WIDTH = 32;
const CLOSE_DISTANCE = 80;
const CLOSE_VELOCITY = 0.8;

export function useSwipeBack() {
  const router = useRouter();

  // 처음 한 번만 만든다 (router는 화면이 살아 있는 동안 같은 객체)
  const [panResponder] = useState(() =>
    PanResponder.create({
      onMoveShouldSetPanResponder: (_evt, gesture) =>
        gesture.x0 <= EDGE_WIDTH &&
        gesture.dx > 10 &&
        Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.5,
      onPanResponderRelease: (_evt, gesture) => {
        if (gesture.dx > CLOSE_DISTANCE || gesture.vx > CLOSE_VELOCITY) {
          router.back();
        }
      },
    })
  );

  return panResponder.panHandlers;
}

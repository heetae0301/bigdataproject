// README용 앱 스크린샷 찍기: `pnpm screenshots` (먼저 `pnpm dev`로 서버를 켜 둔다)
//
// 새 계정으로 세 과목을 풀어(대부분 맞히고 일부는 틀리게) 통계·오답노트를 채운 뒤 주요 화면을
// docs/screenshots/에 저장한다. API는 로컬 서버(local.db)로 돌리고 AI 요청은 막는다 — 동그래 칠판 해설은
// local.db의 scene_cache에 저장된 대본이 있으면 그걸 쓴다(없으면 그 장면만 건너뜀).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createClient } from "@libsql/client";
import questionsModule from "../data/questions.ts";
import { APP, API, REMOTE, isAiCall, launch, trpcOk } from "./lib.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT = path.join(ROOT, "docs", "screenshots");
fs.mkdirSync(OUT, { recursive: true });

const { allQuestions } = questionsModule as typeof import("../data/questions");

// 칠판 해설 장면에 쓸 문제 (local.db에 저장된 실제 AI 대본)
const SCENE_QUESTION_ID = "di-004";
const SCENE_OPTION = 0;
async function cachedScenes(): Promise<unknown[] | null> {
  try {
    const db = createClient({ url: `file:${path.join(ROOT, "local.db")}` });
    const row = await db.execute({
      sql: "select scenes_json from scene_cache where question_id = ? and selected_option = ?",
      args: [SCENE_QUESTION_ID, SCENE_OPTION],
    });
    const json = row.rows[0]?.scenes_json;
    return typeof json === "string" ? JSON.parse(json).scenes : null;
  } catch {
    return null;
  }
}
const scenes = await cachedScenes();

function makeWav(seconds: number) {
  const rate = 8000;
  const n = rate * seconds;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  return buf; // 무음
}
const WAV = makeWav(36);

const browser = await launch(["--autoplay-policy=no-user-gesture-required"]);
const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, locale: "ko-KR" });
await ctx.route(REMOTE, async (route) => {
  const url = route.request().url();
  if (url.includes("explain.generateScenes") && scenes) return route.fulfill({ contentType: "application/json", body: trpcOk({ scenes }) });
  if (url.includes("explain.prepareSpeech")) return route.fulfill({ contentType: "application/json", body: trpcOk({ path: "/api/tts/readme.wav", durationSec: 36 }) });
  if (url.includes("/api/tts/readme.wav")) return route.fulfill({ contentType: "audio/wav", body: WAV, headers: { "accept-ranges": "bytes" } });
  if (isAiCall(url)) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
});
const page = await ctx.newPage();
const save = async (name: string) => {
  await page.waitForTimeout(700);
  await page.screenshot({ path: path.join(OUT, `${name}.png`) });
  console.log("saved", name);
};
const goto = async (p: string, waitText: string) => {
  await page.goto(APP + p, { waitUntil: "networkidle" });
  await page.getByText(waitText).first().waitFor({ timeout: 20000 });
};

/** 지금 보이는 문제를 푼다. correct면 정답, 아니면 오답을 고른다. */
async function answerCurrent(correct: boolean) {
  // 화면에 보이는 문제를 문제은행에서 찾는다 (다른 문제의 일부인 짧은 문제와 헷갈리지 않게 가장 긴 것)
  const body = await page.locator("body").innerText();
  const hit = allQuestions
    .filter((q) => body.includes(q.question))
    .sort((a, b) => b.question.length - a.question.length)[0];
  const answer = hit?.answer ?? 0;
  const pick = correct ? answer : (answer + 1) % 4;
  await page.getByRole("radio").nth(pick).click();
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(300);
}
async function solveSession(subject: string, count: number, wrongAt: number[]) {
  await goto(`/quiz-session?subject=${encodeURIComponent(subject)}`, "정답 확인");
  for (let i = 0; i < count; i++) {
    await answerCurrent(!wrongAt.includes(i));
    await page.getByText(i < count - 1 ? "다음 문제" : "결과 보기", { exact: true }).click();
    await page.waitForTimeout(250);
  }
}

// 1) 로그인 화면
await goto("/login", "오늘도 같이 공부하자!");
await save("login");

// 2) 가입
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`readme+${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("준비생");
await page.getByPlaceholder("6자 이상").fill("readme1234");
await page.getByPlaceholder("비밀번호 재입력").fill("readme1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

// 3) 시험일 설정 (이번 달 또는 다음 달 15일)
await goto("/settings", "설정");
await page.getByText("시험일", { exact: true }).click();
await page.getByText("달력에서 시험일을 선택하세요").waitFor({ timeout: 5000 });
await page.getByText("15", { exact: true }).last().click();
await page.getByText("시험일 저장").click();
await page.waitForTimeout(600);

// 4) 문제 풀이 화면 (정답을 맞힌 직후)
await goto(`/quiz-session?subject=${encodeURIComponent("2과목(데이터 분석 기획)")}`, "정답 확인");
await answerCurrent(true);
await save("question");

// 5) 세 과목 풀어서 기록 채우기 (2과목은 이어서)
for (let i = 1; i < 10; i++) {
  await page.getByText("다음 문제", { exact: true }).click();
  await page.waitForTimeout(250);
  await answerCurrent(![3, 7].includes(i));
}
await page.getByText("결과 보기", { exact: true }).click();
await solveSession("3과목(데이터 분석)", 30, [2, 5, 9, 14, 17, 21, 26]);
await solveSession("1과목(데이터 이해)", 10, [1, 6]);

// 6) 결과 화면 — 전체 목록에서 틀린 문제 하나 펼치기
await page.getByText("이번 점수").waitFor({ timeout: 8000 });
await page.getByRole("radio", { name: /^전체/ }).click();
await page.getByLabel(/^Q\d+ 틀린 문제 펼치기$/).first().click();
await page.waitForTimeout(400);
await page.evaluate(() => window.scrollTo(0, 0));
await page.getByText("문제 다시 보기").scrollIntoViewIfNeeded();
await page.mouse.wheel(0, -120);
await save("result");

// 7) 탭 화면들
await goto("/", "과목별 학습 현황");
await save("home");
await goto("/quiz", "실전 모의고사");
await save("quiz-tab");
await goto("/wrong", "오늘 복습할 오답");
await save("wrong-notes");
await goto("/stats", "학습 통계");
await save("stats");

// 8) 동그래 칠판 해설
if (scenes) {
  await goto(`/quiz-session?subject=${encodeURIComponent("다시")}&ids=${SCENE_QUESTION_ID}`, "정답 확인");
  await page.getByRole("radio").nth(SCENE_OPTION).click();
  await page.getByText("정답 확인", { exact: true }).click();
  await page.getByText("동그래 해설 듣기").click();
  await page.getByText("해설 듣기", { exact: true }).waitFor({ timeout: 10000 });
  await page.getByText("해설 듣기", { exact: true }).click();
  await page.getByText("일시정지", { exact: true }).waitFor({ timeout: 10000 });
  // 비교표 장면(마지막)으로 이동
  const bar = await page.getByLabel("재생 위치").boundingBox();
  if (bar) await page.mouse.click(bar.x + bar.width * 0.8, bar.y + bar.height / 2);
  await page.waitForTimeout(1200);
  await page.getByText("일시정지", { exact: true }).click();
  await save("dongurae-chalkboard");
} else {
  console.log("skip dongurae-chalkboard: local.db에 저장된 칠판 대본이 없어요");
}

// 9) 다크 모드 홈
await goto("/settings", "설정");
await page.getByText("어둡게", { exact: true }).click();
await goto("/", "과목별 학습 현황");
await save("home-dark");
await goto("/settings", "설정");
await page.getByText("자동", { exact: true }).click();

await browser.close();
console.log(`\n저장 위치: ${path.relative(ROOT, OUT)}`);

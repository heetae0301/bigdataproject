// E2E 공통 설정: 브라우저 실행, API 주소 가로채기, 결과 출력.
//
// 웹 앱(Metro, 기본 http://localhost:8081)을 실제 브라우저로 열고, 앱이 부르는 API를 로컬 API 서버
// (기본 http://localhost:3000, local.db)로 돌린다. .env에 배포 서버 주소(EXPO_PUBLIC_API_BASE_URL)가
// 있으면 웹 앱이 그 주소를 부르므로, 그 요청도 가로채서 로컬로 보낸다 — 배포 DB에 테스트 계정이 생기지 않는다.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright-core";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

export const APP = (process.env.E2E_APP_URL ?? "http://localhost:8081").replace(/\/$/, "");
export const API = (process.env.E2E_API_URL ?? "http://localhost:3000").replace(/\/$/, "");

function configuredApiBase() {
  if (process.env.EXPO_PUBLIC_API_BASE_URL) return process.env.EXPO_PUBLIC_API_BASE_URL;
  try {
    const line = fs
      .readFileSync(path.join(ROOT, ".env"), "utf8")
      .split(/\r?\n/)
      .find((l) => l.startsWith("EXPO_PUBLIC_API_BASE_URL="));
    return line?.slice(line.indexOf("=") + 1).trim().replace(/^["']|["']$/g, "") || null;
  } catch {
    return null;
  }
}

const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const apiBases = [configuredApiBase(), API].filter(Boolean).map((b) => b.replace(/\/$/, ""));
/** 앱이 부르는 API 주소(배포 주소 또는 로컬). `url.replace(REMOTE, API)`로 로컬 주소가 된다. */
export const REMOTE = new RegExp(`^(${[...new Set(apiBases)].map(escapeRe).join("|")})`);

/** tRPC 응답 모양 */
export const trpcOk = (data) => JSON.stringify([{ result: { data: { json: data } } }]);
export const trpcErr = (message = "stub", code = "INTERNAL_SERVER_ERROR", httpStatus = 500) =>
  JSON.stringify([{ error: { json: { message, code: -32603, data: { code, httpStatus } } } }]);

/** AI(글 생성·음성)를 부르는 요청 — 테스트에서는 요금이 나가지 않도록 항상 가짜로 응답한다. */
export const isAiCall = (url) => /\/api\/trpc\/[^?]*explain\./.test(url) || /\/api\/trpc\/[^?]*vision\./.test(url);

const SHOTS = path.join(ROOT, "e2e", "shots");
fs.mkdirSync(SHOTS, { recursive: true });
/** 스크린샷 저장 경로 (e2e/shots/<name>.png, git에 올리지 않음) */
export const shot = (name) => path.join(SHOTS, `${name}.png`);

/**
 * 설치된 브라우저로 실행한다 (playwright 브라우저를 따로 받지 않는다).
 * 기본: Windows는 Edge, 그 밖은 Chrome. E2E_BROWSER_CHANNEL(msedge/chrome) 또는 E2E_BROWSER_PATH로 바꿀 수 있다.
 * E2E_HEADED=1이면 창을 띄운다.
 */
export function launch(args = []) {
  const options = { headless: process.env.E2E_HEADED !== "1", args };
  if (process.env.E2E_BROWSER_PATH) options.executablePath = process.env.E2E_BROWSER_PATH;
  else options.channel = process.env.E2E_BROWSER_CHANNEL ?? (process.platform === "win32" ? "msedge" : "chrome");
  return chromium.launch(options);
}

/** 휴대폰 크기 컨텍스트 */
export function phoneContext(browser) {
  return browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, locale: "ko-KR" });
}

/** 결과 기록/출력. 실패가 하나라도 있으면 종료 코드 1. */
export function reporter() {
  const results = [];
  const log = (name, ok, detail = "") => {
    results.push({ name, ok, detail });
    console.log(`${ok ? "PASS" : "FAIL"} | ${name}${detail ? " | " + detail : ""}`);
  };
  const finish = () => {
    const failed = results.filter((r) => !r.ok).length;
    console.log(`\n${results.length - failed}/${results.length} passed`);
    if (failed > 0) process.exitCode = 1;
  };
  return { results, log, finish };
}

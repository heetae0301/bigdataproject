// E2E 전체 실행: `pnpm test:e2e` (특정 묶음만: `pnpm test:e2e player scenes`)
// 먼저 `pnpm dev`로 API 서버(3000)와 Metro(8081)를 켜 둬야 한다. 자세한 내용은 TESTING.md.
import { spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { APP, API } from "./lib.mjs";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const filters = process.argv.slice(2);
const suites = fs
  .readdirSync(path.join(DIR, "suites"))
  .filter((f) => f.endsWith(".mjs"))
  .filter((f) => filters.length === 0 || filters.some((x) => f.includes(x)))
  .sort();

async function reachable(url) {
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
    return res.ok;
  } catch {
    return false;
  }
}

if (!(await reachable(`${API}/api/health`)) || !(await reachable(APP))) {
  console.error(`서버가 꺼져 있어요. 먼저 \`pnpm dev\`로 API(${API})와 Metro(${APP})를 켜 주세요.`);
  process.exit(1);
}
if (suites.length === 0) {
  console.error(`"${filters.join(" ")}"에 맞는 테스트가 없어요.`);
  process.exit(1);
}

const summary = [];
for (const file of suites) {
  console.log(`\n━━ ${file} ━━`);
  const started = Date.now();
  const code = await new Promise((resolve) => {
    const child = spawn(process.execPath, [path.join(DIR, "suites", file)], { stdio: ["ignore", "pipe", "inherit"] });
    let last = "";
    child.stdout.on("data", (chunk) => {
      process.stdout.write(chunk);
      last += chunk.toString();
    });
    child.on("close", (exitCode) => {
      const passed = last.match(/(\d+)\/(\d+) passed/g)?.at(-1) ?? "결과 없음";
      summary.push({ file, ok: exitCode === 0, passed, sec: Math.round((Date.now() - started) / 1000) });
      resolve(exitCode);
    });
  });
  void code;
}

console.log("\n━━ 요약 ━━");
for (const s of summary) console.log(`${s.ok ? "PASS" : "FAIL"}  ${s.file.padEnd(22)} ${s.passed.padEnd(14)} ${s.sec}s`);
const failed = summary.filter((s) => !s.ok).length;
console.log(failed ? `\n${failed}개 묶음 실패 (스크린샷: e2e/shots/)` : "\n모두 통과");
process.exit(failed ? 1 : 0);

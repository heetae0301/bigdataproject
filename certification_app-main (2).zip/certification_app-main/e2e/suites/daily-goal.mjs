// 오늘의 목표 직접 설정 E2E: 홈 팝업(−/+, 칩, 직접 입력, 취소/저장)과 설정 화면 편집기, 새로고침 후 유지.
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();
const browser = await launch();
const ctx = await phoneContext(browser);
await ctx.route(REMOTE, async (r) => /explain./.test(r.request().url()) ? r.fulfill({ status: 500, contentType: "application/json", body: "[]" }) : r.fulfill({ response: await r.fetch({ url: r.request().url().replace(REMOTE, API) }) }));
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
async function step(name, fn) {
  try { const [ok, detail] = await fn(); log(name, ok, detail); }
  catch (e) { await page.screenshot({ path: shot(`g-fail-${results.length}`) }).catch(() => {}); log(name, false, String(e).split("\n")[0]); }
}
const homeGoal = async () => (await page.getByLabel(/오늘의 목표 \d+문제, 눌러서 바꾸기/).getAttribute("aria-label")).match(/\d+/)[0];
const input = () => page.getByLabel("하루 목표 문제 수");
const goHome = async () => {
  await page.goto(APP + "/", { waitUntil: "networkidle" });
  await page.getByText("과목별 학습 현황").waitFor({ timeout: 20000 });
  await page.waitForTimeout(500);
};

await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+g${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("g");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);
await goHome();

await step("기본 목표 20문제", async () => [await homeGoal() === "20", `/${await homeGoal()}`]);

await step("홈에서 목표 누르면 설정 화면이 아니라 팝업", async () => {
  await page.getByLabel(/오늘의 목표 \d+문제, 눌러서 바꾸기/).click();
  await page.getByText("하루에 몇 문제를 풀지 정해 보세요.").waitFor({ timeout: 5000 });
  await page.screenshot({ path: shot("g-01-dialog") });
  return [!page.url().includes("settings") && (await input().inputValue()) === "20", `입력칸 ${await input().inputValue()}`];
});

await step("+ 두 번 → 30, − 한 번 → 25", async () => {
  await page.getByLabel("목표 늘리기").click();
  await page.getByLabel("목표 늘리기").click();
  const a = await input().inputValue();
  await page.getByLabel("목표 줄이기").click();
  const b = await input().inputValue();
  return [a === "30" && b === "25", `${a} → ${b}`];
});

await step("취소하면 홈 목표 그대로", async () => {
  await page.getByText("취소", { exact: true }).click();
  await page.waitForTimeout(400);
  return [await homeGoal() === "20", `/${await homeGoal()}`];
});

await step("다시 열면 저장된 값(20)부터 시작", async () => {
  await page.getByLabel(/오늘의 목표 \d+문제, 눌러서 바꾸기/).click();
  await page.waitForTimeout(400);
  return [(await input().inputValue()) === "20", `입력칸 ${await input().inputValue()}`];
});

await step("직접 입력 37 → 저장 → 홈에 37, 말풍선도 37 기준", async () => {
  await input().click();
  await input().fill("37");
  await page.screenshot({ path: shot("g-02-typed") });
  await page.getByText("저장", { exact: true }).click();
  await page.waitForTimeout(500);
  const bubble = await page.getByText(/시작해 볼까|더 풀면/).first().textContent();
  await page.screenshot({ path: shot("g-03-home-37") });
  return [await homeGoal() === "37", `/${await homeGoal()}, 말풍선 "${bubble.replace(/\n/g, " ")}"`];
});

await step("범위 밖(0, 500) 입력은 무시하고 마지막 유효값 유지", async () => {
  await page.getByLabel(/오늘의 목표 \d+문제, 눌러서 바꾸기/).click();
  await input().click();
  await input().fill("0");
  await page.getByText("하루에 몇 문제를 풀지 정해 보세요.").click(); // 입력칸 밖을 눌러 blur
  const afterZero = await input().inputValue();
  await input().click();
  await input().fill("500");
  await page.getByText("하루에 몇 문제를 풀지 정해 보세요.").click();
  const after500 = await input().inputValue();
  return [afterZero === "37" && after500 === "37", `0 → ${afterZero}, 500 → ${after500} (둘 다 무시)`];
});

await step("칩 10문제 → 저장 → 홈 10", async () => {
  await page.getByText("10문제", { exact: true }).click();
  await page.getByText("저장", { exact: true }).click();
  await page.waitForTimeout(400);
  return [await homeGoal() === "10", `/${await homeGoal()}`];
});

await step("새로고침해도 유지", async () => {
  await goHome();
  return [await homeGoal() === "10", `/${await homeGoal()}`];
});

await step("설정 화면 편집기: + 누르면 즉시 반영 → 홈 15", async () => {
  await page.goto(APP + "/settings", { waitUntil: "networkidle" });
  await page.getByText("하루 목표").waitFor({ timeout: 10000 });
  await page.getByLabel("목표 늘리기").click();
  const v = await input().inputValue();
  await page.getByLabel("하루 목표 문제 수").scrollIntoViewIfNeeded();
  await page.screenshot({ path: shot("g-04-settings") });
  await goHome();
  return [v === "15" && (await homeGoal()) === "15", `설정 ${v}, 홈 /${await homeGoal()}`];
});

await step("최소값 1에서 − 버튼 비활성", async () => {
  await page.goto(APP + "/settings", { waitUntil: "networkidle" });
  await input().click();
  await input().fill("1");
  await page.getByText("하루 목표").click();
  const d = await page.getByLabel("목표 줄이기").getAttribute("aria-disabled");
  return [d === "true", `aria-disabled=${d}`];
});

log("페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
await browser.close();
finish();

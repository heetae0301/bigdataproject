// 1) 서버에 못 닿으면 로그인을 지우지 않고 "다시 시도" 화면 → 다시 시도로 복구
// 2) 서버가 토큰이 무효라고 하면(401) 로그인 화면으로
// 3) 통계 약한 과목 문구: 과목 1개면 "야. 10문제 더 풀어 볼까?", 2개 이상이면 "로 제일 약해"
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

const browser = await launch();
const ctx = await phoneContext(browser);
let meMode = "pass"; // pass | offline | unauthorized
await ctx.route(REMOTE, async (route) => {
  const url = route.request().url();
  if (/explain\./.test(url)) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  if (url.includes("auth.me")) {
    if (meMode === "offline") return route.abort("internetdisconnected");
    if (meMode === "unauthorized")
      return route.fulfill({ status: 401, contentType: "application/json", body: JSON.stringify([{ error: { json: { message: "로그인이 필요합니다.", code: -32001, data: { code: "UNAUTHORIZED", httpStatus: 401, path: "auth.me" } } } }]) });
  }
  await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
async function step(name, fn) {
  try { const [ok, detail] = await fn(); log(name, ok, detail); }
  catch (e) { await page.screenshot({ path: shot(`a-fail-${results.length}`) }).catch(() => {}); log(name, false, String(e).split("\n")[0]); }
}
const tokenKeys = () => page.evaluate(() => Object.keys(localStorage).filter((k) => /token|auth/i.test(k)));

await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+a${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("연결테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);
const savedKeys = await tokenKeys();

await step("오프라인으로 앱 열기 → '서버에 연결하지 못했어요' + 로그인 유지", async () => {
  meMode = "offline";
  await page.goto(APP + "/", { waitUntil: "domcontentloaded" });
  await page.getByText("서버에 연결하지 못했어요").waitFor({ timeout: 15000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: shot("a-01-offline") });
  const imgOk = await page.locator("img").first().evaluate((i) => i.complete && i.naturalWidth > 0).catch(() => "no img");
  console.log("mascot loaded:", imgOk);
  const keys = await tokenKeys();
  const onLogin = await page.getByPlaceholder("you@example.com").isVisible().catch(() => false);
  return [keys.length > 0 && keys.length === savedKeys.length && !onLogin, `저장된 로그인 키 ${keys.join(",") || "없음"}, 로그인 화면 ${onLogin}`];
});

await step("연결 복구 후 '다시 시도' → 홈으로", async () => {
  meMode = "pass";
  await page.getByText("다시 시도", { exact: true }).click();
  await page.getByText("오늘의 목표").first().waitFor({ timeout: 15000 });
  return [true, "홈 표시"];
});

await step("오프라인 화면에서 '다른 계정으로 로그인' → 로그인 화면", async () => {
  meMode = "offline";
  await page.goto(APP + "/", { waitUntil: "domcontentloaded" });
  await page.getByText("다른 계정으로 로그인").waitFor({ timeout: 15000 });
  await page.getByText("다른 계정으로 로그인").click();
  await page.getByPlaceholder("you@example.com").waitFor({ timeout: 10000 });
  return [(await tokenKeys()).length === 0, "로그인 화면, 저장된 로그인 지워짐"];
});

// 다시 로그인용 계정 새로 만들기
meMode = "pass";
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+a2${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("연결테스트2");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

await step("서버가 401(무효 토큰) → 로그인 화면 + 로그인 정보 삭제", async () => {
  meMode = "unauthorized";
  await page.goto(APP + "/", { waitUntil: "domcontentloaded" });
  await page.getByPlaceholder("you@example.com").waitFor({ timeout: 15000 });
  const err = await page.getByText("서버에 연결하지 못했어요").isVisible();
  return [!err && (await tokenKeys()).length === 0, `오류 화면 ${err}`];
});

// 통계 문구
meMode = "pass";
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+st${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("통계테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);
async function solve(subject, n) {
  await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent(subject), { waitUntil: "networkidle" });
  for (let i = 0; i < n; i++) {
    await page.getByRole("radio").nth(i % 4).click({ timeout: 8000 });
    await page.getByText("정답 확인", { exact: true }).click();
    await page.waitForTimeout(500);
    const next = page.getByText(/다음 문제|결과 보기/).first();
    if (await next.isVisible()) await next.click();
    await page.waitForTimeout(500);
  }
}
const tipText = async () => {
  await page.goto(APP + "/stats", { waitUntil: "networkidle" });
  await page.waitForTimeout(1200);
  return (await page.getByText(/정답률이/).first().textContent()).replace(/\s+/g, " ");
};
await step("한 과목만 풀었으면 '제일 약해'라고 하지 않음", async () => {
  await solve("1과목(데이터 이해)", 10);
  const t = await tipText();
  await page.screenshot({ path: shot("a-02-stats-one") });
  return [t.includes("야. 10문제 더 풀어 볼까?") && !t.includes("제일 약해"), t];
});
await step("두 과목 이상이면 가장 낮은 과목을 '제일 약해'로", async () => {
  await solve("2과목(데이터 분석 기획)", 10);
  const t = await tipText();
  await page.screenshot({ path: shot("a-03-stats-two") });
  return [/%로 제일 약해/.test(t), t];
});

log("페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
await browser.close();
finish();

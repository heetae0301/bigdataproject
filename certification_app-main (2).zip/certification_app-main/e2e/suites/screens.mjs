// 새 화면 E2E: 로그인/회원가입/비밀번호 찾기, 문제풀기 탭, 문제 풀이(정답 확인·결과·틀린 문제 복습),
// 오답노트 탭(칩·복습 카드·해설 접기), 통계 탭, 설정 탭(시험일·테마·글자 크기), 다크 모드.
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

const browser = await launch();
async function newPage() {
  const ctx = await phoneContext(browser);
  await ctx.route(REMOTE, async (r) => {
    const url = r.request().url();
    // AI 호출은 할당량을 쓰지 않도록 실패로 돌린다 (앱은 기본 해설로 대체)
    if (url.includes("explain.")) return r.fulfill({ status: 500, contentType: "application/json", body: "[]" });
    await r.fulfill({ response: await r.fetch({ url: url.replace(REMOTE, API) }) });
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  return { ctx, page, errors };
}
const path = (page) => decodeURIComponent(page.url().replace(APP, "")) || "/";
async function step(page, name, fn) {
  try {
    const [ok, detail] = await fn();
    log(name, ok, detail);
  } catch (e) {
    await page.screenshot({ path: shot(`s-fail-${results.length}`) }).catch(() => {});
    log(name, false, String(e).split("\n")[0]);
  }
}
/** 보기 idx를 고르고 정답 확인. 맞았는지 돌려준다 */
async function answer(page, idx) {
  await page.getByRole("radio").nth(idx).click();
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(400);
  return page.getByText("정답이에요!").isVisible();
}
async function goto(page, p, waitText) {
  await page.goto(APP + p, { waitUntil: "networkidle" });
  if (waitText) await page.getByText(waitText).first().waitFor({ timeout: 20000 });
  await page.waitForTimeout(600);
}

// ───────────── 1. 로그인 전 화면 ─────────────
{
  const { ctx, page, errors } = await newPage();
  await step(page, "[로그인] 동그래 영역 + 입력칸 + 회원가입 링크", async () => {
    await goto(page, "/login", "오늘도 같이 공부하자!");
    await page.screenshot({ path: shot("s-login") });
    const ok = (await page.getByPlaceholder("you@example.com").isVisible()) && (await page.getByText("로그인", { exact: true }).count()) >= 1;
    await page.getByText("회원가입", { exact: true }).click();
    await page.getByText("만나서 반가워! 같이 시작하자").waitFor({ timeout: 8000 });
    return [ok && path(page).includes("signup"), `→ ${path(page)}`];
  });
  await step(page, "[로그인] 빈 칸으로 로그인 → 안내 문구", async () => {
    await goto(page, "/login", "오늘도 같이 공부하자!");
    await page.getByText("로그인", { exact: true }).last().click();
    await page.waitForTimeout(400);
    return [await page.getByText("이메일과 비밀번호를 입력해주세요.").isVisible(), ""];
  });
  await step(page, "[비밀번호 찾기] 동그래 영역 + 단계별 말풍선", async () => {
    await goto(page, "/forgot-password", "가입한 이메일로 코드를 보내줄게!");
    await page.screenshot({ path: shot("s-forgot") });
    return [true, ""];
  });
  await goto(page, "/signup", "만나서 반가워! 같이 시작하자");
  await page.screenshot({ path: shot("s-signup") });
  log("[로그인 전] 페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
  await ctx.close();
}

// ───────────── 2. 로그인 후 ─────────────
const { page, errors } = await newPage();
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+s${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("우진");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

// 문제풀기 탭
await step(page, "[문제풀기 탭] 화면 구성", async () => {
  await goto(page, "/quiz", "실전 모의고사");
  await page.screenshot({ path: shot("s-quiz-tab") });
  const need = ["모의고사 시작하기", "전체 랜덤", "약점 집중", "북마크", "사진으로 풀기", "키워드로 문제·해설 검색", "과목별 풀기", "기출 문제"];
  const missing = [];
  for (const t of need) if (!(await page.getByText(t, { exact: true }).count())) missing.push(t);
  return [missing.length === 0, missing.length ? `없음: ${missing.join(", ")}` : "8개 요소 모두 있음"];
});
for (const [name, target, expect] of [
  ["모의고사 시작하기", () => page.getByText("모의고사 시작하기"), (u) => u.startsWith("/mock-exam")],
  ["전체 랜덤", () => page.getByText("전체 랜덤", { exact: true }), (u) => u.includes("subject=전체")],
  ["약점 집중(오답 없음 → 빈 화면)", () => page.getByText("약점 집중", { exact: true }), (u) => u.includes("subject=약점")],
  ["사진으로 풀기", () => page.getByText("사진으로 풀기"), (u) => u.startsWith("/photo-recognition")],
  ["검색창", () => page.getByText("키워드로 문제·해설 검색"), (u) => u.startsWith("/search")],
  ["2과목 줄", () => page.getByText("데이터 분석 기획", { exact: true }), (u) => u.includes("subject=2과목(데이터 분석 기획)")],
  ["기출 제44회 연습", () => page.getByLabel("제44회 연습"), (u) => u.includes("subject=44회")],
  ["기출 제44회 실전", () => page.getByLabel("제44회 실전"), (u) => u.includes("mock-exam") && u.includes("round=44")],
]) {
  await step(page, `[문제풀기 탭] ${name}`, async () => {
    await goto(page, "/quiz", "실전 모의고사");
    await target().first().click();
    await page.waitForTimeout(1200);
    return [expect(path(page)), `→ ${path(page)}`];
  });
}
await step(page, "[문제풀기 탭] 약점 집중 빈 화면에 동그래 + 안내", async () => {
  await goto(page, "/quiz-session?subject=약점", "아직 틀린 문제가 없어요");
  await page.screenshot({ path: shot("s-empty-weak") });
  return [await page.getByText("돌아가기").isVisible(), ""];
});

// 문제 풀이
let wrongIds = 0;
await step(page, "[풀이] 보기를 고르기 전엔 '정답 확인' 비활성, 고르면 활성", async () => {
  await goto(page, "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), "정답 확인");
  await page.screenshot({ path: shot("s-question") });
  const before = await page.getByText("정답 확인", { exact: true }).evaluate((el) => el.closest("[aria-disabled]")?.getAttribute("aria-disabled"));
  await page.getByRole("radio").nth(1).click();
  const checked = await page.getByRole("radio").nth(1).getAttribute("aria-checked");
  const after = await page.getByText("정답 확인", { exact: true }).evaluate((el) => el.closest("[aria-disabled]")?.getAttribute("aria-disabled") ?? "false");
  return [before === "true" && checked === "true" && after !== "true", `확인 전 disabled=${before}, 선택 후 checked=${checked}, disabled=${after}`];
});
await step(page, "[풀이] 다른 보기로 바꿔 고를 수 있음 (채점 전)", async () => {
  await page.getByRole("radio").nth(2).click();
  const c1 = await page.getByRole("radio").nth(1).getAttribute("aria-checked");
  const c2 = await page.getByRole("radio").nth(2).getAttribute("aria-checked");
  return [c1 === "false" && c2 === "true", `2번 ${c1}, 3번 ${c2}`];
});
await step(page, "[풀이] 정답 확인 → 정답/내 답 표시, 해설 바로 보임, 메모 접힘, 동그래 버튼", async () => {
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(500);
  const correct = await page.getByText("정답이에요!").isVisible();
  if (!correct) wrongIds++;
  const tagOk = correct
    ? (await page.getByText("정답", { exact: true }).count()) === 1
    : (await page.getByText("내 답", { exact: true }).count()) === 1 && (await page.getByText("정답", { exact: true }).count()) === 1;
  const saved = correct || (await page.getByText("· 오답노트에 저장됨").isVisible());
  const memo = await page.getByText("메모 남기기").isVisible();
  const dongurae = await page.getByLabel("동그래 해설 듣기").isVisible();
  const locked = await page.getByRole("radio").nth(0).getAttribute("aria-disabled");
  await page.screenshot({ path: shot("s-answered"), fullPage: true });
  return [tagOk && saved && memo && dongurae && locked === "true", `${correct ? "정답" : "오답"}, 태그 ${tagOk}, 저장 안내 ${saved}, 메모 접힘 ${memo}, 동그래 ${dongurae}, 보기 잠김 ${locked}`];
});
await step(page, "[풀이] 메모 남기기 → 입력칸 펼침", async () => {
  await page.getByText("메모 남기기").click();
  await page.waitForTimeout(300);
  return [await page.getByPlaceholder("헷갈린 점이나 외울 내용을 적어두세요").isVisible(), ""];
});
await step(page, "[풀이] 진행 칸: 푼 문제는 색이 바뀜 / '다음 문제' → 2번 문제", async () => {
  await page.getByText("다음 문제", { exact: true }).click();
  await page.waitForTimeout(500);
  const pos = await page.getByText(/^\d+$/).filter({ hasText: "2" }).count();
  const confirmVisible = await page.getByText("정답 확인", { exact: true }).isVisible();
  return [pos > 0 && confirmVisible, `2번 문제로 이동, 정답 확인 버튼 다시 보임`];
});
// 나머지 9문제 풀기 (일부러 1번 보기만)
for (let i = 1; i < 10; i++) {
  const ok = await answer(page, 0);
  if (!ok) wrongIds++;
  await page.getByText(i < 9 ? "다음 문제" : "결과 보기", { exact: true }).click();
  await page.waitForTimeout(400);
}
await step(page, "[결과] 점수·맞힘/틀림 수·틀린 문제 목록·복습 버튼", async () => {
  await page.getByText("이번 점수").waitFor({ timeout: 8000 });
  await page.screenshot({ path: shot("s-result"), fullPage: true });
  const wrongShown = Number(await page.getByText("틀린 문제", { exact: true }).locator("xpath=preceding-sibling::*[1]").textContent());
  const listCount = await page.getByText(/^Q\d+$/).count();
  const reviewBtn = wrongIds > 0 ? await page.getByText(`틀린 ${wrongIds}문제 바로 복습`).isVisible() : true;
  return [wrongShown === wrongIds && listCount === wrongIds && reviewBtn, `틀린 수 표시 ${wrongShown} / 실제 ${wrongIds}, 목록 ${listCount}개, 복습 버튼 ${reviewBtn}`];
});
await step(page, "[결과] '틀린 N문제 바로 복습' → 그 문제들만 다시 풀기", async () => {
  if (wrongIds === 0) return [true, "틀린 문제 없음 (건너뜀)"];
  await page.getByText(`틀린 ${wrongIds}문제 바로 복습`).click();
  await page.getByText("정답 확인").waitFor({ timeout: 8000 });
  const title = await page.getByText("틀린 문제 다시 풀기").isVisible();
  const total = await page.getByText(new RegExp(`/ ${wrongIds}$`)).count();
  await page.screenshot({ path: shot("s-retry-wrong") });
  return [title && total > 0 && path(page).includes("subject=다시"), `제목 ${title}, 총 ${wrongIds}문제, ${path(page).slice(0, 40)}…`];
});

// 오답노트 탭
await step(page, "[오답노트] 복습 카드 + 칩 + 카드 구성", async () => {
  await goto(page, "/wrong", "오늘 복습할 오답");
  await page.screenshot({ path: shot("s-wrong") });
  const n = Number((await page.getByText(/^\d+개의 오답/).first().textContent()).match(/^\d+/)[0]);
  const allChip = await page.getByText(new RegExp(`^전체 ${n}$`)).isVisible();
  const chip1 = await page.getByText(/^1과목 \d+$/).isVisible();
  const dueBtn = await page.getByText(/^오늘 복습 \(\d+\)$/).isVisible();
  const allBtn = await page.getByText(new RegExp(`^전체 \\(${n}\\)$`)).isVisible();
  const collapsed = !(await page.getByText("해설", { exact: true }).first().isVisible().catch(() => false));
  return [n === wrongIds && allChip && chip1 && dueBtn && allBtn && collapsed, `오답 ${n}개(풀이에서 틀린 ${wrongIds}), 칩·버튼 OK, 해설 접힘 ${collapsed}`];
});
await step(page, "[오답노트] 해설 보기 → 펼침 / 해설 접기 → 닫힘", async () => {
  await page.getByText("해설 보기", { exact: true }).first().click();
  await page.waitForTimeout(300);
  const open = await page.getByText("해설", { exact: true }).first().isVisible();
  await page.screenshot({ path: shot("s-wrong-open") });
  await page.getByText("해설 접기", { exact: true }).first().click();
  await page.waitForTimeout(300);
  const closed = (await page.getByText("해설 접기", { exact: true }).count()) === 0;
  return [open && closed, ""];
});
await step(page, "[오답노트] 2과목 칩 → 1과목 오답이 안 보임", async () => {
  await page.getByText(/^2과목 \d+$/).click();
  await page.waitForTimeout(300);
  const empty = await page.getByText("이 분류에는 오답이 없어요").isVisible();
  await page.getByText(/^전체 \d+$/).click();
  return [empty, "1과목만 틀렸으므로 2과목은 빈 목록"];
});
await step(page, "[오답노트] '전체 (N)' → 오답 복습 풀이로 이어짐", async () => {
  await page.getByText(/^전체 \(\d+\)$/).click();
  await page.getByText("정답 확인").waitFor({ timeout: 10000 });
  const title = await page.getByText("오답 복습", { exact: true }).isVisible();
  const subjectChip = await page.getByText("1과목", { exact: true }).locator("visible=true").first().isVisible();
  await page.screenshot({ path: shot("s-wrong-session") });
  return [title && subjectChip && path(page).includes("subject=오답복습"), `제목 ${title}, 과목 칩 ${subjectChip}`];
});
await step(page, "[오답노트] 오늘 복습 0개면 '오늘 복습' 버튼 비활성", async () => {
  await goto(page, "/wrong", "오늘 복습할 오답");
  const d = await page.getByText(/^오늘 복습 \(0\)$/).evaluate((el) => el.closest("[aria-disabled]")?.getAttribute("aria-disabled"));
  return [d === "true", `aria-disabled=${d}`];
});

// 통계 탭
await step(page, "[통계] 숫자 카드·동그래 추천·7일·과목별·TOP5·모의고사·배지", async () => {
  await goto(page, "/stats", "학습 통계");
  await page.screenshot({ path: shot("s-stats") });
  const need = ["총 풀이", "전체 정답률", "연속 학습", "총 정답", "최근 7일", "과목별 정답률", "자주 틀리는 문제 TOP 5", "모의고사 점수 추이", "배지", "오늘", "학습 기록 초기화"];
  const missing = [];
  for (const t of need) if (!(await page.getByText(t, { exact: true }).count())) missing.push(t);
  const tip = await page.getByText(/정답률이|약한 과목을 찾아줄게/).first().isVisible();
  return [missing.length === 0 && tip, missing.length ? `없음: ${missing.join(", ")}` : "모든 섹션 있음, 동그래 추천 있음"];
});
await step(page, "[통계] 1과목 10문제 이상 풀면 약한 과목 추천 + 버튼 이동", async () => {
  const btn = page.getByText(/1과목 10문제 풀기/);
  if (!(await btn.isVisible())) return [false, "추천 버튼 없음"];
  await btn.click();
  await page.waitForTimeout(1000);
  return [path(page).includes("subject=1과목(데이터 이해)"), `→ ${path(page)}`];
});
await step(page, "[통계] 학습 기록 초기화 → 확인창 → 취소", async () => {
  await goto(page, "/stats", "학습 통계");
  await page.getByText("학습 기록 초기화", { exact: true }).last().click();
  await page.getByText("모든 학습 통계와 오답 노트가 초기화됩니다. 계속하시겠습니까?").waitFor({ timeout: 5000 });
  await page.getByText("취소", { exact: true }).last().click();
  return [true, ""];
});

// 설정 탭
await step(page, "[설정] 프로필·그룹(공부/화면/계정) 구성", async () => {
  await goto(page, "/settings", "설정");
  await page.screenshot({ path: shot("s-settings") });
  const need = ["우진", "공부", "시험일", "설정 안 함", "하루 목표", "화면", "테마", "글자 크기", "계정", "닉네임·비밀번호 변경", "로그아웃"];
  const missing = [];
  for (const t of need) if (!(await page.getByText(t, { exact: true }).count())) missing.push(t);
  return [missing.length === 0, missing.length ? `없음: ${missing.join(", ")}` : ""];
});
await step(page, "[설정] 시험일 줄 → 달력 펼침 → 날짜 고르고 저장 → 줄에 날짜·D-day, 홈 히어로에 D-day", async () => {
  await page.getByText("시험일", { exact: true }).click();
  await page.getByText("달력에서 시험일을 선택하세요").waitFor({ timeout: 5000 });
  // 다음 달로 넘겨서 15일 선택
  await page.getByText("15", { exact: true }).last().click();
  await page.waitForTimeout(300);
  await page.screenshot({ path: shot("s-settings-calendar") });
  await page.getByText("시험일 저장").click();
  await page.waitForTimeout(800);
  const rowText = await page.getByText(/월 \d+일 \(.\) · D-/).textContent().catch(() => "");
  const closed = !(await page.getByText("시험일 저장").isVisible());
  await goto(page, "/", "과목별 학습 현황");
  const heroDday = await page.getByText(/^D-\d+$/).first().textContent().catch(() => "");
  return [!!rowText && closed && /^D-\d+$/.test(heroDday), `설정 "${rowText}", 달력 닫힘 ${closed}, 홈 ${heroDday}`];
});
await step(page, "[설정] 글자 크기 '아주 크게' → 미리보기 글자 커짐", async () => {
  await goto(page, "/settings", "설정");
  const preview = page.getByText(/^미리보기:/);
  const before = await preview.evaluate((el) => parseFloat(getComputedStyle(el).fontSize));
  await page.getByText("아주 크게", { exact: true }).click();
  await page.waitForTimeout(300);
  const after = await preview.evaluate((el) => parseFloat(getComputedStyle(el).fontSize));
  await page.getByText("보통", { exact: true }).click();
  return [after > before, `${before}px → ${after}px`];
});
await step(page, "[설정] 테마 '어둡게' → 배경이 어두워짐 (다크 모드 화면들 캡처)", async () => {
  await page.getByText("어둡게", { exact: true }).click();
  await page.waitForTimeout(500);
  // 화면 제목에서 위로 올라가며 처음 만나는 배경색 = 화면 배경
  const bg = await page.getByText("설정", { exact: true }).first().evaluate((el) => {
    for (let n = el; n; n = n.parentElement) {
      const c = getComputedStyle(n).backgroundColor;
      if (c !== "rgba(0, 0, 0, 0)") return c;
    }
    return "";
  });
  await page.screenshot({ path: shot("s-dark-settings") });
  for (const [p, w, n] of [["/", "과목별 학습 현황", "home"], ["/quiz", "실전 모의고사", "quiz"], ["/wrong", "오답 노트", "wrong"], ["/stats", "학습 통계", "stats"]]) {
    await goto(page, p, w);
    await page.screenshot({ path: shot(`s-dark-${n}`) });
  }
  await goto(page, "/settings", "설정");
  await page.getByText("자동", { exact: true }).click();
  const m = bg.match(/\d+/g)?.map(Number) ?? [255, 255, 255];
  return [m[0] < 60 && m[1] < 60 && m[2] < 80, `배경 ${bg}`];
});
await step(page, "[설정] 프로필 카드 → 내 정보 화면", async () => {
  await goto(page, "/settings", "설정");
  await page.getByLabel("내 정보 수정").click();
  await page.waitForTimeout(1000);
  return [path(page).startsWith("/account"), `→ ${path(page)}`];
});
await step(page, "[설정] 로그아웃 → 확인 → 로그인 화면", async () => {
  await goto(page, "/settings", "설정");
  await page.getByText("로그아웃", { exact: true }).first().click();
  await page.getByText("로그아웃하시겠습니까?").waitFor({ timeout: 5000 });
  await page.getByText("로그아웃", { exact: true }).last().click();
  await page.getByText("오늘도 같이 공부하자!").waitFor({ timeout: 10000 });
  return [path(page).includes("login"), `→ ${path(page)}`];
});

const relevant = errors.filter((e) => !/favicon|DevTools|deprecated/i.test(e));
log("[로그인 후] 페이지 에러 없음", relevant.length === 0, relevant.slice(0, 3).join(" || ").slice(0, 300));
await browser.close();
finish();

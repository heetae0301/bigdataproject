// 동그래 칠판 그림 해설 E2E: generateScenes를 가짜 대본(6가지 그림 틀)으로, AI 목소리를 40초 가짜 wav로 바꿔서
// 그림이 그려지는지, 재생/탐색에 따라 장면이 넘어가는지, 대본이 실패하면 자막 해설로 대체되는지 확인한다.
// AI(글 생성·음성)는 한 번도 부르지 않는다.
import { Buffer } from "node:buffer";
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

function makeWav(sec, rate = 8000) {
  const n = sec * rate;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVE", 8); buf.write("fmt ", 12);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(Math.sin((i / rate) * 2 * Math.PI * 440) * 800), 44 + i * 2);
  return buf;
}
const WAV = makeWav(40);
const trpcOk = (data) => JSON.stringify([{ result: { data: { json: data } } }]);
const trpcErr = JSON.stringify([{ error: { json: { message: "stub", code: -32603, data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 500 } } } }]);

const SCENES = [
  { narration: "먼저 네가 고른 보기를 같이 볼까?", visual: { type: "options", options: ["가 보기 문장", "나 보기 문장", "다 보기 문장", "라 보기 문장"], selectedOption: 0, correctOption: 2 } },
  { narration: "정형 데이터와 비정형 데이터를 비교해 보자.", visual: { type: "compare", title: "데이터 유형 비교", left: { title: "정형", points: ["표로 저장", "RDB"] }, right: { title: "비정형", points: ["텍스트·영상", "NoSQL"] } } },
  { narration: "분석 과정은 이렇게 흘러가.", visual: { type: "steps", title: "분석 단계", steps: ["문제 정의", "데이터 준비", "모델링", "평가"], highlight: 2 } },
  { narration: "정밀도는 이렇게 계산해.", visual: { type: "formula", title: "정밀도", lines: ["정밀도 = TP / (TP + FP)", "= 40 / 50", "= 0.8"] } },
  { narration: "핵심 용어 하나만 기억하자.", visual: { type: "keyword", term: "메타데이터", definition: "데이터를 설명하는 데이터", emoji: "🏷️" } },
  { narration: "마지막으로 분류를 정리해 볼게.", visual: { type: "tree", root: "데이터", children: [{ label: "정형" }, { label: "반정형", note: "XML, JSON" }, { label: "비정형" }], highlight: 1 } },
];
const BOARD_TEXT = ["가 보기 문장", "데이터 유형 비교", "분석 단계", "정밀도 = TP / (TP + FP)", "메타데이터", "반정형"];

const browser = await launch(["--autoplay-policy=no-user-gesture-required"]);

async function newSession(scenesMode) {
  const ctx = await phoneContext(browser);
  const calls = { scenes: 0, wrong: 0 };
  await ctx.route(REMOTE, async (route) => {
    const url = route.request().url();
    if (url.includes("explain.generateScenes")) {
      calls.scenes++;
      if (scenesMode === "ok") return route.fulfill({ contentType: "application/json", body: trpcOk({ scenes: SCENES }) });
      return route.fulfill({ status: 500, contentType: "application/json", body: trpcErr });
    }
    if (url.includes("explain.generateForWrongAnswer")) {
      calls.wrong++;
      return route.fulfill({ contentType: "application/json", body: trpcOk({ explanation: "대체 자막 해설입니다. 두 번째 문장입니다." }) });
    }
    if (url.includes("explain.prepareSpeech")) return route.fulfill({ contentType: "application/json", body: trpcOk({ path: "/api/tts/e2e.wav", durationSec: 40 }) });
    if (url.includes("/api/tts/e2e.wav")) return route.fulfill({ contentType: "audio/wav", body: WAV, headers: { "accept-ranges": "bytes" } });
    if (/explain\./.test(url)) return route.fulfill({ status: 500, contentType: "application/json", body: trpcErr });
    await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
  });
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(APP + "/signup", { waitUntil: "networkidle" });
  await page.getByPlaceholder("you@example.com").fill(`e2e+s${scenesMode}${Date.now()}@example.com`);
  await page.getByPlaceholder("앱에서 표시될 이름").fill("s");
  await page.getByPlaceholder("6자 이상").fill("test1234");
  await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
  await page.getByText("회원가입", { exact: true }).last().click();
  await page.waitForTimeout(2500);
  await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), { waitUntil: "networkidle" });
  // 일부러 틀리게: 4번 고르기 (정답이면 맞힌 경우로도 동작해야 하므로 둘 다 괜찮다)
  await page.getByRole("radio").nth(3).click();
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(800);
  await page.getByText("동그래 해설 듣기").click();
  await page.getByText("해설 듣기", { exact: true }).waitFor({ timeout: 15000 });
  return { ctx, page, errors, calls };
}
async function step(page, name, fn) {
  try { const [ok, detail] = await fn(); log(name, ok, detail); }
  catch (e) { await page.screenshot({ path: shot(`s-fail-${results.length}`) }).catch(() => {}); log(name, false, String(e).split("\n")[0]); }
}
const counter = async (page) => (await page.getByText(/^\d+ \/ 6$/).first().textContent()).trim();
const seekTo = async (page, ratio) => {
  const bar = page.getByLabel("재생 위치");
  const box = await bar.boundingBox();
  await page.mouse.click(box.x + box.width * ratio, box.y + box.height / 2);
  await page.waitForTimeout(900);
};

// 1) 대본 성공 → 칠판 그림
{
  const { ctx, page, errors, calls } = await newSession("ok");
  await step(page, "재생 전: 첫 장면(보기 짚기)을 미리 그리고 1 / 6 표시", async () => {
    await page.getByText(BOARD_TEXT[0]).first().waitFor({ timeout: 5000 });
    await page.screenshot({ path: shot("s-01-ready") });
    const c = await counter(page);
    const hint = await page.getByText("재생 버튼을 누르면 동그래가 그림을 그리며 설명해 줘요").isVisible();
    return [c === "1 / 6" && hint && calls.scenes === 1, `카운터 ${c}, 안내 ${hint}, 대본 요청 ${calls.scenes}회`];
  });
  await step(page, "재생: 첫 장면 대사가 자막으로 나옴", async () => {
    await page.getByText("해설 듣기", { exact: true }).click();
    await page.getByText(SCENES[0].narration).waitFor({ timeout: 8000 });
    return [true, SCENES[0].narration];
  });
  const seen = new Set();
  for (const [i, ratio] of [[1, 0.25], [2, 0.42], [3, 0.6], [4, 0.75], [5, 0.95]]) {
    await step(page, `탐색 ${Math.round(ratio * 100)}% → 장면 바뀜 (${SCENES[i].visual.type})`, async () => {
      await seekTo(page, ratio);
      const c = await counter(page);
      const n = Number(c.split(" / ")[0]) - 1;
      const drawn = await page.getByText(BOARD_TEXT[n]).first().isVisible();
      seen.add(SCENES[n].visual.type);
      await page.screenshot({ path: shot(`s-02-scene-${n + 1}`) });
      return [n >= 1 && drawn, `카운터 ${c}, 그림 "${BOARD_TEXT[n]}" ${drawn ? "보임" : "안 보임"}`];
    });
  }
  await step(page, "6가지 그림 틀 중 5개 이상을 거쳐 감 (순서대로 넘어감)", async () => [seen.size >= 4, [...seen].join(", ")]);
  await step(page, "10초 뒤로 → 이전 장면으로 돌아감", async () => {
    const before = await counter(page);
    await page.getByLabel("10초 뒤로").click();
    await page.waitForTimeout(900);
    const after = await counter(page);
    return [Number(after.split(" / ")[0]) < Number(before.split(" / ")[0]), `${before} → ${after}`];
  });
  const drag = async (fromX, dx) => {
    await page.mouse.move(fromX, 420);
    await page.mouse.down();
    await page.mouse.move(fromX + dx, 422, { steps: 12 });
    await page.mouse.up();
    await page.waitForTimeout(700);
  };
  const playerOpen = () => page.getByText("동그래 해설", { exact: true }).isVisible();
  await step(page, "화면 안쪽에서 옆으로 밀면 해설이 닫히지 않음", async () => {
    await drag(150, 200);
    return [await playerOpen(), "가운데에서 200px 밀기"];
  });
  await step(page, "왼쪽 가장자리에서 조금만 밀면 원위치", async () => {
    await drag(4, 40);
    return [await playerOpen(), "가장자리에서 40px 밀기"];
  });
  await step(page, "왼쪽 가장자리에서 오른쪽으로 밀면 해설이 닫힘 (뒤로 가기)", async () => {
    await drag(4, 250);
    const closed = !(await playerOpen());
    const back = await page.getByText("동그래 해설 듣기").isVisible();
    return [closed && back, `해설 ${closed ? "닫힘" : "그대로"}, 문제 화면 ${back ? "보임" : "안 보임"}`];
  });
  log("그림 해설: 페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
  await ctx.close();
}

// 2) 대본 실패 → 예전 자막 해설로 대체
{
  const { ctx, page, errors, calls } = await newSession("fail");
  await step(page, "대본 실패 시 칠판 카운터 없이 자막 해설로 대체", async () => {
    await page.waitForTimeout(800);
    const hasCounter = await page.getByText(/^\d+ \/ 6$/).count();
    await page.getByText("해설 듣기", { exact: true }).click();
    await page.waitForTimeout(1500);
    await page.screenshot({ path: shot("s-03-fallback") });
    const body = await page.locator("body").innerText();
    const usedFallback = calls.wrong === 1 ? body.includes("대체 자막 해설입니다") : true;
    return [hasCounter === 0 && calls.scenes === 1 && usedFallback, `카운터 ${hasCounter}개, 대본 요청 ${calls.scenes}회, 오답 해설 요청 ${calls.wrong}회`];
  });
  log("자막 대체: 페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
  await ctx.close();
}

await browser.close();
finish();

// 동그래 해설 플레이어: 일시정지 / 이어 듣기 / 10초 앞뒤 이동 E2E.
// - AI 목소리 경로: prepareSpeech 응답을 가짜 40초 WAV로 바꿔서(AI 요금 안 씀) 실제 <audio> 재생으로 확인
// - 폰 목소리 경로: prepareSpeech를 실패시키고, 브라우저 speechSynthesis를 가짜로 바꿔 발화 요청을 기록
import { Buffer } from "node:buffer";
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

function makeWav(seconds) {
  const rate = 8000, n = rate * seconds;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVE", 8);
  buf.write("fmt ", 12); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(Math.sin((i / rate) * 2 * Math.PI * 440) * 800), 44 + i * 2);
  return buf;
}
const WAV = makeWav(40);
const trpcOk = (data) => JSON.stringify([{ result: { data: { json: data } } }]);
let prepareCalls = 0;
const trpc429 = JSON.stringify([{ error: { json: { message: "오늘 AI 사용량을 모두 썼어요. 내일 다시 시도해주세요.", code: -32029, data: { code: "TOO_MANY_REQUESTS", httpStatus: 429 } } } }]);
const trpcErr = JSON.stringify([{ error: { json: { message: "stub", code: -32603, data: { code: "INTERNAL_SERVER_ERROR", httpStatus: 500 } } } }]);

const FAKE_TTS = () => {
  window.__spoken = [];
  class FakeUtterance { constructor(t) { this.text = t || ""; } }
  let current = null, timer = null;
  const synth = {
    speaking: false, paused: false, onvoiceschanged: null,
    getVoices: () => [],
    speak(u) {
      window.__spoken.push(u.text);
      current = u; synth.speaking = true;
      const starts = []; const re = /\S+/g; let m;
      while ((m = re.exec(u.text))) starts.push(m.index);
      let i = 0;
      setTimeout(() => u.onstart && u.onstart({}), 0);
      timer = setInterval(() => {
        if (current !== u) return clearInterval(timer);
        if (i < starts.length) { u.onboundary && u.onboundary({ charIndex: starts[i++], charLength: 1 }); return; }
        clearInterval(timer); current = null; synth.speaking = false; u.onend && u.onend({});
      }, 250);
    },
    cancel() {
      const u = current; current = null; synth.speaking = false; clearInterval(timer);
      if (u && u.onerror) u.onerror({ error: "interrupted" }); // 실제 브라우저처럼
    },
    pause() {}, resume() {},
  };
  Object.defineProperty(window, "speechSynthesis", { value: synth, configurable: true });
  window.SpeechSynthesisUtterance = FakeUtterance;
};

const browser = await launch(["--autoplay-policy=no-user-gesture-required"]);

async function newSession(mode) {
  const ctx = await phoneContext(browser);
  await ctx.route(REMOTE, async (route) => {
    const url = route.request().url();
    if (url.includes("explain.generateScenes")) return route.fulfill({ status: 500, contentType: "application/json", body: trpcErr });
    if (url.includes("explain.generateForWrongAnswer")) return route.fulfill({ status: 500, contentType: "application/json", body: trpcErr });
    if (url.includes("explain.prepareSpeech")) {
      if (mode === "ai") return route.fulfill({ contentType: "application/json", body: trpcOk({ path: "/api/tts/e2e.wav", durationSec: 40 }) });
      prepareCalls++;
      return route.fulfill({ status: 429, contentType: "application/json", body: trpc429 });
    }
    if (url.includes("/api/tts/e2e.wav")) return route.fulfill({ contentType: "audio/wav", body: WAV, headers: { "accept-ranges": "bytes" } });
    await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
  });
  if (mode === "device") await ctx.addInitScript(FAKE_TTS);
  const page = await ctx.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  await page.goto(APP + "/signup", { waitUntil: "networkidle" });
  await page.getByPlaceholder("you@example.com").fill(`e2e+p${mode}${Date.now()}@example.com`);
  await page.getByPlaceholder("앱에서 표시될 이름").fill("p");
  await page.getByPlaceholder("6자 이상").fill("test1234");
  await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
  await page.getByText("회원가입", { exact: true }).last().click();
  await page.waitForTimeout(2500);
  await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), { waitUntil: "networkidle" });
  await page.getByRole("radio").nth(0).click();
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(800);
  await page.getByText("동그래 해설 듣기").click();
  await page.getByText("해설 듣기", { exact: true }).waitFor({ timeout: 10000 });
  return { ctx, page, errors };
}

const toSec = (t) => { const [m, s] = t.split(":").map(Number); return m * 60 + s; };
const elapsed = async (page) => {
  const times = await page.getByText(/^\d+:\d\d$/).allTextContents();
  return toSec(times[0]);
};
const mainLabel = async (page) =>
  (await page.getByText(/^(해설 듣기|일시정지|이어 듣기|목소리 준비 중\.\.\.)$/).first().textContent());
async function step(page, name, fn) {
  try { const [ok, detail] = await fn(); log(name, ok, detail); }
  catch (e) { await page.screenshot({ path: shot(`p-fail-${results.length}`) }).catch(() => {}); log(name, false, String(e).split("\n")[0]); }
}

// ── AI 목소리 경로 ──
{
  const { ctx, page, errors } = await newSession("ai");
  await step(page, "[AI] 재생 전에는 10초 버튼 비활성", async () => {
    const d = await page.getByLabel("10초 앞으로").getAttribute("aria-disabled");
    return [d === "true", `aria-disabled=${d}`];
  });
  await step(page, "[AI] 해설 듣기 → 재생, 시간 증가, 총 길이 0:40", async () => {
    await page.getByText("해설 듣기", { exact: true }).click();
    await page.getByText("일시정지", { exact: true }).waitFor({ timeout: 10000 });
    await page.waitForTimeout(2500);
    const t = await elapsed(page);
    const total = await page.getByText("0:40").count();
    await page.screenshot({ path: shot("p-ai-playing") });
    return [t >= 1 && total > 0, `경과 ${t}초`];
  });
  await step(page, "[AI] 10초 앞으로", async () => {
    const before = await elapsed(page);
    await page.getByLabel("10초 앞으로").click();
    await page.waitForTimeout(700);
    const after = await elapsed(page);
    return [after - before >= 9 && after - before <= 12, `${before}초 → ${after}초`];
  });
  await step(page, "[AI] 일시정지 → 시간 멈춤, 버튼 '이어 듣기'", async () => {
    await page.getByText("일시정지", { exact: true }).click();
    await page.waitForTimeout(400);
    const a = await elapsed(page);
    await page.waitForTimeout(2000);
    const b = await elapsed(page);
    const label = await mainLabel(page);
    await page.screenshot({ path: shot("p-ai-paused") });
    return [a === b && label === "이어 듣기", `${a}초 → 2초 뒤 ${b}초, 버튼 "${label}"`];
  });
  await step(page, "[AI] 일시정지 중 10초 뒤로 → 위치만 이동, 계속 멈춤", async () => {
    const before = await elapsed(page);
    await page.getByLabel("10초 뒤로").click();
    await page.waitForTimeout(1500);
    const after = await elapsed(page);
    const label = await mainLabel(page);
    return [before - after >= 9 && label === "이어 듣기", `${before}초 → ${after}초, 버튼 "${label}"`];
  });
  await step(page, "[AI] 이어 듣기 → 다시 진행", async () => {
    const before = await elapsed(page);
    await page.getByText("이어 듣기", { exact: true }).click();
    await page.waitForTimeout(2500);
    const after = await elapsed(page);
    return [after > before && (await mainLabel(page)) === "일시정지", `${before}초 → ${after}초`];
  });
  await step(page, "[AI] 재생 바 75% 지점 클릭 → 약 30초로 이동", async () => {
    const box = await page.getByLabel("재생 위치").boundingBox();
    await page.mouse.click(box.x + box.width * 0.75, box.y + box.height / 2);
    await page.waitForTimeout(700);
    const t = await elapsed(page);
    await page.screenshot({ path: shot("p-ai-scrub-click") });
    return [t >= 29 && t <= 32 && (await mainLabel(page)) === "일시정지", `${t}초, 계속 재생`];
  });
  await step(page, "[AI] 바 끌기: 끄는 동안 미리보기만, 놓으면 약 10초로 이동", async () => {
    const box = await page.getByLabel("재생 위치").boundingBox();
    const y = box.y + box.height / 2;
    await page.mouse.move(box.x + box.width * 0.75, y);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.5, y, { steps: 5 });
    await page.mouse.move(box.x + box.width * 0.25, y, { steps: 5 });
    await page.waitForTimeout(300);
    const preview = await elapsed(page);
    const audioDuringDrag = await page.evaluate(() => document.querySelector("audio")?.currentTime ?? -1);
    await page.screenshot({ path: shot("p-ai-scrub-drag") });
    await page.mouse.up();
    await page.waitForTimeout(800);
    const after = await elapsed(page);
    const audioAfter = await page.evaluate(() => document.querySelector("audio")?.currentTime ?? -1);
    const audioCheck = audioDuringDrag < 0 ? "audio 요소 확인 불가" : `오디오 끄는 중 ${audioDuringDrag.toFixed(1)}초 → 놓은 뒤 ${audioAfter.toFixed(1)}초`;
    const audioOk = audioDuringDrag < 0 || (audioDuringDrag > 25 && audioAfter < 13);
    return [preview >= 9 && preview <= 11 && after >= 9 && after <= 12 && audioOk, `미리보기 ${preview}초, 놓은 뒤 ${after}초, ${audioCheck}`];
  });
  await step(page, "[AI] 일시정지 중 바 클릭 → 위치만 이동, 계속 멈춤", async () => {
    await page.getByText("일시정지", { exact: true }).click();
    const box = await page.getByLabel("재생 위치").boundingBox();
    await page.mouse.click(box.x + box.width * 0.5, box.y + box.height / 2);
    await page.waitForTimeout(1500);
    const t = await elapsed(page);
    const label = await mainLabel(page);
    await page.getByText("이어 듣기", { exact: true }).click();
    return [t >= 19 && t <= 21 && label === "이어 듣기", `${t}초, 버튼 "${label}"`];
  });
  await step(page, "[AI] 처음 근처에서 10초 뒤로 → 0초 아래로 안 감", async () => {
    await page.getByLabel("10초 뒤로").click();
    await page.getByLabel("10초 뒤로").click();
    await page.waitForTimeout(600);
    const t = await elapsed(page);
    return [t >= 0 && t <= 2, `${t}초`];
  });
  await step(page, "[AI] 끝을 넘겨 10초 앞으로 → 재생 종료", async () => {
    let clicks = 0;
    while ((await mainLabel(page)) !== "해설 듣기" && clicks < 6) {
      await page.getByLabel("10초 앞으로").click();
      clicks++;
      await page.waitForTimeout(400);
    }
    const label = await mainLabel(page);
    const disabled = await page.getByLabel("10초 앞으로").getAttribute("aria-disabled");
    return [label === "해설 듣기" && clicks >= 4 && disabled === "true", `${clicks}번 누르고 종료, 버튼 "${label}", 10초 버튼 비활성=${disabled}`];
  });
  log("[AI] 페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
  await ctx.close();
}

// ── 폰 목소리 경로 ──
{
  const { ctx, page, errors } = await newSession("device");
  const spoken = () => page.evaluate(() => window.__spoken.slice());
  let full = "";
  await step(page, "[AI 실패] 할당량 초과 → 폰 목소리로 자동 전환 안 함, 안내 + '다시 시도'", async () => {
    await page.getByText("해설 듣기", { exact: true }).click();
    await page.getByText(/AI 목소리 사용 한도에 걸렸어요/).waitFor({ timeout: 10000 });
    await page.waitForTimeout(1500);
    const s = await spoken();
    const label = await page.getByText("다시 시도", { exact: true }).count();
    await page.screenshot({ path: shot("p-ai-failed") });
    return [s.length === 0 && label === 1, `자동 발화 ${s.length}번, '다시 시도' 버튼 ${label ? "있음" : "없음"}`];
  });
  await step(page, "[AI 실패] '다시 시도' → 서버에 AI 목소리 다시 요청", async () => {
    const before = prepareCalls;
    await page.getByText("다시 시도", { exact: true }).click();
    await page.getByText(/AI 목소리 사용 한도에 걸렸어요/).waitFor({ timeout: 10000 });
    await page.waitForTimeout(500);
    return [prepareCalls === before + 1 && (await spoken()).length === 0, `요청 ${before} → ${prepareCalls}번, 발화 ${(await spoken()).length}번`];
  });
  await step(page, "[폰] '폰 목소리로 듣기'를 눌렀을 때만 처음부터 읽음", async () => {
    await page.getByText("폰 목소리로 듣기", { exact: true }).click();
    await page.getByText("일시정지", { exact: true }).waitFor({ timeout: 10000 });
    await page.waitForTimeout(1500);
    const s = await spoken();
    full = s[0] ?? "";
    const hint = await page.getByText("폰 목소리로 읽는 중이에요").count();
    const failGone = (await page.getByText(/AI 목소리 사용 한도에 걸렸어요/).count()) === 0;
    return [s.length === 1 && full.length > 20 && hint > 0 && failGone, `발화 ${s.length}번, ${full.length}자, 안내 숨김 ${failGone}`];
  });
  await step(page, "[폰] 일시정지 → 발화 취소돼도 재생 상태 유지(이어 듣기)", async () => {
    await page.getByText("일시정지", { exact: true }).click();
    await page.waitForTimeout(1200);
    const label = await mainLabel(page);
    const speaking = await page.evaluate(() => window.speechSynthesis.speaking);
    return [label === "이어 듣기" && !speaking, `버튼 "${label}", 말하는 중=${speaking}`];
  });
  await step(page, "[폰] 이어 듣기 → 멈춘 곳(단어 시작)부터 다시 읽음", async () => {
    await page.getByText("이어 듣기", { exact: true }).click();
    await page.waitForTimeout(600);
    const s = await spoken();
    const last = s[s.length - 1];
    const startsAt = full.length - last.length;
    const ok = s.length === 2 && full.endsWith(last) && startsAt > 0 && (startsAt === 0 || full[startsAt - 1] === " ");
    return [ok && (await mainLabel(page)) === "일시정지", `${startsAt}번째 글자부터: "${last.slice(0, 15)}…"`];
  });
  await step(page, "[폰] 바 끌기: 끄는 동안엔 다시 읽지 않고, 놓을 때 한 번만 그 위치(단어 시작)부터", async () => {
    const before = (await spoken()).length;
    const box = await page.getByLabel("재생 위치").boundingBox();
    const y = box.y + box.height / 2;
    await page.mouse.move(box.x + box.width * 0.1, y);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.3, y, { steps: 6 });
    await page.mouse.move(box.x + box.width * 0.5, y, { steps: 6 });
    await page.waitForTimeout(300);
    const duringDrag = (await spoken()).length - before;
    await page.mouse.up();
    await page.waitForTimeout(600);
    const s = await spoken();
    const added = s.length - before;
    const last = s.at(-1);
    const startsAt = full.length - last.length;
    const ratio = startsAt / full.length;
    return [duringDrag === 0 && added === 1 && full.endsWith(last) && full[startsAt - 1] === " " && ratio > 0.3 && ratio <= 0.52 && (await mainLabel(page)) === "일시정지",
      `끄는 중 새 발화 ${duringDrag}번, 놓은 뒤 ${added}번, ${startsAt}/${full.length}번째 글자부터`];
  });
  await step(page, "[폰] 10초 뒤로 → 처음부터 다시 읽고, 이전 발화 취소에 끊기지 않음", async () => {
    await page.getByLabel("10초 뒤로").click();
    await page.waitForTimeout(300);
    await page.getByLabel("10초 뒤로").click();
    await page.waitForTimeout(600);
    const s = await spoken();
    const label = await mainLabel(page);
    return [s.at(-1) === full && label === "일시정지" && (await page.evaluate(() => window.speechSynthesis.speaking)),
      `마지막 발화 ${s.at(-1).length}자 / 전체 ${full.length}자, 버튼 "${label}"`];
  });
  await step(page, "[폰] 10초 앞으로 → 더 뒤 위치(단어 시작)부터 다시 읽음 (해설이 10초보다 짧으면 바로 종료)", async () => {
    const times = await page.getByText(/^\d+:\d\d$/).allTextContents();
    const totalSec = toSec(times[times.length - 1]);
    const leftAfterSkip = totalSec - (toSec(times[0]) + 10);
    const before = (await spoken()).length;
    await page.getByLabel("10초 앞으로").click();
    await page.waitForTimeout(600);
    const s = await spoken();
    const label = await mainLabel(page);
    // 짧은 해설은 10초 앞으로가 끝(또는 마지막 단어)을 넘을 수 있다 — 그러면 새로 읽지 않고 끝나는 게 맞다.
    // 화면의 시간은 초 단위로 반올림돼 있어서 2초 여유를 둔다.
    if (leftAfterSkip <= 2 && s.length === before) {
      return [label === "해설 듣기", `전체 ${totalSec}초, 이동 후 남은 ${leftAfterSkip}초라 바로 종료, 버튼 "${label}"`];
    }
    const last = s.at(-1);
    const startsAt = full.length - last.length;
    // 남은 몇 단어를 0.6초 안에 다 읽고 끝날 수도 있다 (가짜 TTS는 단어당 0.25초)
    const wordsLeft = last.split(/\s+/).filter(Boolean).length;
    const playingOrJustFinished = label === "일시정지" || (label === "해설 듣기" && wordsLeft * 250 <= 600);
    return [s.length === before + 1 && startsAt > 0 && full.endsWith(last) && full[startsAt - 1] === " " && playingOrJustFinished,
      `${startsAt}/${full.length}번째 글자부터(남은 ${wordsLeft}단어, 전체 ${totalSec}초), 버튼 "${label}"`];
  });
  await step(page, "[폰] 끝을 넘겨 10초 앞으로 → 재생 종료", async () => {
    // 해설 길이가 문제마다 달라서 끝을 넘을 때까지 누른다 (이미 끝났으면 버튼이 비활성이라 안 누른다)
    let clicks = 0;
    while ((await mainLabel(page)) !== "해설 듣기" && clicks < 6) {
      await page.getByLabel("10초 앞으로").click();
      clicks++;
      await page.waitForTimeout(600);
    }
    const label = await mainLabel(page);
    return [label === "해설 듣기", `${clicks}번 누르고 종료, 버튼 "${label}"`];
  });
  await step(page, "[폰] 다시 '해설 듣기'는 AI부터 시도 → 실패 → 폰 목소리로 끝까지 읽으면 '해설 듣기'로 돌아옴", async () => {
    await page.getByText("해설 듣기", { exact: true }).click();
    await page.getByText(/AI 목소리 사용 한도에 걸렸어요/).waitFor({ timeout: 10000 });
    await page.getByText("폰 목소리로 듣기", { exact: true }).click();
    await page.getByText("일시정지", { exact: true }).waitFor({ timeout: 10000 });
    await page.getByText("해설 듣기", { exact: true }).waitFor({ timeout: 60000 });
    await page.screenshot({ path: shot("p-device-done") });
    return [true, `총 발화 ${(await spoken()).length}번`];
  });
  log("[폰] 페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
  await ctx.close();
}

await browser.close();
finish();

// 홈 화면 버튼 E2E: 웹 앱(localhost:8081)을 Edge로 열고, 배포 API 요청을 로컬 API(localhost:3000)로 돌려서
// 테스트 계정으로 가입한 뒤 버튼을 하나씩 눌러 이동한 화면을 기록한다.
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { log, finish } = reporter();

const browser = await launch();
const ctx = await phoneContext(browser);
await ctx.route(REMOTE, async (route) => {
  if (/explain./.test(route.request().url())) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  const url = route.request().url().replace(REMOTE, API);
  const response = await route.fetch({ url });
  await route.fulfill({ response });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => m.type() === "error" && errors.push(m.text()));

const snap = (name) => page.screenshot({ path: shot(name) });
const goHome = async () => {
  await page.goto(APP + "/", { waitUntil: "networkidle" });
  await page.getByText("과목별 학습 현황").waitFor({ timeout: 20000 });
  await page.waitForTimeout(800);
};
async function tap(name, locator, expect) {
  try {
    await goHome();
    await locator().first().click({ timeout: 8000 });
    await page.waitForTimeout(1500);
    const url = page.url().replace(APP, "");
    const ok = await expect(url);
    await snap(name);
    log(name, ok, `→ ${url}`);
  } catch (e) {
    await snap(name).catch(() => {});
    log(name, false, String(e).split("\n")[0]);
  }
}

// 1) 테스트 계정 가입
const email = `e2e+${Date.now()}@example.com`;
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(email);
await page.getByPlaceholder("앱에서 표시될 이름").fill("테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);
log("회원가입 후 홈 진입", !page.url().includes("signup"), page.url().replace(APP, "") || "/");

// 2) 홈 화면 첫 화면 + 전체 스크롤 캡처
await goHome();
await snap("00-home");
await page.screenshot({ path: shot("00-home-full"), fullPage: true });
const pastLabels = await page.getByText(/^제\d+회+$/).allTextContents();
log("기출 회차 라벨 형식", pastLabels.length > 0 && pastLabels.every((t) => /^제\d+회$/.test(t)), pastLabels.slice(0, 4).join(", "));

// 3) 버튼들
await tap("01-히어로(D-day) → 설정", () => page.getByText("D-day가 떠요"), (u) => u.includes("settings"));
await tap("02-오늘의 목표 → 목표 팝업", () => page.getByText("오늘의 목표"), async (u) =>
  !u.includes("settings") && (await page.getByText("하루에 몇 문제를 풀지 정해 보세요.").isVisible()));
await tap("03-오늘의 문제 풀기", () => page.getByText("오늘의 문제 풀기"), (u) => u.includes("quiz-session") && decodeURIComponent(u).includes("전체"));
await tap("04-오답 복습(없을 때 → 오답노트)", () => page.getByText("오답 복습"), (u) => u.includes("wrong"));
await tap("05-전체 랜덤", () => page.getByText("전체 랜덤"), (u) => u.includes("quiz-session") && decodeURIComponent(u).includes("전체"));
await tap("06-1과목 줄 → 1과목 풀기", () => page.getByText("1과목 · 데이터 이해"), (u) => decodeURIComponent(u).includes("1과목(데이터 이해)"));
await tap("07-2과목 줄 → 2과목 풀기", () => page.getByText("2과목 · 데이터 분석 기획"), (u) => decodeURIComponent(u).includes("2과목(데이터 분석 기획)"));
await tap("08-3과목 줄 → 3과목 풀기", () => page.getByText("3과목 · 데이터 분석", { exact: true }), (u) => decodeURIComponent(u).includes("3과목(데이터 분석)"));
await tap("09-기출 줄은 눌러도 이동 안 함", () => page.getByText(/^제\d+회$/), (u) => u === "/" || u === "");

// 4) 문제를 하나 풀고 홈에 반영되는지 (오늘 목표 숫자 / 말풍선)
try {
  await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), { waitUntil: "networkidle" });
  await page.waitForTimeout(1500);
  await page.getByRole("radio").nth(0).click({ timeout: 8000 });
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(2000);
  await snap("10a-answered");
  await goHome();
  const bubble = await page.getByText(/목표 달성이야|시작해 볼까|목표 달성!/).first().textContent();
  await snap("10-home-after-1");
  log("문제 1개 풀고 홈 말풍선 갱신", /더 풀면/.test(bubble ?? ""), (bubble ?? "").replace(/\n/g, " "));
} catch (e) {
  log("문제 1개 풀고 홈 말풍선 갱신", false, String(e).split("\n")[0]);
}

const relevantErrors = errors.filter((e) => !/favicon|DevTools|deprecated/i.test(e));
log("콘솔/페이지 에러 없음", relevantErrors.length === 0, relevantErrors.slice(0, 3).join(" || ").slice(0, 300));
await browser.close();
finish();

// 앱을 열 때 서버가 늦게 답하면(Render 무료 서버가 깨어나는 중) 흰 화면 대신
// 동그래 + "서버를 깨우는 중이에요" 안내를 보여주고, 답이 오면 홈으로 넘어가는지 확인한다.
import { APP, API, REMOTE, isAiCall, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { log, finish } = reporter();
const browser = await launch();
const ctx = await phoneContext(browser);
let slow = false;
await ctx.route(REMOTE, async (route) => {
  const url = route.request().url();
  if (isAiCall(url)) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  if (slow && url.includes("auth.me")) await new Promise((r) => setTimeout(r, 7000));
  await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));

await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+boot${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("부팅테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

slow = true;
await page.goto(APP + "/", { waitUntil: "domcontentloaded" });
await page.waitForTimeout(1000);
const early = await page.getByText("서버를 깨우는 중이에요").isVisible();
log("처음 2.5초 동안은 안내 문구 없이 로딩만", !early, `1초 시점 안내 ${early ? "보임" : "없음"}`);

await page.waitForTimeout(2500);
const later = await page.getByText("서버를 깨우는 중이에요").isVisible();
await page.screenshot({ path: shot("slow-boot") });
log("오래 걸리면 '서버를 깨우는 중이에요' 안내", later, `3.5초 시점 안내 ${later ? "보임" : "없음"}`);

let reachedHome = false;
try {
  await page.getByText("오늘의 목표").first().waitFor({ timeout: 15000 });
  reachedHome = !(await page.getByText("서버를 깨우는 중이에요").isVisible());
} catch {
  // 홈에 못 감
}
await page.screenshot({ path: shot("slow-boot-done") });
log("서버가 답하면 홈으로 넘어감 (로그인 유지)", reachedHome);

log("페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
await browser.close();
finish();

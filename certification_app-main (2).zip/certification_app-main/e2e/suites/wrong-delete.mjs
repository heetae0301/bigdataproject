// 오답노트 삭제 E2E: 새 계정으로 1과목 10문제를 모두 4번으로 풀어 오답을 만들고,
// 하나씩 삭제 / 선택 삭제 / 전체 선택 / 취소 / 전체 삭제를 차례로 확인한다.
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

const browser = await launch();
const ctx = await phoneContext(browser);
await ctx.route(REMOTE, async (route) => {
  if (/explain./.test(route.request().url())) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  const url = route.request().url().replace(REMOTE, API);
  await route.fulfill({ response: await route.fetch({ url }) });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
const snap = (name) => page.screenshot({ path: shot(name) });
const wrongCount = async () => {
  const t = await page.getByText(/^\d+개의 오답/).first().textContent();
  return Number(t.match(/^(\d+)/)[1]);
};
const openWrong = async () => {
  await page.goto(APP + "/wrong", { waitUntil: "networkidle" });
  await page.getByText(/^\d+개의 오답/).waitFor({ timeout: 20000 });
  await page.waitForTimeout(800);
};
async function step(name, fn) {
  try {
    const [ok, detail] = await fn();
    log(name, ok, detail);
  } catch (e) {
    await snap("w-fail-" + results.length).catch(() => {});
    log(name, false, String(e).split("\n")[0]);
  }
}

// 가입
await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+w${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("오답테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

// 10문제 모두 4번으로 풀기
let wrongMade = 0;
await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), { waitUntil: "networkidle" });
for (let i = 0; i < 10; i++) {
  await page.getByRole("radio").nth(3).click({ timeout: 8000 });
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(700);
  if (!(await page.getByText("정답이에요!").isVisible())) wrongMade++;
  const next = page.getByText(/다음 문제|결과 보기/).first();
  if (await next.isVisible()) await next.click();
  await page.waitForTimeout(700);
}
console.log(`오답 ${wrongMade}개 생성`);

await step("오답노트에 틀린 문제가 쌓임", async () => {
  await openWrong();
  await snap("w-00-list");
  const n = await wrongCount();
  return [n === wrongMade && n >= 3, `화면 ${n}개 / 틀린 문제 ${wrongMade}개`];
});

await step("카드 휴지통 → 확인 → 1개 삭제", async () => {
  const before = await wrongCount();
  await page.getByLabel("이 오답 삭제").first().click();
  await page.getByText("이 문제를 오답 노트에서 삭제하시겠습니까?").waitFor({ timeout: 5000 });
  await snap("w-01-confirm-one");
  await page.getByText("삭제", { exact: true }).last().click();
  await page.waitForTimeout(1500);
  const after = await wrongCount();
  await openWrong();
  const reloaded = await wrongCount();
  return [after === before - 1 && reloaded === after, `${before} → ${after} (새로고침 후 ${reloaded})`];
});

await step("카드 휴지통 → 취소하면 그대로", async () => {
  const before = await wrongCount();
  await page.getByLabel("이 오답 삭제").first().click();
  await page.getByText("취소", { exact: true }).last().click();
  await page.waitForTimeout(800);
  return [(await wrongCount()) === before, `${before}개 유지`];
});

await step("선택 모드: 2개 체크 → 2개 삭제", async () => {
  const before = await wrongCount();
  await page.getByText("선택", { exact: true }).click();
  await page.waitForTimeout(500);
  const hiddenTrash = await page.getByLabel("이 오답 삭제").count();
  const cards = page.getByText(/^내 답:/);
  await cards.nth(0).click();
  await cards.nth(1).click();
  await page.waitForTimeout(400);
  await snap("w-02-selected-two");
  const label = await page.getByText(/^\d+개 삭제$/).textContent();
  await page.getByText(/^\d+개 삭제$/).click();
  await page.getByText(/선택한 2개의 문제를/).waitFor({ timeout: 5000 });
  await page.getByText("삭제", { exact: true }).last().click();
  await page.waitForTimeout(2000);
  const after = await wrongCount();
  const exited = await page.getByText("선택", { exact: true }).isVisible();
  return [label === "2개 삭제" && after === before - 2 && hiddenTrash === 0 && exited,
    `버튼 "${label}", ${before} → ${after}, 선택 중 카드 휴지통 ${hiddenTrash}개, 끝나고 선택 모드 해제 ${exited}`];
});

await step("선택 모드: 같은 카드 두 번 누르면 해제 + 0개면 삭제 버튼 비활성", async () => {
  await page.getByText("선택", { exact: true }).click();
  const card = page.getByText(/^내 답:/).first();
  await card.click();
  await card.click();
  await page.waitForTimeout(300);
  const label = await page.getByText(/^\d+개 삭제$/).textContent();
  const before = await wrongCount();
  await page.getByText(/^\d+개 삭제$/).click({ force: true });
  await page.waitForTimeout(500);
  const dialog = await page.getByText(/선택한 \d+개의 문제를/).isVisible();
  return [label === "0개 삭제" && !dialog && (await wrongCount()) === before, `버튼 "${label}", 확인창 ${dialog ? "뜸" : "안 뜸"}`];
});

await step("선택 모드: 전체 선택 → 개수 = 보이는 카드 수, 다시 누르면 해제", async () => {
  const total = await wrongCount();
  await page.getByText("전체 선택", { exact: true }).click();
  await page.waitForTimeout(300);
  const all = await page.getByText(/^\d+개 삭제$/).textContent();
  await page.getByText("전체 선택", { exact: true }).click();
  await page.waitForTimeout(300);
  const none = await page.getByText(/^\d+개 삭제$/).textContent();
  await snap("w-03-select-all-toggle");
  return [all === `${total}개 삭제` && none === "0개 삭제", `"${all}" → "${none}"`];
});

await step("선택 모드: 취소 → 원래 화면(복습 버튼) 복귀", async () => {
  await page.getByText("취소", { exact: true }).first().click();
  await page.waitForTimeout(500);
  const retry = await page.getByText(/^전체 \(\d+\)$/).isVisible();
  const bar = await page.getByText("전체 선택", { exact: true }).isVisible();
  return [retry && !bar, `복습 버튼 ${retry ? "보임" : "안 보임"}, 하단 바 ${bar ? "남음" : "사라짐"}`];
});

await step("필터: 다른 과목 탭에서는 체크해 둔 카드가 지워지지 않음", async () => {
  const before = await wrongCount();
  await page.getByText("선택", { exact: true }).click();
  await page.getByText(/^내 답:/).first().click();
  await page.getByText(/^2과목 \d+$/).click();
  await page.waitForTimeout(500);
  const label = await page.getByText(/^\d+개 삭제$/).isVisible().then(async (v) => (v ? page.getByText(/^\d+개 삭제$/).textContent() : "바 없음(카드 0개)"));
  await page.getByText(/^1과목 \d+$/).click();
  await page.getByText("취소", { exact: true }).first().click();
  await page.getByText(/^전체 \d+$/).click();
  return [(await wrongCount()) === before, `2과목 탭에서 ${label}, 오답 ${before}개 유지`];
});

await step("헤더 전체 삭제 → 확인 → 0개", async () => {
  await page.getByLabel("오답 노트 전체 삭제").click();
  await page.getByText("모든 오답을 삭제하시겠습니까?").waitFor({ timeout: 5000 });
  await page.getByText("삭제", { exact: true }).last().click();
  await page.waitForTimeout(1500);
  await snap("w-04-cleared");
  const empty = await page.getByText("오답이 없습니다!").isVisible();
  const selectBtn = await page.getByText("선택", { exact: true }).isVisible();
  return [empty && !selectBtn, `빈 화면 ${empty}, 선택 버튼 숨김 ${!selectBtn}`];
});

const relevant = errors.filter((e) => !/favicon|DevTools|deprecated/i.test(e));
log("콘솔/페이지 에러 없음", relevant.length === 0, relevant.slice(0, 3).join(" || ").slice(0, 300));
await browser.close();
finish();

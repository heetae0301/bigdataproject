// 결과 화면 "문제 다시 보기": 틀린 문제/전체 전환, 맞힌 문제 펼치기(정답·해설·동그래·북마크), 북마크 → 북마크 모드에 나옴
import { APP, API, REMOTE, shot, launch, phoneContext, reporter } from "../lib.mjs";

const { results, log, finish } = reporter();

const browser = await launch();
const ctx = await phoneContext(browser);
await ctx.route(REMOTE, async (route) => {
  const url = route.request().url();
  if (/explain\./.test(url)) return route.fulfill({ status: 500, contentType: "application/json", body: "[]" });
  await route.fulfill({ response: await route.fetch({ url: url.replace(REMOTE, API) }) });
});
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
async function step(name, fn) {
  try { const [ok, detail] = await fn(); log(name, ok, detail); }
  catch (e) { await page.screenshot({ path: shot(`r-fail-${results.length}`) }).catch(() => {}); log(name, false, String(e).split("\n")[0]); }
}

await page.goto(APP + "/signup", { waitUntil: "networkidle" });
await page.getByPlaceholder("you@example.com").fill(`e2e+r${Date.now()}@example.com`);
await page.getByPlaceholder("앱에서 표시될 이름").fill("결과테스트");
await page.getByPlaceholder("6자 이상").fill("test1234");
await page.getByPlaceholder("비밀번호 재입력").fill("test1234");
await page.getByText("회원가입", { exact: true }).last().click();
await page.waitForTimeout(2500);

// 10문제를 1,2,3,4,1,2,... 순서로 골라 맞힘/틀림을 섞는다
let right = 0;
await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("1과목(데이터 이해)"), { waitUntil: "networkidle" });
for (let i = 0; i < 10; i++) {
  await page.getByRole("radio").nth(i % 4).click({ timeout: 8000 });
  await page.getByText("정답 확인", { exact: true }).click();
  await page.waitForTimeout(500);
  if (await page.getByText("정답이에요!").isVisible()) right++;
  await page.getByText(/다음 문제|결과 보기/).first().click();
  await page.waitForTimeout(500);
}
const wrong = 10 - right;
console.log(`맞힘 ${right}, 틀림 ${wrong}`);
const rows = () => page.getByLabel(/^Q\d+ (맞힌|틀린) 문제 (펼치기|접기)$/);

await step("결과 화면: 기본은 틀린 문제 목록 + 전환 버튼 개수 표시", async () => {
  await page.getByText("문제 다시 보기").waitFor({ timeout: 8000 });
  const wrongTab = await page.getByRole("radio", { name: `틀린 문제 ${wrong}` }).getAttribute("aria-checked");
  const allTab = await page.getByRole("radio", { name: "전체 10" }).getAttribute("aria-checked");
  const n = await rows().count();
  await page.screenshot({ path: shot("r-01-wrong"), fullPage: true });
  const expected = wrong > 0 ? wrong : 10;
  return [n === expected && (wrong > 0 ? wrongTab === "true" && allTab === "false" : allTab === "true"), `행 ${n}개, 틀린 탭 ${wrongTab}, 전체 탭 ${allTab}`];
});

await step("'전체'로 바꾸면 10문제 모두, 맞힌 문제는 '맞힌 문제'로 표시", async () => {
  await page.getByRole("radio", { name: "전체 10" }).click();
  await page.waitForTimeout(300);
  const n = await rows().count();
  const correctRows = await page.getByLabel(/^Q\d+ 맞힌 문제 펼치기$/).count();
  return [n === 10 && correctRows === right, `행 ${n}개, 맞힌 문제 ${correctRows}개`];
});

let openedQ = "";
await step("맞힌 문제 펼치기 → 보기·'정답·내 답'·해설·동그래 해설·북마크", async () => {
  if (right === 0) return [true, "맞힌 문제가 없어 건너뜀"];
  const row = page.getByLabel(/^Q\d+ 맞힌 문제 펼치기$/).first();
  openedQ = (await row.getAttribute("aria-label")).split(" ")[0];
  await row.click();
  await page.waitForTimeout(400);
  const expanded = await page.getByLabel(`${openedQ} 맞힌 문제 접기`).getAttribute("aria-expanded");
  const tag = await page.getByText("정답·내 답", { exact: true }).isVisible();
  const dongurae = await page.getByLabel("동그래 해설 듣기").isVisible();
  const bm = await page.getByLabel("북마크", { exact: true }).isVisible();
  await page.screenshot({ path: shot("r-02-open-correct"), fullPage: true });
  return [expanded === "true" && tag && dongurae && bm, `${openedQ} 펼침=${expanded}, 정답·내 답 ${tag}, 동그래 ${dongurae}, 북마크 ${bm}`];
});

await step("다시 누르면 접힘, 한 번에 하나만 펼쳐짐", async () => {
  if (right === 0 || wrong === 0) return [true, "건너뜀"];
  await page.getByLabel(/^Q\d+ 틀린 문제 펼치기$/).first().click();
  await page.waitForTimeout(300);
  const stillOpen = await page.getByLabel(`${openedQ} 맞힌 문제 접기`).count();
  const mine = await page.getByText("내 답", { exact: true }).isVisible();
  await page.getByLabel(/^Q\d+ 틀린 문제 접기$/).click();
  await page.waitForTimeout(300);
  const closed = await page.getByLabel(/접기$/).count();
  return [stillOpen === 0 && mine && closed === 0, `앞 문제 닫힘 ${stillOpen === 0}, 틀린 문제에 '내 답' ${mine}, 모두 접힘 ${closed === 0}`];
});

await step("결과 화면에서 북마크 → 북마크 모드에 그 문제가 나옴", async () => {
  if (right === 0) return [true, "건너뜀"];
  await page.getByLabel(`${openedQ} 맞힌 문제 펼치기`).click();
  await page.waitForTimeout(300);
  const qText = (await page.getByLabel(`${openedQ} 맞힌 문제 접기`).innerText()).replace(/\s+/g, " ").replace(/^.*?Q\d+\s*/, "").slice(0, 20);
  await page.getByLabel("북마크", { exact: true }).click();
  await page.waitForTimeout(800);
  const toggled = await page.getByLabel("북마크 해제").isVisible();
  await page.goto(APP + "/quiz-session?subject=" + encodeURIComponent("북마크"), { waitUntil: "networkidle" });
  await page.waitForTimeout(800);
  const body = await page.locator("body").innerText();
  return [toggled && body.includes("1 / 1") && body.includes(qText.slice(0, 12)), `버튼 '북마크 해제' ${toggled}, 북마크 모드 "${qText.slice(0, 12)}…" ${body.includes(qText.slice(0, 12))}`];
});

log("페이지 에러 없음", errors.length === 0, errors.slice(0, 2).join(" || "));
await browser.close();
finish();

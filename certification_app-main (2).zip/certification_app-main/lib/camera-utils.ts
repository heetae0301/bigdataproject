import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";

export interface CameraImage {
  uri: string;
  width: number;
  height: number;
  base64?: string;
}

/**
 * 갤러리에서 이미지 선택
 */
export async function pickImageFromGallery(): Promise<CameraImage | null> {
  try {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
      base64: true,
    });

    if (result.canceled) {
      return null;
    }

    const asset = result.assets[0];
    return {
      uri: asset.uri,
      width: asset.width,
      height: asset.height,
      base64: asset.base64 || undefined,
    };
  } catch (error) {
    console.error("Error picking image:", error);
    return null;
  }
}

/**
 * 카메라로 사진 촬영
 */
export async function takeCameraPhoto(): Promise<CameraImage | null> {
  try {
    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.8,
      base64: true,
    });

    if (result.canceled) {
      return null;
    }

    const asset = result.assets[0];
    return {
      uri: asset.uri,
      width: asset.width,
      height: asset.height,
      base64: asset.base64 || undefined,
    };
  } catch (error) {
    console.error("Error taking photo:", error);
    return null;
  }
}

/**
 * 이미지를 Base64로 변환
 */
export async function imageToBase64(uri: string): Promise<string | null> {
  try {
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    return base64;
  } catch (error) {
    console.error("Error converting image to base64:", error);
    return null;
  }
}

/**
 * 카메라 권한 요청
 */
export async function requestCameraPermission(): Promise<boolean> {
  try {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    return status === "granted";
  } catch (error) {
    console.error("Error requesting camera permission:", error);
    return false;
  }
}

/**
 * 갤러리 권한 요청
 */
export async function requestGalleryPermission(): Promise<boolean> {
  try {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    return status === "granted";
  } catch (error) {
    console.error("Error requesting gallery permission:", error);
    return false;
  }
}

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

/**
 * 기기별 앱 설정(하루 목표, 화면 테마, 글자 크기). 계정이 아니라 기기에 저장한다 -
 * 같은 계정이라도 폰과 PC에서 글자 크기나 테마를 다르게 쓰고 싶을 수 있어서다.
 */
const STORAGE_KEY = "app-settings";

export type ThemeMode = "system" | "light" | "dark";

export interface AppSettings {
  /** 하루 목표 문제 수 */
  dailyGoal: number;
  themeMode: ThemeMode;
  /** 문제/선택지/해설 글자 크기 배율 */
  fontScale: number;
}

export const DEFAULT_APP_SETTINGS: AppSettings = { dailyGoal: 20, themeMode: "system", fontScale: 1 };

export const DAILY_GOAL_OPTIONS = [10, 20, 30, 50];
export const MIN_DAILY_GOAL = 1;
export const MAX_DAILY_GOAL = 200;

/** 하루 목표를 1~200 사이 정수로 맞춘다. 숫자가 아니면 기본값. */
export function clampDailyGoal(value: number): number {
  if (!Number.isFinite(value)) return DEFAULT_APP_SETTINGS.dailyGoal;
  return Math.min(MAX_DAILY_GOAL, Math.max(MIN_DAILY_GOAL, Math.round(value)));
}

/** −/+ 버튼: 5문제 단위로 맞춰서 움직이고, 5 이하에서는 1씩 움직인다. */
export function stepDailyGoal(value: number, direction: 1 | -1): number {
  if (direction === 1) return clampDailyGoal(value < 5 ? value + 1 : value - (value % 5) + 5);
  if (value <= 5) return clampDailyGoal(value - 1);
  return clampDailyGoal(value % 5 ? value - (value % 5) : value - 5);
}

export const THEME_MODE_OPTIONS: { label: string; value: ThemeMode }[] = [
  { label: "자동", value: "system" },
  { label: "밝게", value: "light" },
  { label: "어둡게", value: "dark" },
];

export const FONT_SCALE_OPTIONS: { label: string; value: number }[] = [
  { label: "작게", value: 0.9 },
  { label: "보통", value: 1 },
  { label: "크게", value: 1.15 },
  { label: "아주 크게", value: 1.3 },
];

type AppSettingsContextValue = {
  settings: AppSettings;
  updateSettings: (patch: Partial<AppSettings>) => void;
};

const AppSettingsContext = createContext<AppSettingsContextValue | null>(null);

export function AppSettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!raw) return;
        const saved = { ...DEFAULT_APP_SETTINGS, ...JSON.parse(raw) };
        setSettings({ ...saved, dailyGoal: clampDailyGoal(Number(saved.dailyGoal)) });
      })
      .catch(() => {});
  }, []);

  const updateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      if (patch.dailyGoal !== undefined) next.dailyGoal = clampDailyGoal(patch.dailyGoal);
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)).catch(() => {});
      return next;
    });
  }, []);

  const value = useMemo(() => ({ settings, updateSettings }), [settings, updateSettings]);

  return <AppSettingsContext.Provider value={value}>{children}</AppSettingsContext.Provider>;
}

export function useAppSettings(): AppSettingsContextValue {
  const ctx = useContext(AppSettingsContext);
  if (!ctx) {
    throw new Error("useAppSettings must be used within AppSettingsProvider");
  }
  return ctx;
}

/**
 * 글자 크기 설정을 반영한 fontSize/lineHeight 스타일을 만든다.
 * 사용: const ts = useTextScale(); <Text style={[styles.questionText, ts(16, 26)]} />
 */
export function useTextScale(): (fontSize: number, lineHeight: number) => { fontSize: number; lineHeight: number } {
  const { fontScale } = useAppSettings().settings;
  return useCallback(
    (fontSize: number, lineHeight: number) => ({
      fontSize: Math.round(fontSize * fontScale),
      lineHeight: Math.round(lineHeight * fontScale),
    }),
    [fontScale]
  );
}

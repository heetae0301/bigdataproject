import { createContext, useCallback, useContext, useEffect, useMemo } from "react";
import { Appearance, View, useColorScheme as useSystemColorScheme } from "react-native";
import { colorScheme as nativewindColorScheme, vars } from "nativewind";

import { SchemeColors, type ColorScheme } from "@/constants/theme";
import { useAppSettings } from "@/lib/app-settings";

type ThemeContextValue = {
  colorScheme: ColorScheme;
  setColorScheme: (scheme: ColorScheme) => void;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const { settings, updateSettings } = useAppSettings();
  const { themeMode } = settings;
  const systemScheme = useSystemColorScheme();

  // "자동"이면 기기 설정을 따르고, 아니면 사용자가 고른 테마로 고정한다.
  const colorScheme: ColorScheme =
    themeMode === "system" ? (systemScheme === "dark" ? "dark" : "light") : themeMode;

  // 네이티브 쪽 고정값을 맞춘다. "unspecified"로 돌려놔야 useSystemColorScheme이
  // 다시 실제 기기 설정을 돌려준다.
  useEffect(() => {
    Appearance.setColorScheme?.(themeMode === "system" ? "unspecified" : themeMode);
  }, [themeMode]);

  useEffect(() => {
    nativewindColorScheme.set(colorScheme);
    if (typeof document !== "undefined") {
      const root = document.documentElement;
      root.dataset.theme = colorScheme;
      root.classList.toggle("dark", colorScheme === "dark");
      const palette = SchemeColors[colorScheme];
      Object.entries(palette).forEach(([token, value]) => {
        root.style.setProperty(`--color-${token}`, value);
      });
    }
  }, [colorScheme]);

  const setColorScheme = useCallback(
    (scheme: ColorScheme) => updateSettings({ themeMode: scheme }),
    [updateSettings],
  );

  const themeVariables = useMemo(
    () =>
      vars({
        "color-primary": SchemeColors[colorScheme].primary,
        "color-background": SchemeColors[colorScheme].background,
        "color-surface": SchemeColors[colorScheme].surface,
        "color-foreground": SchemeColors[colorScheme].foreground,
        "color-muted": SchemeColors[colorScheme].muted,
        "color-border": SchemeColors[colorScheme].border,
        "color-success": SchemeColors[colorScheme].success,
        "color-warning": SchemeColors[colorScheme].warning,
        "color-error": SchemeColors[colorScheme].error,
      }),
    [colorScheme],
  );

  const value = useMemo(
    () => ({
      colorScheme,
      setColorScheme,
    }),
    [colorScheme, setColorScheme],
  );

  return (
    <ThemeContext.Provider value={value}>
      <View style={[{ flex: 1 }, themeVariables]}>{children}</View>
    </ThemeContext.Provider>
  );
}

export function useThemeContext(): ThemeContextValue {
  const ctx = useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useThemeContext must be used within ThemeProvider");
  }
  return ctx;
}

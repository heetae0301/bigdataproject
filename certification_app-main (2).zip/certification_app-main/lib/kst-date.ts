/**
 * 날짜 문자열(YYYY-MM-DD)은 항상 한국 시간(KST, UTC+9) 기준으로 만든다.
 * `new Date().toISOString()`은 UTC라서, 오전 9시 전에 공부하면 전날로
 * 기록되어 연속 학습일이 끊기는 문제가 있었다. 서버(스트릭/일별 로그)와
 * 클라이언트(D-day, 그래프의 "오늘" 표시)가 같은 함수를 쓴다.
 */
const KST_OFFSET_MS = 9 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

export function kstDateStr(date: Date = new Date()): string {
  return new Date(date.getTime() + KST_OFFSET_MS).toISOString().split("T")[0];
}

export function addDays(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00Z`);
  return new Date(d.getTime() + days * DAY_MS).toISOString().split("T")[0];
}

/** b - a (일 단위). 둘 다 YYYY-MM-DD. */
export function diffDays(a: string, b: string): number {
  return Math.round(
    (new Date(`${b}T00:00:00Z`).getTime() - new Date(`${a}T00:00:00Z`).getTime()) / DAY_MS
  );
}

export function isValidDateStr(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().startsWith(value);
}

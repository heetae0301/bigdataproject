import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { TRPCClientError } from "@trpc/client";
import { trpcVanilla } from "@/lib/trpc";
import { getAuthToken, setAuthToken, clearAuthToken } from "@/lib/auth-token";

export interface AuthUser {
  id: string;
  email: string;
  nickname: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isLoading: boolean;
  /** 저장된 로그인은 있는데 서버에 닿지 못해 확인을 못 한 상태 (오프라인, 서버 장애 등). 로그인은 지우지 않는다. */
  connectionError: boolean;
  /** connectionError일 때 저장된 로그인을 다시 확인한다. */
  retryConnection: () => void;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, nickname: string, password: string) => Promise<void>;
  /** Google 로그인 후 받은 1회용 코드로 로그인한다. null이면(사용자가 취소함) 아무 것도 하지 않는다. */
  loginWithGoogle: (code: string | null) => Promise<void>;
  logout: () => Promise<void>;
  updateNickname: (nickname: string) => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  /** 계정과 모든 학습 기록을 지우고 로그아웃한다. */
  deleteAccount: () => Promise<void>;
  requestPasswordReset: (email: string) => Promise<void>;
  resetPassword: (email: string, code: string, newPassword: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [connectionError, setConnectionError] = useState(false);

  const restoreSession = useCallback(async () => {
    setIsLoading(true);
    setConnectionError(false);
    const token = await getAuthToken();
    if (!token) {
      setIsLoading(false);
      return;
    }
    try {
      const me = await trpcVanilla.auth.me.query();
      setUser(me);
    } catch (error) {
      if (isInvalidSessionError(error)) {
        await clearAuthToken();
      } else {
        // 인터넷이 끊겼거나 서버가 응답하지 않음 — 로그인은 그대로 두고 다시 시도할 수 있게 한다
        setConnectionError(true);
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    // 마운트 시 저장된 로그인을 확인하는 비동기 작업 (상태 변경은 await 뒤에 일어난다)
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void restoreSession();
  }, [restoreSession]);

  const retryConnection = useCallback(() => {
    void restoreSession();
  }, [restoreSession]);

  const login = useCallback(async (email: string, password: string) => {
    const { token, user: loggedInUser } = await trpcVanilla.auth.login.mutate({ email, password });
    await setAuthToken(token);
    setUser(loggedInUser);
  }, []);

  const signup = useCallback(async (email: string, nickname: string, password: string) => {
    const { token, user: newUser } = await trpcVanilla.auth.signup.mutate({ email, nickname, password });
    await setAuthToken(token);
    setUser(newUser);
  }, []);

  const loginWithGoogle = useCallback(async (code: string | null) => {
    if (!code) return;
    const { token, user: loggedInUser } = await trpcVanilla.auth.googleExchange.mutate({ code });
    await setAuthToken(token);
    setUser(loggedInUser);
  }, []);

  const logout = useCallback(async () => {
    await clearAuthToken();
    setUser(null);
    setConnectionError(false);
  }, []);

  const updateNickname = useCallback(async (nickname: string) => {
    const result = await trpcVanilla.auth.updateNickname.mutate({ nickname });
    setUser((prev) => (prev ? { ...prev, nickname: result.nickname } : prev));
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    await trpcVanilla.auth.changePassword.mutate({ currentPassword, newPassword });
  }, []);

  const deleteAccount = useCallback(async () => {
    await trpcVanilla.auth.deleteAccount.mutate();
    await clearAuthToken();
    setUser(null);
  }, []);

  const requestPasswordReset = useCallback(async (email: string) => {
    await trpcVanilla.auth.requestPasswordReset.mutate({ email });
  }, []);

  const resetPassword = useCallback(async (email: string, code: string, newPassword: string) => {
    await trpcVanilla.auth.resetPassword.mutate({ email, code, newPassword });
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        connectionError,
        retryConnection,
        login,
        signup,
        loginWithGoogle,
        logout,
        updateNickname,
        changePassword,
        deleteAccount,
        requestPasswordReset,
        resetPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

/** 서버가 "이 로그인은 더 이상 유효하지 않다"고 답한 경우만 true (만료·위조 토큰, 지워진 계정). */
function isInvalidSessionError(error: unknown): boolean {
  if (!(error instanceof TRPCClientError)) return false;
  const code = (error.data as { code?: string } | undefined)?.code;
  return code === "UNAUTHORIZED" || code === "NOT_FOUND";
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}

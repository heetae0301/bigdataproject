import { trpcVanilla } from "@/lib/trpc";
import type { Question } from "@/data/questions";
import type { ExplanationScene } from "@/lib/explanation-scenes";

export interface DonguraeExplanation {
  /** 그림 해설을 못 만들었을 때 칠판 자막으로 읽을 해설 */
  explanation: string;
  /** 그림 해설 장면 (있으면 DmuExplanationPlayer가 칠판에 그림을 그린다) */
  scenes?: ExplanationScene[];
  /** 문제 본문 (칠판의 보기 장면 위에 같이 보여준다) */
  question?: string;
}

/**
 * 동그래 해설을 준비한다 (문제 풀이 화면, 오답노트 공용).
 * 1) 그림 해설 장면 대본 (맞힌 경우 포함)
 * 2) 실패하면: 틀렸으면 오답 맞춤 해설, 맞혔으면 문제은행 기본 해설 (예전 동작 그대로)
 * 3) 그것도 실패하면 기본 해설
 */
export async function loadDonguraeExplanation(q: Question, selectedOption: number): Promise<DonguraeExplanation> {
  return { ...(await loadExplanationBody(q, selectedOption)), question: q.question };
}

async function loadExplanationBody(q: Question, selectedOption: number): Promise<DonguraeExplanation> {
  try {
    const { scenes } = await trpcVanilla.explain.generateScenes.mutate({ questionId: q.id, selectedOption });
    if (scenes.length > 0) return { explanation: q.explanation, scenes };
  } catch (error) {
    console.warn("[Dongurae] Scene script unavailable, using subtitle explanation:", error);
  }

  if (selectedOption === q.answer) return { explanation: q.explanation };

  try {
    const result = await trpcVanilla.explain.generateForWrongAnswer.mutate({
      questionId: q.id,
      question: q.question,
      options: q.options,
      selectedOption,
      correctOption: q.answer,
    });
    return { explanation: result.explanation };
  } catch (error) {
    console.warn("[Dongurae] Falling back to static explanation:", error);
    return { explanation: q.explanation };
  }
}

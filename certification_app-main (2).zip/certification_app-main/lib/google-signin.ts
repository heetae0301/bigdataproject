import { Platform } from "react-native";
import * as Linking from "expo-linking";
import * as WebBrowser from "expo-web-browser";
import { getApiBaseUrl } from "@/constants/api";

/**
 * 브라우저 기반 Google 로그인. 네이티브 모듈이 필요 없어서 Expo Go(아이폰·안드로이드)와
 * 설치한 빌드 모두에서 같은 방식으로 동작한다. 실제 OAuth 처리는 서버가 한다
 * (server/auth/google-oauth.ts) — 앱은 인앱 브라우저를 열고, 돌아온 1회용 코드만 받는다.
 */
export const isGoogleSignInAvailable = Platform.OS !== "web";

const ERROR_MESSAGES: Record<string, string> = {
  not_configured: "서버에 Google 로그인 설정이 아직 안 돼 있어요.",
  failed: "Google 로그인에 실패했어요. 다시 시도해주세요.",
};

/**
 * Render 무료 서버는 쉬고 있다가 첫 요청에 깨어나는데, 그동안 브라우저에는 Render 대기 화면이 뜬다.
 * 인앱 브라우저를 열기 전에 서버가 응답할 때까지 기다려서 그 화면을 건너뛴다. 실패해도 로그인은 그대로 진행한다.
 */
async function wakeServer(timeoutMs = 60000): Promise<void> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    await fetch(`${getApiBaseUrl()}/api/health`, { signal: controller.signal });
  } catch {
    // 깨우기 실패는 무시 — 브라우저가 열리면서 다시 시도된다
  } finally {
    clearTimeout(timer);
  }
}

/** 로그인 화면이 열릴 때 미리 서버를 깨워 둔다. */
export function prewarmGoogleSignIn(): void {
  if (isGoogleSignInAvailable) void wakeServer();
}

/** Google 로그인 창을 띄우고, 성공하면 서버에서 받은 1회용 코드를 돌려준다. 취소하면 null. */
export async function signInWithGoogle(): Promise<string | null> {
  await wakeServer();
  // Expo Go면 exp(s)://<개발 서버>/--/auth/google, 설치한 빌드면 <앱 스킴>://auth/google
  const returnUrl = Linking.createURL("auth/google");
  const startUrl = `${getApiBaseUrl()}/api/auth/google/start?return=${encodeURIComponent(returnUrl)}`;

  const result = await WebBrowser.openAuthSessionAsync(startUrl, returnUrl);
  if (result.type !== "success") return null;

  const { queryParams } = Linking.parse(result.url);
  const error = queryParams?.error;
  if (typeof error === "string") {
    if (error === "cancelled") return null;
    throw new Error(ERROR_MESSAGES[error] ?? ERROR_MESSAGES.failed);
  }
  const code = queryParams?.code;
  if (typeof code !== "string" || !code) {
    throw new Error(ERROR_MESSAGES.failed);
  }
  return code;
}

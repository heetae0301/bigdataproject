/*
 * 사진 인식 해설 기능 - 공용 타입 및 순수 유틸리티
 *
 * 실제 네트워크 호출(OCR, 해설 생성)은 tRPC(`trpc.vision.recognizeQuestion`,
 * `trpc.explain.generateForWrongAnswer`)로 통일했다. 예전에는 이 파일이 REST 엔드포인트
 * (`/api/ocr`, `/api/explain`, `/api/generate-video`)를 직접 fetch하는
 * 중복 구현을 갖고 있었는데, 그중 `/api/ocr`은 서버에 존재하지도 않는
 * 죽은 경로였고 나머지도 tRPC와 로직이 겹쳐서 모두 정리했다.
 * 자세한 배경은 ADSP_퀴즈앱_재기획서.md 2-2절 참고.
 */

export interface OCRResult {
  text: string;
  confidence: number;
}

export interface ExplanationResult {
  question: string;
  answer: string;
  explanation: string;
  duration: number; // 초 단위
}

export interface SentenceSegment {
  /** 원본 텍스트(트림/공백정규화 이전이 아니라, 실제로 화면에 표시/발화되는 문자열) 안에서의 시작 문자 위치 */
  startChar: number;
  /** 끝 문자 위치 (exclusive) */
  endChar: number;
  text: string;
}

/**
 * 텍스트를 문장 단위로 나누되, 각 문장이 원본 문자열의 몇 번째 글자에서
 * 시작/끝나는지(startChar/endChar)를 함께 반환한다.
 *
 * 이 char 위치는 `Speech.speak()`의 `onBoundary` 콜백이 주는 `charIndex`와
 * 같은 좌표계를 쓴다 — 즉 실시간 TTS 재생 위치를 문장 단위로 매핑하는 데
 * 쓰기 위한 핵심 유틸이다 (components/dmu-explanation-player.tsx 참고).
 * 시간 기반 자막이 필요한 곳(`generateSubtitlesFromExplanation`)도 이 함수
 * 위에 구현되어 있어, "문장을 어떻게 나누는가"는 이 함수 하나로 통일된다.
 */
export function splitIntoSentenceSegments(text: string): SentenceSegment[] {
  const segments: SentenceSegment[] = [];
  const delimiterRegex = /[.!?]+/g;
  let sentenceStart = 0;
  let match: RegExpExecArray | null;

  const pushSegment = (rawStart: number, rawEnd: number) => {
    const raw = text.slice(rawStart, rawEnd);
    const trimmed = raw.trim();
    if (trimmed.length === 0) return;
    const leadingWhitespace = raw.length - raw.trimStart().length;
    const startChar = rawStart + leadingWhitespace;
    segments.push({
      startChar,
      endChar: startChar + trimmed.length,
      text: trimmed,
    });
  };

  while ((match = delimiterRegex.exec(text)) !== null) {
    pushSegment(sentenceStart, match.index);
    sentenceStart = delimiterRegex.lastIndex;
  }
  pushSegment(sentenceStart, text.length);

  return segments;
}

/**
 * 주어진 charIndex(예: onBoundary 콜백의 위치)가 어느 문장 세그먼트에
 * 속하는지 찾는다. 세그먼트 사이의 공백/구두점 위에 charIndex가 떨어지는
 * 경우엔 직전에 시작된 세그먼트를 반환한다.
 */
export function findSegmentForCharIndex(
  segments: SentenceSegment[],
  charIndex: number
): SentenceSegment | null {
  let found: SentenceSegment | null = null;
  for (const seg of segments) {
    if (charIndex >= seg.startChar) {
      found = seg;
    } else {
      break;
    }
  }
  return found ?? segments[0] ?? null;
}

/**
 * 자막 생성 (텍스트 → 시간 기반 자막 배열 + SRT)
 *
 * 실시간 캐릭터 재생 화면(DmuExplanationPlayer)은 이제 이 함수를 쓰지 않고
 * `onBoundary` 콜백으로 실제 발화 위치를 직접 추적한다. 이 함수는 SRT 내보내기
 * 등 "정해진 총 길이에 맞춰 시간표를 미리 만들어야 하는" 용도를 위해 남겨둔
 * 범용 유틸이다. 문장 길이에 비례해서 시간을 배분하므로(예전의 "문장 수로
 * 균등분할"보다 정확함) 실제 발화 속도와도 더 잘 맞는다.
 */
export function generateSubtitlesFromExplanation(
  explanation: string,
  totalDuration: number
): { subtitles: { startTime: number; endTime: number; text: string }[]; srtSubtitles: string } {
  const segments = splitIntoSentenceSegments(explanation);
  const totalChars = segments.reduce((sum, seg) => sum + (seg.endChar - seg.startChar), 0);

  let cursor = 0;
  const subtitles = segments.map((seg) => {
    const segChars = seg.endChar - seg.startChar;
    const duration = totalChars > 0 ? (segChars / totalChars) * totalDuration : 0;
    const startTime = cursor;
    cursor += duration;
    return { startTime, endTime: cursor, text: seg.text };
  });

  // SRT 형식 생성
  const srtSubtitles = subtitles
    .map((sub, index) => {
      const formatTime = (seconds: number) => {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        const ms = Math.floor((seconds % 1) * 1000);
        return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")},${String(ms).padStart(3, "0")}`;
      };

      return `${index + 1}\n${formatTime(sub.startTime)} --> ${formatTime(sub.endTime)}\n${sub.text}`;
    })
    .join("\n\n");

  return { subtitles, srtSubtitles };
}

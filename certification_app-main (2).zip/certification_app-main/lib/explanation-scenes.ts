import { z } from "zod";

/**
 * 동그래 "그림 해설"의 장면 형식. 서버(AI 대본 생성·검증)와 앱(칠판 그리기)이 같이 쓴다.
 *
 * 영상 해설이 텍스트 해설을 그대로 읽기만 하면 새로울 게 없어서, AI가 해설을 몇 개의 장면으로
 * 나누고 장면마다 "동그래가 할 말(narration)"과 "칠판에 그릴 그림(visual)"을 정한다.
 * 그림은 AI가 이미지를 만드는 게 아니라, 아래 정해진 틀 중 하나를 골라 내용만 채우면 앱이 직접 그린다
 * (한글이 깨지지 않고, 빠르고, 할당량을 적게 쓴다).
 *
 * "options"는 내용(보기 문장, 고른 답, 정답)을 서버가 문제은행에서 직접 채운다 — AI가 보기를
 * 잘못 옮겨 적는 일을 막기 위해서다.
 */

const short = (max: number) => z.string().trim().min(1).max(max);

export const optionsVisualSchema = z.object({
  type: z.literal("options"),
  options: z.array(z.string()).min(2).max(6),
  selectedOption: z.number().int(),
  correctOption: z.number().int(),
});

export const compareVisualSchema = z.object({
  type: z.literal("compare"),
  title: short(40).optional(),
  left: z.object({ title: short(24), points: z.array(short(40)).min(1).max(4) }),
  right: z.object({ title: short(24), points: z.array(short(40)).min(1).max(4) }),
});

export const stepsVisualSchema = z.object({
  type: z.literal("steps"),
  title: short(40).optional(),
  steps: z.array(short(30)).min(2).max(6),
  /** 강조할 단계(0부터). 문제에서 묻는 단계를 짚을 때 쓴다. */
  highlight: z.number().int().min(0).optional(),
});

export const formulaVisualSchema = z.object({
  type: z.literal("formula"),
  title: short(40).optional(),
  /** 한 줄씩 차례로 써 내려간다. 예: ["정밀도 = TP / (TP + FP)", "= 40 / (40 + 10)", "= 0.8"] */
  lines: z.array(short(60)).min(1).max(5),
});

export const keywordVisualSchema = z.object({
  type: z.literal("keyword"),
  term: short(30),
  definition: short(90),
  emoji: z.string().trim().max(4).optional(),
});

export const treeVisualSchema = z.object({
  type: z.literal("tree"),
  root: short(30),
  children: z.array(z.object({ label: short(24), note: short(40).optional() })).min(2).max(5),
  /** 강조할 가지(0부터). */
  highlight: z.number().int().min(0).optional(),
});

export const sceneVisualSchema = z.discriminatedUnion("type", [
  optionsVisualSchema,
  compareVisualSchema,
  stepsVisualSchema,
  formulaVisualSchema,
  keywordVisualSchema,
  treeVisualSchema,
]);

export const explanationSceneSchema = z.object({
  /** 이 장면에서 동그래가 소리 내어 말할 내용 (1~2문장) */
  narration: short(220),
  visual: sceneVisualSchema,
});

export type SceneVisual = z.infer<typeof sceneVisualSchema>;
export type ExplanationScene = z.infer<typeof explanationSceneSchema>;

export const SCENE_VISUAL_TYPES = ["options", "compare", "steps", "formula", "keyword", "tree"] as const;

/** 장면 대본은 최소 이만큼은 있어야 "그림 해설"로 쓴다 (그보다 적으면 자막 해설로 대체). */
export const MIN_SCENES = 2;
export const MAX_SCENES = 6;

/** 장면들의 대사를 이어 붙인 전체 대본 (AI 목소리 생성과 자막 위치 계산에 쓴다). */
export function sceneNarrationText(scenes: ExplanationScene[]): string {
  return scenes.map((s) => s.narration.replace(/\s+/g, " ").trim()).join(" ");
}

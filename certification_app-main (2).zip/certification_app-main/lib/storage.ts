import { Subject } from "@/data/questions";
import { trpcVanilla } from "@/lib/trpc";
import type { QuestionProgress } from "@/lib/question-picker";
import type { ReviewStatus } from "@/lib/review-schedule";
import type { SubjectScore } from "@/lib/mock-exam-scoring";

export type { QuestionProgress } from "@/lib/question-picker";

/**
 * 오답노트/학습통계/일별 로그/풀이 기록/모의고사 기록/북마크는 서버 DB에
 * 로그인 계정 기준으로 저장된다 (server/db/schema.ts 참고). 로그인 전에는
 * 호출되지 않아야 한다 — 화면 진입 자체를 lib/auth-context.tsx의 인증 가드가 막는다.
 */

export interface WrongAnswer {
  questionId: string;
  subject: Subject;
  selectedOption: number;
  correctOption: number;
  timestamp: number;
  /** 복습일에 연속으로 맞힌 횟수 (lib/review-schedule.ts) */
  correctStreak: number;
  /** 다음 복습 예정 시각(ms) */
  nextReviewAt: number;
}

export interface SubjectStats {
  total: number;
  correct: number;
}

export interface StudyStats {
  totalAnswered: number;
  totalCorrect: number;
  bySubject: Record<Subject, SubjectStats>;
  lastStudiedAt: number | null;
  streakDays: number;
  lastStreakDate: string | null;
  /** 지금까지의 최장 연속 학습일 (연속이 끊겨도 줄지 않는다) */
  bestStreakDays: number;
}

export interface AnswerOutcome {
  questionId: string;
  isCorrect: boolean;
  reviewStatus: ReviewStatus;
  correctStreak: number | null;
}

export interface MockExamRecord {
  id: number;
  takenAt: number;
  total: number;
  correct: number;
  bySubject: Record<Subject, SubjectScore>;
  passed: boolean;
  durationSeconds: number;
  /** 문제별 답안이 저장되어 있어 다시 볼 수 있는 회차인지 */
  reviewable: boolean;
  /** 기출 회차 실전 응시면 회차 번호, 무작위 모의고사면 null */
  round: number | null;
}

export interface RoundSummary {
  round: number;
  attempts: number;
  /** 최고 정답률 (0~1) */
  bestRate: number;
  everPassed: boolean;
}

// ─── Answers ──────────────────────────────────────────────────────────────────

/** 답 하나를 제출한다. 풀이 기록/통계/일별 로그/오답노트가 서버에서 한 번에 갱신된다. */
export async function submitAnswer(questionId: string, selectedOption: number): Promise<AnswerOutcome> {
  const [outcome] = await trpcVanilla.progress.submitAnswers.mutate({
    answers: [{ questionId, selectedOption }],
  });
  return outcome;
}

export async function getQuestionProgress(): Promise<QuestionProgress[]> {
  return trpcVanilla.progress.getQuestionProgress.query();
}

// ─── Wrong Answers ────────────────────────────────────────────────────────────

export async function getWrongAnswers(): Promise<WrongAnswer[]> {
  return trpcVanilla.progress.getWrongAnswers.query();
}

export async function removeWrongAnswer(questionId: string): Promise<void> {
  await trpcVanilla.progress.removeWrongAnswer.mutate({ questionId });
}

export async function clearWrongAnswers(): Promise<void> {
  await trpcVanilla.progress.clearWrongAnswers.mutate();
}

// ─── Study Stats ──────────────────────────────────────────────────────────────

export async function getStudyStats(): Promise<StudyStats> {
  return trpcVanilla.progress.getStudyStats.query();
}

export async function resetStudyStats(): Promise<void> {
  await trpcVanilla.progress.resetStudyStats.mutate();
}

// ─── Daily Log ────────────────────────────────────────────────────────────────

export async function getLast7DaysLog(): Promise<{ date: string; count: number }[]> {
  return trpcVanilla.progress.getLast7DaysLog.query();
}

// ─── Mock Exam ────────────────────────────────────────────────────────────────

/** round를 주면 그 기출 회차의 실전 응시로 저장된다. */
export async function submitMockExam(
  answers: { questionId: string; selectedOption: number | null }[],
  durationSeconds: number,
  round?: number
) {
  return trpcVanilla.mockExam.submit.mutate({ answers, durationSeconds, round });
}

/** round: 생략=전체, null=무작위 모의고사만, 숫자=그 기출 회차만 */
export async function getMockExamResults(limit = 20, round?: number | null): Promise<MockExamRecord[]> {
  return trpcVanilla.mockExam.list.query({ limit, round });
}

export async function getRoundSummaries(): Promise<RoundSummary[]> {
  return trpcVanilla.mockExam.roundSummaries.query();
}

/** 지난 회차에 나온 문제와 내가 고른 답 (순서는 응시 때와 같다). */
export async function getMockExamAnswers(
  id: number
): Promise<{ questionId: string; selectedOption: number | null }[]> {
  const { answers } = await trpcVanilla.mockExam.get.query({ id });
  return answers;
}

// ─── Notes ────────────────────────────────────────────────────────────────────

export async function getNotes(): Promise<{ questionId: string; note: string }[]> {
  return trpcVanilla.note.list.query();
}

/** 빈 문자열을 저장하면 메모가 삭제된다. */
export async function setNote(questionId: string, note: string): Promise<void> {
  await trpcVanilla.note.set.mutate({ questionId, note });
}

// ─── Bookmarks ────────────────────────────────────────────────────────────────

export async function getBookmarks(): Promise<string[]> {
  return trpcVanilla.bookmark.list.query();
}

export async function toggleBookmark(questionId: string): Promise<boolean> {
  const { bookmarked } = await trpcVanilla.bookmark.toggle.mutate({ questionId });
  return bookmarked;
}

// ─── Settings ─────────────────────────────────────────────────────────────────

export async function getExamDate(): Promise<string | null> {
  const { examDate } = await trpcVanilla.settings.get.query();
  return examDate;
}

export async function setExamDate(examDate: string | null): Promise<void> {
  await trpcVanilla.settings.setExamDate.mutate({ examDate });
}

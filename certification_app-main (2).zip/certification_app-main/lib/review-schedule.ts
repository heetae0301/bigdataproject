import { addDays, kstDateStr } from "@/lib/kst-date";

/**
 * 오답노트 반복 학습(간격 반복) 규칙.
 *
 * - 틀리면 오답노트에 들어가고(또는 진도가 0으로 리셋되고) 1일 뒤 복습 대상이 된다.
 * - 복습일 이후에 맞히면 한 단계 올라간다: 1번째 → 3일 뒤, 2번째 → 7일 뒤 다시 출제.
 * - 복습일에 3번 연속 맞히면 오답노트에서 "졸업"(삭제)한다.
 * - 복습일 전에 맞힌 건 우연히 맞혔을 수도 있으니 진도에 반영하지 않는다.
 *
 * 복습일은 한국 시간 자정 기준이라, 밤 11시에 틀린 문제도 다음 날 아침에 바로 복습할 수 있다.
 */
export const WRONG_GRADUATE_STREAK = 3;
/** index = 현재 correctStreak. 틀린 직후(0) 1일, 1번 맞힌 뒤 3일, 2번 맞힌 뒤 7일. */
export const REVIEW_INTERVAL_DAYS = [1, 3, 7] as const;

export interface ReviewState {
  correctStreak: number;
  nextReviewAt: number;
}

export type ReviewStatus =
  | "added" // 새로 오답노트에 추가됨
  | "reset" // 이미 있던 오답을 또 틀려서 진도 리셋
  | "advanced" // 복습일에 맞혀서 한 단계 올라감
  | "graduated" // 복습 완료, 오답노트에서 빠짐
  | "not_due" // 오답노트에 있지만 아직 복습일이 아님 (진도 변화 없음)
  | "none"; // 오답노트와 무관 (처음부터 맞힘)

export type ReviewUpdate =
  | { kind: "upsert"; status: "added" | "reset" | "advanced"; state: ReviewState }
  | { kind: "delete"; status: "graduated" }
  | { kind: "none"; status: "not_due" | "none" };

/** now 기준 KST로 N일 뒤 자정의 epoch ms */
export function kstMidnightAfterDays(now: number, days: number): number {
  const date = addDays(kstDateStr(new Date(now)), days);
  return Date.parse(`${date}T00:00:00+09:00`);
}

export function applyReview(
  existing: ReviewState | null,
  isCorrect: boolean,
  now: number
): ReviewUpdate {
  if (!isCorrect) {
    return {
      kind: "upsert",
      status: existing ? "reset" : "added",
      state: { correctStreak: 0, nextReviewAt: kstMidnightAfterDays(now, REVIEW_INTERVAL_DAYS[0]) },
    };
  }
  if (!existing) return { kind: "none", status: "none" };
  if (now < existing.nextReviewAt) return { kind: "none", status: "not_due" };

  const correctStreak = existing.correctStreak + 1;
  if (correctStreak >= WRONG_GRADUATE_STREAK) return { kind: "delete", status: "graduated" };
  return {
    kind: "upsert",
    status: "advanced",
    state: {
      correctStreak,
      nextReviewAt: kstMidnightAfterDays(now, REVIEW_INTERVAL_DAYS[correctStreak]),
    },
  };
}

export function isDueForReview(state: ReviewState, now: number = Date.now()): boolean {
  return now >= state.nextReviewAt;
}

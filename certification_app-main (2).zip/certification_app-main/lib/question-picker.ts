import type { Question } from "@/data/questions";

/** 문제 하나에 대한 누적 풀이 기록 (server progress.getQuestionProgress) */
export interface QuestionProgress {
  questionId: string;
  attempts: number;
  correct: number;
  lastCorrect: boolean;
  lastAt: number;
}

export function shuffle<T>(items: readonly T[]): T[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * 약점 집중 풀기용: 한 번이라도 틀린 문제 중에서, 마지막에 틀린 문제 → 오답 비율이
 * 높은 문제 → 많이 틀린 문제 순으로 뽑는다. 틀린 적이 없으면 빈 배열.
 */
export function pickWeakQuestions(
  pool: readonly Question[],
  count: number,
  progress: readonly QuestionProgress[]
): Question[] {
  const byId = new Map(progress.map((p) => [p.questionId, p]));
  const weak = shuffle(pool)
    .map((q) => ({ q, p: byId.get(q.id) }))
    .filter((x): x is { q: Question; p: QuestionProgress } => !!x.p && x.p.attempts > x.p.correct)
    .sort((a, b) => {
      if (a.p.lastCorrect !== b.p.lastCorrect) return a.p.lastCorrect ? 1 : -1;
      const wrongA = a.p.attempts - a.p.correct;
      const wrongB = b.p.attempts - b.p.correct;
      return wrongB / b.p.attempts - wrongA / a.p.attempts || wrongB - wrongA;
    });
  return shuffle(weak.slice(0, count).map((x) => x.q));
}

/**
 * 안 푼 문제 → 마지막에 틀린 문제 → 맞힌 문제(오래전에 푼 순) 순서로 우선 출제한다.
 * 뽑은 뒤에는 순서를 섞어서, 세션 안에서 우선순위가 티 나지 않게 한다.
 */
export function pickQuestions(
  pool: readonly Question[],
  count: number,
  progress: readonly QuestionProgress[]
): Question[] {
  const byId = new Map(progress.map((p) => [p.questionId, p]));
  const unseen: Question[] = [];
  const weak: Question[] = [];
  const solved: Question[] = [];

  for (const q of pool) {
    const p = byId.get(q.id);
    if (!p) unseen.push(q);
    else if (!p.lastCorrect) weak.push(q);
    else solved.push(q);
  }

  const solvedOldestFirst = shuffle(solved).sort(
    (a, b) => byId.get(a.id)!.lastAt - byId.get(b.id)!.lastAt
  );
  const ordered = [...shuffle(unseen), ...shuffle(weak), ...solvedOldestFirst];
  return shuffle(ordered.slice(0, Math.min(count, ordered.length)));
}

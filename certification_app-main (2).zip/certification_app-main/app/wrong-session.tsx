import React, { useEffect, useState } from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { allQuestions } from "@/data/questions";
import { matchesSource, QuestionSource } from "@/data/past-exams";
import { getWrongAnswers } from "@/lib/storage";
import { isDueForReview } from "@/lib/review-schedule";
import { shuffle } from "@/lib/question-picker";

const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/**
 * 오답 복습: 오답노트에서 조건(과목·일반/기출·오늘 복습)에 맞는 오답을 골라
 * 문제 풀이 화면(quiz-session, "오답복습" 모드)으로 넘긴다. 풀이 화면과 결과 화면은 일반 풀이와 같다.
 */
export default function WrongSessionScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const { filter, mode, source } = useLocalSearchParams<{
    filter: string;
    mode?: "due" | "all";
    source?: QuestionSource;
  }>();
  const [empty, setEmpty] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const wrongAnswers = (await getWrongAnswers().catch(() => [])).filter((w) =>
        matchesSource(w.questionId, source ?? "전체")
      );
      const bySubject =
        !filter || filter === "오답_전체" ? wrongAnswers : wrongAnswers.filter((w) => w.subject === filter);
      // "오늘 복습"으로 들어오면 복습일이 된 오답만 낸다.
      const now = Date.now();
      const picked = mode === "due" ? bySubject.filter((w) => isDueForReview(w, now)) : bySubject;
      const known = new Set(allQuestions.map((q) => q.id));
      const ids = shuffle(picked.map((w) => w.questionId).filter((id) => known.has(id)));
      if (cancelled) return;
      if (ids.length === 0) {
        setEmpty(true);
        return;
      }
      router.replace({ pathname: "/quiz-session", params: { subject: "오답복습", ids: ids.join(",") } });
    })();
    return () => {
      cancelled = true;
    };
  }, [filter, mode, source, router]);

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.center}>
        {empty ? (
          <>
            <Image source={CHARACTER_SOURCE} style={styles.character} contentFit="contain" />
            <Text style={[styles.title, { color: colors.foreground }]}>복습할 오답이 없어요!</Text>
            <Text style={[styles.desc, { color: colors.muted }]}>
              {mode === "due" ? "오늘 복습할 문제는 다 끝냈어요" : "틀린 문제가 생기면 여기서 다시 풀 수 있어요"}
            </Text>
            <Pressable
              style={({ pressed }) => [styles.btn, { backgroundColor: colors.primary }, pressed && { opacity: 0.85 }]}
              onPress={() => router.back()}
            >
              <Text style={styles.btnText}>돌아가기</Text>
            </Pressable>
          </>
        ) : (
          <Text style={[styles.desc, { color: colors.muted }]}>오답을 불러오는 중...</Text>
        )}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14, padding: 24 },
  character: { width: 110, height: 110 },
  title: { fontSize: 20, fontWeight: "800" },
  desc: { fontSize: 14, textAlign: "center", lineHeight: 22 },
  btn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  btnText: { color: "#FFFFFF", fontWeight: "700", fontSize: 15 },
});

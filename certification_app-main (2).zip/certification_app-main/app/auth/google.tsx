import { Redirect } from "expo-router";

/**
 * Google 로그인이 끝나고 서버가 앱으로 돌려보내는 주소(.../auth/google?code=...).
 * 실제 처리는 로그인 화면의 openAuthSessionAsync가 하고, 안드로이드에서 이 링크가
 * 라우터로도 들어오는 경우 "없는 화면"이 뜨지 않게 홈으로 넘긴다(로그인 전이면 AuthGate가 로그인 화면으로 보낸다).
 */
export default function GoogleAuthReturn() {
  return <Redirect href="/" />;
}

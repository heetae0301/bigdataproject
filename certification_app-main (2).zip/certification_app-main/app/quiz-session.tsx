import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Animated,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BookmarkButton } from "@/components/bookmark-button";
import { DonguraeExplainButton } from "@/components/dongurae-explain-button";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useBookmarks } from "@/hooks/use-bookmarks";
import {
  allQuestions,
  getQuestionsBySubject,
  questions as baseQuestions,
  Question,
  Subject,
  SUBJECTS,
  SUBJECT_COLORS,
} from "@/data/questions";
import { PAST_EXAM_GROUPS, PastExamGroupKey } from "@/data/past-exams";
import { pickQuestions, pickWeakQuestions, shuffle } from "@/lib/question-picker";
import { getBookmarks, getQuestionProgress, submitAnswer } from "@/lib/storage";
import { useNotes } from "@/hooks/use-notes";
import { QuestionNote } from "@/components/question-note";
import { QuestionImage } from "@/components/question-image";
import { useTextScale } from "@/lib/app-settings";

const DEFAULT_QUIZ_COUNT = 10;
const SUBJECT_3_QUIZ_COUNT = 30;
const BOOKMARK_QUIZ_MAX = 30;
// 문제 수가 이보다 많으면(기출 50문제 등) 칸이 너무 얇아져서 칸 대신 막대 하나로 진행률을 보여준다
const MAX_PROGRESS_SEGMENTS = 30;
const PASS_RATE = 60;
const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/**
 * "북마크"는 북마크한 문제만, "약점"은 틀렸던 문제만 모아서 푸는 모드.
 * "44회" 등 기출 회차는 그 회차 문제 전부를 원래 번호 순서대로 출제한다.
 * "다시"는 결과 화면의 "틀린 문제 바로 복습", "오답복습"은 오답노트의 복습(wrong-session)으로,
 * 둘 다 ids 파라미터의 문제만 그 순서대로 푼다.
 */
type SessionKey = Subject | "전체" | "북마크" | "약점" | "다시" | "오답복습" | PastExamGroupKey;

const SESSION_LABELS: Partial<Record<SessionKey, string>> = {
  북마크: "북마크한 문제",
  약점: "약점 집중 풀기",
  다시: "틀린 문제 다시 풀기",
  오답복습: "오답 복습",
};

const EMPTY_MESSAGES: Partial<Record<SessionKey, { title: string; desc: string }>> = {
  북마크: {
    title: "북마크한 문제가 없어요",
    desc: "문제를 풀 때 오른쪽 위 북마크 버튼을 눌러 헷갈리는 문제를 모아보세요",
  },
  약점: {
    title: "아직 틀린 문제가 없어요",
    desc: "문제를 풀다가 틀리면, 자주 틀리는 문제만 여기서 모아 풀 수 있어요",
  },
};

function isPastExamGroupKey(key: SessionKey): key is PastExamGroupKey {
  return PAST_EXAM_GROUPS.some((g) => g.key === key);
}

function getQuizCount(subject: SessionKey): number {
  if (subject === "북마크") return BOOKMARK_QUIZ_MAX;
  return subject === "3과목(데이터 분석)" ? SUBJECT_3_QUIZ_COUNT : DEFAULT_QUIZ_COUNT;
}

async function loadSessionQuestions(key: SessionKey, ids: string[]): Promise<Question[]> {
  if (key === "다시" || key === "오답복습") {
    const byId = new Map(allQuestions.map((q) => [q.id, q]));
    return ids.map((id) => byId.get(id)).filter((q): q is Question => !!q);
  }
  if (isPastExamGroupKey(key)) {
    return [...PAST_EXAM_GROUPS.find((g) => g.key === key)!.questions];
  }
  const count = getQuizCount(key);
  if (key === "북마크") {
    const bookmarked = new Set(await getBookmarks());
    return shuffle(allQuestions.filter((q) => bookmarked.has(q.id))).slice(0, count);
  }
  // 풀이 기록을 못 불러오면(네트워크 등) 그냥 무작위로 출제한다.
  const progress = await getQuestionProgress().catch(() => []);
  if (key === "약점") {
    return pickWeakQuestions(baseQuestions, count, progress);
  }
  return pickQuestions(getQuestionsBySubject(key), count, progress);
}

// "1과목(데이터 이해)" → "1과목 · 데이터 이해"
function displayLabel(label: string): string {
  return label.replace(/\((.*)\)$/, " · $1");
}

type Phase = "quiz" | "result";

export default function QuizSessionScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const { subject, ids } = useLocalSearchParams<{ subject: string; ids?: string }>();
  const bookmarks = useBookmarks();
  const notes = useNotes();
  const ts = useTextScale();

  const subjectKey = (subject ?? "전체") as SessionKey;
  const idsParam = ids ?? "";
  const sessionLabel = displayLabel(
    isPastExamGroupKey(subjectKey) ? `제${subjectKey} 기출` : SESSION_LABELS[subjectKey] ?? subjectKey
  );
  const emptyMessage = EMPTY_MESSAGES[subjectKey] ?? {
    title: "풀 문제가 없어요",
    desc: "다른 과목이나 전체 랜덤으로 풀어보세요",
  };
  const [questions, setQuestions] = useState<Question[] | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  // 고르기만 한 보기 (아직 채점 전). "정답 확인"을 눌러야 selectedOption으로 확정된다.
  const [pendingOption, setPendingOption] = useState<number | null>(null);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [phase, setPhase] = useState<Phase>("quiz");
  const [fadeAnim] = useState(() => new Animated.Value(1));
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    let cancelled = false;
    loadSessionQuestions(subjectKey, idsParam ? idsParam.split(",") : []).then((qs) => {
      if (cancelled) return;
      setQuestions(qs);
      setAnswers(Array(qs.length).fill(null));
    });
    return () => {
      cancelled = true;
    };
  }, [subjectKey, idsParam]);

  const sessionQuestions = questions ?? [];
  const currentQ = sessionQuestions[currentIndex];
  const isAnswered = selectedOption !== null;
  const isCorrect = selectedOption === currentQ?.answer;
  const isLast = currentIndex + 1 >= sessionQuestions.length;

  const handleConfirm = useCallback(async () => {
    if (isAnswered || pendingOption === null || !currentQ) return;
    const optionIndex = pendingOption;
    setSelectedOption(optionIndex);

    if (Platform.OS !== "web") {
      Haptics.notificationAsync(
        optionIndex === currentQ.answer
          ? Haptics.NotificationFeedbackType.Success
          : Haptics.NotificationFeedbackType.Error
      );
    }

    setAnswers((prev) => {
      const next = [...prev];
      next[currentIndex] = optionIndex;
      return next;
    });

    try {
      await submitAnswer(currentQ.id, optionIndex);
    } catch (error) {
      console.warn("[Quiz] Failed to save answer:", error);
    }
  }, [isAnswered, pendingOption, currentIndex, currentQ]);

  const handleNext = useCallback(() => {
    if (currentIndex + 1 >= sessionQuestions.length) {
      setPhase("result");
      return;
    }
    Animated.sequence([
      Animated.timing(fadeAnim, { toValue: 0, duration: 120, useNativeDriver: true }),
      Animated.timing(fadeAnim, { toValue: 1, duration: 180, useNativeDriver: true }),
    ]).start();
    setCurrentIndex((prev) => prev + 1);
    setPendingOption(null);
    setSelectedOption(null);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  }, [currentIndex, sessionQuestions.length, fadeAnim]);

  const handleRestart = useCallback(() => {
    router.replace({
      pathname: "/quiz-session",
      params: idsParam ? { subject: subjectKey, ids: idsParam } : { subject: subjectKey },
    });
  }, [router, subjectKey, idsParam]);

  if (questions === null || questions.length === 0) {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.center}>
          {questions === null ? (
            <Text style={[styles.centerDesc, { color: colors.muted }]}>문제를 준비하는 중...</Text>
          ) : (
            <>
              <Image source={CHARACTER_SOURCE} style={styles.emptyCharacter} contentFit="contain" />
              <Text style={[styles.centerTitle, { color: colors.foreground }]}>
                {emptyMessage.title}
              </Text>
              <Text style={[styles.centerDesc, { color: colors.muted }]}>
                {emptyMessage.desc}
              </Text>
              <Pressable
                style={({ pressed }) => [
                  styles.centerBtn,
                  { backgroundColor: colors.primary },
                  pressed && { opacity: 0.85 },
                ]}
                onPress={() => router.back()}
              >
                <Text style={styles.centerBtnText}>돌아가기</Text>
              </Pressable>
            </>
          )}
        </View>
      </ScreenContainer>
    );
  }

  if (phase === "result") {
    const answeredItems = questions
      .map((q, i) => ({ q, number: i + 1, answer: answers[i] }))
      .filter((x): x is ResultItem => x.answer !== null);
    const wrongItems = answeredItems.filter((x) => x.answer !== x.q.answer);
    return (
      <ResultScreen
        correctCount={answers.filter((a, i) => a !== null && a === questions[i].answer).length}
        total={questions.length}
        subject={sessionLabel}
        items={answeredItems}
        isBookmarked={bookmarks.isBookmarked}
        onToggleBookmark={bookmarks.toggle}
        onReviewWrong={() =>
          router.replace({
            pathname: "/quiz-session",
            params: { subject: "다시", ids: wrongItems.map((x) => x.q.id).join(",") },
          })
        }
        onRestart={handleRestart}
        onHome={() => router.replace("/")}
      />
    );
  }

  const answeredCount = currentIndex + (isAnswered ? 1 : 0);
  const useSegments = questions.length <= MAX_PROGRESS_SEGMENTS;
  const isMixedSession = !(SUBJECTS as string[]).includes(subjectKey) && !isPastExamGroupKey(subjectKey);

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]} {...swipeBackHandlers}>
      {/* Top Bar: 나가기 / 과목·진행 / 북마크 */}
      <View style={styles.topBar}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="풀이 나가기"
          style={({ pressed }) => [styles.iconBtn, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="xmark" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCenter}>
          <View style={styles.topRow}>
            <Text style={[styles.topSubject, { color: colors.primary }]} numberOfLines={1}>
              {sessionLabel}
            </Text>
            <Text style={[styles.topProgress, { color: colors.muted }]}>
              <Text style={{ color: colors.foreground, fontWeight: "800" }}>{currentIndex + 1}</Text> / {questions.length}
            </Text>
          </View>
          {useSegments ? (
            <View style={styles.segments}>
              {questions.map((q, i) => {
                const a = answers[i];
                const color =
                  a !== null
                    ? a === q.answer
                      ? colors.success
                      : colors.highlight
                    : i === currentIndex
                      ? colors.primary
                      : colors.border;
                return <View key={q.id + i} style={[styles.segment, { backgroundColor: color }]} />;
              })}
            </View>
          ) : (
            <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
              <View
                style={[
                  styles.progressFill,
                  { backgroundColor: colors.primary, width: `${(answeredCount / questions.length) * 100}%` },
                ]}
              />
            </View>
          )}
        </View>
        <BookmarkButton
          bookmarked={bookmarks.isBookmarked(currentQ.id)}
          onPress={() => bookmarks.toggle(currentQ.id)}
        />
      </View>

      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* Question */}
          <View style={styles.questionBlock}>
            <View style={styles.chipRow}>
              <View style={[styles.qChip, { backgroundColor: colors.primary + "1F" }]}>
                <Text style={[styles.qChipText, { color: colors.primary }]}>Q{currentIndex + 1}</Text>
              </View>
              {/* 여러 과목이 섞이는 세션(전체·약점·북마크·복습)에서는 문제마다 과목을 보여준다 */}
              {isMixedSession && SUBJECT_COLORS[currentQ.subject] && (
                <View style={[styles.qChip, { backgroundColor: SUBJECT_COLORS[currentQ.subject] + "1F" }]}>
                  <Text style={[styles.qChipText, { color: SUBJECT_COLORS[currentQ.subject] }]}>
                    {currentQ.subject.replace(/\(.*\)$/, "")}
                  </Text>
                </View>
              )}
            </View>
            <Text style={[styles.questionText, ts(18, 29), { color: colors.foreground }]}>
              {currentQ.question}
            </Text>
            <QuestionImage imageKey={currentQ.image} />
          </View>

          {/* Options */}
          <View style={styles.optionsContainer}>
            {currentQ.options.map((option, idx) => {
              const isCorrectOption = idx === currentQ.answer;
              const isMine = selectedOption === idx;
              const isPending = !isAnswered && pendingOption === idx;
              let bg = colors.surface;
              let border = colors.border;
              let text = colors.foreground;
              let badgeBg = colors.background;
              let badgeText = colors.foreground;
              let tag: string | null = null;

              if (isAnswered) {
                if (isCorrectOption) {
                  bg = colors.success + "14";
                  border = colors.success;
                  text = colors.success;
                  badgeBg = colors.success;
                  badgeText = "#FFFFFF";
                  tag = "정답";
                } else if (isMine) {
                  bg = colors.highlight + "14";
                  border = colors.highlight;
                  text = colors.highlight;
                  badgeBg = colors.highlight;
                  badgeText = "#FFFFFF";
                  tag = "내 답";
                } else {
                  text = colors.muted;
                  badgeText = colors.muted;
                }
              } else if (isPending) {
                bg = colors.primary + "12";
                border = colors.primary;
                badgeBg = colors.primary;
                badgeText = "#FFFFFF";
              }

              return (
                <Pressable
                  key={idx}
                  accessibilityRole="radio"
                  aria-checked={isPending || isMine}
                  aria-disabled={isAnswered}
                  style={({ pressed }) => [
                    styles.optionBtn,
                    { backgroundColor: bg, borderColor: border },
                    pressed && !isAnswered && { opacity: 0.75 },
                  ]}
                  onPress={() => setPendingOption(idx)}
                  disabled={isAnswered}
                >
                  <View style={[styles.optionBadge, { backgroundColor: badgeBg }]}>
                    {isAnswered && (isCorrectOption || isMine) ? (
                      <IconSymbol name={isCorrectOption ? "checkmark" : "xmark"} size={16} color="#FFFFFF" />
                    ) : (
                      <Text style={[styles.optionBadgeText, { color: badgeText }]}>{idx + 1}</Text>
                    )}
                  </View>
                  <Text style={[styles.optionText, ts(15, 23), { color: text }]}>{option}</Text>
                  {tag && <Text style={[styles.optionTag, { color: text }]}>{tag}</Text>}
                </Pressable>
              );
            })}
          </View>

          {/* Feedback: 결과 한 줄 + 해설 + 동그래 해설 + 메모 */}
          {isAnswered && (
            <View style={[styles.feedbackCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <View style={styles.feedbackHeader}>
                <Text style={[styles.feedbackTitle, { color: isCorrect ? colors.success : colors.highlight }]}>
                  {isCorrect ? "정답이에요!" : "아쉬워요, 오답이에요"}
                </Text>
                {!isCorrect && (
                  <Text style={[styles.feedbackSub, { color: colors.muted }]}>· 오답노트에 저장됨</Text>
                )}
              </View>
              <Text style={[styles.explanationText, ts(14, 23), { color: colors.foreground }]}>
                {currentQ.explanation}
              </Text>
              <DonguraeExplainButton key={currentQ.id} question={currentQ} selectedOption={selectedOption} />
              <QuestionNote
                key={`note-${currentQ.id}`}
                collapsible
                note={notes.get(currentQ.id)}
                onSave={(note) => notes.save(currentQ.id, note)}
              />
            </View>
          )}
        </Animated.View>
      </ScrollView>

      {/* 하단 고정 버튼: 정답 확인 → 다음 문제 / 결과 보기 */}
      <View style={[styles.bottomBar, { backgroundColor: colors.background, borderTopColor: colors.border }]}>
        {isAnswered ? (
          <Pressable
            style={({ pressed }) => [styles.mainBtn, { backgroundColor: colors.primary }, pressed && { opacity: 0.85 }]}
            onPress={handleNext}
          >
            <Text style={styles.mainBtnText}>{isLast ? "결과 보기" : "다음 문제"}</Text>
            <IconSymbol name={isLast ? "flag.checkered" : "arrow.right"} size={18} color="#FFFFFF" />
          </Pressable>
        ) : (
          <Pressable
            style={({ pressed }) => [
              styles.mainBtn,
              { backgroundColor: colors.primary },
              pendingOption === null && { opacity: 0.4 },
              pressed && pendingOption !== null && { opacity: 0.85 },
            ]}
            onPress={handleConfirm}
            disabled={pendingOption === null}
          >
            <Text style={styles.mainBtnText}>정답 확인</Text>
          </Pressable>
        )}
      </View>
    </ScreenContainer>
  );
}

// ─── Result Screen ────────────────────────────────────────────────────────────

type ResultItem = { q: Question; number: number; answer: number };

function ResultScreen({
  correctCount,
  total,
  subject,
  items,
  isBookmarked,
  onToggleBookmark,
  onReviewWrong,
  onRestart,
  onHome,
}: {
  correctCount: number;
  total: number;
  subject: string;
  /** 이번에 답한 문제 전부 (맞힌 것 포함) */
  items: ResultItem[];
  isBookmarked: (id: string) => boolean;
  onToggleBookmark: (id: string) => void;
  onReviewWrong: () => void;
  onRestart: () => void;
  onHome: () => void;
}) {
  const colors = useColors();
  const ts = useTextScale();
  const swipeBackHandlers = useSwipeBack();
  const rate = Math.round((correctCount / total) * 100);
  const isPassed = rate >= PASS_RATE;
  const wrongItems = items.filter((x) => x.answer !== x.q.answer);
  const wrongCount = wrongItems.length;
  // 기본은 틀린 문제만. 다 맞혔으면 볼 게 전체뿐이다.
  const [listMode, setListMode] = useState<"wrong" | "all">(wrongCount > 0 ? "wrong" : "all");
  const [openId, setOpenId] = useState<string | null>(null);
  const listItems = listMode === "wrong" ? wrongItems : items;
  const bubble =
    wrongCount === 0
      ? "전부 맞혔어!\n정말 대단해!"
      : isPassed
        ? `틀린 ${wrongCount}문제만\n다시 보면 완벽해!`
        : "괜찮아, 틀린 문제를\n같이 다시 보자!";

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <ScrollView contentContainerStyle={styles.resultContent} showsVerticalScrollIndicator={false}>
        <Text style={[styles.resultSubject, { color: colors.muted }]}>{subject} 풀이 완료</Text>

        <View style={[styles.resultHero, { backgroundColor: colors.primary }]}>
          <View style={styles.resultHeroCircle} />
          <Image source={CHARACTER_SOURCE} style={styles.resultCharacter} contentFit="contain" accessibilityLabel="동그래" />
          <View style={styles.resultHeroText}>
            <Text style={styles.resultLabel}>이번 점수</Text>
            <Text style={styles.resultScore}>
              {rate}
              <Text style={styles.resultScoreUnit}>점</Text>
            </Text>
            <View style={styles.passBadge}>
              <Text style={[styles.passBadgeText, { color: isPassed ? colors.success : colors.highlight }]}>
                {isPassed ? `합격선(${PASS_RATE}점) 넘었어요` : `합격선까지 ${PASS_RATE - rate}점`}
              </Text>
            </View>
            <View style={styles.bubble}>
              <Text style={styles.bubbleText}>{bubble}</Text>
            </View>
          </View>
        </View>

        <View style={styles.resultStats}>
          <View style={[styles.resultStat, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultStatValue, { color: colors.success }]}>{correctCount}</Text>
            <Text style={[styles.resultStatLabel, { color: colors.muted }]}>맞힌 문제</Text>
          </View>
          <View style={[styles.resultStat, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultStatValue, { color: colors.highlight }]}>{wrongCount}</Text>
            <Text style={[styles.resultStatLabel, { color: colors.muted }]}>틀린 문제</Text>
          </View>
          <View style={[styles.resultStat, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultStatValue, { color: colors.foreground }]}>{total}</Text>
            <Text style={[styles.resultStatLabel, { color: colors.muted }]}>푼 문제</Text>
          </View>
        </View>

        {items.length > 0 && (
          <View style={[styles.wrongList, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.listHeader}>
              <Text style={[styles.wrongListTitle, { color: colors.muted }]}>문제 다시 보기</Text>
              <View style={[styles.listToggle, { backgroundColor: colors.background, borderColor: colors.border }]}>
                {(
                  [
                    ["wrong", `틀린 문제 ${wrongCount}`],
                    ["all", `전체 ${items.length}`],
                  ] as const
                ).map(([mode, label]) => {
                  const active = listMode === mode;
                  return (
                    <Pressable
                      key={mode}
                      accessibilityRole="radio"
                      aria-checked={active}
                      onPress={() => {
                        setListMode(mode);
                        setOpenId(null);
                      }}
                      style={[styles.listToggleBtn, active && { backgroundColor: colors.primary }]}
                    >
                      <Text style={[styles.listToggleText, { color: active ? "#FFFFFF" : colors.muted }]}>{label}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
            {listItems.length === 0 ? (
              <Text style={[styles.listEmpty, { color: colors.muted }]}>틀린 문제가 없어요. 전체에서 다시 볼 수 있어요.</Text>
            ) : (
              listItems.map(({ q, number, answer }, i) => {
                const correct = answer === q.answer;
                const open = openId === q.id;
                const mark = correct ? colors.success : colors.highlight;
                return (
                  <View key={q.id} style={i > 0 && { borderTopWidth: 1, borderTopColor: colors.border }}>
                    <Pressable
                      accessibilityRole="button"
                      aria-expanded={open}
                      accessibilityLabel={`Q${number} ${correct ? "맞힌 문제" : "틀린 문제"} ${open ? "접기" : "펼치기"}`}
                      onPress={() => setOpenId(open ? null : q.id)}
                      style={({ pressed }) => [styles.wrongRow, pressed && { opacity: 0.7 }]}
                    >
                      <IconSymbol name={correct ? "checkmark" : "xmark"} size={14} color={mark} />
                      <Text style={[styles.wrongNumber, { color: mark }]}>Q{number}</Text>
                      <Text style={[styles.wrongQuestion, { color: colors.foreground }]} numberOfLines={open ? undefined : 1}>
                        {q.question}
                      </Text>
                      <View style={open ? { transform: [{ rotate: "180deg" }] } : undefined}>
                        <IconSymbol name="chevron.down" size={18} color={colors.muted} />
                      </View>
                    </Pressable>
                    {open && (
                      <View style={styles.reviewBody}>
                        {q.options.map((option, idx) => {
                          const isAnswer = idx === q.answer;
                          const isMine = idx === answer;
                          const color = isAnswer ? colors.success : isMine ? colors.highlight : colors.muted;
                          return (
                            <View key={idx} style={styles.reviewOption}>
                              <Text style={[styles.reviewOptionNo, { color }]}>{idx + 1}</Text>
                              <Text
                                style={[
                                  styles.reviewOptionText,
                                  ts(14, 21),
                                  { color: isAnswer || isMine ? colors.foreground : colors.muted },
                                ]}
                              >
                                {option}
                              </Text>
                              {(isAnswer || isMine) && (
                                <Text style={[styles.optionTag, { color }]}>
                                  {isAnswer ? (isMine ? "정답·내 답" : "정답") : "내 답"}
                                </Text>
                              )}
                            </View>
                          );
                        })}
                        <View style={[styles.reviewExplanation, { backgroundColor: colors.background }]}>
                          <Text style={[styles.explanationText, ts(14, 22), { color: colors.foreground }]}>{q.explanation}</Text>
                        </View>
                        <View style={styles.reviewActions}>
                          <View style={{ flex: 1 }}>
                            <DonguraeExplainButton question={q} selectedOption={answer} />
                          </View>
                          <BookmarkButton bookmarked={isBookmarked(q.id)} onPress={() => onToggleBookmark(q.id)} />
                        </View>
                      </View>
                    )}
                  </View>
                );
              })
            )}
          </View>
        )}

        <View style={styles.resultBtns}>
          {wrongCount > 0 && (
            <Pressable
              style={({ pressed }) => [styles.mainBtn, { backgroundColor: colors.highlight }, pressed && { opacity: 0.85 }]}
              onPress={onReviewWrong}
            >
              <Text style={styles.mainBtnText}>틀린 {wrongCount}문제 바로 복습</Text>
            </Pressable>
          )}
          <View style={styles.resultBtnRow}>
            <Pressable
              style={({ pressed }) => [
                styles.subBtn,
                { backgroundColor: colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.75 },
              ]}
              onPress={onHome}
            >
              <Text style={[styles.subBtnText, { color: colors.foreground }]}>홈으로</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [
                styles.subBtn,
                { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
                pressed && { opacity: 0.75 },
              ]}
              onPress={onRestart}
            >
              <Text style={[styles.subBtnText, { color: colors.primary }]}>다시 풀기</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    padding: 24,
  },
  emptyCharacter: { width: 110, height: 110 },
  centerTitle: { fontSize: 20, fontWeight: "800" },
  centerDesc: { fontSize: 14, textAlign: "center", lineHeight: 22 },
  centerBtn: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 8,
  },
  centerBtnText: { color: "#FFFFFF", fontWeight: "700", fontSize: 15 },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 8,
    paddingTop: 8,
    paddingBottom: 10,
    gap: 4,
  },
  iconBtn: {
    width: 44,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
  },
  topCenter: {
    flex: 1,
    gap: 6,
  },
  topRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  topSubject: {
    fontSize: 13,
    fontWeight: "800",
    flexShrink: 1,
  },
  topProgress: {
    fontSize: 13,
  },
  segments: {
    flexDirection: "row",
    gap: 3,
  },
  segment: {
    flex: 1,
    height: 6,
    borderRadius: 3,
  },
  progressBg: {
    height: 6,
    borderRadius: 3,
    overflow: "hidden",
  },
  progressFill: {
    height: 6,
    borderRadius: 3,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 24,
  },
  questionBlock: {
    paddingHorizontal: 2,
    paddingBottom: 16,
    gap: 10,
  },
  chipRow: {
    flexDirection: "row",
    gap: 6,
  },
  qChip: {
    alignSelf: "flex-start",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  qChipText: {
    fontSize: 12,
    fontWeight: "800",
  },
  questionText: {
    fontSize: 18,
    fontWeight: "700",
    lineHeight: 29,
    letterSpacing: -0.2,
  },
  optionsContainer: {
    gap: 10,
    marginBottom: 16,
  },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    minHeight: 58,
    borderRadius: 14,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 12,
  },
  optionBadge: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  optionBadgeText: {
    fontSize: 14,
    fontWeight: "800",
  },
  optionText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 23,
    fontWeight: "500",
  },
  optionTag: {
    fontSize: 12,
    fontWeight: "800",
  },
  feedbackCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  feedbackHeader: {
    flexDirection: "row",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 6,
  },
  feedbackTitle: {
    fontSize: 16,
    fontWeight: "800",
  },
  feedbackSub: {
    fontSize: 12,
  },
  explanationText: {
    fontSize: 14,
    lineHeight: 23,
  },
  bottomBar: {
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 16,
    borderTopWidth: 1,
  },
  mainBtn: {
    height: 54,
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  mainBtnText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  // Result
  resultContent: {
    padding: 20,
    paddingTop: 24,
    paddingBottom: 40,
    gap: 14,
  },
  resultSubject: {
    fontSize: 13,
    fontWeight: "600",
    textAlign: "center",
  },
  resultHero: {
    borderRadius: 22,
    padding: 20,
    minHeight: 220,
    overflow: "hidden",
  },
  resultHeroCircle: {
    position: "absolute",
    right: -30,
    bottom: -40,
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  resultCharacter: {
    position: "absolute",
    right: -6,
    bottom: -4,
    width: 150,
    height: 150,
  },
  resultHeroText: {
    width: "62%",
    gap: 8,
  },
  resultLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "rgba(255,255,255,0.85)",
  },
  resultScore: {
    fontSize: 56,
    fontWeight: "800",
    letterSpacing: -2,
    color: "#FFFFFF",
    lineHeight: 60,
  },
  resultScoreUnit: {
    fontSize: 24,
    letterSpacing: 0,
  },
  passBadge: {
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  passBadgeText: {
    fontSize: 13,
    fontWeight: "800",
  },
  bubble: {
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 9,
    marginTop: 4,
  },
  bubbleText: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "600",
    color: "#0F172A",
  },
  resultStats: {
    flexDirection: "row",
    gap: 8,
  },
  resultStat: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 12,
    alignItems: "center",
  },
  resultStatValue: {
    fontSize: 20,
    fontWeight: "800",
  },
  resultStatLabel: {
    fontSize: 12,
    marginTop: 2,
  },
  wrongList: {
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingBottom: 4,
  },
  wrongListTitle: {
    fontSize: 13,
    fontWeight: "800",
  },
  listHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
    paddingTop: 10,
    paddingBottom: 6,
  },
  listToggle: {
    flexDirection: "row",
    borderRadius: 999,
    borderWidth: 1,
    padding: 2,
  },
  listToggleBtn: {
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  listToggleText: {
    fontSize: 12,
    fontWeight: "800",
  },
  listEmpty: {
    fontSize: 13,
    paddingVertical: 14,
  },
  reviewBody: {
    gap: 8,
    paddingBottom: 14,
  },
  reviewOption: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 8,
  },
  reviewOptionNo: {
    width: 16,
    fontSize: 14,
    fontWeight: "800",
    lineHeight: 21,
  },
  reviewOptionText: {
    flex: 1,
    fontSize: 14,
    lineHeight: 21,
  },
  reviewExplanation: {
    borderRadius: 12,
    padding: 12,
    marginTop: 4,
  },
  reviewActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  wrongRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 10,
  },
  wrongNumber: {
    fontSize: 14,
    fontWeight: "800",
  },
  wrongQuestion: {
    flex: 1,
    fontSize: 14,
  },
  resultBtns: {
    gap: 10,
    marginTop: 6,
  },
  resultBtnRow: {
    flexDirection: "row",
    gap: 10,
  },
  subBtn: {
    flex: 1,
    height: 50,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  subBtnText: {
    fontSize: 15,
    fontWeight: "700",
  },
});

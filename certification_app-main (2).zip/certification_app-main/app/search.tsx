import React, { useMemo, useState } from "react";
import { View, Text, TextInput, Pressable, FlatList, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useTextScale } from "@/lib/app-settings";
import { allQuestions, Question, SUBJECT_COLORS } from "@/data/questions";

const RESULT_LIMIT = 50;

/** 문제/선택지/해설에 검색어(공백으로 나눈 단어 전부)가 들어 있는 문제를 찾는다. */
function searchQuestions(query: string): Question[] {
  const words = query.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  return allQuestions.filter((q) => {
    const text = `${q.question} ${q.options.join(" ")} ${q.explanation}`.toLowerCase();
    return words.every((w) => text.includes(w));
  });
}

export default function SearchScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const ts = useTextScale();

  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const results = useMemo(() => searchQuestions(query), [query]);
  const shown = results.slice(0, RESULT_LIMIT);

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.topBar}>
        <Pressable
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="키워드로 문제 찾기 (예: 정규화)"
            placeholderTextColor={colors.muted}
            autoFocus
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
            style={[styles.searchInput, { color: colors.foreground }]}
          />
          {query.length > 0 && (
            <Pressable style={({ pressed }) => pressed && { opacity: 0.6 }} onPress={() => setQuery("")}>
              <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
            </Pressable>
          )}
        </View>
      </View>

      {query.trim().length === 0 ? (
        <View style={styles.center}>
          <IconSymbol name="magnifyingglass" size={44} color={colors.border} />
          <Text style={[styles.centerText, { color: colors.muted }]}>
            문제, 선택지, 해설에서 찾아요.{"\n"}여러 단어를 띄어 쓰면 모두 포함된 문제만 보여줘요.
          </Text>
        </View>
      ) : results.length === 0 ? (
        <View style={styles.center}>
          <Text style={[styles.centerText, { color: colors.muted }]}>
            &quot;{query.trim()}&quot;에 해당하는 문제가 없어요
          </Text>
        </View>
      ) : (
        <FlatList
          data={shown}
          keyExtractor={(q) => q.id}
          contentContainerStyle={styles.listContent}
          keyboardShouldPersistTaps="handled"
          ListHeaderComponent={
            <Text style={[styles.countText, { color: colors.muted }]}>
              {results.length}문제 찾음
              {results.length > RESULT_LIMIT ? ` · 앞의 ${RESULT_LIMIT}개만 표시` : ""}
            </Text>
          }
          renderItem={({ item: q }) => {
            const isOpen = openId === q.id;
            const subjectColor = SUBJECT_COLORS[q.subject];
            return (
              <Pressable
                style={({ pressed }) => [
                  styles.card,
                  { backgroundColor: colors.surface, borderColor: colors.border },
                  pressed && { opacity: 0.85 },
                ]}
                onPress={() => setOpenId(isOpen ? null : q.id)}
              >
                <View style={styles.cardHeader}>
                  <View style={[styles.subjectBadge, { backgroundColor: subjectColor + "18" }]}>
                    <Text style={[styles.subjectBadgeText, { color: subjectColor }]}>{q.subject}</Text>
                  </View>
                  <Text style={[styles.toggleText, { color: colors.muted }]}>
                    {isOpen ? "접기" : "정답·해설 보기"}
                  </Text>
                </View>
                <Text
                  style={[styles.questionText, ts(14, 22), { color: colors.foreground }]}
                  numberOfLines={isOpen ? undefined : 3}
                >
                  {q.question}
                </Text>
                {isOpen && (
                  <>
                    <View style={styles.options}>
                      {q.options.map((option, idx) => {
                        const isAnswer = idx === q.answer;
                        return (
                          <Text
                            key={idx}
                            style={[
                              styles.optionText,
                              ts(13, 20),
                              { color: isAnswer ? colors.success : colors.muted },
                              isAnswer && { fontWeight: "700" },
                            ]}
                          >
                            {["①", "②", "③", "④"][idx]} {option}
                            {isAnswer ? "  ✓ 정답" : ""}
                          </Text>
                        );
                      })}
                    </View>
                    <View
                      style={[
                        styles.explanationBox,
                        { backgroundColor: colors.background, borderColor: colors.border },
                      ]}
                    >
                      <Text style={[styles.explanationLabel, { color: colors.muted }]}>해설</Text>
                      <Text style={[styles.explanationText, ts(13, 20), { color: colors.foreground }]}>
                        {q.explanation}
                      </Text>
                    </View>
                  </>
                )}
              </Pressable>
            );
          }}
        />
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  searchBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
  },
  searchInput: { flex: 1, fontSize: 15, padding: 0 },
  center: { flex: 1, alignItems: "center", justifyContent: "center", gap: 14, padding: 32 },
  centerText: { fontSize: 14, lineHeight: 22, textAlign: "center" },
  listContent: { padding: 20, paddingTop: 4, paddingBottom: 40, gap: 12 },
  countText: { fontSize: 12 },
  card: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 10 },
  cardHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  subjectBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20 },
  subjectBadgeText: { fontSize: 11, fontWeight: "700" },
  toggleText: { fontSize: 12, fontWeight: "600" },
  questionText: { fontSize: 14, fontWeight: "600", lineHeight: 22 },
  options: { gap: 6 },
  optionText: { fontSize: 13, lineHeight: 20 },
  explanationBox: { borderRadius: 10, borderWidth: 1, padding: 12, gap: 4 },
  explanationLabel: { fontSize: 11, fontWeight: "700" },
  explanationText: { fontSize: 13, lineHeight: 20 },
});

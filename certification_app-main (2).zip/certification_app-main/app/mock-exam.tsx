import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Alert,
  AppState,
  Platform,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { BookmarkButton } from "@/components/bookmark-button";
import { QuestionImage } from "@/components/question-image";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useBookmarks } from "@/hooks/use-bookmarks";
import {
  getMockExamQuestions,
  MOCK_EXAM_COUNTS,
  Question,
  allQuestions,
  SUBJECTS,
  SUBJECT_COLORS,
  type Subject,
} from "@/data/questions";
import { PAST_EXAM_GROUPS } from "@/data/past-exams";
import { scoreMockExam, subjectPassed } from "@/lib/mock-exam-scoring";
import {
  getMockExamAnswers,
  getMockExamResults,
  submitMockExam,
  MockExamRecord,
} from "@/lib/storage";
import { useTextScale } from "@/lib/app-settings";

const questionById = new Map(allQuestions.map((q) => [q.id, q]));

const EXAM_DURATION_SECONDS = 90 * 60; // 실제 ADsP 시험과 동일하게 90분

type Phase = "intro" | "exam" | "result" | "review";

function formatTime(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function MockExamScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();

  // ?round=48 이면 그 기출 회차 전체를 원래 순서대로 실전처럼 푼다. 없으면 무작위 모의고사.
  const params = useLocalSearchParams<{ round?: string }>();
  const roundGroup = params.round ? PAST_EXAM_GROUPS.find((g) => g.round === Number(params.round)) : undefined;
  const plannedCounts = roundGroup
    ? (Object.fromEntries(
        SUBJECTS.map((s) => [s, roundGroup.questions.filter((q) => q.subject === s).length])
      ) as Record<Subject, number>)
    : MOCK_EXAM_COUNTS;
  const plannedTotal = SUBJECTS.reduce((sum, s) => sum + plannedCounts[s], 0);
  const examTitle = roundGroup ? `제${roundGroup.round}회 실전 응시` : "실전 모의고사";

  const [phase, setPhase] = useState<Phase>("intro");
  const [examQuestions, setExamQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [timeLeft, setTimeLeft] = useState(EXAM_DURATION_SECONDS);
  const [submitting, setSubmitting] = useState(false);
  const [history, setHistory] = useState<MockExamRecord[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startedAtRef = useRef(0);
  const deadlineRef = useRef(0);
  const autoSubmittedRef = useRef(false);
  const bookmarks = useBookmarks();
  const ts = useTextScale();
  // 지난 회차를 다시 보는 중이면 그 기록 (새로 응시한 결과를 보는 중이면 null)
  const [pastRecord, setPastRecord] = useState<MockExamRecord | null>(null);

  useEffect(() => {
    // 무작위 모의고사 화면에는 무작위 기록만, 회차 화면에는 그 회차 기록만 보여준다.
    getMockExamResults(5, roundGroup ? roundGroup.round : null)
      .then(setHistory)
      .catch(() => {});
  }, [roundGroup]);

  const openPastRecord = useCallback(async (record: MockExamRecord) => {
    try {
      const saved = await getMockExamAnswers(record.id);
      // 문제은행에서 빠진 문제는 건너뛴다.
      const items = saved.flatMap((a) => {
        const question = questionById.get(a.questionId);
        return question ? [{ question, selected: a.selectedOption }] : [];
      });
      setExamQuestions(items.map((i) => i.question));
      setAnswers(items.map((i) => i.selected));
      setCurrentIndex(0);
      setPastRecord(record);
      setPhase("result");
    } catch (error) {
      console.warn("[MockExam] Failed to load past record:", error);
      Alert.alert("불러오지 못했어요", "잠시 후 다시 시도해주세요.");
    }
  }, []);

  const stopTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const submitExam = useCallback(async () => {
    stopTimer();
    setSubmitting(true);
    try {
      const durationSeconds = Math.min(
        EXAM_DURATION_SECONDS,
        Math.round((Date.now() - startedAtRef.current) / 1000)
      );
      await submitMockExam(
        examQuestions.map((q, i) => ({ questionId: q.id, selectedOption: answers[i] })),
        durationSeconds,
        roundGroup?.round
      );
    } catch (error) {
      console.warn("[MockExam] Failed to save result:", error);
    } finally {
      setSubmitting(false);
      setPhase("result");
    }
  }, [examQuestions, answers, stopTimer, roundGroup]);

  // 남은 시간은 매번 "마감 시각 - 지금"으로 계산한다. 1초마다 1씩 빼면 앱이 백그라운드에
  // 있거나 화면이 꺼진 동안 타이머가 멈춰서 90분 제한이 지켜지지 않는다.
  useEffect(() => {
    if (phase !== "exam") return;
    const tick = () => {
      const left = Math.max(0, Math.ceil((deadlineRef.current - Date.now()) / 1000));
      setTimeLeft(left);
      if (left === 0 && !autoSubmittedRef.current) {
        autoSubmittedRef.current = true;
        stopTimer();
        submitExam();
      }
    };
    tick();
    timerRef.current = setInterval(tick, 1000);
    // 앱으로 돌아오는 순간 바로 다시 계산 (그 사이 시간이 다 지났으면 자동 제출)
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active") tick();
    });
    return () => {
      stopTimer();
      sub.remove();
    };
  }, [phase, submitExam, stopTimer]);

  const handleStart = useCallback(() => {
    const qs = roundGroup ? [...roundGroup.questions] : getMockExamQuestions();
    setExamQuestions(qs);
    setAnswers(Array(qs.length).fill(null));
    setCurrentIndex(0);
    setTimeLeft(EXAM_DURATION_SECONDS);
    startedAtRef.current = Date.now();
    deadlineRef.current = startedAtRef.current + EXAM_DURATION_SECONDS * 1000;
    autoSubmittedRef.current = false;
    setPhase("exam");
  }, [roundGroup]);

  const handleSelect = useCallback(
    (optionIndex: number) => {
      if (Platform.OS !== "web") {
        Haptics.selectionAsync();
      }
      setAnswers((prev) => {
        const next = [...prev];
        next[currentIndex] = optionIndex;
        return next;
      });
    },
    [currentIndex]
  );

  // Alert.alert는 웹에서 no-op이라 버튼이 안 눌리는 것처럼 보이므로 ConfirmDialog로 확인한다.
  const [confirming, setConfirming] = useState<"submit" | "exit" | null>(null);
  const handleSubmitPress = useCallback(() => setConfirming("submit"), []);
  const handleExit = useCallback(() => setConfirming("exit"), []);
  const unansweredCount = answers.filter((a) => a === null).length;

  // ─── Intro ──────────────────────────────────────────────────────────────
  if (phase === "intro") {
    return (
      <ScreenContainer {...swipeBackHandlers}>
        <View style={styles.topBar}>
          <Pressable
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
            onPress={() => router.back()}
          >
            <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
          </Pressable>
        </View>
        <ScrollView contentContainerStyle={styles.introContent} showsVerticalScrollIndicator={false}>
          <View style={[styles.introIconWrap, { backgroundColor: colors.primary + "18" }]}>
            <IconSymbol name="clock.fill" size={40} color={colors.primary} />
          </View>
          <Text style={[styles.introTitle, { color: colors.foreground }]}>{examTitle}</Text>
          <Text style={[styles.introDesc, { color: colors.muted }]}>
            {roundGroup
              ? `${roundGroup.year}년 제${roundGroup.round}회 기출을 실제 시험처럼 풉니다`
              : "실제 ADsP 시험과 동일한 구성으로 응시합니다"}
          </Text>

          <View style={[styles.introCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {SUBJECTS.map((subject) => (
              <View key={subject} style={styles.introRow}>
                <View style={styles.introRowLeft}>
                  <View style={[styles.subjectDot, { backgroundColor: SUBJECT_COLORS[subject] }]} />
                  <Text style={[styles.introRowLabel, { color: colors.foreground }]}>{subject}</Text>
                </View>
                <Text style={[styles.introRowValue, { color: colors.muted }]}>
                  {plannedCounts[subject]}문항
                </Text>
              </View>
            ))}
            <View style={[styles.introDivider, { backgroundColor: colors.border }]} />
            <View style={styles.introRow}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                총 문항수
              </Text>
              <Text style={[styles.introRowValue, { color: colors.foreground, fontWeight: "700" }]}>
                {plannedTotal}문항
              </Text>
            </View>
            <View style={styles.introRow}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                제한 시간
              </Text>
              <Text style={[styles.introRowValue, { color: colors.foreground, fontWeight: "700" }]}>
                90분
              </Text>
            </View>
          </View>

          <View style={[styles.introNote, { backgroundColor: colors.primary + "10", borderColor: colors.primary + "30" }]}>
            <IconSymbol name="info.circle" size={16} color={colors.primary} />
            <Text style={[styles.introNoteText, { color: colors.primary }]}>
              {roundGroup
                ? "회차 문제를 원래 순서대로 출제합니다. 제출하기 전까지 정답은 보이지 않아요. "
                : "문제는 매번 기출 문제(44~50회)에서 무작위로 출제됩니다. "}
              합격 기준은 과목별 40% 이상 + 전체 60% 이상입니다.
            </Text>
          </View>

          {history.length > 0 && (
            <View style={[styles.introCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.introRowLabel, { color: colors.foreground, fontWeight: "700" }]}>
                최근 응시 기록
              </Text>
              {history.map((h) => (
                <Pressable
                  key={h.id}
                  style={({ pressed }) => [styles.introRow, pressed && h.reviewable && { opacity: 0.6 }]}
                  disabled={!h.reviewable}
                  onPress={() => openPastRecord(h)}
                >
                  <Text style={[styles.introRowLabel, { color: colors.muted }]}>
                    {new Date(h.takenAt).toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" })}
                  </Text>
                  <View style={styles.subjectResultRight}>
                    <Text style={[styles.introRowValue, { color: colors.foreground }]}>
                      {Math.round((h.correct / h.total) * 100)}점
                    </Text>
                    <Text
                      style={[styles.introRowValue, { color: h.passed ? colors.success : colors.error }]}
                    >
                      {h.passed ? "합격" : "불합격"}
                    </Text>
                    {h.reviewable && (
                      <IconSymbol name="chevron.right" size={14} color={colors.muted} />
                    )}
                  </View>
                </Pressable>
              ))}
              {history.some((h) => h.reviewable) && (
                <Text style={[styles.historyHint, { color: colors.muted }]}>
                  화살표가 있는 기록을 누르면 그 회차의 문제와 내 답을 다시 볼 수 있어요
                </Text>
              )}
            </View>
          )}

          <Pressable
            style={({ pressed }) => [
              styles.startBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
            ]}
            onPress={handleStart}
          >
            <IconSymbol name="play.fill" size={18} color="#FFFFFF" />
            <Text style={styles.startBtnText}>{roundGroup ? "실전 응시 시작하기" : "모의고사 시작하기"}</Text>
          </Pressable>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── Result ─────────────────────────────────────────────────────────────
  if (phase === "result" || phase === "review") {
    const score = scoreMockExam(
      examQuestions.map((q, i) => ({ question: q, selected: answers[i] }))
    );
    const bySubject = SUBJECTS.map((subject) => {
      const s = score.bySubject[subject];
      const rate = s.total > 0 ? s.correct / s.total : 0;
      return { subject, ...s, rate, passed: subjectPassed(s) };
    });
    const totalCorrect = score.correct;
    const overallRate = score.total > 0 ? score.correct / score.total : 0;
    const overallPassed = score.passed;

    if (phase === "review") {
      const q = examQuestions[currentIndex];
      const selected = answers[currentIndex];
      const isCorrect = selected === q.answer;
      return (
        <ScreenContainer {...swipeBackHandlers}>
          <View style={styles.topBar}>
            <Pressable
              style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
              onPress={() => setPhase("result")}
            >
              <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
            </Pressable>
            <View style={styles.topCenter}>
              <Text style={[styles.topSubject, { color: colors.primary }]}>전체 리뷰</Text>
              <Text style={[styles.topProgress, { color: colors.muted }]}>
                {currentIndex + 1} / {examQuestions.length}
              </Text>
            </View>
            <BookmarkButton
              bookmarked={bookmarks.isBookmarked(q.id)}
              onPress={() => bookmarks.toggle(q.id)}
            />
          </View>
          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.subjectBadgeRow}>
              <View style={[styles.subjectBadge, { backgroundColor: SUBJECT_COLORS[q.subject] + "18" }]}>
                <Text style={[styles.subjectBadgeText, { color: SUBJECT_COLORS[q.subject] }]}>
                  {q.subject}
                </Text>
              </View>
            </View>
            <View style={[styles.questionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.questionText, ts(16, 26), { color: colors.foreground }]}>{q.question}</Text>
              <QuestionImage imageKey={q.image} />
            </View>
            <View style={styles.optionsContainer}>
              {q.options.map((option, idx) => {
                const isSelected = selected === idx;
                const isCorrectOption = idx === q.answer;
                let bgColor = colors.surface;
                let borderColor = colors.border;
                let textColor = colors.foreground;
                if (isCorrectOption) {
                  bgColor = colors.success + "18";
                  borderColor = colors.success;
                  textColor = colors.success;
                } else if (isSelected && !isCorrectOption) {
                  bgColor = colors.error + "18";
                  borderColor = colors.error;
                  textColor = colors.error;
                }
                return (
                  <View
                    key={idx}
                    style={[styles.optionBtn, { backgroundColor: bgColor, borderColor }]}
                  >
                    <View style={[styles.optionLabel, { backgroundColor: borderColor + "30" }]}>
                      <Text style={[styles.optionLabelText, { color: textColor }]}>
                        {idx + 1}
                      </Text>
                    </View>
                    <Text style={[styles.optionText, ts(14, 22), { color: textColor }]}>
                      {option}
                    </Text>
                    {isCorrectOption && (
                      <IconSymbol name="checkmark.circle.fill" size={20} color={colors.success} />
                    )}
                    {isSelected && !isCorrectOption && (
                      <IconSymbol name="xmark.circle.fill" size={20} color={colors.error} />
                    )}
                  </View>
                );
              })}
            </View>
            {selected === null && (
              <Text style={[styles.unansweredNote, { color: colors.muted }]}>
                이 문제는 풀지 않고 제출했습니다.
              </Text>
            )}
            <View
              style={[
                styles.feedbackCard,
                {
                  backgroundColor: isCorrect ? colors.success + "12" : colors.error + "12",
                  borderColor: isCorrect ? colors.success + "40" : colors.error + "40",
                },
              ]}
            >
              <View style={styles.feedbackHeader}>
                <IconSymbol
                  name={isCorrect ? "checkmark.circle.fill" : "xmark.circle.fill"}
                  size={22}
                  color={isCorrect ? colors.success : colors.error}
                />
                <Text style={[styles.feedbackTitle, { color: isCorrect ? colors.success : colors.error }]}>
                  {isCorrect ? "정답입니다!" : "오답입니다"}
                </Text>
              </View>
              <Text style={[styles.explanationText, ts(13, 22), { color: colors.foreground }]}>
                {q.explanation}
              </Text>
            </View>
            <View style={styles.reviewNavRow}>
              <Pressable
                style={({ pressed }) => [
                  styles.navBtn,
                  { borderColor: colors.border },
                  pressed && { opacity: 0.7 },
                  currentIndex === 0 && styles.navBtnDisabled,
                ]}
                disabled={currentIndex === 0}
                onPress={() => setCurrentIndex((i) => Math.max(0, i - 1))}
              >
                <IconSymbol name="arrow.left" size={16} color={colors.foreground} />
                <Text style={[styles.navBtnText, { color: colors.foreground }]}>이전</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [
                  styles.navBtn,
                  { borderColor: colors.border },
                  pressed && { opacity: 0.7 },
                  currentIndex === examQuestions.length - 1 && styles.navBtnDisabled,
                ]}
                disabled={currentIndex === examQuestions.length - 1}
                onPress={() => setCurrentIndex((i) => Math.min(examQuestions.length - 1, i + 1))}
              >
                <Text style={[styles.navBtnText, { color: colors.foreground }]}>다음</Text>
                <IconSymbol name="arrow.right" size={16} color={colors.foreground} />
              </Pressable>
            </View>
          </ScrollView>
        </ScreenContainer>
      );
    }

    return (
      <ScreenContainer {...swipeBackHandlers}>
        <ScrollView contentContainerStyle={styles.resultContent} showsVerticalScrollIndicator={false}>
          <View style={styles.resultIconWrap}>
            <IconSymbol
              name={overallPassed ? "trophy.fill" : "arrow.clockwise"}
              size={56}
              color={overallPassed ? colors.warning : colors.primary}
            />
          </View>
          <Text style={[styles.resultTitle, { color: colors.foreground }]}>
            {overallPassed ? "합격 기준 달성! 🎉" : "조금 더 준비해요!"}
          </Text>
          <Text style={[styles.resultSubject, { color: colors.muted }]}>
            {pastRecord
              ? `${new Date(pastRecord.takenAt).toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" })} 응시 기록`
              : `${examTitle} 결과`}
          </Text>

          <View style={[styles.resultScoreCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.resultRate, { color: overallPassed ? colors.success : colors.primary }]}>
              {Math.round(overallRate * 100)}%
            </Text>
            <Text style={[styles.resultScore, { color: colors.muted }]}>
              {score.total}문제 중 {totalCorrect}문제 정답
            </Text>
          </View>

          <View style={[styles.subjectResultCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {bySubject.map((s, idx) => (
              <View key={s.subject}>
                {idx > 0 && <View style={[styles.introDivider, { backgroundColor: colors.border }]} />}
                <View style={styles.subjectResultRow}>
                  <View style={styles.introRowLeft}>
                    <View style={[styles.subjectDot, { backgroundColor: SUBJECT_COLORS[s.subject] }]} />
                    <Text style={[styles.introRowLabel, { color: colors.foreground }]}>{s.subject}</Text>
                  </View>
                  <View style={styles.subjectResultRight}>
                    <Text style={[styles.introRowValue, { color: colors.muted }]}>
                      {s.correct}/{s.total} · {Math.round(s.rate * 100)}%
                    </Text>
                    <IconSymbol
                      name={s.passed ? "checkmark.circle.fill" : "xmark.circle.fill"}
                      size={16}
                      color={s.passed ? colors.success : colors.error}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>

          <View style={styles.resultBtns}>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                styles.resultBtnOutline,
                { borderColor: colors.primary },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => {
                setCurrentIndex(0);
                setPhase("review");
              }}
            >
              <IconSymbol name="list.bullet" size={18} color={colors.primary} />
              <Text style={[styles.resultBtnText, { color: colors.primary }]}>전체 리뷰</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [
                styles.resultBtn,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              onPress={() => {
                if (pastRecord) {
                  setPastRecord(null);
                  setPhase("intro");
                } else {
                  router.replace("/");
                }
              }}
            >
              <IconSymbol name={pastRecord ? "arrow.left" : "house.fill"} size={18} color="#FFFFFF" />
              <Text style={[styles.resultBtnText, { color: "#FFFFFF" }]}>
                {pastRecord ? "돌아가기" : "홈으로"}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  // ─── Exam ───────────────────────────────────────────────────────────────
  const currentQ = examQuestions[currentIndex];
  const answeredCount = answers.filter((a) => a !== null).length;
  const isLowTime = timeLeft <= 5 * 60;

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.topBar}>
        <Pressable style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]} onPress={handleExit}>
          <IconSymbol name="xmark" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.topCenter}>
          <Text style={[styles.topProgress, { color: colors.muted }]}>
            {answeredCount} / {examQuestions.length}문제 풀이
          </Text>
        </View>
        <View style={[styles.timerBadge, { backgroundColor: (isLowTime ? colors.error : colors.primary) + "18" }]}>
          <IconSymbol name="clock.fill" size={14} color={isLowTime ? colors.error : colors.primary} />
          <Text style={[styles.timerText, { color: isLowTime ? colors.error : colors.primary }]}>
            {formatTime(timeLeft)}
          </Text>
        </View>
      </View>

      {/* Question Navigator */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.navigatorScroll}
        contentContainerStyle={styles.navigatorContent}
      >
        {examQuestions.map((q, idx) => {
          const isAnswered = answers[idx] !== null;
          const isCurrent = idx === currentIndex;
          return (
            <Pressable
              key={q.id}
              style={[
                styles.navChip,
                { borderColor: SUBJECT_COLORS[q.subject] },
                isAnswered && { backgroundColor: SUBJECT_COLORS[q.subject] },
                isCurrent && styles.navChipCurrent,
                isCurrent && { borderColor: colors.foreground },
              ]}
              onPress={() => setCurrentIndex(idx)}
            >
              <Text
                style={[
                  styles.navChipText,
                  { color: isAnswered ? "#FFFFFF" : SUBJECT_COLORS[q.subject] },
                ]}
              >
                {idx + 1}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.subjectBadgeRow}>
          <View style={[styles.subjectBadge, { backgroundColor: SUBJECT_COLORS[currentQ.subject] + "18" }]}>
            <Text style={[styles.subjectBadgeText, { color: SUBJECT_COLORS[currentQ.subject] }]}>
              {currentQ.subject}
            </Text>
          </View>
        </View>

        <View style={[styles.questionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.questionBadge}>
            <Text style={[styles.questionBadgeText, { color: colors.primary }]}>
              Q{currentIndex + 1}
            </Text>
          </View>
          <Text style={[styles.questionText, ts(16, 26), { color: colors.foreground }]}>{currentQ.question}</Text>
          <QuestionImage imageKey={currentQ.image} />
        </View>

        <View style={styles.optionsContainer}>
          {currentQ.options.map((option, idx) => {
            const isSelected = answers[currentIndex] === idx;
            return (
              <Pressable
                key={idx}
                style={({ pressed }) => [
                  styles.optionBtn,
                  {
                    backgroundColor: isSelected ? colors.primary + "18" : colors.surface,
                    borderColor: isSelected ? colors.primary : colors.border,
                  },
                  pressed && { opacity: 0.75 },
                ]}
                onPress={() => handleSelect(idx)}
              >
                <View
                  style={[
                    styles.optionLabel,
                    { backgroundColor: (isSelected ? colors.primary : colors.border) + "30" },
                  ]}
                >
                  <Text style={[styles.optionLabelText, { color: isSelected ? colors.primary : colors.foreground }]}>
                    {idx + 1}
                  </Text>
                </View>
                <Text
                  style={[styles.optionText, ts(14, 22), { color: isSelected ? colors.primary : colors.foreground }]}
                >
                  {option}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View style={styles.examNavRow}>
          <Pressable
            style={({ pressed }) => [
              styles.navBtn,
              { borderColor: colors.border },
              pressed && { opacity: 0.7 },
              currentIndex === 0 && styles.navBtnDisabled,
            ]}
            disabled={currentIndex === 0}
            onPress={() => setCurrentIndex((i) => Math.max(0, i - 1))}
          >
            <IconSymbol name="arrow.left" size={16} color={colors.foreground} />
            <Text style={[styles.navBtnText, { color: colors.foreground }]}>이전</Text>
          </Pressable>
          {currentIndex === examQuestions.length - 1 ? (
            <Pressable
              style={({ pressed }) => [
                styles.navBtn,
                styles.navBtnPrimary,
                { backgroundColor: colors.primary },
                pressed && { opacity: 0.85 },
              ]}
              disabled={submitting}
              onPress={handleSubmitPress}
            >
              <Text style={[styles.navBtnText, { color: "#FFFFFF" }]}>제출하기</Text>
              <IconSymbol name="flag.checkered" size={16} color="#FFFFFF" />
            </Pressable>
          ) : (
            <Pressable
              style={({ pressed }) => [
                styles.navBtn,
                { borderColor: colors.border },
                pressed && { opacity: 0.7 },
              ]}
              onPress={() => setCurrentIndex((i) => Math.min(examQuestions.length - 1, i + 1))}
            >
              <Text style={[styles.navBtnText, { color: colors.foreground }]}>다음</Text>
              <IconSymbol name="arrow.right" size={16} color={colors.foreground} />
            </Pressable>
          )}
        </View>

        <Pressable
          style={({ pressed }) => [styles.submitAnytimeBtn, pressed && { opacity: 0.7 }]}
          onPress={handleSubmitPress}
          disabled={submitting}
        >
          <Text style={[styles.submitAnytimeText, { color: colors.muted }]}>
            {submitting ? "채점 중..." : "지금 바로 제출하기"}
          </Text>
        </Pressable>
      </ScrollView>

      <ConfirmDialog
        visible={confirming === "submit"}
        title="답안을 제출할까요?"
        message={
          unansweredCount > 0
            ? `아직 풀지 않은 문제가 ${unansweredCount}개 있습니다. 그래도 제출하시겠어요?`
            : "모든 문제를 다 풀었습니다. 제출하시겠어요?"
        }
        confirmLabel="제출"
        destructive
        onConfirm={() => {
          setConfirming(null);
          submitExam();
        }}
        onCancel={() => setConfirming(null)}
      />
      <ConfirmDialog
        visible={confirming === "exit"}
        title={roundGroup ? "응시를 종료할까요?" : "모의고사를 종료할까요?"}
        message="지금까지 푼 내용은 저장되지 않습니다."
        confirmLabel="종료"
        destructive
        onConfirm={() => {
          setConfirming(null);
          // iOS: Modal이 닫히는 도중에 화면을 빠져나가면 하얀 화면에 멈출 수 있어 닫힌 뒤에 이동한다.
          setTimeout(() => router.back(), 350);
        }}
        onCancel={() => setConfirming(null)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  backBtn: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  topCenter: { flex: 1, alignItems: "center" },
  topSubject: { fontSize: 14, fontWeight: "700" },
  topProgress: { fontSize: 12 },
  timerBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 20,
  },
  timerText: { fontSize: 13, fontWeight: "800", fontVariant: ["tabular-nums"] },
  // 웹에서는 아래 문제 영역에 밀려 높이가 줄면서 번호 동그라미 위쪽이 잘리므로 높이를 고정한다.
  // (번호 32 + 위아래 여백 6씩)
  navigatorScroll: { flexGrow: 0, flexShrink: 0, height: 44, marginBottom: 4 },
  navigatorContent: { paddingHorizontal: 16, gap: 6, paddingVertical: 6, alignItems: "center" },
  navChip: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  navChipCurrent: { borderWidth: 2.5 },
  navChipText: { fontSize: 12, fontWeight: "700" },
  scrollContent: { padding: 20, paddingBottom: 40 },
  subjectBadgeRow: { marginBottom: 12 },
  subjectBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 20, alignSelf: "flex-start" },
  subjectBadgeText: { fontSize: 12, fontWeight: "700" },
  questionCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  questionBadge: { marginBottom: 10 },
  questionBadgeText: { fontSize: 13, fontWeight: "700" },
  questionText: { fontSize: 16, fontWeight: "600", lineHeight: 26 },
  optionsContainer: { gap: 10, marginBottom: 16 },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1.5,
    padding: 14,
    gap: 12,
  },
  optionLabel: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  optionLabelText: { fontSize: 14, fontWeight: "700" },
  optionText: { flex: 1, fontSize: 14, lineHeight: 22, fontWeight: "500" },
  unansweredNote: { fontSize: 13, marginBottom: 12, fontStyle: "italic" },
  feedbackCard: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
    gap: 10,
  },
  feedbackHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  feedbackTitle: { fontSize: 15, fontWeight: "700", flex: 1 },
  explanationText: { fontSize: 13, lineHeight: 22 },
  examNavRow: { flexDirection: "row", gap: 10, marginTop: 4 },
  reviewNavRow: { flexDirection: "row", gap: 10, marginTop: 4 },
  navBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderRadius: 14,
    borderWidth: 1.5,
    paddingVertical: 14,
  },
  navBtnPrimary: { borderWidth: 0 },
  navBtnDisabled: { opacity: 0.35 },
  navBtnText: { fontSize: 14, fontWeight: "700" },
  submitAnytimeBtn: { alignItems: "center", marginTop: 16, padding: 8 },
  submitAnytimeText: { fontSize: 13, textDecorationLine: "underline" },
  // Intro
  introContent: { padding: 24, alignItems: "center", paddingBottom: 48 },
  introIconWrap: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  introTitle: { fontSize: 24, fontWeight: "800", letterSpacing: -0.5, marginBottom: 4 },
  introDesc: { fontSize: 14, marginBottom: 24, textAlign: "center" },
  introCard: {
    width: "100%",
    borderRadius: 16,
    borderWidth: 1,
    padding: 18,
    marginBottom: 16,
  },
  introRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  introRowLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  subjectDot: { width: 8, height: 8, borderRadius: 4 },
  introRowLabel: { fontSize: 14 },
  introRowValue: { fontSize: 14 },
  introDivider: { height: 1, marginVertical: 4 },
  historyHint: { fontSize: 11, marginTop: 6 },
  introNote: {
    flexDirection: "row",
    gap: 8,
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 28,
    width: "100%",
  },
  introNoteText: { fontSize: 12, lineHeight: 18, flex: 1 },
  startBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 14,
    paddingVertical: 16,
    width: "100%",
  },
  startBtnText: { fontSize: 16, fontWeight: "700", color: "#FFFFFF" },
  // Result
  resultContent: { padding: 24, alignItems: "center", paddingBottom: 48 },
  resultIconWrap: { marginTop: 24, marginBottom: 16 },
  resultTitle: { fontSize: 26, fontWeight: "800", letterSpacing: -0.5, marginBottom: 4 },
  resultSubject: { fontSize: 14, marginBottom: 24 },
  resultScoreCard: {
    width: "100%",
    borderRadius: 18,
    borderWidth: 1,
    padding: 24,
    alignItems: "center",
    gap: 8,
    marginBottom: 20,
  },
  resultRate: { fontSize: 52, fontWeight: "900", letterSpacing: -2 },
  resultScore: { fontSize: 15 },
  subjectResultCard: {
    width: "100%",
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 32,
  },
  subjectResultRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 8,
  },
  subjectResultRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  resultBtns: { flexDirection: "row", gap: 12, width: "100%" },
  resultBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 15,
    borderRadius: 14,
  },
  resultBtnOutline: { borderWidth: 1.5, backgroundColor: "transparent" },
  resultBtnText: { fontSize: 15, fontWeight: "700" },
});

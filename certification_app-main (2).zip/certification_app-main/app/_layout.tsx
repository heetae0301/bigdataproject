import "@/global.css";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Image, LogBox, Pressable, Text, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import "react-native-reanimated";
import "@/lib/_core/nativewind-pressable";
import { ThemeProvider } from "@/lib/theme-provider";
import { AppSettingsProvider } from "@/lib/app-settings";
import { SafeAreaProvider, initialWindowMetrics } from "react-native-safe-area-context";
import type { EdgeInsets, Rect } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";

import { trpc, createTRPCClient } from "@/lib/trpc";
import { AuthProvider, useAuth } from "@/lib/auth-context";

// 앱 코드는 이미 react-native-safe-area-context를 쓰고 있고, 이 경고는 라이브러리
// 내부에서 나는 것이라 고칠 게 없다. 개발 중 화면에 뜨는 노란 경고창만 숨긴다.
LogBox.ignoreLogs(["SafeAreaView has been deprecated"]);

const AUTH_ROUTES = ["login", "signup", "forgot-password"];
const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/**
 * 저장된 로그인으로 내 정보를 확인하는 동안 보여주는 화면. Render 무료 서버가 잠들어 있으면
 * 깨어나는 데 30초~1분이 걸리므로, 잠깐 지나도 안 끝나면 기다리는 이유를 알려준다.
 */
function LoadingScreen() {
  const colors = useColors();
  const [slow, setSlow] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setSlow(true), 2500);
    return () => clearTimeout(timer);
  }, []);
  return (
    <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", padding: 32 }}>
      <Image source={CHARACTER_SOURCE} style={{ width: 120, height: 120 }} resizeMode="contain" />
      <ActivityIndicator color={colors.primary} style={{ marginTop: 20 }} />
      {slow ? (
        <>
          <Text style={{ marginTop: 16, fontSize: 16, fontWeight: "700", color: colors.foreground, textAlign: "center" }}>
            서버를 깨우는 중이에요
          </Text>
          <Text style={{ marginTop: 6, fontSize: 13, color: colors.muted, textAlign: "center", lineHeight: 19 }}>
            한동안 안 쓰면 서버가 잠들어서{"\n"}처음엔 최대 1분 정도 걸릴 수 있어요
          </Text>
        </>
      ) : null}
    </View>
  );
}

/** 저장된 로그인은 있는데 서버에 닿지 못했을 때. 로그인을 지우지 않고 다시 시도하게 한다. */
function ConnectionErrorScreen({ onRetry, onUseOtherAccount }: { onRetry: () => void; onUseOtherAccount: () => void }) {
  const colors = useColors();
  return (
    <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center", padding: 32 }}>
      <Image source={CHARACTER_SOURCE} style={{ width: 120, height: 120 }} resizeMode="contain" />
      <Text style={{ marginTop: 20, fontSize: 17, fontWeight: "700", color: colors.foreground, textAlign: "center" }}>
        서버에 연결하지 못했어요
      </Text>
      <Text style={{ marginTop: 6, fontSize: 13, color: colors.muted, textAlign: "center", lineHeight: 19 }}>
        인터넷 연결을 확인하고 다시 시도해 주세요.{"\n"}로그인 정보는 그대로 남아 있어요.
      </Text>
      <Pressable
        onPress={onRetry}
        accessibilityRole="button"
        style={({ pressed }) => ({
          marginTop: 24,
          height: 52,
          minWidth: 200,
          paddingHorizontal: 24,
          borderRadius: 14,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: colors.primary,
          opacity: pressed ? 0.85 : 1,
        })}
      >
        <Text style={{ color: "#fff", fontSize: 16, fontWeight: "700" }}>다시 시도</Text>
      </Pressable>
      <Pressable onPress={onUseOtherAccount} accessibilityRole="button" style={{ marginTop: 14, padding: 8 }}>
        <Text style={{ color: colors.muted, fontSize: 13, textDecorationLine: "underline" }}>다른 계정으로 로그인</Text>
      </Pressable>
    </View>
  );
}

function AuthGate({ children }: { children: React.ReactNode }) {
  const { user, isLoading, connectionError, retryConnection, logout } = useAuth();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (isLoading || connectionError) return;
    const inAuthGroup = AUTH_ROUTES.includes(segments[0] as string);
    if (!user && !inAuthGroup) {
      router.replace("/login");
    } else if (user && inAuthGroup) {
      router.replace("/");
    }
  }, [user, isLoading, connectionError, segments, router]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (connectionError && !user) {
    return <ConnectionErrorScreen onRetry={retryConnection} onUseOtherAccount={() => void logout()} />;
  }

  return <>{children}</>;
}

const DEFAULT_WEB_INSETS: EdgeInsets = { top: 0, right: 0, bottom: 0, left: 0 };
const DEFAULT_WEB_FRAME: Rect = { x: 0, y: 0, width: 0, height: 0 };

export const unstable_settings = {
  anchor: "(tabs)",
};

export default function RootLayout() {
  const initialInsets = initialWindowMetrics?.insets ?? DEFAULT_WEB_INSETS;
  const initialFrame = initialWindowMetrics?.frame ?? DEFAULT_WEB_FRAME;

  // Create clients once and reuse them
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            // Disable automatic refetching on window focus for mobile
            refetchOnWindowFocus: false,
            // Retry failed requests once
            retry: 1,
          },
        },
      }),
  );
  const [trpcClient] = useState(() => createTRPCClient());

  // Ensure minimum 8px padding for top and bottom on mobile
  const providerInitialMetrics = useMemo(() => {
    const metrics = initialWindowMetrics ?? { insets: initialInsets, frame: initialFrame };
    return {
      ...metrics,
      insets: {
        ...metrics.insets,
        top: Math.max(metrics.insets.top, 16),
        bottom: Math.max(metrics.insets.bottom, 12),
      },
    };
  }, [initialInsets, initialFrame]);

  return (
    <AppSettingsProvider>
    <ThemeProvider>
      <SafeAreaProvider initialMetrics={providerInitialMetrics}>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <trpc.Provider client={trpcClient} queryClient={queryClient}>
            <QueryClientProvider client={queryClient}>
              <AuthProvider>
                <AuthGate>
                  {/* Default to hiding native headers so raw route segments don't appear (e.g. "(tabs)", "products/[id]"). */}
                  {/* If a screen needs the native header, explicitly enable it and set a human title via Stack.Screen options. */}
                  <Stack screenOptions={{ headerShown: false }}>
                    <Stack.Screen name="(tabs)" />
                    <Stack.Screen name="login" />
                    <Stack.Screen name="signup" />
                  </Stack>
                </AuthGate>
                <StatusBar style="auto" />
              </AuthProvider>
            </QueryClientProvider>
          </trpc.Provider>
        </GestureHandlerRootView>
      </SafeAreaProvider>
    </ThemeProvider>
    </AppSettingsProvider>
  );
}

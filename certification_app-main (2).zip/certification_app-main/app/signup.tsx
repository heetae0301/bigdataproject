import React, { useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Link, useRouter } from "expo-router";
import { AppGoogleSigninButton } from "@/components/google-signin-button";
import { ScreenContainer } from "@/components/screen-container";
import { AuthHero } from "@/components/auth-hero";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { getFriendlyAuthErrorMessage } from "@/lib/auth-error";
import { isGoogleSignInAvailable, prewarmGoogleSignIn, signInWithGoogle } from "@/lib/google-signin";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SignupScreen() {
  const colors = useColors();
  const router = useRouter();
  const { signup, loginWithGoogle } = useAuth();

  const [email, setEmail] = useState("");
  const [nickname, setNickname] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGoogleSubmitting, setIsGoogleSubmitting] = useState(false);

  useEffect(() => {
    prewarmGoogleSignIn();
  }, []);

  const handleGoogleSignIn = async () => {
    setError(null);
    setIsGoogleSubmitting(true);
    try {
      const code = await signInWithGoogle();
      await loginWithGoogle(code);
      if (code) router.replace("/");
    } catch (e) {
      setError(getFriendlyAuthErrorMessage(e));
    } finally {
      setIsGoogleSubmitting(false);
    }
  };

  const handleSubmit = async () => {
    setError(null);

    if (!email.trim() || !nickname.trim() || !password) {
      setError("이메일, 닉네임, 비밀번호를 모두 입력해주세요.");
      return;
    }
    if (!EMAIL_REGEX.test(email.trim())) {
      setError("올바른 이메일 형식을 입력해주세요.");
      return;
    }
    if (nickname.trim().length > 20) {
      setError("닉네임은 20자 이하로 입력해주세요.");
      return;
    }
    if (password.length < 6) {
      setError("비밀번호는 6자 이상이어야 합니다.");
      return;
    }
    if (password !== confirmPassword) {
      setError("비밀번호가 일치하지 않습니다.");
      return;
    }

    setIsSubmitting(true);
    try {
      await signup(email.trim(), nickname.trim(), password);
      router.replace("/");
    } catch (e) {
      setError(getFriendlyAuthErrorMessage(e));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ScreenContainer edges={["left", "right", "bottom"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <AuthHero label="ADsP 데이터분석 준전문가" title={"i can do it\n자격증"} bubble="만나서 반가워! 같이 시작하자" />

          <View style={styles.card}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>회원가입</Text>

            <View style={styles.field}>
              <Text style={[styles.label, { color: colors.foreground }]}>이메일</Text>
              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                placeholderTextColor={colors.muted}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                style={[
                  styles.input,
                  { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                ]}
              />
            </View>

            <View style={styles.field}>
              <Text style={[styles.label, { color: colors.foreground }]}>닉네임</Text>
              <TextInput
                value={nickname}
                onChangeText={setNickname}
                placeholder="앱에서 표시될 이름"
                placeholderTextColor={colors.muted}
                autoCapitalize="none"
                maxLength={20}
                style={[
                  styles.input,
                  { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                ]}
              />
            </View>

            <View style={styles.field}>
              <Text style={[styles.label, { color: colors.foreground }]}>비밀번호</Text>
              <TextInput
                value={password}
                onChangeText={setPassword}
                placeholder="6자 이상"
                placeholderTextColor={colors.muted}
                secureTextEntry
                style={[
                  styles.input,
                  { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                ]}
              />
            </View>

            <View style={styles.field}>
              <Text style={[styles.label, { color: colors.foreground }]}>비밀번호 확인</Text>
              <TextInput
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholder="비밀번호 재입력"
                placeholderTextColor={colors.muted}
                secureTextEntry
                style={[
                  styles.input,
                  { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                ]}
              />
            </View>

            {error ? (
              <View
                style={[
                  styles.errorBox,
                  { backgroundColor: colors.error + "14", borderColor: colors.error + "40" },
                ]}
              >
                <IconSymbol name="exclamationmark.triangle.fill" size={16} color={colors.error} />
                <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
              </View>
            ) : null}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                { backgroundColor: colors.primary },
                (pressed || isSubmitting) && { opacity: 0.8 },
              ]}
              onPress={handleSubmit}
              disabled={isSubmitting}
            >
              <Text style={styles.submitButtonText}>
                {isSubmitting ? "가입 중..." : "회원가입"}
              </Text>
            </Pressable>

            {isGoogleSignInAvailable ? (
              <>
                <View style={styles.dividerRow}>
                  <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
                  <Text style={[styles.dividerText, { color: colors.muted }]}>또는</Text>
                  <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
                </View>

                <AppGoogleSigninButton
                  style={styles.googleButton}
                  onPress={handleGoogleSignIn}
                  disabled={isGoogleSubmitting}
                />
              </>
            ) : null}

            <Link href="/login" replace asChild>
              <Pressable style={styles.linkRow}>
                <Text style={[styles.linkText, { color: colors.muted }]}>
                  이미 계정이 있으신가요?{" "}
                  <Text style={{ color: colors.primary, fontWeight: "700" }}>로그인</Text>
                </Text>
              </Pressable>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 24,
  },
  card: {
    paddingHorizontal: 24,
    paddingTop: 24,
    gap: 4,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 12,
  },
  field: {
    marginBottom: 14,
  },
  label: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 52,
    fontSize: 15,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  errorText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
  },
  submitButton: {
    borderRadius: 14,
    height: 54,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  submitButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "800",
  },
  dividerRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 16,
  },
  dividerLine: {
    flex: 1,
    height: StyleSheet.hairlineWidth,
  },
  dividerText: {
    fontSize: 12,
  },
  googleButton: {
    width: "100%",
    height: 48,
    marginTop: 14,
  },
  linkRow: {
    marginTop: 18,
    alignItems: "center",
  },
  linkText: {
    fontSize: 13,
  },
});

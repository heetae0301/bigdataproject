import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Link, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { AuthHero } from "@/components/auth-hero";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { getFriendlyAuthErrorMessage } from "@/lib/auth-error";

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  const { requestPasswordReset, resetPassword } = useAuth();

  const [step, setStep] = useState<"request" | "reset">("request");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleRequestCode = async () => {
    setError(null);
    if (!EMAIL_REGEX.test(email.trim())) {
      setError("올바른 이메일 형식을 입력해주세요.");
      return;
    }
    setIsSubmitting(true);
    try {
      await requestPasswordReset(email.trim());
      setNotice("입력하신 이메일로 인증코드를 보냈어요. 10분 안에 입력해주세요.");
      setStep("reset");
    } catch (e) {
      setError(getFriendlyAuthErrorMessage(e));
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetPassword = async () => {
    setError(null);
    if (code.trim().length !== 6) {
      setError("6자리 인증코드를 입력해주세요.");
      return;
    }
    if (newPassword.length < 6) {
      setError("비밀번호는 6자 이상이어야 합니다.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setError("비밀번호가 일치하지 않습니다.");
      return;
    }
    setIsSubmitting(true);
    try {
      await resetPassword(email.trim(), code.trim(), newPassword);
      router.replace("/login");
    } catch (e) {
      setError(getFriendlyAuthErrorMessage(e));
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <ScreenContainer edges={["left", "right", "bottom"]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
          <AuthHero label="i can do it 자격증" title={"비밀번호를\n잊으셨나요?"} bubble={step === "request" ? "가입한 이메일로 코드를 보내줄게!" : "메일로 받은 코드를 입력해줘!"} />

          <View style={styles.card}>
            <View style={styles.field}>
              <Text style={[styles.label, { color: colors.foreground }]}>이메일</Text>
              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="you@example.com"
                placeholderTextColor={colors.muted}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="email-address"
                editable={step === "request"}
                style={[
                  styles.input,
                  { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                  step === "reset" && { opacity: 0.6 },
                ]}
              />
            </View>

            {step === "reset" ? (
              <>
                <View style={styles.field}>
                  <Text style={[styles.label, { color: colors.foreground }]}>인증코드 (6자리)</Text>
                  <TextInput
                    value={code}
                    onChangeText={setCode}
                    placeholder="123456"
                    placeholderTextColor={colors.muted}
                    keyboardType="number-pad"
                    maxLength={6}
                    style={[
                      styles.input,
                      { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                    ]}
                  />
                </View>

                <View style={styles.field}>
                  <Text style={[styles.label, { color: colors.foreground }]}>새 비밀번호</Text>
                  <TextInput
                    value={newPassword}
                    onChangeText={setNewPassword}
                    placeholder="6자 이상"
                    placeholderTextColor={colors.muted}
                    secureTextEntry
                    style={[
                      styles.input,
                      { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                    ]}
                  />
                </View>

                <View style={styles.field}>
                  <Text style={[styles.label, { color: colors.foreground }]}>새 비밀번호 확인</Text>
                  <TextInput
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    placeholder="비밀번호 재입력"
                    placeholderTextColor={colors.muted}
                    secureTextEntry
                    style={[
                      styles.input,
                      { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.surface },
                    ]}
                  />
                </View>
              </>
            ) : null}

            {notice ? (
              <View
                style={[
                  styles.noticeBox,
                  { backgroundColor: colors.primary + "14", borderColor: colors.primary + "40" },
                ]}
              >
                <Text style={[styles.noticeText, { color: colors.primary }]}>{notice}</Text>
              </View>
            ) : null}

            {error ? (
              <View style={[styles.errorBox, { backgroundColor: colors.error + "14", borderColor: colors.error + "40" }]}>
                <IconSymbol name="exclamationmark.triangle.fill" size={16} color={colors.error} />
                <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
              </View>
            ) : null}

            <Pressable
              style={({ pressed }) => [
                styles.submitButton,
                { backgroundColor: colors.primary },
                (pressed || isSubmitting) && { opacity: 0.8 },
              ]}
              onPress={step === "request" ? handleRequestCode : handleResetPassword}
              disabled={isSubmitting}
            >
              <Text style={styles.submitButtonText}>
                {isSubmitting
                  ? "처리 중..."
                  : step === "request"
                    ? "인증코드 받기"
                    : "비밀번호 재설정"}
              </Text>
            </Pressable>

            {step === "reset" ? (
              <Pressable
                style={styles.linkRow}
                onPress={() => {
                  setStep("request");
                  setNotice(null);
                  setError(null);
                }}
              >
                <Text style={[styles.linkText, { color: colors.muted }]}>이메일을 다시 입력할까요?</Text>
              </Pressable>
            ) : null}

            <Link href="/login" replace asChild>
              <Pressable style={styles.linkRow}>
                <Text style={[styles.linkText, { color: colors.muted }]}>
                  <Text style={{ color: colors.primary, fontWeight: "700" }}>로그인으로 돌아가기</Text>
                </Text>
              </Pressable>
            </Link>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 24,
  },
  card: {
    paddingHorizontal: 24,
    paddingTop: 24,
    gap: 4,
  },
  field: {
    marginBottom: 14,
  },
  label: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 52,
    fontSize: 15,
  },
  noticeBox: {
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  noticeText: {
    fontSize: 13,
    fontWeight: "600",
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginBottom: 10,
  },
  errorText: {
    flex: 1,
    fontSize: 13,
    fontWeight: "600",
  },
  submitButton: {
    borderRadius: 14,
    height: 54,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
  },
  submitButtonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "800",
  },
  linkRow: {
    marginTop: 14,
    alignItems: "center",
  },
  linkText: {
    fontSize: 13,
  },
});

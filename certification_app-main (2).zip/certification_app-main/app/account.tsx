import React, { useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useSwipeBack } from "@/hooks/use-swipe-back";
import { useAuth } from "@/lib/auth-context";
import { getFriendlyAuthErrorMessage } from "@/lib/auth-error";

type Message = { text: string; isError: boolean } | null;

const DELETE_CONFIRM_WORD = "탈퇴";

/** 내 정보: 닉네임 변경, 비밀번호 변경, 회원 탈퇴. */
export default function AccountScreen() {
  const colors = useColors();
  const router = useRouter();
  const swipeBackHandlers = useSwipeBack();
  const { user, updateNickname, changePassword, deleteAccount } = useAuth();

  const [nickname, setNickname] = useState(user?.nickname ?? "");
  const [nicknameMsg, setNicknameMsg] = useState<Message>(null);
  const [savingNickname, setSavingNickname] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordMsg, setPasswordMsg] = useState<Message>(null);
  const [savingPassword, setSavingPassword] = useState(false);

  const [showDelete, setShowDelete] = useState(false);
  const [deleteInput, setDeleteInput] = useState("");
  const [deleteMsg, setDeleteMsg] = useState<Message>(null);
  const [deleting, setDeleting] = useState(false);

  const inputStyle = [
    styles.input,
    { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background },
  ];

  const handleSaveNickname = async () => {
    const trimmed = nickname.trim();
    if (!trimmed) {
      setNicknameMsg({ text: "닉네임을 입력해주세요.", isError: true });
      return;
    }
    if (trimmed.length > 20) {
      setNicknameMsg({ text: "닉네임은 20자 이하로 입력해주세요.", isError: true });
      return;
    }
    setSavingNickname(true);
    setNicknameMsg(null);
    try {
      await updateNickname(trimmed);
      setNickname(trimmed);
      setNicknameMsg({ text: "닉네임을 바꿨어요.", isError: false });
    } catch (e) {
      setNicknameMsg({ text: getFriendlyAuthErrorMessage(e), isError: true });
    } finally {
      setSavingNickname(false);
    }
  };

  const handleChangePassword = async () => {
    if (!currentPassword) {
      setPasswordMsg({ text: "현재 비밀번호를 입력해주세요.", isError: true });
      return;
    }
    if (newPassword.length < 6) {
      setPasswordMsg({ text: "새 비밀번호는 6자 이상이어야 합니다.", isError: true });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordMsg({ text: "새 비밀번호가 일치하지 않습니다.", isError: true });
      return;
    }
    setSavingPassword(true);
    setPasswordMsg(null);
    try {
      await changePassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setPasswordMsg({ text: "비밀번호를 바꿨어요.", isError: false });
    } catch (e) {
      setPasswordMsg({ text: getFriendlyAuthErrorMessage(e), isError: true });
    } finally {
      setSavingPassword(false);
    }
  };

  const handleDelete = async () => {
    if (deleteInput.trim() !== DELETE_CONFIRM_WORD) return;
    setDeleting(true);
    setDeleteMsg(null);
    try {
      // 성공하면 로그아웃 상태가 되고 AuthGate가 로그인 화면으로 보낸다.
      await deleteAccount();
    } catch (e) {
      setDeleteMsg({ text: getFriendlyAuthErrorMessage(e), isError: true });
      setDeleting(false);
    }
  };

  return (
    <ScreenContainer {...swipeBackHandlers}>
      <View style={styles.topBar}>
        <Pressable
          style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.6 }]}
          onPress={() => router.back()}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.topTitle, { color: colors.foreground }]}>내 정보</Text>
        <View style={styles.backBtn} />
      </View>

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
          <Text style={[styles.email, { color: colors.muted }]}>{user?.email}</Text>

          {/* Nickname */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>닉네임</Text>
            <TextInput
              value={nickname}
              onChangeText={setNickname}
              placeholder="앱에서 표시될 이름"
              placeholderTextColor={colors.muted}
              maxLength={20}
              style={inputStyle}
            />
            <MessageText message={nicknameMsg} />
            <PrimaryButton
              label={savingNickname ? "저장 중..." : "닉네임 저장"}
              onPress={handleSaveNickname}
              disabled={savingNickname || nickname.trim() === user?.nickname}
            />
          </View>

          {/* Password */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>비밀번호 변경</Text>
            <TextInput
              value={currentPassword}
              onChangeText={setCurrentPassword}
              placeholder="현재 비밀번호"
              placeholderTextColor={colors.muted}
              secureTextEntry
              style={inputStyle}
            />
            <TextInput
              value={newPassword}
              onChangeText={setNewPassword}
              placeholder="새 비밀번호 (6자 이상)"
              placeholderTextColor={colors.muted}
              secureTextEntry
              style={inputStyle}
            />
            <TextInput
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              placeholder="새 비밀번호 확인"
              placeholderTextColor={colors.muted}
              secureTextEntry
              style={inputStyle}
            />
            <Text style={[styles.hint, { color: colors.muted }]}>
              Google로 가입해서 비밀번호가 없다면, 로그아웃한 뒤 로그인 화면의 “비밀번호를 잊으셨나요?”로 비밀번호를
              만들 수 있어요.
            </Text>
            <MessageText message={passwordMsg} />
            <PrimaryButton
              label={savingPassword ? "변경 중..." : "비밀번호 변경"}
              onPress={handleChangePassword}
              disabled={savingPassword}
            />
          </View>

          {/* Delete account */}
          <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.error + "40" }]}>
            <Text style={[styles.cardTitle, { color: colors.error }]}>회원 탈퇴</Text>
            <Text style={[styles.hint, { color: colors.muted }]}>
              계정과 모든 학습 기록(오답 노트, 통계, 북마크, 메모, 모의고사 기록)이 삭제되고 되돌릴 수 없어요.
            </Text>
            {showDelete ? (
              <>
                <Text style={[styles.hint, { color: colors.foreground }]}>
                  계속하려면 아래에 <Text style={{ fontWeight: "800" }}>{DELETE_CONFIRM_WORD}</Text>를 입력하세요.
                </Text>
                <TextInput
                  value={deleteInput}
                  onChangeText={setDeleteInput}
                  placeholder={DELETE_CONFIRM_WORD}
                  placeholderTextColor={colors.muted}
                  autoCorrect={false}
                  style={inputStyle}
                />
                <MessageText message={deleteMsg} />
                <Pressable
                  style={({ pressed }) => [
                    styles.button,
                    { backgroundColor: colors.error },
                    (pressed || deleting) && { opacity: 0.8 },
                    deleteInput.trim() !== DELETE_CONFIRM_WORD && { opacity: 0.4 },
                  ]}
                  onPress={handleDelete}
                  disabled={deleting || deleteInput.trim() !== DELETE_CONFIRM_WORD}
                >
                  <Text style={styles.buttonText}>{deleting ? "삭제 중..." : "계정 영구 삭제"}</Text>
                </Pressable>
              </>
            ) : (
              <Pressable
                style={({ pressed }) => [
                  styles.button,
                  styles.outlineButton,
                  { borderColor: colors.error + "60" },
                  pressed && { opacity: 0.7 },
                ]}
                onPress={() => setShowDelete(true)}
              >
                <Text style={[styles.buttonText, { color: colors.error }]}>회원 탈퇴</Text>
              </Pressable>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

function MessageText({ message }: { message: Message }) {
  const colors = useColors();
  if (!message) return null;
  return (
    <Text style={[styles.message, { color: message.isError ? colors.error : colors.success }]}>{message.text}</Text>
  );
}

function PrimaryButton({ label, onPress, disabled }: { label: string; onPress: () => void; disabled?: boolean }) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: colors.primary },
        (pressed || disabled) && { opacity: disabled ? 0.5 : 0.85 },
      ]}
      onPress={onPress}
      disabled={disabled}
    >
      <Text style={styles.buttonText}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  backBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  topTitle: { fontSize: 17, fontWeight: "700" },
  content: { padding: 20, gap: 16, paddingBottom: 40 },
  email: { fontSize: 14, textAlign: "center" },
  card: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 10 },
  cardTitle: { fontSize: 16, fontWeight: "700" },
  input: {
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
  },
  hint: { fontSize: 12, lineHeight: 18 },
  message: { fontSize: 13, fontWeight: "600", textAlign: "center" },
  button: { borderRadius: 12, paddingVertical: 14, alignItems: "center" },
  outlineButton: { borderWidth: 1 },
  buttonText: { color: "#FFFFFF", fontSize: 15, fontWeight: "700" },
});

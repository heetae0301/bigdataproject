import React, { useEffect, useState } from "react";
import { View, Text, Pressable, ScrollView, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { DateCalendar } from "@/components/date-calendar";
import { IconSymbol, type IconSymbolName } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import { getExamDate, setExamDate } from "@/lib/storage";
import { diffDays, isValidDateStr, kstDateStr } from "@/lib/kst-date";
import { DailyGoalEditor } from "@/components/daily-goal-editor";
import { FONT_SCALE_OPTIONS, THEME_MODE_OPTIONS, useAppSettings, useTextScale } from "@/lib/app-settings";

const WEEKDAYS = ["일", "월", "화", "수", "목", "금", "토"];

/** "2026-10-27" → "10월 27일 (화)" */
function formatExamDate(dateStr: string): string {
  if (!isValidDateStr(dateStr)) return dateStr;
  const [, m, d] = dateStr.split("-").map(Number);
  const weekday = WEEKDAYS[new Date(`${dateStr}T00:00:00Z`).getUTCDay()];
  return `${m}월 ${d}일 (${weekday})`;
}

function formatDday(days: number): string {
  if (days === 0) return "D-DAY";
  return days > 0 ? `D-${days}` : `D+${-days}`;
}

export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, logout } = useAuth();

  const { settings, updateSettings } = useAppSettings();
  const ts = useTextScale();

  // 저장된 시험일과, 달력에서 고르는 중인 값을 따로 둔다 (저장해야 반영)
  const [savedExamDate, setSavedExamDate] = useState<string | null>(null);
  const [examDateInput, setExamDateInput] = useState("");
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [message, setMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [saving, setSaving] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  useEffect(() => {
    getExamDate()
      .then((d) => {
        setSavedExamDate(d);
        setExamDateInput(d ?? "");
      })
      .catch(() => {});
  }, []);

  const handleSave = async () => {
    const trimmed = examDateInput.trim();
    if (trimmed && !isValidDateStr(trimmed)) {
      setMessage({ text: "시험일은 2026-11-15 같은 형식으로 입력해주세요.", isError: true });
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      await setExamDate(trimmed || null);
      setSavedExamDate(trimmed || null);
      setMessage({ text: trimmed ? "시험일을 저장했어요." : "시험일을 지웠어요.", isError: false });
      setCalendarOpen(false);
    } catch (error) {
      console.warn("[Settings] save failed:", error);
      setMessage({ text: "저장하지 못했어요. 잠시 후 다시 시도해주세요.", isError: true });
    } finally {
      setSaving(false);
    }
  };

  const confirmLogout = () => {
    setShowLogoutConfirm(false);
    // iOS에서 Modal이 닫히는 애니메이션 도중에 화면을 바꾸면 닫히던 Modal이 엉켜 하얀 화면에 멈춘다.
    // 확인창이 다 닫힌 뒤에 로그아웃한다. 로그인 화면 이동은 AuthGate(app/_layout.tsx)가 맡는다.
    setTimeout(() => {
      logout().catch(() => {});
    }, 350);
  };

  const dday = savedExamDate ? diffDays(kstDateStr(), savedExamDate) : null;

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>설정</Text>

        {/* Profile */}
        {user ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="내 정보 수정"
            style={({ pressed }) => [
              styles.card,
              styles.profile,
              { backgroundColor: colors.surface, borderColor: colors.border },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() => router.push("/account")}
          >
            <View style={[styles.avatar, { backgroundColor: colors.primary + "1F" }]}>
              <Text style={[styles.avatarText, { color: colors.primary }]}>
                {(user.nickname || user.email).slice(0, 1)}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.profileName, { color: colors.foreground }]}>{user.nickname}</Text>
              <Text style={[styles.profileEmail, { color: colors.muted }]} numberOfLines={1}>
                {user.email}
              </Text>
            </View>
            <Text style={[styles.linkLabel, { color: colors.primary }]}>내 정보</Text>
            <IconSymbol name="chevron.right" size={16} color={colors.muted} />
          </Pressable>
        ) : null}

        {/* 공부 */}
        <Text style={[styles.groupLabel, { color: colors.muted }]}>공부</Text>
        <View style={[styles.card, styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            accessibilityRole="button"
            aria-expanded={calendarOpen}
            style={({ pressed }) => [styles.row, pressed && { opacity: 0.7 }]}
            onPress={() => {
              setCalendarOpen((v) => !v);
              setMessage(null);
            }}
          >
            <RowIcon name="calendar" color={colors.primary} />
            <Text style={[styles.rowTitle, { color: colors.foreground }]}>시험일</Text>
            <Text style={[styles.rowValue, { color: savedExamDate ? colors.primary : colors.muted }]} numberOfLines={1}>
              {savedExamDate && dday !== null
                ? `${formatExamDate(savedExamDate)} · ${formatDday(dday)}`
                : "설정 안 함"}
            </Text>
            <IconSymbol name={calendarOpen ? "chevron.down" : "chevron.right"} size={16} color={colors.muted} />
          </Pressable>
          {calendarOpen && (
            <View style={styles.calendarArea}>
              <View style={styles.selectedRow}>
                <Text style={[styles.selectedText, { color: examDateInput ? colors.foreground : colors.muted }]}>
                  {examDateInput ? formatExamDate(examDateInput) : "달력에서 시험일을 선택하세요"}
                </Text>
                {!!examDateInput && (
                  <Pressable style={({ pressed }) => pressed && { opacity: 0.6 }} onPress={() => setExamDateInput("")}>
                    <Text style={[styles.clearText, { color: colors.muted }]}>지우기</Text>
                  </Pressable>
                )}
              </View>
              <DateCalendar value={examDateInput} onChange={setExamDateInput} minDate={kstDateStr()} />
              <Pressable
                style={({ pressed }) => [
                  styles.saveBtn,
                  { backgroundColor: colors.primary },
                  (pressed || saving) && { opacity: 0.85 },
                ]}
                onPress={handleSave}
                disabled={saving}
              >
                <Text style={styles.saveBtnText}>{saving ? "저장 중..." : "시험일 저장"}</Text>
              </Pressable>
            </View>
          )}
          {message && (
            <Text style={[styles.message, { color: message.isError ? colors.error : colors.success }]}>
              {message.text}
            </Text>
          )}

          {/* 하루 목표: 이 기기에만 저장되고, 바꾸는 즉시 적용된다 */}
          <View style={[styles.goalBlock, { borderTopColor: colors.border }]}>
            <View style={styles.goalHeader}>
              <RowIcon name="target" color={colors.highlight} />
              <Text style={[styles.rowTitle, { color: colors.foreground }]}>하루 목표</Text>
            </View>
            <DailyGoalEditor value={settings.dailyGoal} onChange={(dailyGoal) => updateSettings({ dailyGoal })} />
          </View>
        </View>

        {/* 화면 */}
        <Text style={[styles.groupLabel, { color: colors.muted }]}>화면</Text>
        <View style={[styles.card, styles.padded, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.rowTitle, { color: colors.foreground }]}>테마</Text>
          <Segmented
            options={THEME_MODE_OPTIONS}
            selected={settings.themeMode}
            onSelect={(themeMode) => updateSettings({ themeMode })}
          />
          <Text style={[styles.rowTitle, styles.spaced, { color: colors.foreground }]}>글자 크기</Text>
          <Segmented
            options={FONT_SCALE_OPTIONS}
            selected={settings.fontScale}
            onSelect={(fontScale) => updateSettings({ fontScale })}
          />
          <View style={[styles.preview, { backgroundColor: colors.background }]}>
            <Text style={[styles.previewText, ts(16, 26), { color: colors.foreground }]}>
              미리보기: 데이터베이스의 특징으로 올바르지 않은 것은?
            </Text>
          </View>
        </View>

        {/* 계정 */}
        <Text style={[styles.groupLabel, { color: colors.muted }]}>계정</Text>
        <View style={[styles.card, styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            style={({ pressed }) => [styles.row, pressed && { opacity: 0.7 }]}
            onPress={() => router.push("/account")}
          >
            <Text style={[styles.rowTitle, { color: colors.foreground }]}>닉네임·비밀번호 변경</Text>
            <IconSymbol name="chevron.right" size={16} color={colors.muted} />
          </Pressable>
          <Pressable
            style={({ pressed }) => [styles.row, { borderTopWidth: 1, borderTopColor: colors.border }, pressed && { opacity: 0.7 }]}
            onPress={() => setShowLogoutConfirm(true)}
          >
            <Text style={[styles.rowTitle, { color: colors.error }]}>로그아웃</Text>
          </Pressable>
        </View>
      </ScrollView>

      <ConfirmDialog
        visible={showLogoutConfirm}
        title="로그아웃"
        message="로그아웃하시겠습니까?"
        confirmLabel="로그아웃"
        destructive
        onConfirm={confirmLogout}
        onCancel={() => setShowLogoutConfirm(false)}
      />
    </ScreenContainer>
  );
}

function RowIcon({ name, color }: { name: IconSymbolName; color: string }) {
  return (
    <View style={[styles.rowIcon, { backgroundColor: color + "1A" }]}>
      <IconSymbol name={name} size={18} color={color} />
    </View>
  );
}

/** 여러 선택지 중 하나를 고르는 세그먼트 컨트롤. */
function Segmented<T extends string | number>({
  options,
  selected,
  onSelect,
}: {
  options: { label: string; value: T }[];
  selected: T;
  onSelect: (value: T) => void;
}) {
  const colors = useColors();
  return (
    <View style={[styles.segment, { backgroundColor: colors.background }]}>
      {options.map((option) => {
        const isSelected = option.value === selected;
        return (
          <Pressable
            key={String(option.value)}
            accessibilityRole="radio"
            aria-checked={isSelected}
            style={({ pressed }) => [
              styles.segmentItem,
              isSelected && [styles.segmentSelected, { backgroundColor: colors.surface }],
              pressed && !isSelected && { opacity: 0.7 },
            ]}
            onPress={() => onSelect(option.value)}
          >
            <Text
              style={[
                styles.segmentText,
                { color: isSelected ? colors.foreground : colors.muted, fontWeight: isSelected ? "800" : "600" },
              ]}
            >
              {option.label}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: 20, gap: 12, paddingBottom: 40 },
  headerTitle: { fontSize: 24, fontWeight: "800", letterSpacing: -0.5, marginBottom: 2 },
  groupLabel: { fontSize: 13, fontWeight: "800", marginTop: 8, marginLeft: 4 },
  card: { borderRadius: 16, borderWidth: 1 },
  listCard: { paddingHorizontal: 16 },
  padded: { padding: 16, gap: 8 },
  profile: { flexDirection: "row", alignItems: "center", gap: 12, padding: 14 },
  avatar: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  avatarText: { fontSize: 18, fontWeight: "800" },
  profileName: { fontSize: 16, fontWeight: "800" },
  profileEmail: { fontSize: 13, marginTop: 1 },
  linkLabel: { fontSize: 13, fontWeight: "700" },
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 14 },
  rowIcon: { width: 34, height: 34, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  rowTitle: { flex: 1, fontSize: 15, fontWeight: "700" },
  rowValue: { fontSize: 14, fontWeight: "700", flexShrink: 1 },
  spaced: { marginTop: 8 },
  calendarArea: { gap: 10, paddingBottom: 14 },
  selectedRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  selectedText: { fontSize: 15, fontWeight: "700" },
  clearText: { fontSize: 13, fontWeight: "600" },
  message: { fontSize: 13, lineHeight: 20, textAlign: "center", paddingBottom: 12 },
  saveBtn: { borderRadius: 12, height: 50, alignItems: "center", justifyContent: "center" },
  saveBtnText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800" },
  goalBlock: { borderTopWidth: 1, paddingVertical: 14, gap: 12 },
  goalHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  segment: { flexDirection: "row", padding: 4, borderRadius: 12 },
  segmentItem: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 9, borderRadius: 9 },
  segmentSelected: {
    shadowColor: "#0F172A",
    shadowOpacity: 0.08,
    shadowRadius: 2,
    shadowOffset: { width: 0, height: 1 },
    elevation: 1,
  },
  segmentText: { fontSize: 13 },
  preview: { borderRadius: 12, padding: 12, marginTop: 4 },
  previewText: { fontSize: 16, fontWeight: "600", lineHeight: 26 },
});

import React, { useCallback, useState } from "react";
import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol, type IconSymbolName } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import {
  getBookmarks,
  getQuestionProgress,
  getRoundSummaries,
  type QuestionProgress,
  type RoundSummary,
} from "@/lib/storage";
import { SUBJECTS, Subject, SUBJECT_COLORS, questions } from "@/data/questions";
import { PAST_EXAM_YEARS } from "@/data/past-exams";

const SUBJECT_DESCRIPTIONS: Record<Subject, string> = {
  "1과목(데이터 이해)": "데이터 개념 · 데이터베이스 · 빅데이터",
  "2과목(데이터 분석 기획)": "분석 기획 · 통계 기초 · 데이터 수집",
  "3과목(데이터 분석)": "데이터 분석 · 머신러닝 · 시각화",
};

const subjectOf = new Map(questions.map((q) => [q.id, q.subject]));

export default function QuizScreen() {
  const colors = useColors();
  const router = useRouter();

  const [bookmarkCount, setBookmarkCount] = useState(0);
  const [progress, setProgress] = useState<QuestionProgress[]>([]);
  const [roundSummaries, setRoundSummaries] = useState<Map<number, RoundSummary>>(new Map());

  useFocusEffect(
    useCallback(() => {
      getBookmarks()
        .then((ids) => setBookmarkCount(ids.length))
        .catch(() => {});
      getQuestionProgress().then(setProgress).catch(() => {});
      getRoundSummaries()
        .then((list) => setRoundSummaries(new Map(list.map((s) => [s.round, s]))))
        .catch(() => {});
    }, [])
  );

  const solvedBySubject = new Map<string, number>();
  for (const p of progress) {
    const subject = subjectOf.get(p.questionId);
    if (subject) solvedBySubject.set(subject, (solvedBySubject.get(subject) ?? 0) + 1);
  }

  const startQuiz = (subject: string) => router.push({ pathname: "/quiz-session", params: { subject } });

  const quickActions: { title: string; sub: string; icon: IconSymbolName; color: string; onPress: () => void }[] = [
    { title: "전체 랜덤", sub: `${questions.length}문제`, icon: "shuffle", color: colors.primary, onPress: () => startQuiz("전체") },
    { title: "약점 집중", sub: "자주 틀린 10문제", icon: "target", color: colors.highlight, onPress: () => startQuiz("약점") },
    {
      title: "북마크",
      sub: bookmarkCount > 0 ? `표시한 ${bookmarkCount}문제` : "아직 없어요",
      icon: "bookmark.fill",
      color: colors.warning,
      onPress: () => startQuiz("북마크"),
    },
    {
      title: "사진으로 풀기",
      sub: "찍으면 AI 해설",
      icon: "camera.fill",
      color: colors.accent,
      onPress: () => router.push("/photo-recognition"),
    },
  ];

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>문제 풀기</Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>오늘은 무엇부터 풀어볼까요?</Text>
        </View>

        {/* Mock Exam Hero */}
        <View style={[styles.hero, { backgroundColor: colors.primary }]}>
          <View style={styles.heroCircle} />
          <View style={styles.heroTop}>
            <View style={{ flex: 1 }}>
              <Text style={styles.heroLabel}>실전처럼 연습</Text>
              <Text style={styles.heroTitle}>실전 모의고사</Text>
              <Text style={styles.heroDesc}>50문제 · 90분 · 매번 새로 출제</Text>
            </View>
            <IconSymbol name="clock.fill" size={40} color="rgba(255,255,255,0.9)" />
          </View>
          <Pressable
            style={({ pressed }) => [styles.heroBtn, { backgroundColor: colors.highlight }, pressed && { opacity: 0.85 }]}
            onPress={() => router.push("/mock-exam")}
          >
            <Text style={styles.heroBtnText}>모의고사 시작하기</Text>
          </Pressable>
        </View>

        {/* Quick actions */}
        <View style={styles.quickGrid}>
          {quickActions.map((a) => (
            <Pressable
              key={a.title}
              style={({ pressed }) => [
                styles.quickCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.75 },
              ]}
              onPress={a.onPress}
            >
              <View style={[styles.quickIcon, { backgroundColor: a.color + "1A" }]}>
                <IconSymbol name={a.icon} size={20} color={a.color} />
              </View>
              <View>
                <Text style={[styles.quickTitle, { color: colors.foreground }]}>{a.title}</Text>
                <Text style={[styles.quickSub, { color: colors.muted }]}>{a.sub}</Text>
              </View>
            </Pressable>
          ))}
        </View>

        {/* Search */}
        <Pressable
          accessibilityRole="search"
          style={({ pressed }) => [
            styles.searchBar,
            { backgroundColor: colors.surface, borderColor: colors.border },
            pressed && { opacity: 0.75 },
          ]}
          onPress={() => router.push("/search")}
        >
          <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
          <Text style={[styles.searchText, { color: colors.muted }]}>키워드로 문제·해설 검색</Text>
        </Pressable>

        {/* Subjects */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>과목별 풀기</Text>
        <View style={[styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {SUBJECTS.map((subject, i) => {
            const color = SUBJECT_COLORS[subject];
            const total = questions.filter((q) => q.subject === subject).length;
            return (
              <Pressable
                key={subject}
                style={({ pressed }) => [
                  styles.listRow,
                  i > 0 && { borderTopWidth: 1, borderTopColor: colors.border },
                  pressed && { opacity: 0.6 },
                ]}
                onPress={() => startQuiz(subject)}
              >
                <View style={[styles.numBadge, { backgroundColor: color + "1A" }]}>
                  <Text style={[styles.numBadgeText, { color }]}>{i + 1}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.rowTitle, { color: colors.foreground }]}>
                    {subject.replace(/^\d과목\((.*)\)$/, "$1")}
                  </Text>
                  <Text style={[styles.rowSub, { color: colors.muted }]} numberOfLines={1}>
                    {SUBJECT_DESCRIPTIONS[subject]}
                  </Text>
                </View>
                <Text style={[styles.rowMeta, { color: colors.muted }]}>
                  {solvedBySubject.get(subject) ?? 0}/{total}
                </Text>
                <IconSymbol name="chevron.right" size={16} color={colors.muted} />
              </Pressable>
            );
          })}
        </View>

        {/* Past exams by year - 기본 문제은행과 섞지 않고 회차 단위로 따로 출제한다. */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>기출 문제</Text>
        {PAST_EXAM_YEARS.map(({ year, groups }) => (
          <View key={year} style={styles.yearBlock}>
            <Text style={[styles.yearLabel, { color: colors.muted }]}>{year}년</Text>
            <View style={[styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              {groups.map((group, i) => {
                const summary = roundSummaries.get(group.round);
                return (
                  <View
                    key={group.key}
                    style={[styles.listRow, i > 0 && { borderTopWidth: 1, borderTopColor: colors.border }]}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.rowTitle, { color: colors.foreground }]}>제{group.key}</Text>
                      <Text
                        style={[
                          styles.rowSub,
                          !summary
                            ? { color: colors.muted }
                            : { color: summary.everPassed ? colors.success : colors.highlight, fontWeight: "700" },
                        ]}
                      >
                        {summary
                          ? `최고 ${Math.round(summary.bestRate * 100)}점 · ${summary.everPassed ? "합격" : "불합격"}`
                          : `${group.questions.length}문제 · 실전 응시 기록 없음`}
                      </Text>
                    </View>
                    <Pressable
                      accessibilityLabel={`제${group.key} 연습`}
                      style={({ pressed }) => [
                        styles.pill,
                        { backgroundColor: colors.background, borderColor: colors.border },
                        pressed && { opacity: 0.7 },
                      ]}
                      onPress={() => startQuiz(group.key)}
                    >
                      <Text style={[styles.pillText, { color: colors.foreground }]}>연습</Text>
                    </Pressable>
                    <Pressable
                      accessibilityLabel={`제${group.key} 실전`}
                      style={({ pressed }) => [
                        styles.pill,
                        { backgroundColor: colors.primary, borderColor: colors.primary },
                        pressed && { opacity: 0.8 },
                      ]}
                      onPress={() => router.push({ pathname: "/mock-exam", params: { round: String(group.round) } })}
                    >
                      <Text style={[styles.pillText, { color: "#FFFFFF" }]}>실전</Text>
                    </Pressable>
                  </View>
                );
              })}
            </View>
          </View>
        ))}

        <Text style={[styles.footnote, { color: colors.muted }]}>
          과목별 풀기는 10문제씩(3과목은 30문제) 안 푼 문제와 틀린 문제가 먼저 나와요. 기출 ‘연습’은 한 문제씩
          정답을 확인하고, ‘실전’은 90분 타이머로 응시한 뒤 합격 여부를 채점해요.
        </Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
    gap: 14,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  hero: {
    borderRadius: 20,
    padding: 20,
    gap: 14,
    overflow: "hidden",
  },
  heroCircle: {
    position: "absolute",
    right: -36,
    top: -36,
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  heroTop: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  heroLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "rgba(255,255,255,0.8)",
  },
  heroTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
    marginTop: 2,
  },
  heroDesc: {
    fontSize: 13,
    color: "rgba(255,255,255,0.85)",
    marginTop: 4,
  },
  heroBtn: {
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  heroBtnText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  quickGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  quickCard: {
    width: "48.5%",
    flexGrow: 1,
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
    gap: 10,
  },
  quickIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  quickTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  quickSub: {
    fontSize: 12,
    marginTop: 1,
  },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    height: 48,
    paddingHorizontal: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  searchText: {
    fontSize: 14,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "800",
    letterSpacing: -0.3,
    marginTop: 6,
  },
  listCard: {
    borderRadius: 16,
    borderWidth: 1,
    paddingHorizontal: 14,
  },
  listRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 13,
  },
  numBadge: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  numBadgeText: {
    fontSize: 15,
    fontWeight: "800",
  },
  rowTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  rowSub: {
    fontSize: 12,
    marginTop: 1,
  },
  rowMeta: {
    fontSize: 12,
  },
  yearBlock: {
    gap: 8,
  },
  yearLabel: {
    fontSize: 13,
    fontWeight: "700",
  },
  pill: {
    height: 34,
    paddingHorizontal: 14,
    borderRadius: 999,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  pillText: {
    fontSize: 13,
    fontWeight: "700",
  },
  footnote: {
    fontSize: 12,
    lineHeight: 18,
    marginTop: 4,
  },
});

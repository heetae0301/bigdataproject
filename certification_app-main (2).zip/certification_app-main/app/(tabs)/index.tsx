import React, { useCallback, useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { Image } from "expo-image";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DailyGoalDialog } from "@/components/daily-goal-editor";
import { useColors } from "@/hooks/use-colors";
import { useAppSettings } from "@/lib/app-settings";
import {
  getExamDate,
  getLast7DaysLog,
  getQuestionProgress,
  getStudyStats,
  getWrongAnswers,
  QuestionProgress,
  StudyStats,
} from "@/lib/storage";
import { diffDays, kstDateStr } from "@/lib/kst-date";
import { isDueForReview } from "@/lib/review-schedule";
import { SUBJECTS, SUBJECT_COLORS, questions } from "@/data/questions";
import { PAST_EXAM_YEARS } from "@/data/past-exams";

const TOTAL_QUESTIONS = questions.length;
const subjectOf = new Map(questions.map((q) => [q.id, q.subject]));
const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

function formatDday(days: number): string {
  if (days === 0) return "D-DAY";
  return days > 0 ? `D-${days}` : `D+${-days}`;
}

// "1과목(데이터 이해)" → "1과목 · 데이터 이해"
function subjectLabel(subject: string): string {
  return subject.replace(/\((.*)\)$/, " · $1");
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [progress, setProgress] = useState<QuestionProgress[]>([]);
  const [examDate, setExamDate] = useState<string | null>(null);
  const [todayCount, setTodayCount] = useState(0);
  const [dueWrongCount, setDueWrongCount] = useState(0);
  const [goalDialogOpen, setGoalDialogOpen] = useState(false);
  const { settings } = useAppSettings();

  useFocusEffect(
    useCallback(() => {
      getStudyStats().then(setStats).catch(() => {});
      getQuestionProgress().then(setProgress).catch(() => {});
      getExamDate().then(setExamDate).catch(() => {});
      // 오늘 푼 문제 수: 기출·모의고사 포함 오늘 푼 모든 문제 (목표는 학습량 기준)
      getLast7DaysLog()
        .then((log) => setTodayCount(log[log.length - 1]?.count ?? 0))
        .catch(() => {});
      getWrongAnswers()
        .then((list) => {
          const now = Date.now();
          setDueWrongCount(list.filter((w) => isDueForReview(w, now)).length);
        })
        .catch(() => {});
    }, [])
  );

  // 상단 카드와 과목별 현황은 일반 문제(600) 기준. 서버 통계(stats)는 기출 풀이까지 합산돼 있어서
  // 문제별 풀이 기록(progress)에서 일반 문제만 골라 계산한다.
  const baseProgress = progress.filter((p) => subjectOf.has(p.questionId));
  const baseAttempts = baseProgress.reduce((sum, p) => sum + p.attempts, 0);
  const baseCorrect = baseProgress.reduce((sum, p) => sum + p.correct, 0);
  const overallRate = baseAttempts > 0 ? Math.round((baseCorrect / baseAttempts) * 100) : 0;
  const solvedTotal = baseProgress.length;
  const dday = examDate ? diffDays(kstDateStr(), examDate) : null;
  const goalRate = Math.min(100, Math.round((todayCount / settings.dailyGoal) * 100));
  const goalDone = todayCount >= settings.dailyGoal;
  const goalLeft = settings.dailyGoal - todayCount;

  // 동그래 말풍선: 오늘 목표 진행 상황에 맞춰 한마디
  const bubbleText = goalDone
    ? "오늘 목표 달성!\n정말 잘했어!"
    : todayCount === 0
      ? "오늘도 같이\n시작해 볼까?"
      : `오늘 ${goalLeft}문제만 더 풀면\n목표 달성이야!`;

  // 진도율 = 한 번이라도 푼 "서로 다른" 문제 수 / 과목 문제 수 (같은 문제를 여러 번 풀어도 1개)
  const subjectProgress = SUBJECTS.map((subject) => {
    const subjectTotal = questions.filter((q) => q.subject === subject).length;
    const records = baseProgress.filter((p) => subjectOf.get(p.questionId) === subject);
    const attempts = records.reduce((sum, p) => sum + p.attempts, 0);
    const correct = records.reduce((sum, p) => sum + p.correct, 0);
    const rate = attempts > 0 ? Math.round((correct / attempts) * 100) : 0;
    return {
      key: subject,
      label: subjectLabel(subject),
      color: SUBJECT_COLORS[subject],
      solved: records.length,
      rate,
      total: subjectTotal,
    };
  });

  // 기출 회차: 과목별 통계가 없으니 문제별 풀이 기록으로 진도율·정답률을 계산하고, 연도별로 묶는다.
  const pastExamProgressByYear = PAST_EXAM_YEARS.map(({ year, groups }) => ({
    year,
    items: groups.map((group) => {
      const ids = new Set(group.questions.map((q) => q.id));
      const records = progress.filter((p) => ids.has(p.questionId));
      const attempts = records.reduce((sum, p) => sum + p.attempts, 0);
      const correct = records.reduce((sum, p) => sum + p.correct, 0);
      const rate = attempts > 0 ? Math.round((correct / attempts) * 100) : 0;
      return { key: `제${group.key}`, label: `제${group.key}`, color: group.color, solved: records.length, rate, total: ids.size };
    }),
  }));

  const startQuiz = (subject: string) =>
    router.push({ pathname: "/quiz-session", params: { subject } });

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={{ flexShrink: 1 }}>
            <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
              ADsP 데이터분석 준전문가
            </Text>
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>
              i can do it 자격증
            </Text>
          </View>
          {stats?.streakDays ? (
            <View style={[styles.streakBadge, { backgroundColor: colors.highlight + "1A" }]}>
              <IconSymbol name="flame.fill" size={15} color={colors.highlight} />
              <Text style={[styles.streakText, { color: colors.highlight }]}>
                {stats.streakDays}일 연속
              </Text>
            </View>
          ) : null}
        </View>

        {/* Hero: D-day + 동그래 + 전체 통계 */}
        <Pressable
          style={({ pressed }) => [
            styles.heroCard,
            { backgroundColor: colors.primary },
            pressed && { opacity: 0.92 },
          ]}
          onPress={() => router.push("/settings")}
        >
          <View style={styles.heroCircle} />
          <Image
            source={CHARACTER_SOURCE}
            style={styles.heroCharacter}
            contentFit="contain"
            accessibilityLabel="동그래"
          />
          <View style={styles.heroText}>
            {dday !== null ? (
              <>
                <Text style={styles.heroLabel} numberOfLines={1}>
                  ADsP 시험까지 · {examDate}
                </Text>
                <Text style={styles.heroDday}>{formatDday(dday)}</Text>
              </>
            ) : (
              <>
                <Text style={styles.heroLabel}>시험일을 설정하면</Text>
                <Text style={styles.heroDdayEmpty}>D-day가 떠요</Text>
              </>
            )}
            <View style={styles.bubble}>
              <Text style={styles.bubbleText}>
                {dday !== null && dday < 0 ? "시험 끝! 다음 시험일을\n설정해 볼까?" : bubbleText}
              </Text>
            </View>
          </View>
          <View style={styles.heroStats}>
            <View style={styles.heroStatItem}>
              <Text style={styles.heroStatValue}>{baseAttempts}</Text>
              <Text style={styles.heroStatLabel}>총 풀이</Text>
            </View>
            <View style={styles.heroStatItem}>
              <Text style={styles.heroStatValue}>{overallRate}%</Text>
              <Text style={styles.heroStatLabel}>정답률</Text>
            </View>
            <View style={styles.heroStatItem}>
              <Text style={styles.heroStatValue}>
                {solvedTotal}
                <Text style={styles.heroStatValueSub}>/{TOTAL_QUESTIONS}</Text>
              </Text>
              <Text style={styles.heroStatLabel}>푼 문제</Text>
            </View>
          </View>
        </Pressable>

        {/* Daily Goal + 시작 버튼 */}
        <View style={[styles.card, styles.goalCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`오늘의 목표 ${settings.dailyGoal}문제, 눌러서 바꾸기`}
            style={({ pressed }) => [styles.goalHeader, pressed && { opacity: 0.7 }]}
            onPress={() => setGoalDialogOpen(true)}
          >
            <View style={styles.goalTitleRow}>
              <Text style={[styles.goalTitle, { color: colors.foreground }]}>오늘의 목표</Text>
              <IconSymbol name="pencil" size={14} color={colors.muted} />
            </View>
            <Text style={[styles.goalCount, { color: colors.muted }]}>
              <Text style={{ color: goalDone ? colors.success : colors.primary, fontWeight: "800" }}>
                {todayCount}
              </Text>
              {" "}/ {settings.dailyGoal}문제
            </Text>
          </Pressable>
          <View style={[styles.progressBg, styles.goalBar, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.progressFill,
                styles.goalBar,
                { backgroundColor: goalDone ? colors.success : colors.primary, width: `${goalRate}%` },
              ]}
            />
          </View>
          <Pressable
            style={({ pressed }) => [styles.startBtn, { backgroundColor: colors.highlight }, pressed && { opacity: 0.85 }]}
            onPress={() => startQuiz("전체")}
          >
            <IconSymbol name="play.fill" size={16} color="#FFFFFF" />
            <Text style={styles.startBtnText}>{goalDone ? "더 풀어보기" : "오늘의 문제 풀기"}</Text>
          </Pressable>
        </View>

        {/* Quick actions */}
        <View style={styles.quickRow}>
          <Pressable
            style={({ pressed }) => [
              styles.quickCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() =>
              dueWrongCount > 0
                ? router.push({
                    pathname: "/wrong-session",
                    params: { filter: "오답_전체", mode: "due", source: "전체" },
                  })
                : router.push("/wrong")
            }
          >
            <View style={[styles.quickIcon, { backgroundColor: colors.highlight + "1A" }]}>
              <IconSymbol name="xmark.circle.fill" size={20} color={colors.highlight} />
            </View>
            <View style={{ flexShrink: 1 }}>
              <Text style={[styles.quickTitle, { color: colors.foreground }]}>오답 복습</Text>
              <Text style={[styles.quickSub, { color: colors.muted }]}>
                {dueWrongCount > 0 ? `오늘 ${dueWrongCount}문제` : "오늘은 없어요"}
              </Text>
            </View>
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              styles.quickCard,
              { backgroundColor: colors.surface, borderColor: colors.border },
              pressed && { opacity: 0.75 },
            ]}
            onPress={() => startQuiz("전체")}
          >
            <View style={[styles.quickIcon, { backgroundColor: colors.primary + "1A" }]}>
              <IconSymbol name="shuffle" size={20} color={colors.primary} />
            </View>
            <View style={{ flexShrink: 1 }}>
              <Text style={[styles.quickTitle, { color: colors.foreground }]}>전체 랜덤</Text>
              <Text style={[styles.quickSub, { color: colors.muted }]}>{TOTAL_QUESTIONS}문제</Text>
            </View>
          </Pressable>
        </View>

        {/* Subject Progress (누르면 그 과목 풀기) */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          과목별 학습 현황
        </Text>
        <ProgressCard items={subjectProgress} onPressItem={startQuiz} />

        {/* Past Exam Progress */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          기출 문제 학습 현황
        </Text>
        {pastExamProgressByYear.map(({ year, items }) => (
          <View key={year}>
            <Text style={[styles.yearLabel, { color: colors.muted }]}>{year}년</Text>
            <ProgressCard items={items} />
          </View>
        ))}
      </ScrollView>
      <DailyGoalDialog visible={goalDialogOpen} onClose={() => setGoalDialogOpen(false)} />
    </ScreenContainer>
  );
}

type ProgressItem = { key: string; label: string; color: string; solved: number; total: number; rate: number };

function ProgressCard({
  items,
  onPressItem,
}: {
  items: ProgressItem[];
  onPressItem?: (key: string) => void;
}) {
  const colors = useColors();
  return (
    <View style={[styles.card, styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {items.map((item, idx) => (
        <Pressable
          key={item.key}
          disabled={!onPressItem}
          onPress={() => onPressItem?.(item.key)}
          style={({ pressed }) => [
            styles.progressRow,
            idx > 0 && { borderTopWidth: 1, borderTopColor: colors.border },
            pressed && { opacity: 0.6 },
          ]}
        >
          <View style={styles.subjectRow}>
            <Text style={[styles.subjectName, { color: colors.foreground }]} numberOfLines={1}>
              {item.label}
            </Text>
            <View style={styles.subjectMeta}>
              <Text style={[styles.subjectRate, { color: colors.muted }]}>
                {item.solved}/{item.total} · {item.rate}%
              </Text>
              {onPressItem && <IconSymbol name="chevron.right" size={14} color={colors.muted} />}
            </View>
          </View>
          <View style={[styles.progressBg, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: item.color,
                  width: `${item.total > 0 ? Math.round((item.solved / item.total) * 100) : 0}%`,
                },
              ]}
            />
          </View>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
    gap: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: -0.5,
    marginTop: 2,
  },
  headerSubtitle: {
    fontSize: 13,
    fontWeight: "500",
  },
  streakBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  streakText: {
    fontSize: 13,
    fontWeight: "700",
  },
  heroCard: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 14,
    overflow: "hidden",
    gap: 16,
  },
  heroCircle: {
    position: "absolute",
    right: -40,
    top: -30,
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  heroCharacter: {
    position: "absolute",
    right: -4,
    top: 6,
    width: 150,
    height: 150,
  },
  heroText: {
    width: "58%",
    gap: 10,
  },
  heroLabel: {
    fontSize: 13,
    fontWeight: "500",
    color: "rgba(255,255,255,0.85)",
  },
  heroDday: {
    fontSize: 44,
    fontWeight: "800",
    letterSpacing: -1.5,
    color: "#FFFFFF",
    marginTop: -6,
  },
  heroDdayEmpty: {
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.5,
    color: "#FFFFFF",
    marginTop: -6,
  },
  bubble: {
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 9,
  },
  bubbleText: {
    fontSize: 14,
    lineHeight: 20,
    fontWeight: "600",
    color: "#0F172A",
  },
  heroStats: {
    flexDirection: "row",
    backgroundColor: "rgba(0,0,0,0.15)",
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 8,
  },
  heroStatItem: {
    flex: 1,
    alignItems: "center",
  },
  heroStatValue: {
    fontSize: 20,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  heroStatValueSub: {
    fontSize: 13,
    fontWeight: "600",
    color: "rgba(255,255,255,0.75)",
  },
  heroStatLabel: {
    fontSize: 12,
    color: "rgba(255,255,255,0.8)",
    marginTop: 2,
  },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 24,
  },
  goalCard: {
    padding: 16,
    gap: 12,
    marginBottom: 14,
  },
  goalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  goalTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  goalTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  goalCount: {
    fontSize: 14,
  },
  goalBar: {
    height: 10,
    borderRadius: 5,
  },
  startBtn: {
    height: 52,
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  startBtnText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  quickRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 24,
  },
  quickCard: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 16,
    borderWidth: 1,
    padding: 14,
  },
  quickIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  quickTitle: {
    fontSize: 15,
    fontWeight: "700",
  },
  quickSub: {
    fontSize: 12,
    marginTop: 1,
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "800",
    marginBottom: 12,
    letterSpacing: -0.3,
  },
  yearLabel: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 8,
  },
  listCard: {
    paddingHorizontal: 16,
    paddingVertical: 2,
  },
  progressRow: {
    paddingVertical: 14,
    gap: 8,
  },
  subjectRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  subjectName: {
    fontSize: 14,
    fontWeight: "700",
    flexShrink: 1,
  },
  subjectMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  subjectRate: {
    fontSize: 13,
  },
  progressBg: {
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
  },
  progressFill: {
    height: 8,
    borderRadius: 4,
  },
});

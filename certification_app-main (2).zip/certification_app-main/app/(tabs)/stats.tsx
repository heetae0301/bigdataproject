import React, { useCallback, useState } from "react";
import {
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
} from "react-native";
import { Image } from "expo-image";
import { useFocusEffect, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/lib/auth-context";
import {
  getStudyStats,
  getLast7DaysLog,
  getQuestionProgress,
  getMockExamResults,
  resetStudyStats,
  clearWrongAnswers,
  MockExamRecord,
  QuestionProgress,
  StudyStats,
} from "@/lib/storage";
import { OVERALL_PASS_RATE } from "@/lib/mock-exam-scoring";
import { allQuestions, questions, Question, SUBJECTS, Subject, SUBJECT_COLORS } from "@/data/questions";

interface DayLog {
  date: string;
  count: number;
}

// 약한 과목 추천은 이만큼은 풀어봐야 의미가 있다.
const WEAK_SUBJECT_MIN_ANSWERED = 5;
const FREQUENT_WRONG_LIMIT = 5;
const MOCK_TREND_LIMIT = 10;

const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");
const questionById = new Map(allQuestions.map((q) => [q.id, q]));
const baseSubjectOf = new Map(questions.map((q) => [q.id, q.subject]));

export default function StatsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuth();
  const [stats, setStats] = useState<StudyStats | null>(null);
  const [dailyLog, setDailyLog] = useState<DayLog[]>([]);
  const [progress, setProgress] = useState<QuestionProgress[]>([]);
  const [mockResults, setMockResults] = useState<MockExamRecord[]>([]);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const loadAll = useCallback(async () => {
    const [s, log, p, mock] = await Promise.all([
      getStudyStats(),
      getLast7DaysLog(),
      getQuestionProgress(),
      // 무작위 실전 모의고사만 (기출 회차 실전 점수는 문제풀기 탭 회차 칸에 따로 표시)
      getMockExamResults(MOCK_TREND_LIMIT, null),
    ]);
    setStats(s);
    setDailyLog(log);
    setProgress(p);
    setMockResults(mock);
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadAll().catch(() => {});
    }, [loadAll])
  );

  // 숫자 카드와 과목별 정답률은 홈 화면과 같은 기준(일반 문제 600)으로 계산한다. 서버 통계(stats)는
  // 기출 풀이까지 합산돼 있어서 문제별 풀이 기록(progress)에서 일반 문제만 골라 계산한다.
  const bySubject = Object.fromEntries(
    SUBJECTS.map((subject) => [subject, { total: 0, correct: 0 }])
  ) as Record<Subject, { total: number; correct: number }>;
  for (const p of progress) {
    const subject = baseSubjectOf.get(p.questionId);
    if (!subject) continue;
    bySubject[subject].total += p.attempts;
    bySubject[subject].correct += p.correct;
  }
  const baseAnswered = SUBJECTS.reduce((sum, s) => sum + bySubject[s].total, 0);
  const baseCorrect = SUBJECTS.reduce((sum, s) => sum + bySubject[s].correct, 0);
  const overallRate = baseAnswered > 0 ? Math.round((baseCorrect / baseAnswered) * 100) : 0;

  const maxDailyCount = Math.max(...dailyLog.map((d) => d.count), 1);
  const bestStreak = stats?.bestStreakDays ?? 0;

  // 정답률이 가장 낮은 과목 (충분히 풀어본 과목 중에서)
  const rankedSubjects = SUBJECTS.map((subject) => {
    const s = bySubject[subject];
    return { subject, answered: s.total, rate: s.total > 0 ? s.correct / s.total : 0 };
  })
    .filter((s) => s.answered >= WEAK_SUBJECT_MIN_ANSWERED)
    .sort((a, b) => a.rate - b.rate);
  const weakSubject = rankedSubjects[0];
  // 비교할 과목이 둘 이상일 때만 "제일 약해"라고 말한다
  const canCompareSubjects = rankedSubjects.length >= 2;

  // 틀린 횟수가 많은 순 (같으면 오답 비율이 높은 순)
  const frequentWrong = progress
    .map((p) => ({ ...p, wrong: p.attempts - p.correct, question: questionById.get(p.questionId) }))
    .filter((p): p is typeof p & { question: Question } => p.wrong > 0 && p.question !== undefined)
    .sort((a, b) => b.wrong - a.wrong || b.wrong / b.attempts - a.wrong / a.attempts)
    .slice(0, FREQUENT_WRONG_LIMIT);

  // 오래된 것 → 최신 순으로 그래프에 그린다
  const mockTrend = [...mockResults].reverse();

  const handleReset = () => setShowResetConfirm(true);

  const confirmReset = async () => {
    setShowResetConfirm(false);
    await resetStudyStats();
    await clearWrongAnswers();
    await loadAll();
  };

  // "YYYY-MM-DD" → "M/D" (Date로 파싱하면 기기 시간대에 따라 하루 밀릴 수 있어서 문자열로 자른다)
  const formatDate = (dateStr: string) => {
    const [, m, d] = dateStr.split("-");
    return `${Number(m)}/${Number(d)}`;
  };
  const achievements = [
    { icon: "play.fill" as const, label: "첫 문제 풀기", achieved: (stats?.totalAnswered ?? 0) >= 1, color: colors.primary },
    { icon: "checkmark" as const, label: "10문제 정답", achieved: (stats?.totalCorrect ?? 0) >= 10, color: colors.success },
    { icon: "doc.text.fill" as const, label: "100문제 풀이", achieved: (stats?.totalAnswered ?? 0) >= 100, color: colors.accent },
    {
      icon: "trophy.fill" as const,
      label: "정답률 70%",
      achieved: overallRate >= 70 && (stats?.totalAnswered ?? 0) >= 10,
      color: colors.warning,
    },
    // 연속 학습 배지는 최장 기록 기준이라, 연속이 끊겨도 사라지지 않는다.
    ...[3, 7, 30].map((days) => ({
      icon: "flame.fill" as const,
      label: `${days}일 연속 학습`,
      achieved: bestStreak >= days,
      color: colors.highlight,
    })),
    {
      icon: "graduationcap.fill" as const,
      label: "모의고사 합격",
      achieved: mockResults.some((r) => r.passed),
      color: colors.success,
    },
  ];
  const achievedCount = achievements.filter((a) => a.achieved).length;

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>학습 통계</Text>
          <Text style={[styles.headerSub, { color: colors.muted }]}>
            {user ? `${user.nickname || user.email} 님의 지금까지 기록` : "지금까지의 기록"}
          </Text>
        </View>

        {/* Overall: 파란 카드 하나에 숫자 4개 */}
        <View style={[styles.overall, { backgroundColor: colors.primary }]}>
          {[
            { label: "총 풀이", value: String(baseAnswered) },
            { label: "전체 정답률", value: `${overallRate}%` },
            { label: "연속 학습", value: `${stats?.streakDays ?? 0}일` },
            { label: "총 정답", value: String(baseCorrect) },
          ].map((s) => (
            <View key={s.label} style={styles.overallItem}>
              <Text style={styles.overallLabel}>{s.label}</Text>
              <Text style={styles.overallValue}>{s.value}</Text>
            </View>
          ))}
        </View>

        {/* 동그래 추천: 가장 약한 과목 */}
        <View
          style={[
            styles.tipCard,
            { backgroundColor: colors.highlight + "10", borderColor: colors.highlight + "40" },
          ]}
        >
          <Image source={CHARACTER_SOURCE} style={styles.tipCharacter} contentFit="contain" accessibilityLabel="동그래" />
          <View style={{ flex: 1, gap: 8 }}>
            {weakSubject ? (
              <>
                <Text style={[styles.tipText, { color: colors.foreground }]}>
                  {weakSubject.subject.replace(/\(.*\)$/, "")} 정답률이{" "}
                  <Text style={{ color: colors.highlight, fontWeight: "800" }}>{Math.round(weakSubject.rate * 100)}%</Text>
                  {canCompareSubjects ? "로 제일 약해. 같이 10문제 풀자!" : "야. 10문제 더 풀어 볼까?"}
                </Text>
                <Pressable
                  style={({ pressed }) => [styles.tipBtn, { backgroundColor: colors.highlight }, pressed && { opacity: 0.85 }]}
                  onPress={() => router.push({ pathname: "/quiz-session", params: { subject: weakSubject.subject } })}
                >
                  <Text style={styles.tipBtnText}>{weakSubject.subject.replace(/\(.*\)$/, "")} 10문제 풀기</Text>
                </Pressable>
              </>
            ) : (
              <Text style={[styles.tipText, { color: colors.foreground }]}>
                과목마다 {WEAK_SUBJECT_MIN_ANSWERED}문제 이상 풀면{"\n"}약한 과목을 찾아줄게!
              </Text>
            )}
          </View>
        </View>

        {/* Daily Log */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>최근 7일</Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.chartContainer}>
            {dailyLog.map((day, idx) => {
              const barHeight = Math.max((day.count / maxDailyCount) * 100, day.count > 0 ? 8 : 3);
              // 서버가 한국 시간 기준 오늘을 마지막 항목으로 돌려준다
              const isToday = idx === dailyLog.length - 1;
              return (
                <View key={day.date} style={styles.chartBar}>
                  <Text style={[styles.chartCount, { color: isToday ? colors.primary : colors.muted }, isToday && styles.bold]}>
                    {day.count}
                  </Text>
                  <View style={styles.chartBarWrap}>
                    <View
                      style={[
                        styles.chartBarFill,
                        {
                          height: barHeight,
                          backgroundColor:
                            day.count === 0 ? colors.border : isToday ? colors.primary : colors.primary + "55",
                        },
                      ]}
                    />
                  </View>
                  <Text style={[styles.chartDate, { color: isToday ? colors.primary : colors.muted }, isToday && styles.bold]}>
                    {isToday ? "오늘" : formatDate(day.date)}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Subject Stats */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>과목별 정답률</Text>
        <View style={[styles.card, styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {SUBJECTS.map((subject, idx) => {
            const answered = bySubject[subject].total;
            const correct = bySubject[subject].correct;
            const rate = answered > 0 ? Math.round((correct / answered) * 100) : 0;
            const color = SUBJECT_COLORS[subject as Subject];
            return (
              <View
                key={subject}
                style={[styles.subjectBlock, idx > 0 && { borderTopWidth: 1, borderTopColor: colors.border }]}
              >
                <View style={styles.subjectRow}>
                  <Text style={[styles.subjectName, { color: colors.foreground }]}>
                    {subject.replace(/\((.*)\)$/, " · $1")}
                  </Text>
                  <Text style={[styles.subjectMeta, { color: colors.muted }]}>
                    <Text style={{ color, fontWeight: "800" }}>{rate}%</Text>  {correct}/{answered}
                  </Text>
                </View>
                <View style={[styles.barBg, { backgroundColor: colors.border }]}>
                  <View style={[styles.barFill, { backgroundColor: color, width: `${rate}%` }]} />
                </View>
              </View>
            );
          })}
        </View>

        {/* Frequently Wrong */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>자주 틀리는 문제 TOP {FREQUENT_WRONG_LIMIT}</Text>
        <View style={[styles.card, styles.listCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {frequentWrong.length === 0 ? (
            <Text style={[styles.emptyNote, { color: colors.muted }]}>아직 틀린 문제가 없어요. 계속 풀어보세요!</Text>
          ) : (
            frequentWrong.map((item, idx) => (
              <View
                key={item.questionId}
                style={[styles.wrongRow, idx > 0 && { borderTopWidth: 1, borderTopColor: colors.border }]}
              >
                <Text style={[styles.wrongRank, { color: colors.highlight }]}>{idx + 1}</Text>
                <View style={{ flex: 1, gap: 3 }}>
                  <Text style={[styles.wrongQuestion, { color: colors.foreground }]} numberOfLines={2}>
                    {item.question.question}
                  </Text>
                  <Text style={[styles.wrongMeta, { color: colors.muted }]}>
                    {item.question.subject.replace(/\(.*\)$/, "")} · {item.attempts}번 중 {item.wrong}번 틀림
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Mock Exam Trend */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>모의고사 점수 추이</Text>
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {mockTrend.length === 0 ? (
            <Pressable onPress={() => router.push("/mock-exam")}>
              <Text style={[styles.emptyNote, { color: colors.muted }]}>
                아직 응시 기록이 없어요. 실전 모의고사에 도전해보세요 →
              </Text>
            </Pressable>
          ) : (
            <>
              <View style={styles.chartContainer}>
                <View
                  pointerEvents="none"
                  style={[
                    styles.passLine,
                    // 막대 영역(100px)은 날짜 라벨(약 13px) + gap(4px) 위에서 시작한다
                    { bottom: 17 + OVERALL_PASS_RATE * 100, borderColor: colors.success + "80" },
                  ]}
                />
                {mockTrend.map((r) => {
                  const score = Math.round((r.correct / r.total) * 100);
                  return (
                    <View key={r.id} style={styles.chartBar}>
                      <Text style={[styles.chartCount, { color: colors.muted }]}>{score}</Text>
                      <View style={styles.chartBarWrap}>
                        <View
                          style={[
                            styles.chartBarFill,
                            {
                              height: Math.max(score, 4),
                              backgroundColor: r.passed ? colors.success : colors.highlight + "99",
                            },
                          ]}
                        />
                      </View>
                      <Text style={[styles.chartDate, { color: colors.muted }]}>
                        {new Date(r.takenAt).getMonth() + 1}/{new Date(r.takenAt).getDate()}
                      </Text>
                    </View>
                  );
                })}
              </View>
              <Text style={[styles.chartNote, { color: colors.muted }]}>
                최근 {mockTrend.length}회 · 초록 = 합격 · 점선 = 합격선 {OVERALL_PASS_RATE * 100}점
              </Text>
            </>
          )}
        </View>

        {/* Achievement */}
        <View style={styles.sectionRow}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>배지</Text>
          <Text style={[styles.sectionMeta, { color: colors.muted }]}>
            {achievements.length}개 중 {achievedCount}개 달성 · 최장 {bestStreak}일 연속
          </Text>
        </View>
        <View style={styles.achievementGrid}>
          {achievements.map((item) => (
            <View
              key={item.label}
              accessibilityLabel={`${item.label} ${item.achieved ? "달성" : "미달성"}`}
              style={[
                styles.achieveCard,
                item.achieved
                  ? { backgroundColor: colors.surface, borderColor: colors.border }
                  : { backgroundColor: colors.background, borderColor: colors.border, borderStyle: "dashed" },
              ]}
            >
              <View
                style={[
                  styles.achieveIcon,
                  { backgroundColor: item.achieved ? item.color + "1F" : colors.border + "80" },
                ]}
              >
                <IconSymbol name={item.icon} size={22} color={item.achieved ? item.color : colors.muted} />
              </View>
              <Text
                style={[styles.achieveLabel, { color: item.achieved ? colors.foreground : colors.muted }]}
                numberOfLines={2}
              >
                {item.label}
              </Text>
            </View>
          ))}
        </View>

        <Pressable style={({ pressed }) => [styles.resetBtn, pressed && { opacity: 0.6 }]} onPress={handleReset}>
          <Text style={[styles.resetText, { color: colors.muted }]}>학습 기록 초기화</Text>
        </Pressable>
      </ScrollView>

      <ConfirmDialog
        visible={showResetConfirm}
        title="학습 기록 초기화"
        message="모든 학습 통계와 오답 노트가 초기화됩니다. 계속하시겠습니까?"
        confirmLabel="초기화"
        destructive
        onConfirm={confirmReset}
        onCancel={() => setShowResetConfirm(false)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scrollContent: {
    padding: 20,
    paddingBottom: 32,
    gap: 14,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  headerSub: {
    fontSize: 13,
    marginTop: 2,
  },
  overall: {
    borderRadius: 20,
    padding: 16,
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  overallItem: {
    width: "47%",
    flexGrow: 1,
    backgroundColor: "rgba(0,0,0,0.15)",
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
  },
  overallLabel: {
    fontSize: 12,
    color: "rgba(255,255,255,0.8)",
  },
  overallValue: {
    fontSize: 24,
    fontWeight: "800",
    color: "#FFFFFF",
    marginTop: 2,
  },
  tipCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderRadius: 18,
    borderWidth: 1,
    padding: 14,
  },
  tipCharacter: {
    width: 64,
    height: 64,
  },
  tipText: {
    fontSize: 14,
    lineHeight: 21,
    fontWeight: "600",
  },
  tipBtn: {
    alignSelf: "flex-start",
    height: 36,
    paddingHorizontal: 14,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  tipBtnText: {
    fontSize: 13,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "800",
    letterSpacing: -0.3,
    marginTop: 6,
  },
  sectionRow: {
    flexDirection: "row",
    alignItems: "baseline",
    justifyContent: "space-between",
    gap: 8,
  },
  sectionMeta: {
    fontSize: 12,
  },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
  },
  listCard: {
    paddingVertical: 2,
  },
  subjectBlock: {
    paddingVertical: 13,
    gap: 8,
  },
  subjectRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  subjectName: {
    fontSize: 14,
    fontWeight: "700",
    flexShrink: 1,
  },
  subjectMeta: {
    fontSize: 12,
  },
  barBg: {
    height: 8,
    borderRadius: 4,
    overflow: "hidden",
  },
  barFill: {
    height: 8,
    borderRadius: 4,
  },
  chartContainer: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    gap: 8,
    height: 150,
  },
  chartBar: {
    flex: 1,
    alignItems: "center",
    gap: 4,
  },
  chartCount: {
    fontSize: 11,
  },
  chartBarWrap: {
    width: "100%",
    height: 100,
    justifyContent: "flex-end",
  },
  chartBarFill: {
    width: "100%",
    borderTopLeftRadius: 6,
    borderTopRightRadius: 6,
    borderBottomLeftRadius: 2,
    borderBottomRightRadius: 2,
  },
  chartDate: {
    fontSize: 11,
  },
  bold: {
    fontWeight: "800",
  },
  chartNote: {
    fontSize: 12,
    marginTop: 10,
  },
  passLine: {
    position: "absolute",
    left: 0,
    right: 0,
    borderTopWidth: 1.5,
    borderStyle: "dashed",
  },
  wrongRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
    paddingVertical: 12,
  },
  wrongRank: {
    fontSize: 16,
    fontWeight: "800",
    width: 16,
  },
  wrongQuestion: {
    fontSize: 14,
    fontWeight: "600",
    lineHeight: 20,
  },
  wrongMeta: {
    fontSize: 12,
  },
  emptyNote: {
    fontSize: 14,
    textAlign: "center",
    paddingVertical: 16,
  },
  achievementGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  achieveCard: {
    width: "31%",
    flexGrow: 1,
    borderRadius: 16,
    borderWidth: 1,
    paddingVertical: 14,
    paddingHorizontal: 8,
    alignItems: "center",
    gap: 8,
  },
  achieveIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  achieveLabel: {
    fontSize: 12,
    fontWeight: "700",
    textAlign: "center",
  },
  resetBtn: {
    alignSelf: "center",
    paddingVertical: 8,
    marginTop: 4,
  },
  resetText: {
    fontSize: 13,
    textDecorationLine: "underline",
  },
});

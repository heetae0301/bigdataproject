import React, { useCallback, useState } from "react";
import {
  FlatList,
  ScrollView,
  Text,
  View,
  Pressable,
  StyleSheet,
  Modal,
  ActivityIndicator,
  StyleProp,
  ViewStyle,
} from "react-native";
import { Image } from "expo-image";
import { useFocusEffect, useRouter } from "expo-router";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { ScreenContainer } from "@/components/screen-container";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DmuExplanationPlayer } from "@/components/dmu-explanation-player";
import { useColors } from "@/hooks/use-colors";
import { loadDonguraeExplanation, type DonguraeExplanation } from "@/lib/dongurae-explanation";
import {
  getWrongAnswers,
  WrongAnswer,
  clearWrongAnswers,
  removeWrongAnswer,
} from "@/lib/storage";
import { allQuestions, Question, Subject, SUBJECT_COLORS, SUBJECTS } from "@/data/questions";
import { getPastExamRound, matchesSource } from "@/data/past-exams";
import { diffDays, kstDateStr } from "@/lib/kst-date";
import { isDueForReview, WRONG_GRADUATE_STREAK } from "@/lib/review-schedule";
import { useNotes } from "@/hooks/use-notes";
import { QuestionNote } from "@/components/question-note";
import { useTextScale } from "@/lib/app-settings";

const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/** 칩 필터: 전체 / 과목별(일반·기출 모두) / 기출만 */
type Filter = "전체" | Subject | "기출";

const questionMap = new Map<string, Question>(allQuestions.map((q) => [q.id, q]));

function matchesFilter(w: WrongAnswer, filter: Filter): boolean {
  if (filter === "전체") return true;
  if (filter === "기출") return matchesSource(w.questionId, "기출");
  return w.subject === filter;
}

function daysUntilReview(item: WrongAnswer, now: number): number {
  return diffDays(kstDateStr(new Date(now)), kstDateStr(new Date(item.nextReviewAt)));
}

function reviewLabel(item: WrongAnswer, now: number): string {
  if (isDueForReview(item, now)) return "오늘 복습";
  const days = daysUntilReview(item, now);
  return days <= 1 ? "내일 복습" : `${days}일 뒤 복습`;
}

// 선택 모드일 때만 카드 전체를 버튼으로 감싼다. 평소에도 disabled Pressable로 감싸 두면
// 웹에서 카드 안의 휴지통·메모·해설 버튼까지 "비활성 버튼 안"으로 취급된다.
function SelectableCard({
  selecting,
  checked,
  onPress,
  style,
  children,
}: {
  selecting: boolean;
  checked: boolean;
  onPress: () => void;
  style: StyleProp<ViewStyle>;
  children: React.ReactNode;
}) {
  return selecting ? (
    <Pressable accessibilityRole="checkbox" aria-checked={checked} onPress={onPress} style={style}>
      {children}
    </Pressable>
  ) : (
    <View style={style}>{children}</View>
  );
}

export default function WrongScreen() {
  const colors = useColors();
  const router = useRouter();
  const [wrongAnswers, setWrongAnswers] = useState<WrongAnswer[]>([]);
  const [filter, setFilter] = useState<Filter>("전체");
  // 해설을 펼친 카드들
  const [openIds, setOpenIds] = useState<Set<string>>(new Set());
  const [activeExplanation, setActiveExplanation] = useState<DonguraeExplanation | null>(null);
  // 칠판(자막/TTS)은 오답 맞춤 해설을 쓰지만, 하단 "해설 내용" 박스는 항상
  // 문제은행의 기본 해설을 보여준다 - 둘을 분리해서 둘 다 확인할 수 있게 한다.
  const [activeDefaultExplanation, setActiveDefaultExplanation] = useState("");
  const [generatingId, setGeneratingId] = useState<string | null>(null);

  const notes = useNotes();
  const ts = useTextScale();
  const reloadNotes = notes.reload;

  // 복습 예정 계산 기준 시각. 렌더링마다 Date.now()를 부르지 않고, 화면에 들어올 때마다 갱신한다.
  const [now, setNow] = useState(() => Date.now());

  useFocusEffect(
    useCallback(() => {
      setNow(Date.now());
      getWrongAnswers().then(setWrongAnswers).catch(() => {});
      reloadNotes();
    }, [reloadNotes])
  );

  const filtered = wrongAnswers.filter((w) => matchesFilter(w, filter));
  const dueCount = filtered.filter((w) => isDueForReview(w, now)).length;
  const tomorrowCount = filtered.filter((w) => !isDueForReview(w, now) && daysUntilReview(w, now) <= 1).length;
  const laterCount = filtered.length - dueCount - tomorrowCount;

  const filterChips: { value: Filter; label: string; count: number }[] = [
    { value: "전체", label: "전체", count: wrongAnswers.length },
    ...SUBJECTS.map((s) => ({
      value: s as Filter,
      label: s.replace(/\(.*\)$/, ""),
      count: wrongAnswers.filter((w) => w.subject === s).length,
    })),
    { value: "기출", label: "기출", count: wrongAnswers.filter((w) => matchesSource(w.questionId, "기출")).length },
  ];

  // Alert.alert는 웹에서 no-op이라 ConfirmDialog로 확인한다.
  const [confirmingClear, setConfirmingClear] = useState(false);
  const confirmClearAll = async () => {
    setConfirmingClear(false);
    await clearWrongAnswers();
    setWrongAnswers([]);
  };

  // 선택 모드: 카드를 눌러 체크하고 한꺼번에 삭제한다. 삭제는 지금 필터에
  // 보이는 카드 중 체크된 것만 대상으로 해서, 안 보이는 오답이 같이 지워지지 않게 한다.
  const [selecting, setSelecting] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [confirmingBulk, setConfirmingBulk] = useState(false);
  const selectedVisible = filtered.filter((w) => selectedIds.has(w.questionId));
  const allVisibleSelected = filtered.length > 0 && selectedVisible.length === filtered.length;

  const exitSelecting = () => {
    setSelecting(false);
    setSelectedIds(new Set());
  };
  const toggleSelected = (questionId: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(questionId)) next.delete(questionId);
      else next.add(questionId);
      return next;
    });
  };
  const toggleSelectAll = () => {
    setSelectedIds(allVisibleSelected ? new Set() : new Set(filtered.map((w) => w.questionId)));
  };
  const confirmDeleteSelected = async () => {
    setConfirmingBulk(false);
    const ids = selectedVisible.map((w) => w.questionId);
    const results = await Promise.allSettled(ids.map((id) => removeWrongAnswer(id)));
    const removed = new Set(ids.filter((_, i) => results[i].status === "fulfilled"));
    if (removed.size < ids.length) {
      console.warn(`[Wrong] Failed to remove ${ids.length - removed.size} wrong answers`);
    }
    setWrongAnswers((prev) => prev.filter((w) => !removed.has(w.questionId)));
    exitSelecting();
  };

  const [deletingId, setDeletingId] = useState<string | null>(null);
  const confirmDeleteOne = async () => {
    const questionId = deletingId;
    setDeletingId(null);
    if (!questionId) return;
    try {
      await removeWrongAnswer(questionId);
      setWrongAnswers((prev) => prev.filter((w) => w.questionId !== questionId));
    } catch (error) {
      console.warn("[Wrong] Failed to remove wrong answer:", error);
    }
  };

  const handleRetry = (mode: "due" | "all") => {
    if (filtered.length === 0) return;
    router.push({
      pathname: "/wrong-session",
      params: {
        filter: filter === "전체" || filter === "기출" ? "오답_전체" : filter,
        mode,
        source: filter === "기출" ? "기출" : "전체",
      },
    });
  };

  const toggleOpen = (questionId: string) => {
    setOpenIds((prev) => {
      const next = new Set(prev);
      if (next.has(questionId)) next.delete(questionId);
      else next.add(questionId);
      return next;
    });
  };

  const handleShowDmuExplanation = async (item: WrongAnswer, q: Question) => {
    if (generatingId) return;
    setGeneratingId(item.questionId);
    setActiveDefaultExplanation(q.explanation);
    try {
      setActiveExplanation(await loadDonguraeExplanation(q, item.selectedOption));
    } finally {
      setGeneratingId(null);
    }
  };

  const listHeader = (
    <View style={styles.listHeader}>
      {/* 오늘 복습 카드 */}
      {!selecting && filtered.length > 0 && (
        <View style={[styles.dueCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.dueTop}>
            <View style={[styles.dueBadge, { backgroundColor: colors.highlight + "1A" }]}>
              <Text style={[styles.dueBadgeNum, { color: colors.highlight }]}>{dueCount}</Text>
              <Text style={[styles.dueBadgeUnit, { color: colors.highlight }]}>문제</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.dueTitle, { color: colors.foreground }]}>오늘 복습할 오답</Text>
              <Text style={[styles.dueSub, { color: colors.muted }]}>
                {tomorrowCount + laterCount === 0
                  ? "남은 복습 일정이 없어요"
                  : [tomorrowCount > 0 && `내일 ${tomorrowCount}문제`, laterCount > 0 && `이후 ${laterCount}문제`]
                      .filter(Boolean)
                      .join(" · ")}
              </Text>
            </View>
          </View>
          <View style={styles.dueBtns}>
            <Pressable
              style={({ pressed }) => [
                styles.dueBtn,
                { flex: 1.3, backgroundColor: colors.highlight },
                dueCount === 0 && { opacity: 0.4 },
                pressed && dueCount > 0 && { opacity: 0.85 },
              ]}
              onPress={() => handleRetry("due")}
              disabled={dueCount === 0}
            >
              <Text style={[styles.dueBtnText, { color: "#FFFFFF" }]}>오늘 복습 ({dueCount})</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [
                styles.dueBtn,
                { flex: 1, backgroundColor: colors.background, borderColor: colors.border, borderWidth: 1 },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => handleRetry("all")}
            >
              <Text style={[styles.dueBtnText, { color: colors.foreground }]}>전체 ({filtered.length})</Text>
            </Pressable>
          </View>
          <Text style={[styles.dueHint, { color: colors.muted }]}>
            복습일에 {WRONG_GRADUATE_STREAK}번 맞히면 졸업해요 (1일 → 3일 → 7일 간격)
          </Text>
        </View>
      )}

      {/* 필터 칩 */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipRow}>
        {filterChips.map((chip) => {
          const active = filter === chip.value;
          return (
            <Pressable
              key={chip.value}
              accessibilityRole="tab"
              aria-selected={active}
              style={({ pressed }) => [
                styles.chip,
                active
                  ? { backgroundColor: colors.foreground, borderColor: colors.foreground }
                  : { backgroundColor: colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => setFilter(chip.value)}
            >
              <Text style={[styles.chipText, { color: active ? colors.background : colors.foreground }]}>
                {chip.label} {chip.count}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={styles.header}>
        <View style={{ flexShrink: 1 }}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>오답 노트</Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
            {wrongAnswers.length}개의 오답 · {WRONG_GRADUATE_STREAK}번 맞히면 졸업
          </Text>
        </View>
        {wrongAnswers.length > 0 && (
          <View style={styles.headerActions}>
            <Pressable
              hitSlop={8}
              style={({ pressed }) => [
                styles.headerActionBtn,
                { borderColor: colors.primary },
                pressed && { opacity: 0.6 },
              ]}
              onPress={selecting ? exitSelecting : () => setSelecting(true)}
            >
              <Text style={[styles.headerActionText, { color: colors.primary }]}>{selecting ? "취소" : "선택"}</Text>
            </Pressable>
            {!selecting && (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="오답 노트 전체 삭제"
                hitSlop={8}
                style={({ pressed }) => [pressed && { opacity: 0.6 }]}
                onPress={() => setConfirmingClear(true)}
              >
                <IconSymbol name="trash.fill" size={20} color={colors.muted} />
              </Pressable>
            )}
          </View>
        )}
      </View>

      {wrongAnswers.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Image source={CHARACTER_SOURCE} style={styles.emptyCharacter} contentFit="contain" />
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>오답이 없습니다!</Text>
          <Text style={[styles.emptyDesc, { color: colors.muted }]}>문제를 풀다 틀리면 여기에 자동으로 모여요</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.questionId}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={listHeader}
          ListEmptyComponent={
            <Text style={[styles.emptyFilter, { color: colors.muted }]}>이 분류에는 오답이 없어요</Text>
          }
          renderItem={({ item }) => {
            const q = questionMap.get(item.questionId);
            if (!q) return null;
            const subjectColor = SUBJECT_COLORS[item.subject];
            const pastRound = getPastExamRound(item.questionId);
            const isSelected = selecting && selectedIds.has(item.questionId);
            const isOpen = openIds.has(item.questionId);
            const due = isDueForReview(item, now);
            return (
              <SelectableCard
                selecting={selecting}
                checked={isSelected}
                onPress={() => toggleSelected(item.questionId)}
                style={[
                  styles.wrongCard,
                  {
                    backgroundColor: isSelected ? colors.primary + "0D" : colors.surface,
                    borderColor: isSelected ? colors.primary : colors.border,
                  },
                ]}
              >
                <View style={styles.cardHeader}>
                  <View style={styles.badgeRow}>
                    {selecting && (
                      <IconSymbol
                        name={isSelected ? "checkmark.circle.fill" : "circle"}
                        size={22}
                        color={isSelected ? colors.primary : colors.muted}
                      />
                    )}
                    <View style={[styles.badge, { backgroundColor: subjectColor + "1A" }]}>
                      <Text style={[styles.badgeText, { color: subjectColor }]}>
                        {item.subject.replace(/\(.*\)$/, "")}
                      </Text>
                    </View>
                    {pastRound !== null && (
                      <View style={[styles.badge, { backgroundColor: colors.foreground + "12" }]}>
                        <Text style={[styles.badgeText, { color: colors.foreground }]}>제{pastRound}회 기출</Text>
                      </View>
                    )}
                    <View
                      style={[
                        styles.badge,
                        { backgroundColor: due ? colors.highlight + "1A" : colors.muted + "1A" },
                      ]}
                    >
                      <Text style={[styles.badgeText, { color: due ? colors.highlight : colors.muted }]}>
                        {reviewLabel(item, now)}
                      </Text>
                    </View>
                  </View>
                  <View style={styles.reviewDots}>
                    {Array.from({ length: WRONG_GRADUATE_STREAK }, (_, i) => (
                      <View
                        key={i}
                        style={[
                          styles.reviewDot,
                          { backgroundColor: i < item.correctStreak ? colors.success : colors.border },
                        ]}
                      />
                    ))}
                  </View>
                </View>

                <Text style={[styles.question, ts(15, 23), { color: colors.foreground }]} numberOfLines={isOpen ? undefined : 3}>
                  {q.question}
                </Text>

                <View style={styles.answers}>
                  <Text style={[styles.answerLine, ts(13, 19), { color: colors.foreground }]}>
                    <Text style={[styles.answerTag, { color: colors.highlight }]}>내 답: </Text>
                    {q.options[item.selectedOption]}
                  </Text>
                  <Text style={[styles.answerLine, ts(13, 19), { color: colors.foreground }]}>
                    <Text style={[styles.answerTag, { color: colors.success }]}>정답: </Text>
                    {q.options[q.answer]}
                  </Text>
                </View>

                {isOpen && !selecting && (
                  <View style={styles.openArea}>
                    <View style={[styles.explanationBox, { backgroundColor: colors.background }]}>
                      <Text style={[styles.explanationLabel, { color: colors.muted }]}>해설</Text>
                      <Text style={[styles.explanationText, ts(14, 22), { color: colors.foreground }]}>
                        {q.explanation}
                      </Text>
                    </View>
                    <QuestionNote
                      collapsible
                      note={notes.get(item.questionId)}
                      onSave={(note) => notes.save(item.questionId, note)}
                    />
                  </View>
                )}

                {!selecting && (
                  <View style={[styles.actions, { borderTopColor: colors.border }]}>
                    <Pressable
                      style={({ pressed }) => [
                        styles.actionBtn,
                        { backgroundColor: colors.background, borderColor: colors.border },
                        pressed && { opacity: 0.7 },
                      ]}
                      onPress={() => toggleOpen(item.questionId)}
                    >
                      <Text style={[styles.actionText, { color: colors.foreground }]}>
                        {isOpen ? "해설 접기" : "해설 보기"}
                      </Text>
                    </Pressable>
                    <Pressable
                      style={({ pressed }) => [
                        styles.actionBtn,
                        { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
                        (pressed || generatingId === item.questionId) && { opacity: 0.7 },
                      ]}
                      onPress={() => handleShowDmuExplanation(item, q)}
                      disabled={generatingId !== null}
                    >
                      {generatingId === item.questionId ? (
                        <ActivityIndicator size="small" color={colors.primary} />
                      ) : (
                        <Text style={[styles.actionText, { color: colors.primary }]}>동그래 해설</Text>
                      )}
                    </Pressable>
                    <Pressable
                      accessibilityRole="button"
                      accessibilityLabel="이 오답 삭제"
                      style={({ pressed }) => [
                        styles.trashBtn,
                        { backgroundColor: colors.surface, borderColor: colors.border },
                        pressed && { opacity: 0.6 },
                      ]}
                      onPress={() => setDeletingId(item.questionId)}
                    >
                      <IconSymbol name="trash.fill" size={16} color={colors.muted} />
                    </Pressable>
                  </View>
                )}
              </SelectableCard>
            );
          }}
        />
      )}

      {/* 선택 모드 하단 바 */}
      {selecting && filtered.length > 0 && (
        <View style={[styles.selectBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable
            style={({ pressed }) => [styles.selectAllBtn, pressed && { opacity: 0.6 }]}
            onPress={toggleSelectAll}
          >
            <IconSymbol
              name={allVisibleSelected ? "checkmark.circle.fill" : "circle"}
              size={20}
              color={allVisibleSelected ? colors.primary : colors.muted}
            />
            <Text style={[styles.selectAllText, { color: colors.foreground }]}>전체 선택</Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [
              styles.bulkDeleteBtn,
              { backgroundColor: colors.error },
              selectedVisible.length === 0 && { opacity: 0.4 },
              pressed && { opacity: 0.85 },
            ]}
            disabled={selectedVisible.length === 0}
            onPress={() => setConfirmingBulk(true)}
          >
            <IconSymbol name="trash.fill" size={16} color="#FFFFFF" />
            <Text style={styles.bulkDeleteText}>{selectedVisible.length}개 삭제</Text>
          </Pressable>
        </View>
      )}

      {/*
        RN의 Modal은 별도 네이티브 창(윈도우)에 렌더링되기 때문에, 앱 루트의
        GestureHandlerRootView 밖으로 벗어난다. 그 상태에서는 gesture-handler가
        터치 시스템을 가로채면서 안쪽의 일반 PanResponder(동그래 해설의 스와이프
        닫기)가 move 이벤트를 못 받는 문제가 생겨서, Modal 안에 별도로 하나 더
        둬야 한다.
      */}
      <Modal
        visible={activeExplanation !== null}
        animationType="slide"
        onRequestClose={() => setActiveExplanation(null)}
      >
        <GestureHandlerRootView style={{ flex: 1 }}>
          <ScreenContainer>
            <DmuExplanationPlayer
              explanation={activeExplanation?.explanation ?? ""}
              scenes={activeExplanation?.scenes}
              questionText={activeExplanation?.question}
              referenceExplanation={activeDefaultExplanation}
              onClose={() => setActiveExplanation(null)}
            />
          </ScreenContainer>
        </GestureHandlerRootView>
      </Modal>
      <ConfirmDialog
        visible={confirmingClear}
        title="오답 노트 초기화"
        message="모든 오답을 삭제하시겠습니까?"
        confirmLabel="삭제"
        destructive
        onConfirm={confirmClearAll}
        onCancel={() => setConfirmingClear(false)}
      />
      <ConfirmDialog
        visible={deletingId !== null}
        title="오답 삭제"
        message="이 문제를 오답 노트에서 삭제하시겠습니까?"
        confirmLabel="삭제"
        destructive
        onConfirm={confirmDeleteOne}
        onCancel={() => setDeletingId(null)}
      />
      <ConfirmDialog
        visible={confirmingBulk}
        title="선택한 오답 삭제"
        message={`선택한 ${selectedVisible.length}개의 문제를 오답 노트에서 삭제하시겠습니까?`}
        confirmLabel="삭제"
        destructive
        onConfirm={confirmDeleteSelected}
        onCancel={() => setConfirmingBulk(false)}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
    gap: 12,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: "800",
    letterSpacing: -0.5,
  },
  headerSubtitle: {
    fontSize: 13,
    marginTop: 2,
  },
  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  headerActionBtn: {
    borderWidth: 1.5,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  headerActionText: {
    fontSize: 14,
    fontWeight: "700",
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 32,
    gap: 12,
  },
  listHeader: {
    gap: 12,
    marginBottom: 2,
  },
  dueCard: {
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
    gap: 12,
  },
  dueTop: {
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  dueBadge: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  dueBadgeNum: {
    fontSize: 22,
    fontWeight: "800",
    lineHeight: 24,
  },
  dueBadgeUnit: {
    fontSize: 10,
    fontWeight: "700",
  },
  dueTitle: {
    fontSize: 16,
    fontWeight: "800",
  },
  dueSub: {
    fontSize: 12,
    marginTop: 2,
  },
  dueBtns: {
    flexDirection: "row",
    gap: 8,
  },
  dueBtn: {
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  dueBtnText: {
    fontSize: 14,
    fontWeight: "800",
  },
  dueHint: {
    fontSize: 12,
  },
  chipRow: {
    gap: 8,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 999,
    borderWidth: 1,
  },
  chipText: {
    fontSize: 13,
    fontWeight: "700",
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingBottom: 60,
  },
  emptyCharacter: {
    width: 120,
    height: 120,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "800",
  },
  emptyDesc: {
    fontSize: 14,
    textAlign: "center",
    lineHeight: 22,
  },
  emptyFilter: {
    fontSize: 14,
    textAlign: "center",
    paddingVertical: 32,
  },
  wrongCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    gap: 10,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 8,
  },
  badgeRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    alignItems: "center",
    gap: 6,
    flexShrink: 1,
  },
  badge: {
    paddingHorizontal: 9,
    paddingVertical: 3,
    borderRadius: 999,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "700",
  },
  reviewDots: {
    flexDirection: "row",
    gap: 4,
  },
  reviewDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  question: {
    fontSize: 15,
    fontWeight: "700",
    lineHeight: 23,
  },
  answers: {
    gap: 6,
  },
  answerLine: {
    fontSize: 13,
    lineHeight: 19,
  },
  answerTag: {
    fontWeight: "800",
  },
  openArea: {
    gap: 8,
  },
  explanationBox: {
    borderRadius: 12,
    padding: 12,
    gap: 4,
  },
  explanationLabel: {
    fontSize: 12,
    fontWeight: "800",
  },
  explanationText: {
    fontSize: 14,
    lineHeight: 22,
  },
  actions: {
    flexDirection: "row",
    gap: 8,
    borderTopWidth: 1,
    paddingTop: 10,
  },
  actionBtn: {
    flex: 1,
    height: 38,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  actionText: {
    fontSize: 13,
    fontWeight: "700",
  },
  trashBtn: {
    width: 38,
    height: 38,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  selectBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderTopWidth: 1,
  },
  selectAllBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  selectAllText: {
    fontSize: 14,
    fontWeight: "600",
  },
  bulkDeleteBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  bulkDeleteText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFFFFF",
  },
});

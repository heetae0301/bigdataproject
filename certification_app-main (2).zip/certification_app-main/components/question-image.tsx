import React from "react";
import { StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { QUESTION_IMAGES } from "@/data/question-images";
import { useColors } from "@/hooks/use-colors";

interface QuestionImageProps {
  imageKey?: string;
}

// 그림 높이 상한. 폭을 꽉 채우면 세로로 긴 그림(박스플롯 등)이 화면보다 커지므로
// 높이가 이 값을 넘지 않도록 폭을 비율에 맞춰 줄인다.
const MAX_IMAGE_HEIGHT = 220;

// 문제에 딸린 그림(박스플롯, 덴드로그램 등)을 표시한다. 이미지가 없으면 아무것도 그리지 않는다.
export function QuestionImage({ imageKey }: QuestionImageProps) {
  const colors = useColors();
  const asset = imageKey ? QUESTION_IMAGES[imageKey] : undefined;
  if (!asset) return null;

  return (
    <View
      style={[
        styles.container,
        { borderColor: colors.border, maxWidth: MAX_IMAGE_HEIGHT * asset.aspectRatio },
      ]}
    >
      <Image
        source={asset.source}
        style={{ width: "100%", aspectRatio: asset.aspectRatio }}
        contentFit="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
    alignSelf: "center",
    marginTop: 12,
    borderWidth: 1,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "#FFFFFF",
  },
});

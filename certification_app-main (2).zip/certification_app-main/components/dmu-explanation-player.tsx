import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import {
  View,
  Text,
  Pressable,
  ScrollView,
  StyleSheet,
  Animated,
  Platform,
  Easing,
  ActivityIndicator,
  useWindowDimensions,
} from "react-native";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { Image } from "expo-image";
import * as Speech from "expo-speech";
import { createAudioPlayer, setAudioModeAsync, type AudioPlayer } from "expo-audio";
import { getApiBaseUrl } from "@/constants/api";
import { trpcVanilla } from "@/lib/trpc";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import {
  splitIntoSentenceSegments,
  findSegmentForCharIndex,
  type SentenceSegment,
} from "@/lib/ai-service";
import { SceneBoard } from "@/components/scene-board";
import { sceneNarrationText, type ExplanationScene } from "@/lib/explanation-scenes";

const DONGGURAECHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

// expo-speech가 ios/android에서 발화 위치(onBoundary)를 얼마나 빨리 보내는지는
// 단말/엔진마다 다르다. 이 시간 안에 첫 이벤트가 안 오면 "이 기기는 onBoundary를
// 지원하지 않는다"고 보고 추정 시간 기반 폴백으로 전환한다.
const BOUNDARY_GRACE_MS = 600;
// AI 목소리: 처음 듣는 해설은 서버가 음성을 만드는 데 1~3분이 걸리기도 한다(재시도·대체 모델 포함).
// 중간에 폰 목소리로 넘어가면 같은 해설을 폰 목소리로 끝까지 듣게 되므로, 준비될 때까지 기다린다.
// 이 시간은 서버가 응답 없이 멈췄을 때를 대비한 안전장치일 뿐이다.
const AI_VOICE_PREPARE_TIMEOUT_MS = 300_000;
// 음성 파일을 받아 재생이 시작되기까지 기다리는 최대 시간. WAV가 1~3MB라 Render에서 받는 데
// 8초로는 모자란 경우가 있어 넉넉히 잡고, 그래도 안 되면 한 번은 자동으로 다시 받아 본다.
const AI_VOICE_START_TIMEOUT_MS = 20_000;
const AI_VOICE_START_RETRIES = 1;
const SPEECH_RATE = Platform.OS === "ios" ? 0.58 : 1.1;

export interface DmuExplanationPlayerProps {
  /** 칠판에서 자막으로 보여주고 TTS로 읽어주는 해설 (오답 맞춤 해설, 실패 시 기본 해설로 대체됨) */
  explanation: string;
  /** 하단 "해설 내용" 박스에 표시할 텍스트. 생략하면 explanation을 그대로 보여준다
   *  (오답노트에서는 항상 기본 해설을 넘겨서, 맞춤 해설과 별개로 원문 해설도 읽을 수 있게 한다). */
  referenceExplanation?: string;
  /** 그림 해설 장면(server/lib/scene-script.ts). 있으면 칠판에 장면 그림을 그리고, 대사를 이어 붙여
   *  목소리로 읽으며(explanation 대신), 자막은 칠판 아래에 보여준다. 없으면 기존처럼 칠판에 자막만 띄운다. */
  scenes?: ExplanationScene[];
  /** 문제 본문. 그림 해설의 보기 장면에서 보기 위에 같이 보여준다. */
  questionText?: string;
  onClose: () => void;
  characterSize?: number;
}

/**
 * 텍스트 길이 기반으로 대략적인 발화 시간을 추정한다 (폴백 전용).
 * 실제 재생 중에는 onBoundary가 정확한 위치를 알려주므로 이 추정치는
 * onBoundary를 못 받는 기기에서만 쓰인다.
 */
function estimateSpeechDurationSeconds(text: string, rate: number): number {
  const syllablesPerSecond = 6; // 평균적인 한국어 발화 속도 근사치
  const base = text.length / syllablesPerSecond;
  const adjusted = base / rate;
  return Math.max(2, Math.min(180, adjusted));
}

type FallbackWindow = SentenceSegment & { startTime: number; endTime: number };

/** 초 → "m:ss" */
function formatTime(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

/**
 * AI 목소리를 못 만든 이유 (화면에 안내). TOO_MANY_REQUESTS는 AI 요청 한도에 걸렸다는 뜻이다
 * (server/lib/ai.ts withFallback). 분당 한도일 수도 있어서 "오늘은 안 된다"고 단정하지 않는다.
 */
function aiVoiceFailNotice(error: unknown): string {
  const code = (error as { data?: { code?: string } } | null)?.data?.code;
  if (code === "TOO_MANY_REQUESTS") {
    return "AI 목소리 사용 한도에 걸렸어요. 잠시 후 다시 시도하거나, 폰 목소리로 들어보세요.";
  }
  if (code === "SERVICE_UNAVAILABLE") return "AI 서버가 바빠요. 잠시 후 다시 시도해 주세요.";
  if (error instanceof Error && error.message === "timeout") {
    return "목소리를 만드는 데 너무 오래 걸렸어요. 잠시 후 다시 시도해 주세요.";
  }
  return "동그래 목소리를 불러오지 못했어요. 다시 시도해 주세요.";
}

/** 총 재생 시간을 문장 길이(글자 수)에 비례해 나눠, 문장별 자막 표시 구간을 만든다. */
function windowsFor(segments: SentenceSegment[], totalSec: number): FallbackWindow[] {
  const totalChars = segments.reduce((sum, seg) => sum + (seg.endChar - seg.startChar), 0);
  let cursor = 0;
  return segments.map((seg) => {
    const segChars = seg.endChar - seg.startChar;
    const duration = totalChars > 0 ? (segChars / totalChars) * totalSec : 0;
    const startTime = cursor;
    cursor += duration;
    return { ...seg, startTime, endTime: cursor };
  });
}

export function DmuExplanationPlayer({
  explanation,
  referenceExplanation,
  scenes,
  questionText,
  onClose,
  characterSize: baseCharacterSize = 90,
}: DmuExplanationPlayerProps) {
  const colors = useColors();
  const hasScenes = !!scenes && scenes.length > 0;
  // 그림 해설에서는 칠판을 그림이 써야 하므로 캐릭터를 조금 작게 띄운다
  const characterSize = hasScenes ? Math.round(baseCharacterSize * 0.72) : baseCharacterSize;

  const [isPlaying, setIsPlaying] = useState(false);
  // AI 목소리를 서버에서 만드는 중 (재생 버튼에 "목소리 준비 중" 표시)
  const [preparing, setPreparing] = useState(false);
  const preparingRef = useRef(false);
  const audioPlayerRef = useRef<AudioPlayer | null>(null);
  // 화면이 닫혔는지 — 음성 준비가 끝났을 때 이미 닫혔으면 재생하지 않는다
  const closedRef = useRef(false);
  // AI 목소리 준비 기다림을 끝내는 함수 (준비 중에만 설정됨, 화면을 닫을 때 쓴다)
  const skipAiWaitRef = useRef<(() => void) | null>(null);
  // 준비 중 경과 시간(초) 표시용
  const [preparingSec, setPreparingSec] = useState(0);
  // 폰 목소리로 대신 읽을 때 그 이유
  // AI 목소리를 못 만들었을 때 그 이유 (다시 시도 / 폰 목소리로 듣기 버튼과 함께 표시)
  const [aiFailNotice, setAiFailNotice] = useState<string | null>(null);
  // 사용자가 "폰 목소리로 듣기"를 골라서 지금 폰 목소리로 읽는 중인지
  const [usingDeviceVoice, setUsingDeviceVoice] = useState(false);
  // AI 목소리 파일은 준비됐지만 아직 받아오는 중이라 소리가 시작되지 않은 상태.
  // 이때 "일시정지"를 보여주면 눌러도 반응 없는 것처럼 보여서, 불러오는 중이라고 따로 보여준다.
  const [buffering, setBuffering] = useState(false);
  useEffect(() => {
    if (!preparing) return;
    const startedAt = Date.now();
    const id = setInterval(() => setPreparingSec(Math.floor((Date.now() - startedAt) / 1000)), 1000);
    // 준비가 끝나면(정리 시점) 경과 시간을 0으로 되돌린다
    return () => {
      clearInterval(id);
      setPreparingSec(0);
    };
  }, [preparing]);
  const [currentSegment, setCurrentSegment] = useState<SentenceSegment | null>(null);
  const [progress, setProgress] = useState(0);

  const [bodyBounce] = useState(() => new Animated.Value(0));
  const [subtitleOpacity] = useState(() => new Animated.Value(1));
  // 말할 때마다(단어 경계마다) 짧게 통통 튀는 "입 모양" 대용 펄스
  const [scaleAnim] = useState(() => new Animated.Value(1));
  // 해설 중에만 쓰는 "생생하게 설명하는" 느낌의 추가 모션들
  const [wiggleAnim] = useState(() => new Animated.Value(0));
  const [pointerAnim] = useState(() => new Animated.Value(0));
  // 아래로 스와이프해서 닫을 때 화면을 손가락 따라 살짝 끌어내리는 용도
  const [swipeTranslateY] = useState(() => new Animated.Value(0));
  // 왼쪽 가장자리에서 오른쪽으로 밀어 뒤로 갈 때 화면을 손가락 따라 옆으로 미는 용도
  const [swipeTranslateX] = useState(() => new Animated.Value(0));
  const { width: screenWidth } = useWindowDimensions();

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const bodyAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const talkPulseRef = useRef<Animated.CompositeAnimation | null>(null);
  const wiggleAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const pointerAnimRef = useRef<Animated.CompositeAnimation | null>(null);
  const startTimeRef = useRef<number>(0);
  const isPlayingRef = useRef(false);
  const hasBoundaryFiredRef = useRef(false);
  const fallbackModeRef = useRef(false);
  const lastFallbackPulseMsRef = useRef(0);

  // 일시정지 / 10초 이동
  const [isPaused, setIsPaused] = useState(false);
  const isPausedRef = useRef(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [totalSec, setTotalSec] = useState(0);
  // 지금 재생 중인 경로: AI 목소리(오디오 파일) 또는 폰 목소리(expo-speech)
  const modeRef = useRef<"ai" | "device" | null>(null);
  // 폰 목소리는 일시정지·되감기를 지원하지 않는 기기가 많아서, 읽던 글자 위치를 기억해 뒀다가
  // 그 위치부터 다시 읽는 방식으로 구현한다. 다시 읽기 시작할 때마다 세대 번호를 올려서
  // 멈춘 이전 발화의 콜백(onDone, 웹의 onError("interrupted") 등)이 새 재생을 끊지 않게 한다.
  const speechGenRef = useRef(0);
  const devicePosRef = useRef(0);

  // 실제로 화면에 표시/발화되는 정규화된 텍스트. onBoundary의 charIndex는
  // 이 문자열 기준 위치이므로, 세그먼트 분할도 반드시 같은 문자열로 해야 한다.
  // 그림 해설이면 장면 대사를 이어 붙인 대본을 읽는다.
  const cleanText = useMemo(
    () => (hasScenes ? sceneNarrationText(scenes!) : explanation.replace(/\s+/g, " ").trim()),
    [hasScenes, scenes, explanation]
  );

  // 자막 단위: 그림 해설은 장면 하나가 한 단위(장면 전환 = 자막 전환), 아니면 문장 단위.
  // sceneNarrationText가 대사를 공백 하나로 이어 붙이므로 같은 규칙으로 위치를 계산한다.
  const segments = useMemo(() => {
    if (!hasScenes) return splitIntoSentenceSegments(cleanText);
    let cursor = 0;
    return scenes!.map((scene) => {
      const text = scene.narration.replace(/\s+/g, " ").trim();
      const seg = { startChar: cursor, endChar: cursor + text.length, text };
      cursor += text.length + 1;
      return seg;
    });
  }, [hasScenes, scenes, cleanText]);

  // 지금 보여줄 장면 (재생 전에는 첫 장면을 미리 그려 둔다)
  const sceneIndex = hasScenes && currentSegment
    ? Math.max(0, segments.findIndex((seg) => seg.startChar === currentSegment.startChar))
    : 0;

  const estimatedDurationSec = useMemo(
    () => estimateSpeechDurationSeconds(cleanText, SPEECH_RATE),
    [cleanText]
  );

  useEffect(() => {
    if (!currentSegment) return;
    Animated.sequence([
      Animated.timing(subtitleOpacity, {
        toValue: 0,
        duration: 60,
        useNativeDriver: true,
      }),
      Animated.timing(subtitleOpacity, {
        toValue: 1,
        duration: 120,
        useNativeDriver: true,
      }),
    ]).start();
  }, [currentSegment, subtitleOpacity]);

  // 진폭/시간에 ±지터를 줘서, 완벽히 똑같은 주기로 반복되는 "로봇 같은" 느낌을
  // 없앤다. 사람의 움직임은 매번 조금씩 다르다는 점을 흉내낸 것.
  const withJitter = (base: number, ratio: number) => base * (1 - ratio + Math.random() * ratio * 2);

  // 평소(대기)에는 잔잔하게 숨쉬듯, 해설 중에는 더 크고 빠르게 - 진폭/속도만
  // 바꿔서 같은 bodyBounce 값을 재사용한다 (전환 시 이전 사이클을 멈추고 새로
  // 시작한다). Animated.loop 대신 매 사이클마다 스스로 다시 예약하는 방식이라
  // 사이클마다 진폭/시간을 살짝씩 다르게 줄 수 있다.
  const runBodyBounceLoop = useCallback(
    (amplitude: number, durationMs: number) => {
      bodyAnimRef.current?.stop();
      bodyBounce.setValue(0);

      const cycle = () => {
        const amp = withJitter(amplitude, 0.18);
        const dur = withJitter(durationMs, 0.18);
        const seq = Animated.sequence([
          Animated.timing(bodyBounce, {
            toValue: -amp,
            duration: dur,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(bodyBounce, {
            toValue: 0,
            duration: dur,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
        ]);
        bodyAnimRef.current = seq;
        seq.start(({ finished }) => {
          if (finished) cycle();
        });
      };
      cycle();
    },
    [bodyBounce]
  );

  // 대기 상태에서도 캐릭터가 완전히 멈춰있지 않도록, 마운트되면 바로 잔잔한
  // 숨쉬기 루프를 시작한다.
  useEffect(() => {
    runBodyBounceLoop(4, 900);
  }, [runBodyBounceLoop]);

  // 단어 경계(onBoundary)마다 짧게 통통 튀며 "말하는" 인상을 준다. 별도의
  // 입 모양 이미지가 없어서 정확한 립싱크는 아니지만, 고정 주기 반복 대신
  // 실제 발화 타이밍에 맞춰 튀기 때문에 훨씬 자연스럽게 느껴진다.
  const triggerTalkPulse = useCallback(() => {
    talkPulseRef.current?.stop();
    const seq = Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.05 + Math.random() * 0.03,
        duration: 90,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 130,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]);
    talkPulseRef.current = seq;
    seq.start();
  }, [scaleAnim]);

  const startAnimations = useCallback(() => {
    // 해설 중에는 더 크고 활발하게 - 실제로 설명하는 듯한 인상을 준다.
    // (입 모양 펄스는 더 이상 여기서 고정 주기로 돌리지 않고, onBoundary/폴백
    // 타이머에서 실제 발화 타이밍에 맞춰 triggerTalkPulse()를 호출한다.)
    runBodyBounceLoop(9, 320);

    // 고개를 갸웃거리듯 좌우로 살짝 흔들어 "설명하고 있다"는 느낌을 더한다.
    // bodyBounce와 마찬가지로 매 사이클 진폭/시간에 지터를 줘서 기계적으로
    // 반복되는 느낌을 없앤다.
    const wiggleCycle = () => {
      const seq = Animated.sequence([
        Animated.timing(wiggleAnim, {
          toValue: withJitter(1, 0.2),
          duration: withJitter(420, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(wiggleAnim, {
          toValue: withJitter(-1, 0.2),
          duration: withJitter(840, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(wiggleAnim, {
          toValue: 0,
          duration: withJitter(420, 0.25),
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]);
      wiggleAnimRef.current = seq;
      seq.start(({ finished }) => {
        if (finished) wiggleCycle();
      });
    };
    wiggleCycle();

    // 칠판을 톡톡 짚어가며 설명하는 듯한 포인터(분필) 모션.
    const pointerCycle = () => {
      const seq = Animated.sequence([
        Animated.timing(pointerAnim, {
          toValue: 1,
          duration: 260,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(pointerAnim, {
          toValue: 0,
          duration: 260,
          easing: Easing.in(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.delay(withJitter(500, 0.3)),
      ]);
      pointerAnimRef.current = seq;
      seq.start(({ finished }) => {
        if (finished) pointerCycle();
      });
    };
    pointerCycle();
  }, [runBodyBounceLoop, wiggleAnim, pointerAnim]);

  const stopAnimations = useCallback(() => {
    talkPulseRef.current?.stop();
    talkPulseRef.current = null;
    scaleAnim.setValue(1);

    wiggleAnimRef.current?.stop();
    wiggleAnimRef.current = null;
    wiggleAnim.setValue(0);

    pointerAnimRef.current?.stop();
    pointerAnimRef.current = null;
    pointerAnim.setValue(0);

    // 완전히 멈추지 않고 잔잔한 대기 애니메이션으로 되돌아간다.
    runBodyBounceLoop(4, 900);
  }, [scaleAnim, wiggleAnim, pointerAnim, runBodyBounceLoop]);

  const releaseAudioPlayer = useCallback(() => {
    const player = audioPlayerRef.current;
    audioPlayerRef.current = null;
    if (player) {
      try {
        player.pause();
        player.remove();
      } catch {
        // 이미 해제된 플레이어
      }
    }
  }, []);

  const stopAll = useCallback(() => {
    isPlayingRef.current = false;
    setIsPlaying(false);
    isPausedRef.current = false;
    setIsPaused(false);
    setBuffering(false);
    modeRef.current = null;
    speechGenRef.current++;
    setElapsedSec(0);
    Speech.stop();
    releaseAudioPlayer();
    stopAnimations();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setProgress(0);
    setCurrentSegment(null);
  }, [stopAnimations, releaseAudioPlayer, setIsPaused, setElapsedSec]);

  const handleClose = useCallback(() => {
    closedRef.current = true;
    skipAiWaitRef.current?.(); // 준비 중이었으면 기다림을 끝낸다 (닫혔으므로 아무것도 재생하지 않음)
    stopAll();
    onClose();
  }, [stopAll, onClose]);

  // 화면을 아래로 스와이프하면 손가락을 따라 끌려 내려가다가, 일정 거리
  // 이상 놓으면 닫히고 아니면 원위치로 튕겨 돌아온다.
  // PanResponder(RN 구식 responder 시스템) 대신 react-native-gesture-handler를
  // 쓰는 이유: 이 화면은 RN Modal 안에서 열리는데, Modal은 별도 네이티브 창에
  // 렌더링되고 그 안에 GestureHandlerRootView를 다시 둬야 하다 보니, 같은
  // gesture-handler 계열로 통일해야 터치가 안정적으로 잡힌다.
  const swipeGesture = Gesture.Pan()
    .activeOffsetY([12, 999])
    .failOffsetX([-25, 25])
    .runOnJS(true)
    .onUpdate((e) => {
      if (e.translationY > 0) {
        swipeTranslateY.setValue(e.translationY);
      }
    })
    // 제스처 콜백은 손가락을 뗄 때만 실행된다 (렌더링 중이 아님). Gesture 빌더 체인을 렌더 중 호출로 오인한 경고라 끈다.
    // eslint-disable-next-line react-hooks/refs
    .onEnd((e) => {
      if (e.translationY > 120 || e.velocityY > 800) {
        Animated.timing(swipeTranslateY, {
          toValue: 600,
          duration: 200,
          useNativeDriver: true,
        }).start(() => {
          swipeTranslateY.setValue(0);
          handleClose();
        });
      } else {
        Animated.spring(swipeTranslateY, {
          toValue: 0,
          useNativeDriver: true,
          friction: 8,
        }).start();
      }
    });

  // 다른 화면들(hooks/use-swipe-back)처럼 왼쪽 가장자리에서 오른쪽으로 밀면 뒤로 간다.
  // 이 화면은 Modal이라 화면 이동(router.back) 대신 닫는다. hitSlop으로 가장자리 32px에서
  // 시작한 터치만 받으므로, 화면 안쪽 버튼의 탭을 가로채지 않는다.
  const edgeSwipeGesture = Gesture.Pan()
    .hitSlop({ left: 0, width: 32 })
    .activeOffsetX(10)
    .failOffsetY([-20, 20])
    .runOnJS(true)
    .onUpdate((e) => {
      if (e.translationX > 0) {
        swipeTranslateX.setValue(e.translationX);
      }
    })
    // 위 swipeGesture와 같은 이유(손을 뗄 때만 실행되는 콜백)로 경고를 끈다.
    // eslint-disable-next-line react-hooks/refs
    .onEnd((e) => {
      if (e.translationX > 80 || e.velocityX > 800) {
        Animated.timing(swipeTranslateX, {
          toValue: screenWidth,
          duration: 200,
          useNativeDriver: true,
        }).start(() => {
          swipeTranslateX.setValue(0);
          handleClose();
        });
      } else {
        Animated.spring(swipeTranslateX, {
          toValue: 0,
          useNativeDriver: true,
          friction: 8,
        }).start();
      }
    });

  // 폰 목소리의 초당 글자 수 추정치. 10초 이동을 글자 위치로 바꾸고, 진행 시간을 표시할 때 쓴다.
  const deviceCharsPerSec = cleanText.length / estimatedDurationSec;

  /**
   * 폰 목소리로 startChar 위치부터 끝까지 읽는다. 일시정지 후 이어 듣기, 10초 이동이 모두
   * "그 위치부터 새로 읽기"로 동작한다. onBoundary의 charIndex는 잘라낸 문자열 기준이라 startChar를 더한다.
   */
  const deviceSpeakFrom = useCallback(
    (startChar: number) => {
      const gen = ++speechGenRef.current;
      Speech.stop();
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      const total = cleanText.length || 1;
      const offsetSec = startChar / deviceCharsPerSec;
      devicePosRef.current = startChar;
      isPausedRef.current = false;
      setIsPaused(false);
      hasBoundaryFiredRef.current = false;
      fallbackModeRef.current = false;
      lastFallbackPulseMsRef.current = 0;
      startTimeRef.current = Date.now();

      const showPosition = (pos: number) => {
        devicePosRef.current = pos;
        setProgress(Math.min(pos / total, 1));
        setElapsedSec(Math.min(pos / deviceCharsPerSec, estimatedDurationSec));
        const seg = findSegmentForCharIndex(segments, pos);
        setCurrentSegment((prev) => (seg && prev?.startChar === seg.startChar ? prev : seg));
      };
      showPosition(startChar);

      // 타이머는 (1) onBoundary가 안 오면 폴백으로 전환하는 감시 역할과
      // (2) 폴백 모드일 때 실제 진행률/자막을 미는 역할을 함께 한다.
      const safetyLimitSec = estimatedDurationSec - offsetSec + 5;
      timerRef.current = setInterval(() => {
        if (gen !== speechGenRef.current || !isPlayingRef.current || isPausedRef.current) return;
        const elapsed = (Date.now() - startTimeRef.current) / 1000;

        if (!hasBoundaryFiredRef.current && !fallbackModeRef.current && elapsed * 1000 > BOUNDARY_GRACE_MS) {
          console.log("[DmuPlayer] No onBoundary event received, switching to time-based fallback sync");
          fallbackModeRef.current = true;
        }

        if (fallbackModeRef.current) {
          showPosition(Math.min(total, Math.round((offsetSec + elapsed) * deviceCharsPerSec)));

          // onBoundary가 없는 기기에서는 단어 단위 타이밍을 알 수 없으니,
          // 평균적인 발화 속도만큼의 간격으로 대신 펄스를 흉내낸다.
          const elapsedMs = elapsed * 1000;
          if (elapsedMs - lastFallbackPulseMsRef.current > 280) {
            lastFallbackPulseMsRef.current = elapsedMs;
            triggerTalkPulse();
          }
        }

        if (elapsed >= safetyLimitSec) {
          stopAll();
        }
      }, 100);

      Speech.speak(cleanText.slice(startChar), {
        language: "ko-KR",
        rate: SPEECH_RATE,
        pitch: 1.0,
        volume: 1.0,
        onBoundary: (event: { charIndex?: number; charLength?: number }) => {
          if (gen !== speechGenRef.current) return;
          // ios/android: { charIndex, charLength } / web: SpeechSynthesisEvent(같은 필드 보유)
          hasBoundaryFiredRef.current = true;
          fallbackModeRef.current = false;
          showPosition(startChar + (event?.charIndex ?? 0));
          // onBoundary는 보통 단어 단위로 오므로, 실제 발화 타이밍 그대로
          // 펄스를 줘서 "말하는" 인상을 준다 (고정 주기 반복보다 훨씬 자연스럽다).
          triggerTalkPulse();
        },
        onDone: () => {
          if (gen !== speechGenRef.current) return;
          stopAll();
        },
        onError: (error: Error) => {
          // 웹은 Speech.stop()으로 멈춰도 onError("interrupted")가 온다.
          // 우리가 직접 멈추거나 다른 위치에서 다시 읽기 시작한 경우라면 오류가 아니므로 무시한다.
          if (gen !== speechGenRef.current || !isPlayingRef.current) return;
          console.warn("[DmuPlayer] TTS error:", error);
          stopAll();
        },
      });
    },
    [cleanText, segments, deviceCharsPerSec, estimatedDurationSec, stopAll, triggerTalkPulse, setIsPaused, setElapsedSec]
  );

  // 폰 내장 목소리(expo-speech)로 읽는다. AI 목소리가 실패했을 때 사용자가 "폰 목소리로 듣기"를 고른 경우에만 쓴다.
  const playDeviceVoice = useCallback(async () => {
    // Stop any existing speech first.
    // 일부 Android 기기는 TTS 엔진이 준비되지 않으면 isSpeakingAsync()가 끝나지 않아서
    // 재생 버튼을 눌러도 아무 반응이 없게 된다. 그래서 잠깐만 기다리고 넘어간다.
    try {
      const speaking = await Promise.race([
        Speech.isSpeakingAsync(),
        new Promise<boolean>((r) => setTimeout(() => r(false), 500)),
      ]);
      if (speaking) {
        await Speech.stop();
        // Small delay to ensure speech engine is ready
        await new Promise((r) => setTimeout(r, 200));
      }
    } catch (e) {
      console.warn("[DmuPlayer] isSpeakingAsync error:", e);
    }

    modeRef.current = "device";
    isPlayingRef.current = true;
    setIsPlaying(true);
    setProgress(0);
    setCurrentSegment(null);
    setTotalSec(estimatedDurationSec);

    // Start animations
    startAnimations();

    deviceSpeakFrom(0);
  }, [estimatedDurationSec, startAnimations, deviceSpeakFrom, setTotalSec]);

  /**
   * AI 목소리(서버의 OpenAI TTS, server/lib/tts.ts)로 재생한다. 음성 준비에 실패하면
   * false를 돌려주고 호출한 쪽이 폰 목소리로 대신 읽는다. 준비는 됐는데 재생이 시작되지
   * 않으면 여기서 직접 폰 목소리로 넘긴다.
   * 단어 경계 이벤트가 없으므로 자막은 실제 오디오 길이에 맞춰 문장 길이 비율로 넘긴다.
   */
  /** 소리가 나기 시작했으면 "started", 준비 실패·닫힘 등으로 끝났으면 "stopped",
   *  음성 파일을 시간 안에 못 받아 재생이 시작되지 않았으면 "noStart" (호출한 쪽이 다시 시도한다). */
  const playAiVoice = useCallback(async (): Promise<"started" | "stopped" | "noStart"> => {
    let prepared: { path: string; durationSec: number };
    let timeoutId: ReturnType<typeof setTimeout> | undefined;
    try {
      prepared = await Promise.race([
        trpcVanilla.explain.prepareSpeech.mutate({ text: cleanText.slice(0, 2000) }),
        new Promise<never>((_, reject) => {
          timeoutId = setTimeout(() => reject(new Error("timeout")), AI_VOICE_PREPARE_TIMEOUT_MS);
        }),
        // 준비 중에 화면을 닫으면 기다림을 바로 끝낸다 (handleClose)
        new Promise<never>((_, reject) => {
          skipAiWaitRef.current = () => reject(new Error("skipped"));
        }),
      ]);
    } catch (error) {
      console.warn("[DmuPlayer] AI voice unavailable, using device voice:", error);
      if (!closedRef.current && (error as Error)?.message !== "skipped") setAiFailNotice(aiVoiceFailNotice(error));
      return "stopped";
    } finally {
      clearTimeout(timeoutId);
      skipAiWaitRef.current = null;
    }
    if (closedRef.current) return "stopped"; // 준비하는 동안 화면을 닫았으면 아무것도 재생하지 않는다

    try {
      await setAudioModeAsync({ playsInSilentMode: true });
    } catch {
      // 오디오 모드 설정 실패는 재생 자체를 막지 않는다
    }
    const player = createAudioPlayer({ uri: `${getApiBaseUrl()}${prepared.path}` });
    audioPlayerRef.current = player;

    const windows = windowsFor(segments, prepared.durationSec);
    modeRef.current = "ai";
    isPausedRef.current = false;
    setIsPaused(false);
    setTotalSec(prepared.durationSec);
    isPlayingRef.current = true;
    setIsPlaying(true);
    setBuffering(true);
    setProgress(0);
    setCurrentSegment(null);
    lastFallbackPulseMsRef.current = 0;

    let started = false;
    const createdAt = Date.now();
    const statusSub = player.addListener("playbackStatusUpdate", (status) => {
      if (status.didJustFinish) stopAll();
    });
    player.play();

    return new Promise((resolve) => {
    timerRef.current = setInterval(() => {
      // 정지/닫기/다른 재생으로 이 플레이어가 해제됐으면 구독만 정리한다
      if (audioPlayerRef.current !== player || !isPlayingRef.current) {
        statusSub.remove();
        resolve("stopped");
        return;
      }
      const elapsed = player.currentTime;
      if (!started && (player.playing || elapsed > 0)) {
        started = true;
        setBuffering(false);
        startAnimations();
        resolve("started");
      }

      // 일정 시간 안에 재생이 시작되지 않으면(오디오 로드 실패, 서버 재시작으로 파일이 사라짐 등) 멈춘다
      if (!started) {
        if (Date.now() - createdAt > AI_VOICE_START_TIMEOUT_MS) {
          console.warn("[DmuPlayer] AI voice did not start");
          statusSub.remove();
          stopAll();
          resolve("noStart");
        }
        return;
      }

      const active = windows.find((w) => elapsed >= w.startTime && elapsed < w.endTime);
      setCurrentSegment((prev) => {
        if (!active) return prev;
        return prev?.startChar === active.startChar ? prev : active;
      });
      setProgress(prepared.durationSec > 0 ? Math.min(elapsed / prepared.durationSec, 1) : 0);
      setElapsedSec(Math.min(elapsed, prepared.durationSec));
      const elapsedMs = elapsed * 1000;
      if (player.playing && elapsedMs - lastFallbackPulseMsRef.current > 280) {
        lastFallbackPulseMsRef.current = elapsedMs;
        triggerTalkPulse();
      }
    }, 100);
    });
  }, [cleanText, segments, startAnimations, stopAll, triggerTalkPulse, setIsPaused, setElapsedSec, setAiFailNotice]);

  // 기본은 AI 목소리로만 읽는다. 실패해도 폰 목소리로 자동으로 넘어가지 않고, 이유와 함께
  // "다시 시도" / "폰 목소리로 듣기"를 보여줘서 사용자가 고르게 한다.
  // 음성 파일을 못 받아 소리가 안 나면 음성을 다시 준비해서(서버 재시작으로 파일이 사라졌을 수 있다)
  // 자동으로 한 번 더 시도한다 — 예전엔 사용자가 버튼을 여러 번 눌러야 했다.
  const handlePlay = useCallback(async () => {
    if (isPlayingRef.current || preparingRef.current) return;
    if (!cleanText) {
      console.warn("[DmuPlayer] No explanation text to speak");
      return;
    }
    preparingRef.current = true;
    setPreparing(true);
    setAiFailNotice(null);
    setUsingDeviceVoice(false);
    try {
      for (let attempt = 0; attempt <= AI_VOICE_START_RETRIES; attempt++) {
        const result = await playAiVoice();
        if (result !== "noStart") return;
        if (closedRef.current) return;
      }
      setAiFailNotice(aiVoiceFailNotice(null));
    } finally {
      preparingRef.current = false;
      setPreparing(false);
    }
  }, [cleanText, playAiVoice, setAiFailNotice, setUsingDeviceVoice]);

  /** 사용자가 직접 고른 경우에만 폰 내장 목소리로 읽는다. */
  const handlePlayDeviceVoice = useCallback(async () => {
    if (isPlayingRef.current || preparingRef.current || !cleanText) return;
    setAiFailNotice(null);
    setUsingDeviceVoice(true);
    await playDeviceVoice();
  }, [cleanText, playDeviceVoice, setAiFailNotice, setUsingDeviceVoice]);

  const handlePause = useCallback(() => {
    if (!isPlayingRef.current || isPausedRef.current) return;
    isPausedRef.current = true;
    setIsPaused(true);
    if (modeRef.current === "ai") {
      audioPlayerRef.current?.pause();
    } else {
      speechGenRef.current++; // 멈춘 발화의 콜백이 재생 상태를 건드리지 않게
      Speech.stop();
    }
    stopAnimations();
  }, [stopAnimations, setIsPaused]);

  const handleResume = useCallback(() => {
    if (!isPlayingRef.current || !isPausedRef.current) return;
    startAnimations();
    if (modeRef.current === "ai") {
      isPausedRef.current = false;
      setIsPaused(false);
      audioPlayerRef.current?.play();
    } else {
      deviceSpeakFrom(devicePosRef.current);
    }
  }, [startAnimations, deviceSpeakFrom, setIsPaused]);

  /**
   * 재생 위치를 targetSec초로 옮긴다 (10초 버튼, 재생 바 공통). 끝을 넘기면 재생을 끝낸다.
   * 일시정지 중이면 위치만 옮기고 계속 멈춰 있다.
   */
  const handleSeekTo = useCallback(
    (targetSec: number) => {
      if (!isPlayingRef.current) return;
      if (modeRef.current === "ai") {
        const player = audioPlayerRef.current;
        if (!player) return;
        const target = Math.max(0, targetSec);
        if (totalSec > 0 && target >= totalSec) {
          stopAll();
          return;
        }
        player.seekTo(target);
        setElapsedSec(target);
        setProgress(totalSec > 0 ? target / totalSec : 0);
        return;
      }
      const length = cleanText.length;
      let pos = Math.round(targetSec * deviceCharsPerSec);
      if (pos >= length) {
        stopAll();
        return;
      }
      // 단어 중간부터 읽지 않도록 그 앞의 띄어쓰기 바로 뒤로 맞춘다
      pos = Math.max(0, pos);
      pos = pos > 0 ? cleanText.lastIndexOf(" ", pos) + 1 : 0;
      if (isPausedRef.current) {
        devicePosRef.current = pos;
        setProgress(pos / (length || 1));
        setElapsedSec(pos / deviceCharsPerSec);
        const seg = findSegmentForCharIndex(segments, pos);
        setCurrentSegment(seg ?? null);
      } else {
        deviceSpeakFrom(pos);
      }
    },
    [cleanText, segments, totalSec, deviceCharsPerSec, deviceSpeakFrom, stopAll, setElapsedSec]
  );

  /** 지금 위치에서 deltaSec만큼 옮긴다 (음수면 뒤로). */
  const handleSeek = useCallback(
    (deltaSec: number) => {
      const current =
        modeRef.current === "ai"
          ? (audioPlayerRef.current?.currentTime ?? 0)
          : devicePosRef.current / deviceCharsPerSec;
      handleSeekTo(current + deltaSec);
    },
    [deviceCharsPerSec, handleSeekTo]
  );

  // 재생 바: 누른 곳으로 이동하고, 손잡이를 끄는 동안에는 미리보기 시간만 보여주다가 손을 떼면 이동한다.
  // (폰 목소리는 이동할 때마다 그 위치부터 새로 읽기 시작하므로, 끄는 도중에는 이동하지 않는다.)
  const [barWidth, setBarWidth] = useState(0);
  const [dragSec, setDragSec] = useState<number | null>(null);
  const canScrub = isPlaying && totalSec > 0 && barWidth > 0;
  const secAtX = (x: number) => totalSec * Math.min(1, Math.max(0, x / barWidth));
  const scrubGesture = Gesture.Pan()
    .enabled(canScrub)
    .minDistance(0)
    .runOnJS(true)
    .onBegin((e) => setDragSec(secAtX(e.x)))
    .onUpdate((e) => setDragSec(secAtX(e.x)))
    // 제스처 콜백은 손가락을 뗄 때만 실행된다 (렌더링 중이 아님). Gesture 빌더 체인을 렌더 중 호출로 오인한 경고라 끈다.
    // eslint-disable-next-line react-hooks/refs
    .onEnd((e) => handleSeekTo(secAtX(e.x)))
    .onFinalize(() => setDragSec(null));
  const shownSec = dragSec ?? elapsedSec;
  const shownProgress = dragSec !== null && totalSec > 0 ? dragSec / totalSec : progress;

  useEffect(() => {
    const speechGen = speechGenRef;
    return () => {
      closedRef.current = true;
      isPlayingRef.current = false;
      speechGen.current++;
      Speech.stop();
      releaseAudioPlayer();
      stopAnimations();
      // stopAnimations()는 대기용 숨쉬기 루프를 다시 시작시키므로, 언마운트
      // 시에는 그것까지 마저 멈춘다.
      bodyAnimRef.current?.stop();
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 소리가 실제로 나오기 전(목소리 준비 또는 파일 받는 중)에는 재생 버튼을 잠근다
  const loadingVoice = preparing || buffering;
  const loadingText = buffering
    ? "동그래 목소리를 불러오는 중..."
    : `동그래가 목소리를 가다듬는 중... ${preparingSec}초`;

  return (
    <GestureDetector gesture={edgeSwipeGesture}>
    <Animated.View
      collapsable={false}
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
          transform: [{ translateX: swipeTranslateX }, { translateY: swipeTranslateY }],
        },
      ]}
    >
      {/* 아래로 스와이프해서 닫기는 손잡이·헤더에서만 받는다. 화면 전체에 걸면 Android에서
          재생 버튼 같은 일반 버튼의 탭을 제스처가 가로채서 몇 번 눌러야 반응하는 일이 생긴다. */}
      <GestureDetector gesture={swipeGesture}>
      <View collapsable={false}>
      {/* 아래로 스와이프해서 닫을 수 있다는 걸 알려주는 손잡이 */}
      <View style={styles.dragHandleWrapper}>
        <View style={[styles.dragHandle, { backgroundColor: colors.border }]} />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <Pressable
          style={({ pressed }) => [
            styles.closeButton,
            pressed && { opacity: 0.6 },
          ]}
          onPress={handleClose}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>
          동그래 해설
        </Text>
        <View style={{ width: 36 }} />
      </View>
      </View>
      </GestureDetector>

      {/* 문제 본문이 칠판에 같이 들어가면서 길어질 수 있어 아래 내용은 스크롤한다 */}
      <ScrollView style={styles.body} contentContainerStyle={styles.bodyContent} showsVerticalScrollIndicator={false}>
      {/* 글씨가 칠판 전체 폭을 쓰고, 캐릭터는 오른쪽 아래 구석에 작게 떠 있다 */}
      <View style={styles.stageArea}>
        <View style={[styles.blackboard, hasScenes && styles.blackboardScenes]}>
          <View style={styles.chalkTray} />

          {/* 아래쪽엔 구석 캐릭터가 있는 만큼 paddingBottom으로 그 높이를
              비워둔다 - 글씨 폭은 그대로 전체를 쓰면서, 줄이 늘어나도 캐릭터와
              절대 안 겹치게 하기 위함(가로로 폭을 줄이면 다시 읽기 불편해짐). */}
          <View style={[styles.textArea, { paddingBottom: hasScenes ? characterSize * 0.8 : characterSize + 12 }]}>
            {hasScenes ? (
              <SceneBoard visual={scenes![sceneIndex].visual} sceneKey={sceneIndex} questionText={questionText} />
            ) : currentSegment ? (
              <Animated.View style={{ opacity: subtitleOpacity }}>
                <Text style={styles.subtitleText}>{currentSegment.text}</Text>
              </Animated.View>
            ) : (
              <Text style={styles.subtitlePlaceholder}>
                {buffering
                  ? loadingText
                  : preparing
                  ? `${loadingText}\n처음 듣는 해설은 1~3분 걸려요. 한 번 만들면 다음부터는 바로 나와요.`
                  : isPlaying
                    ? "재생 중..."
                    : "재생 버튼을 눌러주세요"}
              </Text>
            )}
          </View>

          <Animated.View
            style={[
              styles.characterWrapper,
              {
                transform: [
                  { translateY: bodyBounce },
                  { scale: scaleAnim },
                  {
                    rotate: wiggleAnim.interpolate({
                      inputRange: [-1, 1],
                      outputRange: ["-4deg", "4deg"],
                    }),
                  },
                ],
              },
            ]}
          >
            <Image
              source={DONGGURAECHARACTER_SOURCE}
              style={[
                styles.characterImage,
                { width: characterSize, height: characterSize },
              ]}
              contentFit="contain"
            />

            {/* 글씨(왼쪽)를 향해 짚어가며 설명하는 분필 포인터 */}
            <Animated.View
              style={[
                styles.chalkPointer,
                {
                  opacity: isPlaying && !buffering ? 1 : 0,
                  transform: [
                    {
                      rotate: pointerAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ["0deg", "-18deg"],
                      }),
                    },
                    {
                      translateX: pointerAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0, -10],
                      }),
                    },
                  ],
                },
              ]}
            >
              <View style={styles.chalkStick} />
            </Animated.View>
          </Animated.View>
        </View>
      </View>

      {/* 그림 해설: 칠판에는 그림, 대사 자막은 칠판 아래에 */}
      {hasScenes && (
        <View style={[styles.caption, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.captionCounter, { color: colors.muted }]}>
            {sceneIndex + 1} / {scenes!.length}
          </Text>
          <Text style={[styles.captionText, { color: currentSegment ? colors.foreground : colors.muted }]}>
            {currentSegment
              ? currentSegment.text
              : buffering
                ? loadingText
                : preparing
                ? `${loadingText} (처음 듣는 해설은 1~3분 걸려요)`
                : "재생 버튼을 누르면 동그래가 그림을 그리며 설명해 줘요"}
          </Text>
        </View>
      )}

      {/* Silent mode hint for iOS */}
      {Platform.OS === "ios" && (
        <Text style={[styles.silentModeHint, { color: colors.warning }]}>
          * iPhone 좌측 스위치를 올려 무음 모드를 해제해 주세요
        </Text>
      )}

      {aiFailNotice && !isPlaying && (
        <View style={[styles.failBox, { backgroundColor: colors.warning + "14", borderColor: colors.warning + "50" }]}>
          <Text style={[styles.failText, { color: colors.foreground }]}>{aiFailNotice}</Text>
          <Pressable
            accessibilityRole="button"
            style={({ pressed }) => [styles.deviceVoiceBtn, { borderColor: colors.border, backgroundColor: colors.surface }, pressed && { opacity: 0.7 }]}
            onPress={handlePlayDeviceVoice}
          >
            <IconSymbol name="speaker.wave.2.fill" size={16} color={colors.foreground} />
            <Text style={[styles.deviceVoiceText, { color: colors.foreground }]}>폰 목소리로 듣기</Text>
          </Pressable>
        </View>
      )}
      {usingDeviceVoice && isPlaying && (
        <Text style={[styles.silentModeHint, { color: colors.muted }]}>폰 목소리로 읽는 중이에요</Text>
      )}

      {/* 재생 바: 누르거나 끌어서 위치 이동 */}
      <GestureDetector gesture={scrubGesture}>
        <View
          collapsable={false}
          accessible
          accessibilityRole="adjustable"
          accessibilityLabel="재생 위치"
          accessibilityValue={{ min: 0, max: Math.round(totalSec), now: Math.round(shownSec), text: `${formatTime(shownSec)} / ${formatTime(totalSec)}` }}
          accessibilityActions={[{ name: "increment" }, { name: "decrement" }]}
          onAccessibilityAction={(e) => handleSeek(e.nativeEvent.actionName === "increment" ? 10 : -10)}
          onLayout={(e) => setBarWidth(e.nativeEvent.layout.width)}
          style={styles.scrubArea}
        >
          <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: colors.primary,
                  width: `${shownProgress * 100}%`,
                },
              ]}
            />
          </View>
          {isPlaying && (
            <View
              pointerEvents="none"
              style={[
                styles.scrubThumb,
                {
                  backgroundColor: colors.primary,
                  borderColor: colors.surface,
                  left: shownProgress * barWidth - (dragSec !== null ? 11 : 8),
                },
                dragSec !== null && styles.scrubThumbActive,
              ]}
            />
          )}
        </View>
      </GestureDetector>

      <View style={styles.timeRow}>
        <Text style={[styles.timeText, { color: dragSec !== null ? colors.primary : colors.muted }]}>
          {formatTime(shownSec)}
        </Text>
        <Text style={[styles.timeText, { color: colors.muted }]}>
          {totalSec > 0 ? formatTime(totalSec) : "--:--"}
        </Text>
      </View>

      {/* 10초 뒤로 / 재생·일시정지·이어 듣기 / 10초 앞으로 */}
      <View style={styles.controls}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="10초 뒤로"
          style={({ pressed }) => [
            styles.seekButton,
            { borderColor: colors.border, backgroundColor: colors.surface },
            !isPlaying && { opacity: 0.4 },
            pressed && { opacity: 0.6 },
          ]}
          onPress={() => handleSeek(-10)}
          disabled={!isPlaying}
        >
          <IconSymbol name="gobackward.10" size={24} color={colors.foreground} />
        </Pressable>
        <Pressable
          style={({ pressed }) => [
            styles.playButton,
            { backgroundColor: colors.primary },
            loadingVoice && { opacity: 0.7 },
            pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
          ]}
          onPress={!isPlaying ? handlePlay : isPaused ? handleResume : handlePause}
          disabled={loadingVoice}
        >
          {loadingVoice ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <IconSymbol
              name={isPlaying && !isPaused ? "pause.fill" : "play.fill"}
              size={24}
              color="#FFFFFF"
            />
          )}
          <Text style={styles.playButtonText}>
            {buffering
              ? "불러오는 중..."
              : preparing
              ? "목소리 준비 중..."
              : !isPlaying
                ? aiFailNotice
                  ? "다시 시도"
                  : "해설 듣기"
                : isPaused
                  ? "이어 듣기"
                  : "일시정지"}
          </Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="10초 앞으로"
          style={({ pressed }) => [
            styles.seekButton,
            { borderColor: colors.border, backgroundColor: colors.surface },
            !isPlaying && { opacity: 0.4 },
            pressed && { opacity: 0.6 },
          ]}
          onPress={() => handleSeek(10)}
          disabled={!isPlaying}
        >
          <IconSymbol name="goforward.10" size={24} color={colors.foreground} />
        </Pressable>
      </View>

      {/* Explanation text preview - 길어도 잘리지 않고 스크롤해서 끝까지 읽을 수 있다.
          칠판(자막/TTS)은 오답 맞춤 해설을 쓰지만, 이 박스는 항상 기본 해설을 보여준다
          (referenceExplanation 미지정 시엔 explanation을 그대로 씀 - 사진인식 등). */}
      <View style={[styles.explanationPreview, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.explanationLabel, { color: colors.muted }]}>
          해설 내용
        </Text>
        <ScrollView style={styles.explanationScroll} nestedScrollEnabled showsVerticalScrollIndicator={true}>
          <Text style={[styles.explanationText, { color: colors.foreground }]}>
            {referenceExplanation ?? explanation}
          </Text>
        </ScrollView>
      </View>
      </ScrollView>
    </Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
  },
  body: {
    flex: 1,
  },
  bodyContent: {
    paddingBottom: 16,
  },
  dragHandleWrapper: {
    alignItems: "center",
    paddingTop: 8,
  },
  dragHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
  },
  closeButton: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "700",
  },
  // 칠판이 전체 폭을 차지하고, 글씨가 그 폭을 온전히 다 쓴다. 캐릭터는 더 이상
  // 글씨와 폭을 나눠 쓰지 않고, 칠판 오른쪽 아래 구석에 작게 떠 있는 형태로
  // 바뀌었다 (글씨 가독성이 안 좋다는 피드백 때문 - 캐릭터가 옆에서 폭을
  // 잡아먹으면 좁은 폭에 줄바꿈이 많아져서 읽기 불편했다).
  stageArea: {
    paddingVertical: 20,
  },
  blackboard: {
    minHeight: 240,
    justifyContent: "center",
    backgroundColor: "#1f3d2e",
    borderRadius: 12,
    borderWidth: 8,
    // 나무 액자 느낌의 진한 갈색 테두리
    borderColor: "#6b4a34",
    paddingHorizontal: 20,
    paddingVertical: 20,
    paddingBottom: 28,
    position: "relative",
  },
  blackboardScenes: {
    minHeight: 280,
    justifyContent: "flex-start",
    paddingHorizontal: 14,
    paddingVertical: 16,
  },
  caption: {
    borderWidth: 1,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginTop: -6,
    marginBottom: 12,
    gap: 4,
  },
  captionCounter: {
    fontSize: 11,
    fontWeight: "700",
    fontVariant: ["tabular-nums"],
  },
  captionText: {
    fontSize: 15,
    lineHeight: 22,
    fontWeight: "600",
  },
  chalkTray: {
    position: "absolute",
    bottom: -6,
    left: "8%",
    right: "8%",
    height: 8,
    borderRadius: 4,
    backgroundColor: "#4a3323",
  },
  textArea: {
    width: "100%",
  },
  characterWrapper: {
    position: "absolute",
    right: 8,
    bottom: 8,
    alignItems: "center",
    justifyContent: "flex-end",
  },
  characterImage: {},
  chalkPointer: {
    position: "absolute",
    bottom: "30%",
    left: -6,
  },
  chalkStick: {
    width: 34,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#f5e6c8",
    transform: [{ rotate: "-35deg" }],
  },
  failBox: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    gap: 10,
    marginBottom: 10,
  },
  failText: {
    fontSize: 13,
    lineHeight: 19,
    fontWeight: "600",
  },
  deviceVoiceBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
  },
  deviceVoiceText: {
    fontSize: 14,
    fontWeight: "700",
  },
  silentModeHint: {
    fontSize: 12,
    textAlign: "center",
    marginBottom: 10,
    fontWeight: "600",
  },
  subtitleText: {
    fontSize: 19,
    fontWeight: "700",
    lineHeight: 30,
    letterSpacing: 0.2,
    textAlign: "left",
    color: "#fdf6e8",
  },
  subtitlePlaceholder: {
    fontSize: 15,
    textAlign: "left",
    color: "#cbb996",
  },
  // 바 자체는 얇지만 손가락으로 잡기 쉽게 터치 영역은 32px로 잡는다
  scrubArea: {
    height: 32,
    justifyContent: "center",
  },
  progressBar: {
    height: 6,
    borderRadius: 3,
    overflow: "hidden",
  },
  scrubThumb: {
    position: "absolute",
    top: 8,
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
  },
  scrubThumbActive: {
    top: 5,
    width: 22,
    height: 22,
    borderRadius: 11,
  },
  timeRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  timeText: {
    fontSize: 12,
    fontVariant: ["tabular-nums"],
  },
  seekButton: {
    width: 52,
    height: 52,
    borderRadius: 26,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
  controls: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 14,
    marginBottom: 16,
  },
  playButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    borderRadius: 28,
    paddingVertical: 14,
    paddingHorizontal: 32,
    minWidth: 160,
  },
  playButtonText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  explanationPreview: {
    borderRadius: 14,
    borderWidth: 1,
    padding: 16,
  },
  explanationScroll: {
    maxHeight: 220,
  },
  explanationLabel: {
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 8,
  },
  explanationText: {
    fontSize: 16,
    lineHeight: 26,
    letterSpacing: 0.1,
  },
});

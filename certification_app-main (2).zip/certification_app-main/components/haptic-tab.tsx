import type { BottomTabBarButtonProps } from "expo-router/build/react-navigation/bottom-tabs/types";
import { Platform, Pressable } from "react-native";
import * as Haptics from "expo-haptics";

// Plain Pressable instead of @react-navigation/elements' PlatformPressable:
// that component reads theme via @react-navigation/core's useTheme(), which
// throws because expo-router (SDK 56+) no longer renders a NavigationContainer.
export function HapticTab({ style, onPress, onPressIn, children, ref: _ref, ...rest }: BottomTabBarButtonProps) {
  return (
    <Pressable
      {...rest}
      style={style}
      onPress={(ev) => {
        // 웹에서는 탭 버튼이 <a href>로 렌더링된다. 브라우저 기본 동작을 막지 않으면
        // 앱 내 이동 직후에 페이지 전체가 한 번 더 새로 로드된다.
        if (Platform.OS === "web") ev.preventDefault();
        onPress?.(ev);
      }}
      android_ripple={Platform.OS === "android" ? { borderless: true, foreground: true } : undefined}
      onPressIn={(ev) => {
        if (process.env.EXPO_OS === "ios") {
          // Add a soft haptic feedback when pressing down on the tabs.
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }
        onPressIn?.(ev);
      }}
    >
      {children}
    </Pressable>
  );
}

import React from "react";
import { ActivityIndicator, Pressable, StyleProp, StyleSheet, Text, View, ViewStyle } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { isGoogleSignInAvailable } from "@/lib/google-signin";

interface Props {
  onPress: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
}

/** "Google로 계속하기" 버튼. 웹에서는 렌더링하지 않는다(앱 전용). */
export function AppGoogleSigninButton({ onPress, disabled, style }: Props) {
  const colors = useColors();
  if (!isGoogleSignInAvailable) return null;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: colors.surface, borderColor: colors.border },
        (pressed || disabled) && { opacity: 0.6 },
        style,
      ]}
    >
      {disabled ? (
        <ActivityIndicator color={colors.muted} />
      ) : (
        <View style={styles.row}>
          <Text style={styles.logo}>
            <Text style={{ color: "#4285F4" }}>G</Text>
          </Text>
          <Text style={[styles.label, { color: colors.foreground }]}>Google로 계속하기</Text>
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    borderWidth: 1,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  logo: {
    fontSize: 18,
    fontWeight: "800",
  },
  label: {
    fontSize: 15,
    fontWeight: "700",
  },
});

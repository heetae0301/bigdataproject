import React from "react";
import { Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

/** 문제 풀이 화면 상단 오른쪽의 북마크(헷갈리는 문제 표시) 버튼 */
export function BookmarkButton({
  bookmarked,
  onPress,
}: {
  bookmarked: boolean;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      style={({ pressed }) => [styles.btn, pressed && { opacity: 0.6 }]}
      onPress={onPress}
      hitSlop={8}
      accessibilityRole="button"
      accessibilityLabel={bookmarked ? "북마크 해제" : "북마크"}
    >
      <IconSymbol
        name={bookmarked ? "bookmark.fill" : "bookmark"}
        size={22}
        color={bookmarked ? colors.warning : colors.muted}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    width: 36,
    height: 36,
    alignItems: "center",
    justifyContent: "center",
  },
});

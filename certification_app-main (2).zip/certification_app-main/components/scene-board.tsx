import React, { useEffect, useMemo } from "react";
import { Animated, Easing, StyleSheet, Text, View } from "react-native";
import type { SceneVisual } from "@/lib/explanation-scenes";

/**
 * 동그래 그림 해설의 칠판 그림. 장면(visual)의 틀마다 정해진 모양으로 그리고,
 * 장면이 바뀌면 항목을 하나씩 차례로 써 내려가듯 나타나게 한다.
 * 색은 칠판 위 분필 느낌으로 고정한다(라이트/다크 모드와 무관하게 칠판은 늘 짙은 초록).
 */

const CHALK = {
  white: "#fdf6e8",
  muted: "#cbb996",
  yellow: "#ffe28a",
  red: "#ff9e9e",
  green: "#b5e7a0",
  line: "rgba(253, 246, 232, 0.35)",
  highlightBg: "rgba(255, 226, 138, 0.14)",
};

const ITEM_DELAY_MS = 320;

/** 장면이 바뀔 때마다(sceneKey) 항목 count개를 차례로 나타나게 하는 애니메이션 값들. */
function useStaggeredEntrance(count: number, sceneKey: string | number) {
  const values = useMemo(
    () => Array.from({ length: count }, () => new Animated.Value(0)),
    // sceneKey가 바뀌면 새 값으로 처음부터 다시 그린다
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [count, sceneKey]
  );
  useEffect(() => {
    const anim = Animated.stagger(
      ITEM_DELAY_MS,
      values.map((v) =>
        Animated.timing(v, { toValue: 1, duration: 380, easing: Easing.out(Easing.cubic), useNativeDriver: true })
      )
    );
    anim.start();
    return () => anim.stop();
  }, [values]);
  return values;
}

function Appear({ value, children, style }: { value: Animated.Value; children: React.ReactNode; style?: object }) {
  return (
    <Animated.View
      style={[
        style,
        {
          opacity: value,
          transform: [{ translateY: value.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}

function BoardTitle({ text }: { text?: string }) {
  if (!text) return null;
  return (
    <View style={styles.titleWrap}>
      <Text style={styles.title}>{text}</Text>
      <View style={styles.titleUnderline} />
    </View>
  );
}

function OptionsBoard({
  v,
  sceneKey,
  questionText,
}: {
  v: Extract<SceneVisual, { type: "options" }>;
  sceneKey: string | number;
  questionText?: string;
}) {
  const anims = useStaggeredEntrance(v.options.length, sceneKey);
  const gotItRight = v.selectedOption === v.correctOption;
  return (
    <View style={styles.optionsList}>
      {/* 보기만 있으면 무슨 문제였는지 알기 어려워서 문제 본문을 먼저 써 둔다 */}
      {questionText ? (
        <View style={styles.questionWrap}>
          <Text style={styles.questionLabel}>Q.</Text>
          <Text style={styles.questionText}>{questionText}</Text>
        </View>
      ) : null}
      {v.options.map((opt, i) => {
        const isCorrect = i === v.correctOption;
        const isSelected = i === v.selectedOption;
        const dim = !isCorrect && !isSelected;
        return (
          <Appear key={i} value={anims[i]}>
            <View
              style={[
                styles.optionRow,
                isCorrect && { borderColor: CHALK.green, backgroundColor: "rgba(181, 231, 160, 0.12)" },
                isSelected && !isCorrect && { borderColor: CHALK.red, backgroundColor: "rgba(255, 158, 158, 0.12)" },
              ]}
            >
              <Text style={[styles.optionNum, dim && styles.dimText]}>{i + 1}</Text>
              <Text style={[styles.optionText, dim && styles.dimText]}>
                {opt}
              </Text>
              {isCorrect && (
                <Text style={[styles.optionMark, { color: CHALK.green }]}>{gotItRight ? "○ 내 답·정답" : "○ 정답"}</Text>
              )}
              {isSelected && !isCorrect && <Text style={[styles.optionMark, { color: CHALK.red }]}>✗ 내 답</Text>}
            </View>
          </Appear>
        );
      })}
    </View>
  );
}

function CompareBoard({ v, sceneKey }: { v: Extract<SceneVisual, { type: "compare" }>; sceneKey: string | number }) {
  const anims = useStaggeredEntrance(3, sceneKey);
  const column = (side: { title: string; points: string[] }, color: string, anim: Animated.Value) => (
    <Appear value={anim} style={styles.compareCol}>
      <Text style={[styles.compareHead, { color }]}>{side.title}</Text>
      <View style={[styles.compareHeadLine, { backgroundColor: color }]} />
      {side.points.map((p, i) => (
        <Text key={i} style={styles.bullet}>
          · {p}
        </Text>
      ))}
    </Appear>
  );
  return (
    <View>
      <BoardTitle text={v.title} />
      <View style={styles.compareRow}>
        {column(v.left, CHALK.yellow, anims[0])}
        <Appear value={anims[1]} style={styles.vsWrap}>
          <Text style={styles.vs}>vs</Text>
        </Appear>
        {column(v.right, CHALK.green, anims[2])}
      </View>
    </View>
  );
}

function StepsBoard({ v, sceneKey }: { v: Extract<SceneVisual, { type: "steps" }>; sceneKey: string | number }) {
  const anims = useStaggeredEntrance(v.steps.length, sceneKey);
  return (
    <View>
      <BoardTitle text={v.title} />
      {v.steps.map((step, i) => {
        const hl = i === v.highlight;
        return (
          <Appear key={i} value={anims[i]}>
            {i > 0 && <Text style={styles.stepArrow}>↓</Text>}
            <View style={[styles.stepRow, hl && styles.highlightBox]}>
              <View style={[styles.stepNum, hl && { borderColor: CHALK.yellow }]}>
                <Text style={[styles.stepNumText, hl && { color: CHALK.yellow }]}>{i + 1}</Text>
              </View>
              <Text style={[styles.stepText, hl && { color: CHALK.yellow }]}>{step}</Text>
            </View>
          </Appear>
        );
      })}
    </View>
  );
}

function FormulaBoard({ v, sceneKey }: { v: Extract<SceneVisual, { type: "formula" }>; sceneKey: string | number }) {
  const anims = useStaggeredEntrance(v.lines.length, sceneKey);
  return (
    <View>
      <BoardTitle text={v.title} />
      {v.lines.map((line, i) => (
        <Appear key={i} value={anims[i]}>
          <Text style={[styles.formulaLine, i === 0 && styles.formulaFirst]}>{line}</Text>
        </Appear>
      ))}
    </View>
  );
}

function KeywordBoard({ v, sceneKey }: { v: Extract<SceneVisual, { type: "keyword" }>; sceneKey: string | number }) {
  const anims = useStaggeredEntrance(2, sceneKey);
  return (
    <View style={styles.keywordWrap}>
      <Appear value={anims[0]} style={styles.keywordHead}>
        {v.emoji ? <Text style={styles.keywordEmoji}>{v.emoji}</Text> : null}
        <Text style={styles.keywordTerm}>{v.term}</Text>
      </Appear>
      <Appear value={anims[1]}>
        <View style={styles.keywordLine} />
        <Text style={styles.keywordDef}>{v.definition}</Text>
      </Appear>
    </View>
  );
}

function TreeBoard({ v, sceneKey }: { v: Extract<SceneVisual, { type: "tree" }>; sceneKey: string | number }) {
  const anims = useStaggeredEntrance(v.children.length + 1, sceneKey);
  return (
    <View style={styles.treeWrap}>
      <Appear value={anims[0]} style={styles.treeRootWrap}>
        <View style={styles.treeRoot}>
          <Text style={styles.treeRootText}>{v.root}</Text>
        </View>
        <View style={styles.treeStem} />
        <View style={styles.treeBar} />
      </Appear>
      <View style={styles.treeChildren}>
        {v.children.map((c, i) => {
          const hl = i === v.highlight;
          return (
            <Appear key={i} value={anims[i + 1]} style={styles.treeChildWrap}>
              <View style={styles.treeStub} />
              <View style={[styles.treeChild, hl && { borderColor: CHALK.yellow, backgroundColor: CHALK.highlightBg }]}>
                <Text style={[styles.treeChildText, hl && { color: CHALK.yellow }]}>{c.label}</Text>
                {c.note ? <Text style={styles.treeNote}>{c.note}</Text> : null}
              </View>
            </Appear>
          );
        })}
      </View>
    </View>
  );
}

export function SceneBoard({
  visual,
  sceneKey,
  questionText,
}: {
  visual: SceneVisual;
  sceneKey: string | number;
  /** 보기(options) 장면 위에 같이 보여줄 문제 본문 */
  questionText?: string;
}) {
  switch (visual.type) {
    case "options":
      return <OptionsBoard v={visual} sceneKey={sceneKey} questionText={questionText} />;
    case "compare":
      return <CompareBoard v={visual} sceneKey={sceneKey} />;
    case "steps":
      return <StepsBoard v={visual} sceneKey={sceneKey} />;
    case "formula":
      return <FormulaBoard v={visual} sceneKey={sceneKey} />;
    case "keyword":
      return <KeywordBoard v={visual} sceneKey={sceneKey} />;
    case "tree":
      return <TreeBoard v={visual} sceneKey={sceneKey} />;
  }
}

const styles = StyleSheet.create({
  dimText: { color: CHALK.muted, opacity: 0.75 },
  titleWrap: { alignSelf: "flex-start", marginBottom: 12 },
  title: { color: CHALK.white, fontSize: 16, fontWeight: "800" },
  titleUnderline: { height: 2, borderRadius: 1, backgroundColor: CHALK.yellow, marginTop: 4, opacity: 0.8 },
  highlightBox: {
    borderColor: CHALK.yellow,
    backgroundColor: CHALK.highlightBg,
  },

  optionsList: { gap: 7 },
  questionWrap: {
    flexDirection: "row",
    gap: 6,
    paddingBottom: 10,
    marginBottom: 3,
    borderBottomWidth: 1,
    borderBottomColor: CHALK.line,
  },
  questionLabel: { color: CHALK.yellow, fontSize: 16, fontWeight: "800", lineHeight: 23 },
  questionText: { flex: 1, color: CHALK.white, fontSize: 16, fontWeight: "700", lineHeight: 23 },
  optionRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1.5,
    borderColor: "transparent",
    borderRadius: 10,
    paddingVertical: 6,
    paddingHorizontal: 8,
  },
  optionNum: { color: CHALK.white, fontSize: 15, fontWeight: "800", width: 16, textAlign: "center" },
  optionText: { flex: 1, color: CHALK.white, fontSize: 14, lineHeight: 20 },
  optionMark: { fontSize: 12, fontWeight: "800" },

  compareRow: { flexDirection: "row", alignItems: "stretch", gap: 6 },
  compareCol: { flex: 1 },
  compareHead: { fontSize: 15, fontWeight: "800" },
  compareHeadLine: { height: 2, borderRadius: 1, marginTop: 4, marginBottom: 8, opacity: 0.8 },
  bullet: { color: CHALK.white, fontSize: 13.5, lineHeight: 20, marginBottom: 4 },
  vsWrap: { justifyContent: "center", paddingHorizontal: 2 },
  vs: { color: CHALK.muted, fontSize: 14, fontWeight: "800", fontStyle: "italic" },

  stepArrow: { color: CHALK.muted, fontSize: 14, marginLeft: 9, lineHeight: 16 },
  stepRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderWidth: 1.5,
    borderColor: "transparent",
    borderRadius: 10,
    paddingVertical: 4,
    paddingHorizontal: 4,
  },
  stepNum: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: CHALK.white,
    alignItems: "center",
    justifyContent: "center",
  },
  stepNumText: { color: CHALK.white, fontSize: 12, fontWeight: "800" },
  stepText: { flex: 1, color: CHALK.white, fontSize: 15, fontWeight: "600", lineHeight: 21 },

  formulaLine: { color: CHALK.white, fontSize: 17, fontWeight: "700", lineHeight: 28, letterSpacing: 0.3 },
  formulaFirst: { color: CHALK.yellow },

  keywordWrap: { alignItems: "center", paddingVertical: 6 },
  keywordHead: { alignItems: "center" },
  keywordEmoji: { fontSize: 34, marginBottom: 4 },
  keywordTerm: { color: CHALK.yellow, fontSize: 22, fontWeight: "800", textAlign: "center" },
  keywordLine: { height: 2, width: 60, alignSelf: "center", backgroundColor: CHALK.line, marginVertical: 10 },
  keywordDef: { color: CHALK.white, fontSize: 15, lineHeight: 23, textAlign: "center" },

  treeWrap: { alignItems: "stretch" },
  treeRootWrap: { alignItems: "center" },
  treeRoot: {
    borderWidth: 1.5,
    borderColor: CHALK.white,
    borderRadius: 10,
    paddingVertical: 6,
    paddingHorizontal: 14,
  },
  treeRootText: { color: CHALK.white, fontSize: 15, fontWeight: "800" },
  treeStem: { width: 1.5, height: 12, backgroundColor: CHALK.line },
  treeBar: { height: 1.5, alignSelf: "stretch", marginHorizontal: "12%", backgroundColor: CHALK.line },
  treeChildren: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8 },
  treeChildWrap: { alignItems: "center", minWidth: 70, maxWidth: "48%" },
  treeStub: { width: 1.5, height: 10, backgroundColor: CHALK.line },
  treeChild: {
    borderWidth: 1.5,
    borderColor: CHALK.line,
    borderRadius: 10,
    paddingVertical: 5,
    paddingHorizontal: 9,
    alignItems: "center",
  },
  treeChildText: { color: CHALK.white, fontSize: 13.5, fontWeight: "700", textAlign: "center" },
  treeNote: { color: CHALK.muted, fontSize: 11.5, textAlign: "center", marginTop: 2 },
});

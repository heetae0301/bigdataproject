import React, { useState } from "react";
import { Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import {
  DAILY_GOAL_OPTIONS,
  MAX_DAILY_GOAL,
  MIN_DAILY_GOAL,
  stepDailyGoal,
  useAppSettings,
} from "@/lib/app-settings";

/**
 * 하루 목표 문제 수 편집기: −/+ 버튼, 숫자 직접 입력, 자주 쓰는 값 칩.
 * 값은 바뀔 때마다 onChange로 바로 알린다 (입력 중에는 1~200 범위의 숫자일 때만).
 */
export function DailyGoalEditor({ value, onChange }: { value: number; onChange: (goal: number) => void }) {
  const colors = useColors();
  // 입력 중에는 사용자가 친 글자를 그대로 보여주고(빈 칸, 범위 밖 숫자 포함),
  // 입력을 마치면 마지막으로 유효했던 값으로 돌아간다.
  const [focused, setFocused] = useState(false);
  const [draft, setDraft] = useState("");

  const handleChangeText = (text: string) => {
    const digits = text.replace(/[^0-9]/g, "");
    setDraft(digits);
    const n = Number(digits);
    if (digits && n >= MIN_DAILY_GOAL && n <= MAX_DAILY_GOAL) onChange(n);
  };

  return (
    <View style={styles.editor}>
      <View style={styles.stepperRow}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="목표 줄이기"
          disabled={value <= MIN_DAILY_GOAL}
          style={({ pressed }) => [
            styles.stepBtn,
            { backgroundColor: colors.background, borderColor: colors.border },
            value <= MIN_DAILY_GOAL && { opacity: 0.4 },
            pressed && { opacity: 0.6 },
          ]}
          onPress={() => onChange(stepDailyGoal(value, -1))}
        >
          <IconSymbol name="minus" size={22} color={colors.foreground} />
        </Pressable>
        <View style={styles.valueBox}>
          <TextInput
            accessibilityLabel="하루 목표 문제 수"
            value={focused ? draft : String(value)}
            onFocus={() => {
              setDraft(String(value));
              setFocused(true);
            }}
            onBlur={() => setFocused(false)}
            onChangeText={handleChangeText}
            keyboardType="number-pad"
            maxLength={3}
            selectTextOnFocus
            style={[
              styles.valueInput,
              { color: colors.foreground, borderColor: focused ? colors.primary : "transparent" },
              Platform.OS === "web" && WEB_NO_OUTLINE,
            ]}
          />
          <Text style={[styles.valueUnit, { color: colors.muted }]}>문제</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="목표 늘리기"
          disabled={value >= MAX_DAILY_GOAL}
          style={({ pressed }) => [
            styles.stepBtn,
            { backgroundColor: colors.background, borderColor: colors.border },
            value >= MAX_DAILY_GOAL && { opacity: 0.4 },
            pressed && { opacity: 0.6 },
          ]}
          onPress={() => onChange(stepDailyGoal(value, 1))}
        >
          <IconSymbol name="plus" size={22} color={colors.foreground} />
        </Pressable>
      </View>
      <View style={styles.chipRow}>
        {DAILY_GOAL_OPTIONS.map((n) => {
          const selected = n === value;
          return (
            <Pressable
              key={n}
              style={({ pressed }) => [
                styles.chip,
                {
                  backgroundColor: selected ? colors.primary : colors.background,
                  borderColor: selected ? colors.primary : colors.border,
                },
                pressed && { opacity: 0.75 },
              ]}
              onPress={() => onChange(n)}
            >
              <Text style={[styles.chipText, { color: selected ? "#FFFFFF" : colors.foreground }]}>{n}문제</Text>
            </Pressable>
          );
        })}
      </View>
      <Text style={[styles.hint, { color: colors.muted }]}>
        숫자를 눌러 직접 입력할 수 있어요 ({MIN_DAILY_GOAL}~{MAX_DAILY_GOAL}문제)
      </Text>
    </View>
  );
}

/** 홈 화면에서 바로 하루 목표를 바꾸는 창. 저장을 눌러야 적용된다. */
export function DailyGoalDialog({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const colors = useColors();
  const { settings, updateSettings } = useAppSettings();
  const [draft, setDraft] = useState(settings.dailyGoal);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
      onShow={() => setDraft(settings.dailyGoal)}
    >
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable
          style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={(e) => e.stopPropagation()}
        >
          <Text style={[styles.title, { color: colors.foreground }]}>오늘의 목표</Text>
          <Text style={[styles.desc, { color: colors.muted }]}>하루에 몇 문제를 풀지 정해 보세요.</Text>
          <DailyGoalEditor value={draft} onChange={setDraft} />
          <View style={styles.actions}>
            <Pressable
              style={({ pressed }) => [
                styles.actionBtn,
                { backgroundColor: colors.background, borderColor: colors.border },
                pressed && { opacity: 0.7 },
              ]}
              onPress={onClose}
            >
              <Text style={[styles.actionText, { color: colors.foreground }]}>취소</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.actionBtn, { backgroundColor: colors.primary }, pressed && { opacity: 0.85 }]}
              onPress={() => {
                updateSettings({ dailyGoal: draft });
                onClose();
              }}
            >
              <Text style={[styles.actionText, { color: "#FFFFFF" }]}>저장</Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// 웹 브라우저 기본 포커스 테두리 대신 아래 밑줄 색으로 포커스를 보여준다 (RN 스타일 타입에 "none"이 없어 캐스팅)
const WEB_NO_OUTLINE = { outlineStyle: "none" } as unknown as object;

const styles = StyleSheet.create({
  editor: { gap: 12 },
  stepperRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  stepBtn: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  valueBox: { flex: 1, flexDirection: "row", alignItems: "baseline", justifyContent: "center", gap: 4 },
  valueInput: {
    width: 84,
    fontSize: 36,
    fontWeight: "800",
    textAlign: "center",
    paddingVertical: 2,
    borderBottomWidth: 2,
  },
  valueUnit: { fontSize: 16, fontWeight: "600", flexShrink: 0 },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 20, borderWidth: 1 },
  chipText: { fontSize: 14, fontWeight: "600" },
  hint: { fontSize: 12, textAlign: "center" },
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  card: { width: "100%", maxWidth: 360, borderRadius: 16, borderWidth: 1, padding: 20, gap: 14 },
  title: { fontSize: 17, fontWeight: "700" },
  desc: { fontSize: 14, lineHeight: 20, marginTop: -8 },
  actions: { flexDirection: "row", gap: 10, justifyContent: "flex-end" },
  actionBtn: {
    borderWidth: 1,
    borderColor: "transparent",
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
    minWidth: 80,
    alignItems: "center",
  },
  actionText: { fontSize: 14, fontWeight: "700" },
});

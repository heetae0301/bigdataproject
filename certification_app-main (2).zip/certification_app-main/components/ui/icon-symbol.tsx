// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<string, ComponentProps<typeof MaterialIcons>["name"]>;
export type IconSymbolName = keyof typeof MAPPING;

/**
 * Add your SF Symbols to Material Icons mappings here.
 * - see Material Icons in the [Icons Directory](https://icons.expo.fyi).
 * - see SF Symbols in the [SF Symbols](https://developer.apple.com/sf-symbols/) app.
 */
const MAPPING = {
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "expand-more",
  "book.fill": "menu-book",
  "doc.text.fill": "description",
  "chart.bar.fill": "bar-chart",
  "xmark.circle.fill": "cancel",
  "checkmark.circle.fill": "check-circle",
  "arrow.clockwise": "refresh",
  "star.fill": "star",
  "flame.fill": "local-fire-department",
  "trophy.fill": "emoji-events",
  "list.bullet": "list",
  "shuffle": "shuffle",
  "play.fill": "play-arrow",
  "pause.fill": "pause",
  "gobackward.10": "replay-10",
  "goforward.10": "forward-10",
  "xmark": "close",
  "checkmark": "check",
  "info.circle": "info",
  "exclamationmark.triangle.fill": "warning",
  "lightbulb.fill": "lightbulb",
  "person.fill": "person",
  "gear": "settings",
  "magnifyingglass": "search",
  "trash.fill": "delete",
  "arrow.right": "arrow-forward",
  "arrow.left": "arrow-back",
  "circle.fill": "circle",
  "circle": "radio-button-unchecked",
  "stop.fill": "stop",
  "camera.fill": "camera-alt",
  "photo.fill": "photo",
  "speaker.wave.2.fill": "volume-up",
  "rectangle.portrait.and.arrow.right": "logout",
  "clock.fill": "access-time",
  "flag.checkered": "flag",
  "bookmark": "bookmark-border",
  "bookmark.fill": "bookmark",
  "calendar": "event",
  "bell.fill": "notifications",
  "graduationcap.fill": "school",
  "chart.line.uptrend.xyaxis": "show-chart",
  "pencil": "edit",
  "plus": "add",
  "minus": "remove",
  "target": "track-changes",
  "moon.fill": "dark-mode",
  "textformat.size": "format-size",
} satisfies IconMapping;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 * This ensures a consistent look across platforms, and optimal resource usage.
 * Icon `name`s are based on SF Symbols and require manual mapping to Material Icons.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}

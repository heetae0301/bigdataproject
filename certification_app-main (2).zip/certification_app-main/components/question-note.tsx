import React, { useState } from "react";
import { View, Text, TextInput, Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";

const NOTE_MAX_LENGTH = 500;

/**
 * 문제 하나에 대한 메모 입력칸. 내용이 바뀌었을 때만 "저장" 버튼이 나타나고,
 * 비우고 저장하면 메모가 삭제된다.
 */
export function QuestionNote({
  note,
  onSave,
  collapsible = false,
}: {
  /** 저장되어 있는 메모 (없으면 빈 문자열) */
  note: string;
  onSave: (note: string) => void;
  /** true면 메모가 없을 때 "메모 남기기" 버튼으로 접어 둔다 */
  collapsible?: boolean;
}) {
  const colors = useColors();
  const [draft, setDraft] = useState(note);
  const [expanded, setExpanded] = useState(false);

  // 메모 목록이 늦게 로드되거나 저장이 끝나면 입력칸을 저장된 값에 맞춘다.
  const [syncedNote, setSyncedNote] = useState(note);
  if (note !== syncedNote) {
    setSyncedNote(note);
    setDraft(note);
  }

  const changed = draft.trim() !== note;

  if (collapsible && !note && !expanded) {
    return (
      <Pressable
        accessibilityRole="button"
        style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.6 }]}
        onPress={() => setExpanded(true)}
      >
        <IconSymbol name="plus" size={14} color={colors.muted} />
        <Text style={[styles.addText, { color: colors.muted }]}>메모 남기기</Text>
      </Pressable>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background, borderColor: colors.border }]}>
      <View style={styles.header}>
        <IconSymbol name="pencil" size={14} color={colors.muted} />
        <Text style={[styles.label, { color: colors.muted }]}>내 메모</Text>
        {changed && (
          <Pressable
            style={({ pressed }) => [
              styles.saveBtn,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.8 },
            ]}
            onPress={() => onSave(draft)}
          >
            <Text style={styles.saveBtnText}>저장</Text>
          </Pressable>
        )}
      </View>
      <TextInput
        value={draft}
        onChangeText={setDraft}
        placeholder="헷갈린 점이나 외울 내용을 적어두세요"
        placeholderTextColor={colors.muted}
        multiline
        autoFocus={collapsible && expanded && !note}
        maxLength={NOTE_MAX_LENGTH}
        style={[styles.input, { color: colors.foreground }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { borderRadius: 10, borderWidth: 1, padding: 10, gap: 6 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "flex-start", paddingVertical: 6 },
  addText: { fontSize: 13, fontWeight: "700" },
  header: { flexDirection: "row", alignItems: "center", gap: 6, minHeight: 24 },
  label: { fontSize: 11, fontWeight: "700", flex: 1 },
  saveBtn: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 8 },
  saveBtnText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  input: { fontSize: 13, lineHeight: 20, minHeight: 40, padding: 0, textAlignVertical: "top" },
});

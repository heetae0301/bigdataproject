import React, { useState } from "react";
import { View, Text, Pressable, StyleSheet } from "react-native";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { useColors } from "@/hooks/use-colors";
import { isValidDateStr, kstDateStr } from "@/lib/kst-date";

const WEEKDAYS = ["일", "월", "화", "수", "목", "금", "토"];
const pad = (n: number) => String(n).padStart(2, "0");

/**
 * 달력에서 날짜 하나를 고르는 월 단위 달력. 값은 YYYY-MM-DD(빈 문자열 = 선택 없음).
 * 선택된 날짜를 다시 누르면 선택이 해제된다.
 */
export function DateCalendar({
  value,
  onChange,
  minDate,
}: {
  value: string;
  onChange: (value: string) => void;
  /** 이 날짜(YYYY-MM-DD)보다 이전은 선택할 수 없다. */
  minDate?: string;
}) {
  const colors = useColors();
  const today = kstDateStr();
  const selected = isValidDateStr(value) ? value : "";

  const [view, setView] = useState(() => monthOf(selected || today));

  // 저장된 시험일이 늦게 로드되면 그 달로 이동한다.
  const [syncedSelected, setSyncedSelected] = useState(selected);
  if (selected !== syncedSelected) {
    setSyncedSelected(selected);
    if (selected) setView(monthOf(selected));
  }

  const moveMonth = (delta: number) => {
    setView((prev) => {
      const d = new Date(Date.UTC(prev.year, prev.month + delta, 1));
      return { year: d.getUTCFullYear(), month: d.getUTCMonth() };
    });
  };

  const firstWeekday = new Date(Date.UTC(view.year, view.month, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(view.year, view.month + 1, 0)).getUTCDate();
  const cells: (number | null)[] = [
    ...Array<null>(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable
          style={({ pressed }) => [styles.navBtn, pressed && { opacity: 0.6 }]}
          onPress={() => moveMonth(-1)}
        >
          <IconSymbol name="chevron.left" size={22} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.monthText, { color: colors.foreground }]}>
          {view.year}년 {view.month + 1}월
        </Text>
        <Pressable
          style={({ pressed }) => [styles.navBtn, pressed && { opacity: 0.6 }]}
          onPress={() => moveMonth(1)}
        >
          <IconSymbol name="chevron.right" size={22} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={styles.grid}>
        {WEEKDAYS.map((w, i) => (
          <View key={w} style={styles.cell}>
            <Text
              style={[
                styles.weekdayText,
                { color: i === 0 ? colors.error : i === 6 ? colors.primary : colors.muted },
              ]}
            >
              {w}
            </Text>
          </View>
        ))}

        {cells.map((day, i) => {
          if (day === null) return <View key={`empty-${i}`} style={styles.cell} />;

          const dateStr = `${view.year}-${pad(view.month + 1)}-${pad(day)}`;
          const isSelected = dateStr === selected;
          const isToday = dateStr === today;
          const disabled = !!minDate && dateStr < minDate;
          const weekday = i % 7;

          return (
            <View key={dateStr} style={styles.cell}>
              <Pressable
                style={({ pressed }) => [
                  styles.dayBtn,
                  isToday && { borderWidth: 1, borderColor: colors.primary },
                  isSelected && { backgroundColor: colors.primary },
                  pressed && { opacity: 0.6 },
                ]}
                onPress={() => onChange(isSelected ? "" : dateStr)}
                disabled={disabled}
              >
                <Text
                  style={[
                    styles.dayText,
                    {
                      color: isSelected
                        ? "#FFFFFF"
                        : weekday === 0
                          ? colors.error
                          : weekday === 6
                            ? colors.primary
                            : colors.foreground,
                    },
                    disabled && { opacity: 0.3 },
                  ]}
                >
                  {day}
                </Text>
              </Pressable>
            </View>
          );
        })}
      </View>
    </View>
  );
}

function monthOf(dateStr: string): { year: number; month: number } {
  const [year, month] = dateStr.split("-").map(Number);
  return { year, month: month - 1 };
}

const styles = StyleSheet.create({
  container: { gap: 8 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  navBtn: { width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  monthText: { fontSize: 16, fontWeight: "700" },
  grid: { flexDirection: "row", flexWrap: "wrap" },
  cell: { width: `${100 / 7}%`, alignItems: "center", paddingVertical: 2 },
  weekdayText: { fontSize: 12, fontWeight: "600", paddingVertical: 6 },
  dayBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  dayText: { fontSize: 14, fontWeight: "600", fontVariant: ["tabular-nums"] },
});

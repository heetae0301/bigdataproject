import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/use-colors";

const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/**
 * 로그인·회원가입·비밀번호 찾기 화면 위쪽의 파란 영역: 앱 이름 + 동그래 + 말풍선.
 * 화면 맨 위까지 채우므로 ScreenContainer는 top edge 없이 쓴다(안전 영역은 여기서 띄운다).
 */
export function AuthHero({ label, title, bubble }: { label: string; title: string; bubble: string }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.hero, { backgroundColor: colors.primary, paddingTop: insets.top + 40 }]}>
      <View style={styles.circle} />
      <Image source={CHARACTER_SOURCE} style={styles.character} contentFit="contain" accessibilityLabel="동그래" />
      <View style={styles.text}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.title}>{title}</Text>
        <View style={styles.bubble}>
          <Text style={styles.bubbleText}>{bubble}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  hero: {
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
    paddingHorizontal: 24,
    paddingBottom: 28,
    minHeight: 250,
    overflow: "hidden",
  },
  circle: {
    position: "absolute",
    right: -50,
    bottom: -20,
    width: 220,
    height: 220,
    borderRadius: 110,
    backgroundColor: "rgba(255,255,255,0.12)",
  },
  character: {
    position: "absolute",
    right: 4,
    bottom: -8,
    width: 160,
    height: 160,
  },
  text: {
    width: "58%",
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: "rgba(255,255,255,0.85)",
  },
  title: {
    fontSize: 28,
    fontWeight: "800",
    letterSpacing: -0.5,
    lineHeight: 35,
    color: "#FFFFFF",
    marginTop: 4,
  },
  bubble: {
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    borderBottomLeftRadius: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginTop: 14,
  },
  bubbleText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#0F172A",
  },
});

import React, { useState } from "react";
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { ScreenContainer } from "@/components/screen-container";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { DmuExplanationPlayer } from "@/components/dmu-explanation-player";
import { useColors } from "@/hooks/use-colors";
import { loadDonguraeExplanation, type DonguraeExplanation } from "@/lib/dongurae-explanation";
import type { Question } from "@/data/questions";

const CHARACTER_SOURCE = require("@/assets/images/dmu-character.png");

/**
 * 문제 풀이 화면용 "동그래 해설 듣기" 버튼 + 재생 모달.
 * 고른 답 기준의 그림 해설(장면 대본)을 먼저 만들고, 실패하면 예전처럼
 * 틀렸을 땐 오답 맞춤 해설, 맞혔을 땐 문제은행 기본 해설을 읽어준다 (lib/dongurae-explanation.ts).
 */
export function DonguraeExplainButton({
  question,
  selectedOption,
}: {
  question: Question;
  selectedOption: number;
}) {
  const colors = useColors();
  const [explanation, setExplanation] = useState<DonguraeExplanation | null>(null);
  const [loading, setLoading] = useState(false);

  const isCorrect = selectedOption === question.answer;

  const handlePress = async () => {
    if (loading) return;
    setLoading(true);
    try {
      setExplanation(await loadDonguraeExplanation(question, selectedOption));
    } finally {
      setLoading(false);
    }
  };

  const subtitle = loading
    ? "칠판에 그림을 준비하는 중이에요..."
    : isCorrect
      ? "핵심만 다시 짚어줄게!"
      : `왜 ${selectedOption + 1}번이 틀렸는지 알려줄게!`;

  return (
    <>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="동그래 해설 듣기"
        style={({ pressed }) => [
          styles.btn,
          { backgroundColor: colors.primary + "12", borderColor: colors.primary + "40" },
          (pressed || loading) && { opacity: 0.75 },
        ]}
        onPress={handlePress}
        disabled={loading}
      >
        <Image source={CHARACTER_SOURCE} style={styles.character} contentFit="contain" />
        <View style={styles.textBox}>
          <Text style={[styles.btnText, { color: colors.primary }]}>동그래 해설 듣기</Text>
          <Text style={[styles.subText, { color: colors.foreground }]}>{subtitle}</Text>
        </View>
        {loading ? (
          <ActivityIndicator size="small" color={colors.primary} />
        ) : (
          <IconSymbol name="play.fill" size={16} color={colors.primary} />
        )}
      </Pressable>

      {/* Modal은 앱 루트의 GestureHandlerRootView 밖에 렌더링되므로 안에 하나 더 둔다 (wrong.tsx 참고). */}
      <Modal
        visible={explanation !== null}
        animationType="slide"
        onRequestClose={() => setExplanation(null)}
      >
        <GestureHandlerRootView style={{ flex: 1 }}>
          <ScreenContainer>
            <DmuExplanationPlayer
              explanation={explanation?.explanation ?? ""}
              scenes={explanation?.scenes}
              questionText={explanation?.question}
              referenceExplanation={question.explanation}
              onClose={() => setExplanation(null)}
            />
          </ScreenContainer>
        </GestureHandlerRootView>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  btn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  character: {
    width: 40,
    height: 40,
  },
  textBox: {
    flex: 1,
    gap: 1,
  },
  btnText: {
    fontSize: 14,
    fontWeight: "800",
  },
  subText: {
    fontSize: 13,
  },
});

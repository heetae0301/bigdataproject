"""
기출 PDF에서 그림 문제의 그림 영역을 잘라 PNG로 저장하고,
data/question-images.ts (Question.image 키 → require 매핑)를 다시 생성한다.

사용법
  pip install pymupdf
  python scripts/extract_question_images.py            # scripts/pdfs/ 의 PDF 사용
  python scripts/extract_question_images.py <PDF폴더>   # 다른 폴더 지정
  python scripts/extract_question_images.py --map-only # 추출 없이 매핑 파일만 재생성

- PDF 파일명에 'NN회'가 들어 있으면 회차를 자동으로 찾는다. (예: 'ADsP 44회 기출 복원 (링크).pdf')
- 자른 영역이 어긋나면 FIGURES의 rect 값을 조정한 뒤 다시 실행한다.
- 이미지를 직접 assets/images/questions/<키>.png 로 넣고 --map-only 로 매핑만 갱신해도 된다.
"""

import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "assets" / "images" / "questions"
MAP_FILE = ROOT / "data" / "question-images.ts"
DEFAULT_PDF_DIR = ROOT / "scripts" / "pdfs"
ZOOM = 3  # 렌더링 배율 (PDF 72dpi 기준 → 약 216dpi)

# key: Question.image 값 / exam: 회차 / page: 1부터 시작하는 페이지 번호
# rect: 페이지 크기 대비 비율 (x0, y0, x1, y1)
# mask: (선택) 잘라낸 영역 대비 비율로, 흰색으로 덮을 부분 목록 (그림 옆에 걸친 문제 글 등)
FIGURES = [
    {"key": "adsp44-25", "exam": 44, "page": 2, "rect": (0.84, 0.57, 0.97, 0.69)},   # Box plot
    {"key": "adsp44-31", "exam": 44, "page": 3, "rect": (0.325, 0.445, 0.49, 0.515)},  # 노드 C (Good/Bad)
    {"key": "adsp45-44", "exam": 45, "page": 4, "rect": (0.25, 0.08, 0.47, 0.23)},   # 덴드로그램
    {"key": "adsp47-23", "exam": 47, "page": 2, "rect": (0.83, 0.35, 0.96, 0.465)},  # Box plot
    {"key": "adsp47-27", "exam": 47, "page": 3, "rect": (0.33, 0.05, 0.495, 0.175)},  # 오른쪽 꼬리 분포
    {"key": "adsp47-46", "exam": 47, "page": 4, "rect": (0.72, 0.18, 0.985, 0.31),
     "mask": [(0, 0, 0.18, 0.11)]},                                                   # Scree plot
    {"key": "adsp48-29", "exam": 48, "page": 3, "rect": (0.60, 0.345, 0.89, 0.527)},  # 잔차도
    {"key": "adsp50-32", "exam": 50, "page": 8, "rect": (0.06, 0.14, 0.95, 0.40)},   # ACF / PACF
    {"key": "adsp50-46", "exam": 50, "page": 12, "rect": (0.06, 0.16, 0.95, 0.385)}, # 산점도
    # ── 표 (교차표·거래표·혼동행렬·요약 통계표·R 출력) ──
    {"key": "adsp44-33", "exam": 44, "page": 3, "rect": (0.22, 0.78, 0.49, 0.853)},    # 성별·과일 교차표
    {"key": "adsp44-50", "exam": 44, "page": 4, "rect": (0.525, 0.487, 0.885, 0.54)},  # 관광지 방문 표
    {"key": "adsp45-45", "exam": 45, "page": 4, "rect": (0.255, 0.285, 0.48, 0.335)},  # 버터·빵 표
    {"key": "adsp46-49", "exam": 46, "page": 4, "rect": (0.538, 0.392, 0.975, 0.499)},  # 음료 구매 건수
    {"key": "adsp47-44", "exam": 47, "page": 4, "rect": (0.07, 0.571, 0.43, 0.702)},   # 오분류표
    {"key": "adsp47-50", "exam": 47, "page": 4, "rect": (0.51, 0.841, 0.96, 0.894)},   # 음료 구매 건수
    {"key": "adsp48-49", "exam": 48, "page": 5, "rect": (0.024, 0.696, 0.36, 0.814)},  # 품목별 거래 건수
    {"key": "adsp49-26", "exam": 49, "page": 3, "rect": (0.513, 0.152, 0.807, 0.255)}, # 요약 통계량
    {"key": "adsp49-41", "exam": 49, "page": 4, "rect": (0.516, 0.788, 0.79, 0.849)},  # 상자그림 요약
    {"key": "adsp49-44", "exam": 49, "page": 5, "rect": (0.022, 0.4, 0.203, 0.464)},   # 확률분포표
    {"key": "adsp49-48", "exam": 49, "page": 5, "rect": (0.521, 0.221, 0.768, 0.304)}, # 혼동행렬
    {"key": "adsp49-49", "exam": 49, "page": 5, "rect": (0.521, 0.472, 0.818, 0.556)}, # 기저귀·맥주 거래
    {"key": "adsp50-27", "exam": 50, "page": 6, "rect": (0.06, 0.396, 0.57, 0.454)},   # 우유·빵 거래
    {"key": "adsp50-28", "exam": 50, "page": 6, "rect": (0.06, 0.668, 0.818, 0.776)},  # PCA 결과
    {"key": "adsp50-31", "exam": 50, "page": 7, "rect": (0.06, 0.28, 0.955, 0.741)},   # 로지스틱 회귀 R 출력
    {"key": "adsp50-35", "exam": 50, "page": 9, "rect": (0.06, 0.165, 0.955, 0.46)},   # 선형회귀 R 출력
    {"key": "adsp50-41", "exam": 50, "page": 10, "rect": (0.06, 0.602, 0.461, 0.71)},  # 분산분석표
    {"key": "adsp50-49", "exam": 50, "page": 13, "rect": (0.06, 0.148, 0.408, 0.256)}, # 혼동행렬
]


def find_pdfs(pdf_dir: Path) -> dict[int, Path]:
    pdfs: dict[int, Path] = {}
    for path in pdf_dir.glob("*.pdf"):
        m = re.search(r"(\d+)\s*회", path.name)
        if m:
            pdfs[int(m.group(1))] = path
    return pdfs


def extract(pdf_dir: Path) -> None:
    import pymupdf as fitz

    pdfs = find_pdfs(pdf_dir)
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    for fig in FIGURES:
        pdf_path = pdfs.get(fig["exam"])
        if pdf_path is None:
            print(f"[건너뜀] {fig['key']}: {fig['exam']}회 PDF를 {pdf_dir} 에서 찾지 못함")
            continue
        with fitz.open(pdf_path) as doc:
            page = doc[fig["page"] - 1]
            w, h = page.rect.width, page.rect.height
            x0, y0, x1, y1 = fig["rect"]
            clip = fitz.Rect(x0 * w, y0 * h, x1 * w, y1 * h)
            pix = page.get_pixmap(matrix=fitz.Matrix(ZOOM, ZOOM), clip=clip, alpha=False)
            for mx0, my0, mx1, my1 in fig.get("mask", []):
                # 잘라낸 pixmap의 원점(pix.x, pix.y)은 페이지 기준 좌표라 오프셋을 더해야 한다
                mask = fitz.IRect(
                    pix.x + int(mx0 * pix.width), pix.y + int(my0 * pix.height),
                    pix.x + int(mx1 * pix.width), pix.y + int(my1 * pix.height),
                )
                pix.set_rect(mask, (255, 255, 255))
            out = OUT_DIR / f"{fig['key']}.png"
            pix.save(out)
            print(f"[저장] {out.relative_to(ROOT)} ({pix.width}x{pix.height})")


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as f:
        header = f.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"PNG 파일이 아님: {path}")
    return struct.unpack(">II", header[16:24])


def write_map() -> None:
    entries = []
    for path in sorted(OUT_DIR.glob("*.png")) if OUT_DIR.exists() else []:
        width, height = png_size(path)
        entries.append(
            f'  "{path.stem}": {{ source: require("../assets/images/questions/{path.name}"), '
            f"aspectRatio: {width / height:.4f} }},"
        )

    body = "\n".join(entries)
    content = (
        "// 이 파일은 scripts/extract_question_images.py 가 자동 생성합니다. 직접 수정하지 마세요.\n"
        "// assets/images/questions/ 폴더의 PNG 파일을 Question.image 키로 매핑합니다.\n"
        "\n"
        "export interface QuestionImageAsset {\n"
        "  source: number;\n"
        "  aspectRatio: number; // width / height\n"
        "}\n"
        "\n"
        + (
            f"export const QUESTION_IMAGES: Record<string, QuestionImageAsset> = {{\n{body}\n}};\n"
            if entries
            else "export const QUESTION_IMAGES: Record<string, QuestionImageAsset> = {};\n"
        )
    )
    MAP_FILE.write_text(content, encoding="utf-8")
    print(f"[갱신] {MAP_FILE.relative_to(ROOT)} ({len(entries)}개 이미지)")


def main() -> None:
    args = sys.argv[1:]
    if "--map-only" not in args:
        pdf_dir = Path(args[0]) if args else DEFAULT_PDF_DIR
        if not pdf_dir.exists():
            sys.exit(f"PDF 폴더가 없습니다: {pdf_dir}")
        extract(pdf_dir)
    write_map()


if __name__ == "__main__":
    main()

#!/usr/bin/env node
// npm/pnpm run scripts through cmd.exe on Windows, which doesn't understand
// bash's ${VAR:-default} syntax. This wrapper picks the port in Node instead,
// so `pnpm dev:metro` works the same on Windows, macOS, and Linux.
//
// .env에 NGROK_AUTHTOKEN과 NGROK_DOMAIN이 있으면 본인 ngrok 고정 도메인으로
// Metro를 터널링한다. 주소가 안 바뀌어서 Expo Go QR도 매번 같다.
// (expo-dev-client가 설치돼 있어 --go를 줘야 QR이 Expo Go용으로 나온다.)
import "./load-env.js";
import { spawn } from "node:child_process";
import QRCode from "qrcode";

const port = process.env.EXPO_PORT || "8081";
const env = { ...process.env, EXPO_USE_METRO_WORKSPACE_ROOT: "1" };

let listener = null;
const NGROK_AUTHTOKEN = process.env.NGROK_AUTHTOKEN;
const NGROK_DOMAIN = process.env.NGROK_DOMAIN;

if (NGROK_AUTHTOKEN && NGROK_DOMAIN) {
  const ngrok = await import("@ngrok/ngrok");
  listener = await ngrok.forward({
    addr: Number(port),
    authtoken: NGROK_AUTHTOKEN,
    domain: NGROK_DOMAIN,
  });
  env.EXPO_PACKAGER_PROXY_URL = `https://${NGROK_DOMAIN}`;

  const expoGoUrl = `exp://${NGROK_DOMAIN}`;
  await QRCode.toFile("expo-qr-code.png", expoGoUrl, { width: 512 });
  console.log(`\n[ngrok] ${listener.url()} -> localhost:${port}`);
  console.log(`[ngrok] Expo Go 주소: ${expoGoUrl} (QR: expo-qr-code.png)\n`);
  console.log(await QRCode.toString(expoGoUrl, { type: "terminal", small: true }));
}

const child = spawn("npx", ["expo", "start", "--go", "--web", "--port", port], {
  stdio: "inherit",
  shell: true,
  env,
});

child.on("exit", async (code) => {
  await listener?.close();
  process.exit(code ?? 1);
});

import { createHash, randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { synthesizeSpeech, TTS_PCM_SAMPLE_RATE, TTS_VOICE } from "./ai";
import { listCachedSpeechHashes, loadCachedSpeech, saveCachedSpeech } from "./ai-cache-store";

/**
 * 동그래 해설 AI 목소리 (OpenAI TTS, server/lib/ai.ts).
 *
 * 음성 생성은 쓴 만큼 돈이 들고 시간도 걸려서, 같은 해설은 한 번 정상으로 만든
 * 음성을 저장해 두고 다시 쓴다: 메모리(빠름) → DB speech_cache(서버가 잠들어도 남음) → 생성 순.
 * 맞춤 해설도 "문제 + 고른 답"별로 저장되므로(explanation_cache) 같은 오답이면 문장이 같아져 여기서 재사용된다.
 * 생성에 실패하면 앱은 이유를 보여주고, 사용자가 고르면 폰 내장 목소리로 읽는다(components/dmu-explanation-player.tsx).
 */

// 저장 키 버전: 음성 만드는 방식이 바뀌면 올려서 예전 음성을 쓰지 않게 한다.
// v3: Gemini TTS(Achird) → OpenAI TTS. 예전 목소리와 섞이지 않게 키가 달라진다.
const SPEECH_CACHE_VERSION = "v3";

// 30초 해설 WAV가 약 1.4MB라 40개면 60MB 정도. Render 무료 플랜(512MB)에서 안전한 선.
const MAX_CACHE_ENTRIES = 40;

interface CachedAudio {
  id: string;
  wav: Buffer;
  durationSec: number;
}

const byTextHash = new Map<string, CachedAudio>(); // 삽입 순서 = 오래된 순 (LRU)
const byId = new Map<string, CachedAudio>();
const inFlight = new Map<string, Promise<CachedAudio>>();

function remember(hash: string, entry: CachedAudio) {
  byTextHash.delete(hash);
  byTextHash.set(hash, entry);
  byId.set(entry.id, entry);
  while (byTextHash.size > MAX_CACHE_ENTRIES) {
    const [oldestHash, oldest] = byTextHash.entries().next().value!;
    byTextHash.delete(oldestHash);
    byId.delete(oldest.id);
  }
}

/** 헤더 없는 PCM(audio/L16;rate=...)에 WAV 헤더를 붙인다. 이미 WAV면 그대로. */
export function toWav(audio: Buffer, mimeType: string): Buffer {
  if (audio.subarray(0, 4).toString() === "RIFF") return audio;
  const rate = Number(/rate=(\d+)/.exec(mimeType)?.[1] ?? 24000);
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + audio.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // PCM
  header.writeUInt16LE(1, 22); // mono
  header.writeUInt32LE(rate, 24);
  header.writeUInt32LE(rate * 2, 28); // byte rate (16-bit mono)
  header.writeUInt16LE(2, 32);
  header.writeUInt16LE(16, 34);
  header.write("data", 36);
  header.writeUInt32LE(audio.length, 40);
  return Buffer.concat([header, audio]);
}

/** WAV 헤더의 byte rate로 재생 시간(초)을 계산한다. */
export function wavDurationSec(wav: Buffer): number {
  const byteRate = wav.readUInt32LE(28);
  return byteRate > 0 ? (wav.length - 44) / byteRate : 0;
}

async function generate(text: string): Promise<{ wav: Buffer; durationSec: number; complete: boolean }> {
  const wav = toWav(await synthesizeSpeech(text), `audio/L16;rate=${TTS_PCM_SAMPLE_RATE}`);
  // OpenAI 음성 API는 끝까지 만든 음성만 돌려준다 (중간에 끊긴 응답은 오류로 온다).
  return { wav, durationSec: wavDurationSec(wav), complete: true };
}

export function speechHash(text: string): string {
  return createHash("sha256").update(`${SPEECH_CACHE_VERSION}\n${TTS_VOICE}\n${text}`).digest("hex");
}

/** 음성이 준비된 해설의 해시 전체 — DB 저장분 + 메모리 (미리 만들기 작업이 건너뛸 대상을 고를 때 쓴다). */
export async function storedSpeechHashes(): Promise<Set<string>> {
  const hashes = await listCachedSpeechHashes();
  for (const hash of byTextHash.keys()) hashes.add(hash);
  return hashes;
}

/** 사용자 요청으로 음성을 만드는 중인지 (미리 만들기 작업은 이때 양보한다). */
export function isGeneratingForUser(): boolean {
  return inFlight.size > 0;
}

/** 해설 텍스트의 음성을 준비하고(캐시 우선) 재생용 id와 길이를 돌려준다. */
export async function prepareSpeech(text: string): Promise<{ id: string; durationSec: number }> {
  const hash = speechHash(text);
  const cached = byTextHash.get(hash);
  if (cached) {
    remember(hash, cached); // 최근 사용으로 갱신
    return { id: cached.id, durationSec: cached.durationSec };
  }

  // 같은 해설을 여러 명이 동시에 요청해도 DB 조회/AI 호출은 한 번만 한다.
  let pending = inFlight.get(hash);
  if (!pending) {
    pending = (async () => {
      // 서버가 잠들었다 깨서 메모리가 비었어도, 전에 정상으로 만든 음성은 DB에 남아 있다.
      const stored = await loadCachedSpeech(hash);
      const audio = stored ?? (await generate(text));
      if (!stored && "complete" in audio && audio.complete) {
        await saveCachedSpeech(hash, audio.wav, audio.durationSec); // 정상으로 끝까지 만든 것만 저장
      }
      const entry = { id: randomBytes(16).toString("hex"), wav: audio.wav, durationSec: audio.durationSec };
      remember(hash, entry);
      return entry;
    })().finally(() => inFlight.delete(hash));
    inFlight.set(hash, pending);
  }
  const entry = await pending;
  return { id: entry.id, durationSec: entry.durationSec };
}

/**
 * GET /api/tts/:id.wav — 준비된 음성 파일. iOS 플레이어(AVPlayer)는 Range 요청을 지원하지
 * 않는 서버의 오디오를 재생하지 못하는 경우가 있어서 bytes 범위 요청을 처리한다.
 * id는 추측할 수 없는 무작위 값이고, 해설 음성 자체는 민감한 정보가 아니라 로그인을 요구하지 않는다
 * (오디오 플레이어가 Authorization 헤더를 안정적으로 붙이지 못하는 플랫폼도 있다).
 */
export function serveSpeech(req: Request, res: Response) {
  const entry = byId.get(req.params.id);
  if (!entry) {
    res.status(404).end();
    return;
  }
  const { wav } = entry;
  res.setHeader("Content-Type", "audio/wav");
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Cache-Control", "private, max-age=600");

  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range ?? "");
  if (!range) {
    res.setHeader("Content-Length", wav.length);
    res.end(wav);
    return;
  }
  const start = range[1] ? Number(range[1]) : Math.max(0, wav.length - Number(range[2]));
  const end = range[1] && range[2] ? Math.min(Number(range[2]), wav.length - 1) : wav.length - 1;
  if (start >= wav.length || start > end) {
    res.status(416).setHeader("Content-Range", `bytes */${wav.length}`).end();
    return;
  }
  res.status(206);
  res.setHeader("Content-Range", `bytes ${start}-${end}/${wav.length}`);
  res.setHeader("Content-Length", end - start + 1);
  res.end(wav.subarray(start, end + 1));
}

/** 테스트용 */
export function _resetTtsCacheForTest() {
  byTextHash.clear();
  byId.clear();
  inFlight.clear();
}

import { and, eq } from "drizzle-orm";
import { db } from "../db/client";
import { explanationCache, sceneCache, speechCache } from "../db/schema";

/**
 * 동그래 해설용 공용 캐시의 DB 읽기/쓰기. AI가 "정상으로 만든" 결과만 저장한다
 * (실패하면 저장하지 않아서 다음 요청 때 다시 시도된다).
 * DB 오류는 기능을 막지 않도록 삼키고 경고만 남긴다 — 캐시는 있으면 좋은 것일 뿐이다.
 */

export async function loadCachedExplanation(questionId: string, selectedOption: number): Promise<string | null> {
  try {
    const row = await db
      .select({ explanation: explanationCache.explanation })
      .from(explanationCache)
      .where(and(eq(explanationCache.questionId, questionId), eq(explanationCache.selectedOption, selectedOption)))
      .get();
    return row?.explanation ?? null;
  } catch (error) {
    console.warn("[AiCache] explanation load failed:", error);
    return null;
  }
}

export async function saveCachedExplanation(questionId: string, selectedOption: number, explanation: string) {
  try {
    await db
      .insert(explanationCache)
      .values({ questionId, selectedOption, explanation, createdAt: Date.now() })
      .onConflictDoNothing();
  } catch (error) {
    console.warn("[AiCache] explanation save failed:", error);
  }
}

export async function loadCachedSpeech(textHash: string): Promise<{ wav: Buffer; durationSec: number } | null> {
  try {
    const row = await db
      .select({ wav: speechCache.wav, durationSec: speechCache.durationSec })
      .from(speechCache)
      .where(eq(speechCache.textHash, textHash))
      .get();
    return row ? { wav: Buffer.from(row.wav), durationSec: row.durationSec } : null;
  } catch (error) {
    console.warn("[AiCache] speech load failed:", error);
    return null;
  }
}

/** 저장된 음성의 해시 전체 (음성 데이터는 읽지 않는다). */
export async function listCachedSpeechHashes(): Promise<Set<string>> {
  try {
    const rows = await db.select({ textHash: speechCache.textHash }).from(speechCache);
    return new Set(rows.map((r) => r.textHash));
  } catch (error) {
    console.warn("[AiCache] speech hash list failed:", error);
    return new Set();
  }
}

export async function saveCachedSpeech(textHash: string, wav: Buffer, durationSec: number) {
  try {
    await db
      .insert(speechCache)
      .values({ textHash, wav, durationSec, createdAt: Date.now() })
      .onConflictDoNothing();
  } catch (error) {
    console.warn("[AiCache] speech save failed:", error);
  }
}

export async function loadCachedScenes(questionId: string, selectedOption: number): Promise<string | null> {
  try {
    const row = await db
      .select({ scenesJson: sceneCache.scenesJson })
      .from(sceneCache)
      .where(and(eq(sceneCache.questionId, questionId), eq(sceneCache.selectedOption, selectedOption)))
      .get();
    return row?.scenesJson ?? null;
  } catch (error) {
    console.warn("[AiCache] scenes load failed:", error);
    return null;
  }
}

export async function saveCachedScenes(questionId: string, selectedOption: number, scenesJson: string) {
  try {
    await db
      .insert(sceneCache)
      .values({ questionId, selectedOption, scenesJson, createdAt: Date.now() })
      // 대본 규칙이 바뀌어 새로 만든 대본은 옛 대본을 덮어쓴다 (SCENE_SCRIPT_VERSION)
      .onConflictDoUpdate({
        target: [sceneCache.questionId, sceneCache.selectedOption],
        set: { scenesJson, createdAt: Date.now() },
      });
  } catch (error) {
    console.warn("[AiCache] scenes save failed:", error);
  }
}

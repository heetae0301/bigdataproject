import { generateText } from "./ai";
import { loadCachedScenes, saveCachedScenes } from "./ai-cache-store";
import {
  explanationSceneSchema,
  MAX_SCENES,
  MIN_SCENES,
  type ExplanationScene,
} from "@/lib/explanation-scenes";
import type { Question } from "@/data/questions";

/**
 * 동그래 그림 해설의 장면 대본을 만든다 (형식은 lib/explanation-scenes.ts).
 * "문제 + 고른 답"마다 정상으로 만든 대본은 scene_cache에 저장해 모두가 같이 쓴다 —
 * AI 비용을 아끼고, 같은 대사가 되므로 AI 목소리 캐시(speech_cache)도 재사용된다.
 */

/** 대본 규칙(프롬프트)을 바꾸면 올린다 — 버전이 다른 저장분은 새로 만들어 덮어쓴다. */
export const SCENE_SCRIPT_VERSION = 2;

const SYSTEM_INSTRUCTION = `당신은 ADSP(데이터분석 준전문가) 자격증 강사 캐릭터 "동그래"입니다.
칠판에 그림을 그려 가며 설명하는 짧은 해설 영상의 대본을 JSON으로 만듭니다.

규칙:
- 장면은 3~5개. 대사(narration)를 모두 이으면 소리 내어 30~45초 분량(한글 250~400자)이 되게 하세요.
- narration: 그 장면에서 동그래가 말할 1~2문장. 친근하고 격려하는 해요체. 칠판 그림을 가리키듯 말하세요("여기 보면", "왼쪽은").
  마크다운, 이모지, 괄호 속 영어 약어 나열은 쓰지 마세요(소리 내어 읽힙니다).
  보기 번호는 "3번"처럼 아라비아 숫자로 쓰세요("삼번" ✗). 학생에게 직접 말하듯 "3번을 골랐네요"라고 하고, "학생은"처럼 3인칭으로 부르지 마세요.
- visual: 칠판에 그릴 그림. 아래 틀 중 하나만 고르고, 칠판 글씨는 짧은 키워드로 쓰세요(대사를 그대로 옮겨 적지 마세요).
  1) {"type":"options"} — 문제의 보기를 칠판에 쓰고 학생이 고른 답과 정답을 표시합니다. 다른 필드는 쓰지 마세요(보기 내용은 시스템이 채웁니다).
  2) {"type":"compare","title":"…","left":{"title":"…","points":["…"]},"right":{"title":"…","points":["…"]}} — 두 개념 비교(points 1~4개)
  3) {"type":"steps","title":"…","steps":["…"],"highlight":0} — 순서·절차·단계(2~6개). highlight는 강조할 단계 번호(0부터, 선택)
  4) {"type":"formula","title":"…","lines":["…"]} — 공식과 계산 과정을 한 줄씩(1~5줄). 문제에 있는 숫자만 쓰고 새 숫자를 지어내지 마세요.
  5) {"type":"keyword","term":"…","definition":"…","emoji":"…"} — 핵심 용어 하나와 짧은 정의(emoji는 선택, 1개)
  6) {"type":"tree","root":"…","children":[{"label":"…","note":"…"}],"highlight":0} — 상위 개념과 하위 분류(2~5개)
- 칠판 글씨 길이: title 40자, 비교 points 40자, steps 항목 30자, formula 한 줄 60자, definition 90자, tree label 24자 이내.
- 같은 틀을 연달아 쓰지 말고, 내용에 가장 잘 맞는 틀을 고르세요. 계산이 없는 문제에는 formula를 쓰지 마세요.
- 출력은 {"scenes":[{"narration":"…","visual":{…}}]} 형태의 JSON 하나만.`;

function buildPrompt(q: Question, selectedOption: number): string {
  const optionsList = q.options.map((opt, idx) => `${idx + 1}. ${opt}`).join("\n");
  const isCorrect = selectedOption === q.answer;
  const situation = isCorrect
    ? `정답(${q.answer + 1}번)을 맞혔습니다. 정답의 핵심 개념을 그림으로 다시 정리해 주세요.
첫 장면은 options 틀로 정답을 짚으며 칭찬하고, 이어지는 장면에서 개념을 그림으로 풀어 주세요.`
    : `${selectedOption + 1}번(오답)을 골랐고 정답은 ${q.answer + 1}번입니다.
첫 장면은 options 틀로 고른 답과 정답을 짚어 주세요. 이어지는 장면에서 왜 ${selectedOption + 1}번이 헷갈렸을지,
왜 틀렸는지, 정답이 왜 맞는지를 그림으로 풀어 주세요. 학생을 탓하지 마세요.`;

  return `문제: ${q.question}

보기:
${optionsList}

참고용 기본 해설: ${q.explanation}

${situation}`;
}

/** 모델 출력에서 JSON 부분만 꺼낸다 (가끔 \`\`\`json 펜스로 감싸서 준다). */
function extractJson(text: string): unknown {
  const trimmed = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "");
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("No JSON object in scene script");
  return JSON.parse(trimmed.slice(start, end + 1));
}

/**
 * 장면 목록을 검증하고 다듬는다. 틀에 안 맞는 장면은 버리고, options 장면에는 문제은행의 보기를 채우며,
 * 범위를 벗어난 강조 번호는 지운다. 쓸 수 있는 장면이 MIN_SCENES보다 적으면 null.
 */
export function sanitizeScenes(raw: unknown, q: Question, selectedOption: number): ExplanationScene[] | null {
  const list = (raw as { scenes?: unknown } | null)?.scenes;
  if (!Array.isArray(list)) return null;

  const scenes: ExplanationScene[] = [];
  for (const item of list) {
    if (scenes.length >= MAX_SCENES) break;
    const candidate = item as { narration?: unknown; visual?: Record<string, unknown> } | null;
    if (!candidate?.visual || typeof candidate.visual !== "object") continue;

    let visual: Record<string, unknown> = candidate.visual;
    if (visual.type === "options") {
      visual = { type: "options", options: q.options, selectedOption, correctOption: q.answer };
    }
    const parsed = explanationSceneSchema.safeParse({ narration: candidate.narration, visual });
    if (!parsed.success) continue;

    const scene = parsed.data;
    const v = scene.visual;
    if (v.type === "steps" && v.highlight !== undefined && v.highlight >= v.steps.length) delete v.highlight;
    if (v.type === "tree" && v.highlight !== undefined && v.highlight >= v.children.length) delete v.highlight;
    scenes.push(scene);
  }
  return scenes.length >= MIN_SCENES ? scenes : null;
}

export async function getExplanationScenes(q: Question, selectedOption: number): Promise<ExplanationScene[]> {
  const cached = await loadCachedScenes(q.id, selectedOption);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as { version?: number };
      const scenes = parsed.version === SCENE_SCRIPT_VERSION ? sanitizeScenes(parsed, q, selectedOption) : null;
      if (scenes) return scenes;
    } catch {
      // 형식이 깨진 옛 캐시 — 새로 만든다
    }
  }

  const { text, complete } = await generateText({
    instructions: SYSTEM_INSTRUCTION,
    prompt: buildPrompt(q, selectedOption),
    json: true,
    maxOutputTokens: 4096,
  });

  const scenes = sanitizeScenes(extractJson(text), q, selectedOption);
  if (!scenes) {
    console.error("[SceneScript] Unusable scene script from AI:", text.slice(0, 500));
    throw new Error("Unusable scene script");
  }

  // 끝까지 정상으로 만들어진 대본만 저장한다 (토큰 한도로 잘린 대본은 저장하지 않음).
  if (complete) {
    await saveCachedScenes(q.id, selectedOption, JSON.stringify({ version: SCENE_SCRIPT_VERSION, scenes }));
  }
  return scenes;
}

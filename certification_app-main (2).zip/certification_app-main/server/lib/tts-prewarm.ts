import { TRPCError } from "@trpc/server";
import { allQuestions } from "@/data/questions";
import { isGeneratingForUser, prepareSpeech, speechHash, storedSpeechHashes } from "./tts";

/**
 * 동그래 AI 목소리 미리 만들기.
 *
 * 처음 듣는 해설은 음성 생성에 1~3분이 걸려서 첫 사용자는 폰 목소리로 듣게 된다.
 * 그래서 서버가 쉬는 동안 문제은행의 기본 해설(정답을 맞혔을 때 나오는 해설) 음성을
 * 하나씩 만들어 DB(speech_cache_v2)에 저장해 둔다. 오답 맞춤 해설은 경우의 수가 많아서 대상이 아니다.
 *
 * - 천천히(PACE_MS마다 1개) 만들고, 한도에 걸리면(429) 한참 쉰다. TTS_PREWARM=1일 때만 돈다.
 * - 사용자가 직접 음성을 만드는 중이면 그 차례는 양보한다.
 * - 같은 AI 키를 쓰는 로컬 개발 서버가 비용을 쓰지 않도록 실서버(production + 원격 DB)에서만 돈다.
 * - Render 무료 서버는 요청이 없으면 잠들기 때문에, 깨어 있는 동안에만 진행된다.
 */

const PACE_MS = 2 * 60 * 1000;
const QUOTA_BACKOFF_MS = 60 * 60 * 1000;
const BUSY_BACKOFF_MS = 10 * 60 * 1000;
const START_DELAY_MS = 60 * 1000;

// 앱(dmu-explanation-player의 cleanText → 2000자 제한)과 똑같이 정리한 문장이어야 같은 음성으로 재사용된다.
// 같은 해설 문장은 한 번만 (기출/일반에 같은 해설이 있을 수도 있다).
const TARGET_TEXTS = [
  ...new Set(allQuestions.map((q) => q.explanation.replace(/\s+/g, " ").trim().slice(0, 2000))),
].filter(Boolean);

let cursor = 0;
let timer: ReturnType<typeof setTimeout> | null = null;
const stats = { generated: 0, lastError: null as string | null, pausedUntil: 0 };

// 음성 생성은 쓴 만큼 돈이 들고, 칠판 해설은 장면 대사를 따로 읽어서 기본 해설 음성은 잘 쓰이지 않는다.
// 그래서 TTS_PREWARM=1일 때만 켠다.
export function prewarmEnabled(): boolean {
  return process.env.NODE_ENV === "production" && !!process.env.DATABASE_URL && process.env.TTS_PREWARM === "1";
}

let scheduleFn = (ms: number) => {
  timer = setTimeout(tick, ms);
};
function schedule(ms: number) {
  scheduleFn(ms);
}

/** 아직 음성이 없는 다음 해설을 찾는다 (DB 조회 1번). 다 만들었으면 null. */
async function findNextMissing(): Promise<string | null> {
  const stored = await storedSpeechHashes();
  for (let scanned = 0; scanned < TARGET_TEXTS.length; scanned++) {
    const text = TARGET_TEXTS[cursor];
    cursor = (cursor + 1) % TARGET_TEXTS.length;
    if (!stored.has(speechHash(text))) return text;
  }
  return null;
}

async function tick() {
  if (isGeneratingForUser()) {
    schedule(PACE_MS);
    return;
  }
  try {
    const text = await findNextMissing();
    if (!text) {
      console.log("[TTS prewarm] 모든 기본 해설 음성이 준비됐습니다.");
      return; // 다 만들었으면 멈춘다 (다음 서버 시작 때 다시 확인)
    }
    await prepareSpeech(text);
    stats.generated += 1;
    stats.lastError = null;
    schedule(PACE_MS);
  } catch (error) {
    const quota = error instanceof TRPCError && error.code === "TOO_MANY_REQUESTS";
    stats.lastError = error instanceof Error ? error.message : String(error);
    const wait = quota ? QUOTA_BACKOFF_MS : BUSY_BACKOFF_MS;
    stats.pausedUntil = Date.now() + wait;
    console.warn(`[TTS prewarm] ${quota ? "할당량 초과" : "실패"} — ${wait / 60000}분 쉬고 다시 시도:`, stats.lastError);
    schedule(wait);
  }
}

/** 테스트용: 한 번만 실행하고 다음 예약 시간(ms, 멈추면 null)을 돌려준다. */
export async function _prewarmTickForTest(): Promise<number | null> {
  let next: number | null = null;
  const realSchedule = scheduleFn;
  scheduleFn = (ms) => {
    next = ms;
  };
  try {
    await tick();
  } finally {
    scheduleFn = realSchedule;
  }
  return next;
}

export function startSpeechPrewarm() {
  if (!prewarmEnabled() || timer) return;
  console.log(`[TTS prewarm] 시작: 기본 해설 ${TARGET_TEXTS.length}개`);
  schedule(START_DELAY_MS);
}

/** GET /api/tts-status — 미리 만들기 진행 상황 */
export async function speechPrewarmStatus() {
  const stored = await storedSpeechHashes();
  const ready = TARGET_TEXTS.filter((text) => stored.has(speechHash(text))).length;
  return {
    enabled: prewarmEnabled(),
    ready,
    total: TARGET_TEXTS.length,
    generatedSinceStart: stats.generated,
    pausedUntil: stats.pausedUntil > Date.now() ? new Date(stats.pausedUntil).toISOString() : null,
    lastError: stats.lastError,
  };
}

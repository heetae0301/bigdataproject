import { and, eq } from "drizzle-orm";
import { db } from "../db/client";
import { dailyLog, questionAttempts, studyStats, subjectStats, wrongAnswers } from "../db/schema";
import { diffDays, kstDateStr } from "@/lib/kst-date";
import { applyReview, type ReviewStatus } from "@/lib/review-schedule";
import type { Question, Subject } from "@/data/questions";

export interface AnswerOutcome {
  questionId: string;
  isCorrect: boolean;
  reviewStatus: ReviewStatus;
  /** 반영 후 오답노트 진도 (오답노트에 없으면 null) */
  correctStreak: number | null;
}

/**
 * 지금 화면에 보여줄 연속 학습일. 저장된 값은 공부할 때만 갱신되므로, 마지막으로 공부한 날이
 * 어제보다 전이면 이미 끊긴 것이라 0이다 (그대로 보여주면 끊긴 뒤에도 옛 숫자가 남아 있다가
 * 다음에 공부하면 1로 떨어져서, 연속일이 안 오르는 것처럼 보였다).
 */
export function currentStreakDays(streakDays: number, lastStreakDate: string | null, now: Date = new Date()): number {
  if (!lastStreakDate) return 0;
  return diffDays(lastStreakDate, kstDateStr(now)) <= 1 ? streakDays : 0;
}

/** 총 풀이/정답 수, 과목별 합계, 연속 학습일(KST 기준)을 갱신한다. */
export async function updateStudyStats(
  userId: string,
  results: { subject: Subject; isCorrect: boolean }[],
  now: Date = new Date()
): Promise<void> {
  if (results.length === 0) return;

  const existing = await db.select().from(studyStats).where(eq(studyStats.userId, userId)).get();

  const today = kstDateStr(now);
  let streakDays = existing?.streakDays ?? 0;
  let lastStreakDate = existing?.lastStreakDate ?? null;

  if (lastStreakDate === null) {
    streakDays = 1;
    lastStreakDate = today;
  } else {
    const gap = diffDays(lastStreakDate, today);
    if (gap === 1) {
      streakDays += 1;
      lastStreakDate = today;
    } else if (gap !== 0) {
      streakDays = 1;
      lastStreakDate = today;
    }
  }

  const correctCount = results.filter((r) => r.isCorrect).length;
  const totalAnswered = (existing?.totalAnswered ?? 0) + results.length;
  const totalCorrect = (existing?.totalCorrect ?? 0) + correctCount;
  const lastStudiedAt = now.getTime();
  const bestStreak = Math.max(existing?.bestStreak ?? 0, streakDays);

  await db
    .insert(studyStats)
    .values({ userId, totalAnswered, totalCorrect, lastStudiedAt, streakDays, lastStreakDate, bestStreak })
    .onConflictDoUpdate({
      target: studyStats.userId,
      set: { totalAnswered, totalCorrect, lastStudiedAt, streakDays, lastStreakDate, bestStreak },
    });

  const bySubject = new Map<Subject, { total: number; correct: number }>();
  for (const r of results) {
    const s = bySubject.get(r.subject) ?? { total: 0, correct: 0 };
    s.total += 1;
    if (r.isCorrect) s.correct += 1;
    bySubject.set(r.subject, s);
  }

  for (const [subject, delta] of bySubject) {
    const existingSubject = await db
      .select()
      .from(subjectStats)
      .where(and(eq(subjectStats.userId, userId), eq(subjectStats.subject, subject)))
      .get();

    const total = (existingSubject?.total ?? 0) + delta.total;
    const correct = (existingSubject?.correct ?? 0) + delta.correct;

    await db
      .insert(subjectStats)
      .values({ userId, subject, total, correct })
      .onConflictDoUpdate({
        target: [subjectStats.userId, subjectStats.subject],
        set: { total, correct },
      });
  }
}

export async function incrementDailyLog(
  userId: string,
  amount: number = 1,
  now: Date = new Date()
): Promise<void> {
  const today = kstDateStr(now);
  const existing = await db
    .select()
    .from(dailyLog)
    .where(and(eq(dailyLog.userId, userId), eq(dailyLog.date, today)))
    .get();

  const count = (existing?.count ?? 0) + amount;

  await db
    .insert(dailyLog)
    .values({ userId, date: today, count })
    .onConflictDoUpdate({
      target: [dailyLog.userId, dailyLog.date],
      set: { count },
    });
}

/**
 * 답안 제출 한 번에 필요한 기록을 전부 남긴다: 문제별 풀이 기록, 학습 통계,
 * 일별 로그, 오답노트(반복 학습 규칙 적용). 정답 여부는 서버의 문제은행으로 판정한다.
 */
export async function recordAnswers(
  userId: string,
  items: { question: Question; selectedOption: number }[],
  now: Date = new Date()
): Promise<AnswerOutcome[]> {
  if (items.length === 0) return [];
  const nowMs = now.getTime();

  const graded = items.map(({ question, selectedOption }) => ({
    question,
    selectedOption,
    isCorrect: selectedOption === question.answer,
  }));

  await db.insert(questionAttempts).values(
    graded.map((g) => ({
      userId,
      questionId: g.question.id,
      subject: g.question.subject,
      correct: g.isCorrect ? 1 : 0,
      timestamp: nowMs,
    }))
  );

  await updateStudyStats(
    userId,
    graded.map((g) => ({ subject: g.question.subject, isCorrect: g.isCorrect })),
    now
  );
  await incrementDailyLog(userId, graded.length, now);

  const outcomes: AnswerOutcome[] = [];
  for (const g of graded) {
    const where = and(eq(wrongAnswers.userId, userId), eq(wrongAnswers.questionId, g.question.id));
    const existing = await db.select().from(wrongAnswers).where(where).get();
    const update = applyReview(existing ?? null, g.isCorrect, nowMs);

    let correctStreak: number | null = existing?.correctStreak ?? null;
    if (update.kind === "upsert") {
      correctStreak = update.state.correctStreak;
      const row = {
        subject: g.question.subject,
        // 맞혀서 한 단계 올라간 경우엔 마지막으로 틀렸던 선택지를 그대로 보여준다.
        selectedOption: g.isCorrect ? existing!.selectedOption : g.selectedOption,
        correctOption: g.question.answer,
        timestamp: g.isCorrect ? existing!.timestamp : nowMs,
        correctStreak: update.state.correctStreak,
        nextReviewAt: update.state.nextReviewAt,
      };
      await db
        .insert(wrongAnswers)
        .values({ userId, questionId: g.question.id, ...row })
        .onConflictDoUpdate({ target: [wrongAnswers.userId, wrongAnswers.questionId], set: row });
    } else if (update.kind === "delete") {
      correctStreak = null;
      await db.delete(wrongAnswers).where(where);
    }

    outcomes.push({
      questionId: g.question.id,
      isCorrect: g.isCorrect,
      reviewStatus: update.status,
      correctStreak,
    });
  }
  return outcomes;
}

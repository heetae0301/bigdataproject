import OpenAI, { APIError } from "openai";
import { TRPCError } from "@trpc/server";

/**
 * 서버의 AI 호출을 한곳에 모은다 (OpenAI). 글 생성(해설·칠판 대본·사진 인식)과 음성 합성(동그래 목소리).
 * 모델을 바꾸려면 아래 상수만 바꾸면 된다.
 */

// 싸고 빠른 모델 (이미지 입력·JSON 출력 지원). 해설·칠판 대본·사진 인식에 쓴다.
export const AI_TEXT_MODEL = "gpt-6-luna";
// 기본 모델이 바쁘거나(5xx) 요청 한도(429 rate limit)에 걸렸을 때 대신 쓰는 모델.
export const AI_TEXT_FALLBACK_MODEL = "gpt-6.1-sol";
// 해설 생성은 깊은 추론이 필요 없어서 추론을 가장 낮게 둔다 (두 모델 모두 지원하는 단계).
const REASONING_EFFORT = "low" as const;

export const TTS_MODEL = "gpt-4o-mini-tts";
export const TTS_VOICE = "cedar"; // 자연스럽고 차분한 남자 목소리
// OpenAI는 말투 지시를 본문과 따로 받으므로(instructions), 지시문을 소리 내어 읽지 않는다.
export const TTS_INSTRUCTIONS =
  "한국어로, 학생을 격려하는 밝고 다정한 선생님 캐릭터처럼 또박또박 말해 주세요. 너무 빠르지 않게.";
// response_format "pcm"은 24kHz 16비트 모노, 헤더 없는 원시 샘플이다 (tts.ts에서 WAV 헤더를 붙인다).
export const TTS_PCM_SAMPLE_RATE = 24000;

const RETRY_DELAY_MS = 2000;

export function getAiClient(): OpenAI {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY not configured");
  }
  return new OpenAI({ apiKey, maxRetries: 0 }); // 재시도는 아래 withFallback이 직접 한다
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * AI 호출을 일시적인 실패에 강하게 감싼다.
 * - 5xx(서버 바쁨): 같은 모델로 잠깐 뒤 한 번 더
 * - 그래도 실패하거나 429 요청 한도(rate limit): 다음 모델로
 * - 429 insufficient_quota(결제 한도·잔액 부족): 모델을 바꿔도 소용없으니 바로 안내
 * - 다 실패하면 사용자에게 그대로 보여줄 수 있는 한국어 메시지의 TRPCError로 바꿔 던진다
 */
export async function withFallback<T>(models: string[], call: (model: string) => Promise<T>): Promise<T> {
  let lastStatus: number | undefined;
  for (const model of models) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await call(model);
      } catch (error) {
        if (!(error instanceof APIError)) throw error;
        lastStatus = error.status;
        console.warn(`[AI] ${model} attempt ${attempt + 1} failed (status ${lastStatus ?? "?"}${error.code ? `, ${error.code}` : ""})`);
        if (lastStatus === 429 && error.code === "insufficient_quota") {
          throw new TRPCError({
            code: "TOO_MANY_REQUESTS",
            message: "AI 사용 한도를 모두 썼어요. 관리자에게 알려주세요.",
          });
        }
        // 상태 코드가 없으면 네트워크 연결 실패 — 서버 바쁨(5xx)과 똑같이 다룬다
        const transient = lastStatus === undefined || lastStatus >= 500;
        if (transient && attempt === 0) {
          await sleep(RETRY_DELAY_MS);
          continue;
        }
        if (lastStatus === 429 || transient) break; // 다음 모델로
        throw error;
      }
    }
  }

  if (lastStatus === 429) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "지금 AI 요청이 너무 많아요. 잠시 후 다시 시도해주세요.",
    });
  }
  throw new TRPCError({
    code: "SERVICE_UNAVAILABLE",
    message: "지금 AI 서버가 바빠요. 잠시 후 다시 시도해주세요.",
  });
}

export interface TextRequest {
  /** 시스템 지시 (역할·말투·출력 형식) */
  instructions?: string;
  prompt: string;
  /** 함께 보낼 사진 (JPEG base64) */
  imageBase64?: string;
  /** JSON 객체 하나로만 답하게 한다 */
  json?: boolean;
  maxOutputTokens?: number;
}

export interface TextResult {
  text: string;
  /** 끝까지 만들어졌는지 (토큰 한도 등으로 잘렸으면 false — 캐시에 저장하지 않는다) */
  complete: boolean;
}

/** 글을 만든다 (해설, 칠판 대본, 사진 속 문제 읽기). */
export async function generateText(request: TextRequest): Promise<TextResult> {
  const client = getAiClient();
  // JSON 모드는 instructions가 아니라 사용자 메시지에 "json"이라는 말이 있어야 받아 준다 (없으면 400).
  const prompt = request.json && !/json/i.test(request.prompt) ? `${request.prompt}

JSON 객체 하나로만 답하세요.` : request.prompt;
  const content: OpenAI.Responses.ResponseInputContent[] = [{ type: "input_text", text: prompt }];
  if (request.imageBase64) {
    content.push({ type: "input_image", image_url: `data:image/jpeg;base64,${request.imageBase64}`, detail: "high" });
  }
  const response = await withFallback([AI_TEXT_MODEL, AI_TEXT_FALLBACK_MODEL], (model) =>
    client.responses.create({
      model,
      instructions: request.instructions,
      input: [{ role: "user", content }],
      reasoning: { effort: REASONING_EFFORT },
      max_output_tokens: request.maxOutputTokens ?? 2048,
      ...(request.json ? { text: { format: { type: "json_object" as const } } } : {}),
    })
  );
  return { text: response.output_text ?? "", complete: response.status === "completed" };
}

/** 문장을 동그래 목소리로 읽은 원시 PCM(24kHz, 16비트 모노)을 돌려준다. */
export async function synthesizeSpeech(text: string): Promise<Buffer> {
  const client = getAiClient();
  const response = await withFallback([TTS_MODEL], (model) =>
    client.audio.speech.create({
      model,
      voice: TTS_VOICE,
      input: text,
      instructions: TTS_INSTRUCTIONS,
      response_format: "pcm",
    })
  );
  const audio = Buffer.from(await response.arrayBuffer());
  if (audio.length === 0) throw new Error("TTS 응답에 오디오가 없습니다");
  return audio;
}

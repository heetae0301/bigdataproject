// Brevo(구 Sendinblue) 트랜잭션 이메일 API. HTTP(443) 기반이라 Render 무료 플랜의
// SMTP 포트(25/465/587) 차단에 안 걸린다 — Gmail SMTP(nodemailer)는 거기서 막혔다.
// "발신자 인증"만 돼 있으면(도메인 인증 불필요) 수신자 제한 없이 아무에게나 보낼 수 있다.
const BREVO_API_URL = "https://api.brevo.com/v3/smtp/email";

export async function sendPasswordResetEmail(to: string, code: string): Promise<void> {
  const apiKey = process.env.BREVO_API_KEY;
  const senderEmail = process.env.BREVO_SENDER_EMAIL;
  if (!apiKey || !senderEmail) {
    throw new Error("BREVO_API_KEY / BREVO_SENDER_EMAIL가 설정되지 않아 이메일을 보낼 수 없습니다.");
  }

  const res = await fetch(BREVO_API_URL, {
    method: "POST",
    headers: {
      "api-key": apiKey,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      sender: { name: "i can do it 자격증", email: senderEmail },
      to: [{ email: to }],
      subject: "[i can do it 자격증] 비밀번호 재설정 인증코드",
      textContent: `인증코드: ${code}\n\n이 코드는 10분간 유효합니다. 본인이 요청하지 않았다면 이 메일을 무시하세요.`,
      htmlContent: `
        <div style="font-family: sans-serif; padding: 16px;">
          <p>비밀번호 재설정 인증코드입니다:</p>
          <p style="font-size: 28px; font-weight: 700; letter-spacing: 4px;">${code}</p>
          <p style="color: #666; font-size: 13px;">이 코드는 10분간 유효합니다. 본인이 요청하지 않았다면 이 메일을 무시하세요.</p>
        </div>
      `,
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Brevo 이메일 발송 실패 (${res.status}): ${body}`);
  }
}

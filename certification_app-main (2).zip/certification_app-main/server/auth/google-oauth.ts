import { randomBytes } from "node:crypto";
import { Router, type Request } from "express";
import { createGoogleOAuthClient, verifyGoogleIdToken } from "./google";
import { loginWithGoogleProfile, type LoginResult } from "./google-user";
import { signOAuthState, verifyOAuthState } from "./jwt";

/**
 * 브라우저 기반 Google 로그인 (Expo Go·아이폰·안드로이드 공통).
 *
 * 1. 앱이 인앱 브라우저로 GET /api/auth/google/start?return=<앱 주소> 를 연다.
 * 2. 서버가 Google 로그인 화면으로 보낸다. Google은 다시 이 서버의 https 콜백으로 돌려준다.
 * 3. 콜백에서 Google 계정을 검증하고 로그인 결과를 1회용 코드(2분)에 담아 앱 주소로 돌려보낸다.
 * 4. 앱은 그 코드를 tRPC auth.googleExchange로 바꿔 JWT를 받는다.
 *
 * 토큰 대신 1회용 코드를 URL에 싣는 건, 앱으로 돌아가는 링크가 기록에 남아도
 * 30일짜리 로그인 토큰이 새지 않게 하기 위해서다.
 */

const LOGIN_CODE_TTL_MS = 2 * 60 * 1000;
const loginCodes = new Map<string, { result: LoginResult; expiresAt: number }>();

export function issueLoginCode(result: LoginResult): string {
  const now = Date.now();
  for (const [code, entry] of loginCodes) {
    if (entry.expiresAt < now) loginCodes.delete(code);
  }
  const code = randomBytes(32).toString("hex");
  loginCodes.set(code, { result, expiresAt: now + LOGIN_CODE_TTL_MS });
  return code;
}

/** 1회용 코드를 로그인 결과로 바꾼다. 한 번 쓰면 사라지고, 만료됐거나 없는 코드면 null. */
export function takeLoginCode(code: string): LoginResult | null {
  const entry = loginCodes.get(code);
  if (!entry) return null;
  loginCodes.delete(code);
  return entry.expiresAt >= Date.now() ? entry.result : null;
}

function isPrivateHost(hostname: string): boolean {
  return (
    hostname === "localhost" ||
    /^127\./.test(hostname) ||
    /^10\./.test(hostname) ||
    /^192\.168\./.test(hostname) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(hostname)
  );
}

/**
 * 로그인 결과(1회용 코드)를 넘겨줄 수 있는 앱 주소인지 확인한다. 아무 주소나 허용하면
 * 남이 만든 링크로 로그인했을 때 코드가 그 사람 서버로 새어 나갈 수 있다.
 * - 앱 자체 스킴(manus...://) — 설치된 빌드
 * - exp:// / exps:// — Expo Go. 같은 와이파이(사설 IP)이거나 EXPO_RETURN_HOSTS에 등록한 주소만.
 * - exp://u.expo.dev/<우리 프로젝트 ID>/... — PC 없이 Expo Go로 연 EAS 업데이트.
 *   u.expo.dev는 모든 Expo 프로젝트가 같이 쓰므로 우리 프로젝트 경로만 허용한다.
 */
const EAS_PROJECT_ID = "c7ad6e1f-de42-47ae-8596-29cf717bdbe7"; // app.config.ts의 extra.eas.projectId

export function isAllowedReturnUrl(raw: string): boolean {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return false;
  }
  if (/^manus\d+:$/.test(url.protocol)) return true;
  if (url.protocol !== "exp:" && url.protocol !== "exps:") return false;
  const allowedHosts = (process.env.EXPO_RETURN_HOSTS ?? "")
    .split(",")
    .map((h) => h.trim().toLowerCase())
    .filter(Boolean);
  const hostname = url.hostname.toLowerCase();
  if (hostname === "u.expo.dev") {
    return url.pathname === `/${EAS_PROJECT_ID}` || url.pathname.startsWith(`/${EAS_PROJECT_ID}/`);
  }
  return isPrivateHost(hostname) || allowedHosts.includes(hostname);
}

function withParam(returnUrl: string, key: string, value: string): string {
  const url = new URL(returnUrl);
  url.searchParams.set(key, value);
  return url.toString();
}

function callbackUrl(req: Request): string {
  // Render는 프록시 뒤라 trust proxy 설정이 있어야 req.protocol이 https로 잡힌다.
  return `${req.protocol}://${req.get("host")}/api/auth/google/callback`;
}

function sendMessage(res: import("express").Response, status: number, message: string) {
  res
    .status(status)
    .type("html")
    .send(
      `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width">` +
        `<p style="font-family:sans-serif;padding:24px;line-height:1.6">${message}</p>`
    );
}

export const googleOAuthRouter = Router();

googleOAuthRouter.get("/start", (req, res) => {
  const returnUrl = typeof req.query.return === "string" ? req.query.return : "";
  if (!isAllowedReturnUrl(returnUrl)) {
    sendMessage(res, 400, "허용되지 않은 앱 주소입니다. 앱에서 다시 시도해주세요.");
    return;
  }
  const client = createGoogleOAuthClient(callbackUrl(req));
  if (!client) {
    console.warn("[auth] GOOGLE_WEB_CLIENT_ID / GOOGLE_CLIENT_SECRET가 설정되지 않아 Google 로그인을 시작할 수 없습니다.");
    res.redirect(withParam(returnUrl, "error", "not_configured"));
    return;
  }
  const authUrl = client.generateAuthUrl({
    scope: ["openid", "email", "profile"],
    state: signOAuthState(returnUrl),
    prompt: "select_account",
  });
  res.redirect(authUrl);
});

googleOAuthRouter.get("/callback", async (req, res) => {
  const state = typeof req.query.state === "string" ? req.query.state : "";
  const returnUrl = verifyOAuthState(state);
  if (!returnUrl || !isAllowedReturnUrl(returnUrl)) {
    sendMessage(res, 400, "로그인 요청이 만료됐거나 올바르지 않습니다. 앱으로 돌아가 다시 시도해주세요.");
    return;
  }

  // 사용자가 Google 화면에서 취소한 경우 (?error=access_denied)
  if (typeof req.query.error === "string") {
    res.redirect(withParam(returnUrl, "error", "cancelled"));
    return;
  }

  try {
    const code = typeof req.query.code === "string" ? req.query.code : "";
    const client = createGoogleOAuthClient(callbackUrl(req));
    if (!client || !code) throw new Error("missing client or code");

    const { tokens } = await client.getToken(code);
    const profile = tokens.id_token ? await verifyGoogleIdToken(tokens.id_token) : null;
    if (!profile) throw new Error("id_token verification failed");

    const result = await loginWithGoogleProfile(profile);
    res.redirect(withParam(returnUrl, "code", issueLoginCode(result)));
  } catch (err) {
    console.error("[auth] Google 로그인 콜백 실패:", err);
    res.redirect(withParam(returnUrl, "error", "failed"));
  }
});

import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "../db/client";
import { users } from "../db/schema";
import { hashPassword } from "./password";
import { signToken } from "./jwt";
import type { GoogleProfile } from "./google";

export interface LoginResult {
  token: string;
  user: { id: string; email: string; nickname: string };
}

/** 검증된 Google 프로필로 로그인한다. 계정이 없으면 연동하거나 새로 만든다. */
export async function loginWithGoogleProfile(profile: GoogleProfile): Promise<LoginResult> {
  const email = profile.email.trim().toLowerCase();

  // 1) 이미 이 Google 계정으로 로그인한 적 있으면 그대로 로그인.
  let user = await db.select().from(users).where(eq(users.googleId, profile.googleId)).get();

  // 2) 같은 이메일로 가입한 계정(이메일/비밀번호)이 있으면 이번 기회에 Google 계정을 연동.
  if (!user) {
    const existing = await db.select().from(users).where(eq(users.email, email)).get();
    if (existing) {
      await db.update(users).set({ googleId: profile.googleId }).where(eq(users.id, existing.id));
      user = { ...existing, googleId: profile.googleId };
    }
  }

  // 3) 처음 보는 이메일이면 새 계정을 만든다. password_hash는 채워야 하지만(NOT NULL),
  //    아무도 모르는 무작위 값이라 이 계정은 비밀번호로는 로그인할 수 없다.
  //    (비밀번호 찾기로 비밀번호를 설정하면 이메일 로그인도 쓸 수 있다.)
  if (!user) {
    const id = randomUUID();
    const nickname = (profile.name?.trim() || email.split("@")[0]).slice(0, 20);
    const passwordHash = await hashPassword(randomUUID());
    await db.insert(users).values({
      id,
      email,
      nickname,
      passwordHash,
      createdAt: Date.now(),
      googleId: profile.googleId,
    });
    return { token: signToken({ userId: id }), user: { id, email, nickname } };
  }

  return {
    token: signToken({ userId: user.id }),
    user: { id: user.id, email: user.email, nickname: user.nickname },
  };
}

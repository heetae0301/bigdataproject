import jwt from "jsonwebtoken";

const DEV_FALLBACK_SECRET = "adsp-quiz-app-dev-only-secret-do-not-use-in-production";

function getSecret(): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.warn(
      "[auth] JWT_SECRET is not set — using an insecure development default. " +
        "Set JWT_SECRET in .env before deploying anywhere real users can reach."
    );
    return DEV_FALLBACK_SECRET;
  }
  return secret;
}

export interface AuthTokenPayload {
  userId: string;
}

export function signToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, getSecret(), { expiresIn: "30d" });
}

/** Google OAuth 왕복 동안 "로그인 끝나면 돌아갈 앱 주소"를 위조 못 하게 서명해서 state로 넘긴다. */
export function signOAuthState(returnUrl: string): string {
  return jwt.sign({ r: returnUrl, typ: "google-oauth-state" }, getSecret(), { expiresIn: "10m" });
}

export function verifyOAuthState(state: string): string | null {
  try {
    const decoded = jwt.verify(state, getSecret()) as Record<string, unknown>;
    if (decoded?.typ !== "google-oauth-state" || typeof decoded.r !== "string") return null;
    return decoded.r;
  } catch {
    return null;
  }
}

export function verifyToken(token: string): AuthTokenPayload | null {
  try {
    const decoded = jwt.verify(token, getSecret());
    if (typeof decoded === "object" && decoded && "userId" in decoded) {
      return { userId: String((decoded as Record<string, unknown>).userId) };
    }
    return null;
  } catch {
    return null;
  }
}

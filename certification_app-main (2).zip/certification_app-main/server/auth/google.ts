import { OAuth2Client } from "google-auth-library";

// Google Cloud Console에서 발급받은 "웹 애플리케이션" 클라이언트 ID(GOOGLE_WEB_CLIENT_ID)와
// 보안 비밀번호(GOOGLE_CLIENT_SECRET). 로그인은 서버가 웹 OAuth 흐름으로 처리한다(google-oauth.ts).
const client = new OAuth2Client();

/** 웹 OAuth(authorization code) 흐름용 클라이언트. 설정이 빠졌으면 null. */
export function createGoogleOAuthClient(redirectUri: string): OAuth2Client | null {
  // 대시보드에 붙여넣을 때 섞여 들어간 공백/줄바꿈 때문에 invalid_client가 나지 않게 다듬는다.
  const clientId = process.env.GOOGLE_WEB_CLIENT_ID?.trim();
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET?.trim();
  if (!clientId || !clientSecret) return null;
  return new OAuth2Client({ clientId, clientSecret, redirectUri });
}

export interface GoogleProfile {
  googleId: string;
  email: string;
  name: string | null;
}

/** idToken을 검증하고 신뢰할 수 있는 사용자 정보를 돌려준다. 위조/만료된 토큰이면 null. */
export async function verifyGoogleIdToken(idToken: string): Promise<GoogleProfile | null> {
  const audience = process.env.GOOGLE_WEB_CLIENT_ID?.trim();
  if (!audience) {
    console.warn("[auth] GOOGLE_WEB_CLIENT_ID가 설정되지 않아 Google 로그인을 검증할 수 없습니다.");
    return null;
  }

  try {
    const ticket = await client.verifyIdToken({ idToken, audience });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload.email) {
      return null;
    }
    if (payload.email_verified === false) {
      return null;
    }
    return { googleId: payload.sub, email: payload.email, name: payload.name ?? null };
  } catch {
    return null;
  }
}

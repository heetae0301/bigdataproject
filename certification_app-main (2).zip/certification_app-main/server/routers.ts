import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { randomUUID, randomInt } from "node:crypto";
import { eq, and, desc, sql, isNull, isNotNull } from "drizzle-orm";
import { db } from "./db/client";
import {
  users,
  wrongAnswers,
  studyStats,
  subjectStats,
  dailyLog,
  questionAttempts,
  mockExamResults,
  bookmarks,
  questionNotes,
} from "./db/schema";
import { hashPassword, verifyPassword } from "./auth/password";
import { signToken } from "./auth/jwt";
import { takeLoginCode } from "./auth/google-oauth";
import { sendPasswordResetEmail } from "./lib/mailer";
import { generateText } from "./lib/ai";
import { prepareSpeech } from "./lib/tts";
import { loadCachedExplanation, saveCachedExplanation } from "./lib/ai-cache-store";
import { getExplanationScenes } from "./lib/scene-script";
import { sceneNarrationText } from "@/lib/explanation-scenes";
import { currentStreakDays, incrementDailyLog, recordAnswers, updateStudyStats } from "./lib/progress";
import { SUBJECTS, allQuestions, type Question, type Subject } from "@/data/questions";
import { getPastExamRound } from "@/data/past-exams";
import { addDays, isValidDateStr, kstDateStr } from "@/lib/kst-date";
import { scoreMockExam, type SubjectScore } from "@/lib/mock-exam-scoring";

const RESET_CODE_TTL_MS = 10 * 60 * 1000;

const subjectSchema = z.enum(SUBJECTS as [Subject, ...Subject[]]);

const questionById = new Map(allQuestions.map((q) => [q.id, q]));

function getQuestionOrThrow(questionId: string): Question {
  const q = questionById.get(questionId);
  if (!q) {
    throw new TRPCError({ code: "BAD_REQUEST", message: `알 수 없는 문제입니다: ${questionId}` });
  }
  return q;
}

const answerInputSchema = z.object({
  questionId: z.string(),
  selectedOption: z.number().int().min(0),
});

function emptySubjectTotals(): Record<Subject, { total: number; correct: number }> {
  return {
    "1과목(데이터 이해)": { total: 0, correct: 0 },
    "2과목(데이터 분석 기획)": { total: 0, correct: 0 },
    "3과목(데이터 분석)": { total: 0, correct: 0 },
  };
}

const authRouter = router({
  signup: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        nickname: z.string().trim().min(1, "닉네임을 입력해주세요.").max(20, "닉네임은 20자 이하로 입력해주세요."),
        password: z.string().min(6, "비밀번호는 6자 이상이어야 합니다."),
      })
    )
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const nickname = input.nickname.trim();

      const existing = await db.select().from(users).where(eq(users.email, email)).get();
      if (existing) {
        throw new TRPCError({ code: "CONFLICT", message: "이미 가입된 이메일입니다." });
      }

      const passwordHash = await hashPassword(input.password);
      const id = randomUUID();
      await db.insert(users).values({ id, email, nickname, passwordHash, createdAt: Date.now() });

      const token = signToken({ userId: id });
      return { token, user: { id, email, nickname } };
    }),

  login: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const user = await db.select().from(users).where(eq(users.email, email)).get();
      if (!user) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "이메일 또는 비밀번호가 올바르지 않습니다." });
      }

      const valid = await verifyPassword(input.password, user.passwordHash);
      if (!valid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "이메일 또는 비밀번호가 올바르지 않습니다." });
      }

      const token = signToken({ userId: user.id });
      return { token, user: { id: user.id, email: user.email, nickname: user.nickname } };
    }),

  // 브라우저 Google 로그인(server/auth/google-oauth.ts)이 앱에 돌려준 1회용 코드를 로그인 토큰으로 바꾼다.
  googleExchange: publicProcedure
    .input(z.object({ code: z.string().min(1) }))
    .mutation(({ input }) => {
      const result = takeLoginCode(input.code);
      if (!result) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Google 로그인 시간이 만료됐어요. 다시 시도해주세요." });
      }
      return result;
    }),

  requestPasswordReset: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const user = await db.select().from(users).where(eq(users.email, email)).get();

      // 가입 여부를 노출하지 않기 위해 계정이 없어도 항상 성공으로 응답한다.
      if (user) {
        const code = randomInt(0, 1_000_000).toString().padStart(6, "0");
        const resetCodeHash = await hashPassword(code);
        await db
          .update(users)
          .set({ resetCodeHash, resetCodeExpiresAt: Date.now() + RESET_CODE_TTL_MS })
          .where(eq(users.id, user.id));
        await sendPasswordResetEmail(email, code);
      }

      return { ok: true };
    }),

  resetPassword: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        code: z.string().length(6),
        newPassword: z.string().min(6, "비밀번호는 6자 이상이어야 합니다."),
      })
    )
    .mutation(async ({ input }) => {
      const email = input.email.trim().toLowerCase();
      const user = await db.select().from(users).where(eq(users.email, email)).get();

      if (
        !user ||
        !user.resetCodeHash ||
        !user.resetCodeExpiresAt ||
        user.resetCodeExpiresAt < Date.now()
      ) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "인증코드가 올바르지 않거나 만료되었습니다." });
      }

      const valid = await verifyPassword(input.code, user.resetCodeHash);
      if (!valid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "인증코드가 올바르지 않거나 만료되었습니다." });
      }

      const passwordHash = await hashPassword(input.newPassword);
      await db
        .update(users)
        .set({ passwordHash, resetCodeHash: null, resetCodeExpiresAt: null })
        .where(eq(users.id, user.id));

      return { ok: true };
    }),

  me: protectedProcedure.query(async ({ ctx }) => {
    const user = await db.select().from(users).where(eq(users.id, ctx.userId)).get();
    if (!user) {
      throw new TRPCError({ code: "NOT_FOUND", message: "사용자를 찾을 수 없습니다." });
    }
    return { id: user.id, email: user.email, nickname: user.nickname };
  }),

  updateNickname: protectedProcedure
    .input(
      z.object({
        nickname: z.string().trim().min(1, "닉네임을 입력해주세요.").max(20, "닉네임은 20자 이하로 입력해주세요."),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const nickname = input.nickname.trim();
      await db.update(users).set({ nickname }).where(eq(users.id, ctx.userId));
      return { nickname };
    }),

  changePassword: protectedProcedure
    .input(
      z.object({
        currentPassword: z.string().min(1),
        newPassword: z.string().min(6, "비밀번호는 6자 이상이어야 합니다."),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const user = await db.select().from(users).where(eq(users.id, ctx.userId)).get();
      if (!user) {
        throw new TRPCError({ code: "NOT_FOUND", message: "사용자를 찾을 수 없습니다." });
      }
      // Google로만 가입한 계정은 아무도 모르는 무작위 비밀번호라 여기서 항상 걸린다 —
      // 그런 사용자는 앱에서 "비밀번호 찾기"로 비밀번호를 처음 설정하도록 안내한다.
      const valid = await verifyPassword(input.currentPassword, user.passwordHash);
      if (!valid) {
        throw new TRPCError({ code: "UNAUTHORIZED", message: "현재 비밀번호가 올바르지 않습니다." });
      }
      const passwordHash = await hashPassword(input.newPassword);
      await db.update(users).set({ passwordHash }).where(eq(users.id, ctx.userId));
      return { ok: true };
    }),

  // 회원 탈퇴: 계정과 모든 학습 기록을 지운다. ON DELETE CASCADE는 SQLite에서 연결마다
  // foreign_keys가 켜져 있어야 동작하므로 기대지 않고, 테이블마다 명시적으로 한 번에(batch) 지운다.
  deleteAccount: protectedProcedure.mutation(async ({ ctx }) => {
    const userId = ctx.userId;
    await db.batch([
      db.delete(wrongAnswers).where(eq(wrongAnswers.userId, userId)),
      db.delete(questionAttempts).where(eq(questionAttempts.userId, userId)),
      db.delete(mockExamResults).where(eq(mockExamResults.userId, userId)),
      db.delete(questionNotes).where(eq(questionNotes.userId, userId)),
      db.delete(bookmarks).where(eq(bookmarks.userId, userId)),
      db.delete(studyStats).where(eq(studyStats.userId, userId)),
      db.delete(subjectStats).where(eq(subjectStats.userId, userId)),
      db.delete(dailyLog).where(eq(dailyLog.userId, userId)),
      db.delete(users).where(eq(users.id, userId)),
    ]);
    return { ok: true };
  }),
});

const progressRouter = router({
  getWrongAnswers: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(wrongAnswers).where(eq(wrongAnswers.userId, ctx.userId));
    return rows.map((r) => ({
      questionId: r.questionId,
      subject: r.subject as Subject,
      selectedOption: r.selectedOption,
      correctOption: r.correctOption,
      timestamp: r.timestamp,
      correctStreak: r.correctStreak,
      nextReviewAt: r.nextReviewAt,
    }));
  }),

  // 문제 풀이 화면들(일반/오답 재풀기)이 답을 고를 때마다 호출한다. 풀이 기록,
  // 통계, 일별 로그, 오답노트 반복 학습을 한 번에 처리하고 문제별 결과를 돌려준다.
  submitAnswers: protectedProcedure
    .input(z.object({ answers: z.array(answerInputSchema).min(1).max(100) }))
    .mutation(async ({ ctx, input }) => {
      const items = input.answers.map((a) => ({
        question: getQuestionOrThrow(a.questionId),
        selectedOption: a.selectedOption,
      }));
      return recordAnswers(ctx.userId, items);
    }),

  // 문제별 누적 풀이 기록. 진도율, 안 푼 문제 우선 출제, 자주 틀리는 문제 순위에 쓴다.
  getQuestionProgress: protectedProcedure.query(async ({ ctx }) => {
    // SQLite는 max()가 딱 하나 있는 집계 쿼리에서, 집계되지 않은 컬럼(correct, timestamp)을
    // max()가 고른 행에서 가져온다. id는 자동 증가라 max(id)가 마지막 풀이이므로,
    // 이걸로 "마지막 풀이의 정답 여부/시각"을 한 번에 구한다. (max/min을 더 넣으면 이 보장이 깨진다.)
    const rows = await db
      .select({
        questionId: questionAttempts.questionId,
        attempts: sql<number>`count(*)`,
        correct: sql<number>`sum(${questionAttempts.correct})`,
        lastId: sql<number>`max(${questionAttempts.id})`,
        lastAt: questionAttempts.timestamp,
        lastCorrect: questionAttempts.correct,
      })
      .from(questionAttempts)
      .where(eq(questionAttempts.userId, ctx.userId))
      .groupBy(questionAttempts.questionId);

    return rows.map((r) => ({
      questionId: r.questionId,
      attempts: Number(r.attempts),
      correct: Number(r.correct),
      lastCorrect: Number(r.lastCorrect) === 1,
      lastAt: Number(r.lastAt),
    }));
  }),

  addWrongAnswer: protectedProcedure
    .input(
      z.object({
        questionId: z.string(),
        subject: subjectSchema,
        selectedOption: z.number(),
        correctOption: z.number(),
        timestamp: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db
        .insert(wrongAnswers)
        .values({ userId: ctx.userId, ...input })
        .onConflictDoUpdate({
          target: [wrongAnswers.userId, wrongAnswers.questionId],
          set: {
            subject: input.subject,
            selectedOption: input.selectedOption,
            correctOption: input.correctOption,
            timestamp: input.timestamp,
            correctStreak: 0,
          },
        });
    }),

  removeWrongAnswer: protectedProcedure
    .input(z.object({ questionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      await db
        .delete(wrongAnswers)
        .where(and(eq(wrongAnswers.userId, ctx.userId), eq(wrongAnswers.questionId, input.questionId)));
    }),

  clearWrongAnswers: protectedProcedure.mutation(async ({ ctx }) => {
    await db.delete(wrongAnswers).where(eq(wrongAnswers.userId, ctx.userId));
  }),

  getStudyStats: protectedProcedure.query(async ({ ctx }) => {
    const stats = await db.select().from(studyStats).where(eq(studyStats.userId, ctx.userId)).get();
    const subjectRows = await db
      .select()
      .from(subjectStats)
      .where(eq(subjectStats.userId, ctx.userId));

    const bySubject = emptySubjectTotals();
    for (const row of subjectRows) {
      bySubject[row.subject as Subject] = { total: row.total, correct: row.correct };
    }

    return {
      totalAnswered: stats?.totalAnswered ?? 0,
      totalCorrect: stats?.totalCorrect ?? 0,
      bySubject,
      lastStudiedAt: stats?.lastStudiedAt ?? null,
      streakDays: currentStreakDays(stats?.streakDays ?? 0, stats?.lastStreakDate ?? null),
      lastStreakDate: stats?.lastStreakDate ?? null,
      // best_streak 컬럼이 생기기 전의 기록은 0이라, 현재 연속일보다 작을 수 있다.
      bestStreakDays: Math.max(stats?.bestStreak ?? 0, stats?.streakDays ?? 0),
    };
  }),

  recordAnswer: protectedProcedure
    .input(z.object({ subject: subjectSchema, isCorrect: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      await updateStudyStats(ctx.userId, [input]);
    }),

  resetStudyStats: protectedProcedure.mutation(async ({ ctx }) => {
    await db.delete(studyStats).where(eq(studyStats.userId, ctx.userId));
    await db.delete(subjectStats).where(eq(subjectStats.userId, ctx.userId));
    await db.delete(questionAttempts).where(eq(questionAttempts.userId, ctx.userId));
    await db.delete(mockExamResults).where(eq(mockExamResults.userId, ctx.userId));
  }),

  // 한국 시간 기준 오늘 포함 최근 7일. 마지막 항목이 오늘이다.
  getLast7DaysLog: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(dailyLog).where(eq(dailyLog.userId, ctx.userId));
    const byDate = new Map(rows.map((r) => [r.date, r.count]));

    const today = kstDateStr();
    const result: { date: string; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const dateStr = addDays(today, -i);
      result.push({ date: dateStr, count: byDate.get(dateStr) ?? 0 });
    }
    return result;
  }),

  incrementDailyLog: protectedProcedure.mutation(async ({ ctx }) => {
    await incrementDailyLog(ctx.userId);
  }),
});

const mockExamRouter = router({
  // 답안 기록(통계/오답노트 반영)과 채점, 결과 저장을 한 번에 한다.
  // 풀지 않은 문제(selectedOption: null)는 오답으로 채점하되 풀이 기록에는 남기지 않는다.
  submit: protectedProcedure
    .input(
      z.object({
        answers: z
          .array(
            z.object({
              questionId: z.string(),
              selectedOption: z.number().int().min(0).nullable(),
            })
          )
          .min(1)
          .max(100),
        durationSeconds: z.number().int().min(0),
        // 기출 회차 실전 응시면 회차 번호. 없으면 무작위 모의고사.
        round: z.number().int().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const items = input.answers.map((a) => ({
        question: getQuestionOrThrow(a.questionId),
        selected: a.selectedOption,
      }));
      if (input.round !== undefined && !items.every((i) => getPastExamRound(i.question.id) === input.round)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `제${input.round}회 문제가 아닌 답안이 섞여 있습니다.` });
      }

      await recordAnswers(
        ctx.userId,
        items.flatMap((i) =>
          i.selected === null ? [] : [{ question: i.question, selectedOption: i.selected }]
        )
      );

      const score = scoreMockExam(items);
      const takenAt = Date.now();
      await db.insert(mockExamResults).values({
        userId: ctx.userId,
        takenAt,
        total: score.total,
        correct: score.correct,
        subjectScores: JSON.stringify(score.bySubject),
        passed: score.passed ? 1 : 0,
        durationSeconds: input.durationSeconds,
        answers: JSON.stringify(input.answers),
        round: input.round ?? null,
      });
      return { ...score, takenAt };
    }),

  // 기출 회차별 실전 응시 요약: 응시 횟수, 최고 점수(정답률), 합격한 적 있는지.
  roundSummaries: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db
      .select({
        round: mockExamResults.round,
        total: mockExamResults.total,
        correct: mockExamResults.correct,
        passed: mockExamResults.passed,
      })
      .from(mockExamResults)
      .where(and(eq(mockExamResults.userId, ctx.userId), isNotNull(mockExamResults.round)));

    const byRound = new Map<number, { round: number; attempts: number; bestRate: number; everPassed: boolean }>();
    for (const r of rows) {
      if (r.round === null) continue;
      const rate = r.total > 0 ? r.correct / r.total : 0;
      const prev = byRound.get(r.round);
      byRound.set(r.round, {
        round: r.round,
        attempts: (prev?.attempts ?? 0) + 1,
        bestRate: Math.max(prev?.bestRate ?? 0, rate),
        everPassed: (prev?.everPassed ?? false) || r.passed === 1,
      });
    }
    return [...byRound.values()];
  }),

  // 지난 회차 다시 보기용: 그 회차에 나온 문제와 내가 고른 답.
  get: protectedProcedure
    .input(z.object({ id: z.number().int() }))
    .query(async ({ ctx, input }) => {
      const row = await db
        .select()
        .from(mockExamResults)
        .where(and(eq(mockExamResults.userId, ctx.userId), eq(mockExamResults.id, input.id)))
        .get();
      if (!row || !row.answers) {
        throw new TRPCError({ code: "NOT_FOUND", message: "다시 볼 수 없는 응시 기록입니다." });
      }
      return {
        id: row.id,
        takenAt: row.takenAt,
        answers: JSON.parse(row.answers) as { questionId: string; selectedOption: number | null }[],
      };
    }),

  // 최근 응시 기록 (최신순). round: 생략=전체, null=무작위 모의고사만, 숫자=그 기출 회차만.
  list: protectedProcedure
    .input(
      z
        .object({
          limit: z.number().int().min(1).max(100).default(20),
          round: z.number().int().nullable().optional(),
        })
        .optional()
    )
    .query(async ({ ctx, input }) => {
      const roundFilter =
        input?.round === undefined
          ? undefined
          : input.round === null
            ? isNull(mockExamResults.round)
            : eq(mockExamResults.round, input.round);
      const rows = await db
        .select()
        .from(mockExamResults)
        .where(and(eq(mockExamResults.userId, ctx.userId), roundFilter))
        .orderBy(desc(mockExamResults.takenAt))
        .limit(input?.limit ?? 20);

      return rows.map((r) => ({
        id: r.id,
        takenAt: r.takenAt,
        total: r.total,
        correct: r.correct,
        bySubject: JSON.parse(r.subjectScores) as Record<Subject, SubjectScore>,
        passed: r.passed === 1,
        durationSeconds: r.durationSeconds,
        reviewable: r.answers !== null,
        round: r.round,
      }));
    }),
});

const noteRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db.select().from(questionNotes).where(eq(questionNotes.userId, ctx.userId));
    return rows.map((r) => ({ questionId: r.questionId, note: r.note }));
  }),

  // 빈 메모를 저장하면 삭제한다.
  set: protectedProcedure
    .input(z.object({ questionId: z.string(), note: z.string().max(500) }))
    .mutation(async ({ ctx, input }) => {
      getQuestionOrThrow(input.questionId);
      const note = input.note.trim();
      if (!note) {
        await db
          .delete(questionNotes)
          .where(and(eq(questionNotes.userId, ctx.userId), eq(questionNotes.questionId, input.questionId)));
        return { note: "" };
      }
      const updatedAt = Date.now();
      await db
        .insert(questionNotes)
        .values({ userId: ctx.userId, questionId: input.questionId, note, updatedAt })
        .onConflictDoUpdate({
          target: [questionNotes.userId, questionNotes.questionId],
          set: { note, updatedAt },
        });
      return { note };
    }),
});

const bookmarkRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    const rows = await db
      .select()
      .from(bookmarks)
      .where(eq(bookmarks.userId, ctx.userId))
      .orderBy(desc(bookmarks.createdAt));
    return rows.map((r) => r.questionId);
  }),

  toggle: protectedProcedure
    .input(z.object({ questionId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      getQuestionOrThrow(input.questionId);
      const where = and(eq(bookmarks.userId, ctx.userId), eq(bookmarks.questionId, input.questionId));
      const existing = await db.select().from(bookmarks).where(where).get();
      if (existing) {
        await db.delete(bookmarks).where(where);
        return { bookmarked: false };
      }
      await db
        .insert(bookmarks)
        .values({ userId: ctx.userId, questionId: input.questionId, createdAt: Date.now() });
      return { bookmarked: true };
    }),
});

const settingsRouter = router({
  get: protectedProcedure.query(async ({ ctx }) => {
    const user = await db.select().from(users).where(eq(users.id, ctx.userId)).get();
    return { examDate: user?.examDate ?? null };
  }),

  setExamDate: protectedProcedure
    .input(
      z.object({
        examDate: z
          .string()
          .refine(isValidDateStr, "날짜는 YYYY-MM-DD 형식으로 입력해주세요.")
          .nullable(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      await db.update(users).set({ examDate: input.examDate }).where(eq(users.id, ctx.userId));
      return { examDate: input.examDate };
    }),
});

export const appRouter = router({
  auth: authRouter,
  progress: progressRouter,
  mockExam: mockExamRouter,
  bookmark: bookmarkRouter,
  note: noteRouter,
  settings: settingsRouter,

  // AI Vision API for image recognition
  // 문제 텍스트 추출과 해설 생성을 한 번의 AI 호출로 합쳐서 처리한다
  // (OCR과 해설을 따로 부르면 사진 한 장당 비용이 두 배가 된다).
  vision: router({
    // 로그인한 사용자만 (generateForWrongAnswer와 같은 이유)
    recognizeQuestion: protectedProcedure
      .input(z.object({
        base64Image: z.string(),
      }))
      .mutation(async ({ input }) => {
        try {
          console.log("[Server] Recognizing question + generating explanation from image...");
          console.log("[Server] Image size:", input.base64Image.length, "bytes");

          const { text: fullText } = await generateText({
            prompt:
              "이 이미지에서 보이는 IT 자격증 시험 문제의 모든 텍스트(문제, 선택지)를 정확하게 추출하고, 이어서 정답과 해설을 작성해주세요.\n\n" +
              "다음 형식을 정확히 지켜서 답변하세요 (대괄호 표시도 그대로 포함):\n" +
              "[문제]\n(추출한 문제와 선택지 전체)\n\n" +
              "[해설]\n(정답이 무엇이고 왜 그런지 설명하는 해설. 약 30초 분량의 음성 해설로 읽을 수 있는 길이, 학생을 격려하는 자연스러운 어조)",
            imageBase64: input.base64Image,
            maxOutputTokens: 4096,
          });

          if (!fullText || fullText.trim().length === 0) {
            console.error("[Server] Empty response from AI");
            throw new Error("Empty response from AI");
          }

          const marker = fullText.match(/\[해설\]/);
          if (!marker || marker.index === undefined) {
            console.error("[Server] Could not find [해설] marker in AI response:", fullText);
            throw new Error("해설 구간을 찾을 수 없습니다");
          }

          const text = fullText.slice(0, marker.index).replace(/^\[문제\]\s*/, "").trim();
          const explanation = fullText.slice(marker.index + marker[0].length).trim();

          if (!text || !explanation) {
            console.error("[Server] Question or explanation parsing failed. Full response:", fullText);
            throw new Error("문제 또는 해설 파싱 실패");
          }

          console.log("[Server] Question + explanation recognized successfully");
          return {
            success: true,
            text,
            explanation,
          };
        } catch (error) {
          console.error("[Server] Vision API error:", error);
          console.error("[Server] Error details:", error instanceof Error ? error.message : String(error));
          // 바쁨/한도 초과는 generateText(withFallback)가 이미 사용자용 메시지로 바꿔 둔다.
          if (error instanceof TRPCError) throw error;
          // 그 외(문제를 못 읽었거나 응답 형식이 깨진 경우)는 다시 찍어보라고 안내한다.
          throw new TRPCError({
            code: "UNPROCESSABLE_CONTENT",
            message: "사진에서 문제를 읽지 못했어요. 문제 부분이 잘 보이게 다시 찍어주세요.",
          });
        }
      }),
  }),

  explain: router({
    // 동그래 해설 AI 목소리: 음성을 준비(캐시 우선)하고 재생 주소를 돌려준다.
    // 실패(할당량 초과 등)하면 앱이 폰 내장 목소리로 대신 읽는다.
    prepareSpeech: protectedProcedure
      .input(z.object({ text: z.string().trim().min(1).max(2000) }))
      .mutation(async ({ input }) => {
        const { id, durationSec } = await prepareSpeech(input.text);
        return { path: `/api/tts/${id}.wav`, durationSec };
      }),

    // 동그래 그림 해설: 해설을 장면(대사 + 칠판 그림)으로 나눈 대본을 돌려준다 (server/lib/scene-script.ts).
    // 문제은행 문제만 받는다 — 문제 내용을 서버가 직접 가져와야 공용 캐시가 오염되지 않는다.
    // 실패하면 앱이 기존 자막 해설(generateForWrongAnswer / 기본 해설)로 대신 보여준다.
    generateScenes: protectedProcedure
      .input(z.object({ questionId: z.string(), selectedOption: z.number().int().min(0) }))
      .mutation(async ({ input }) => {
        const q = getQuestionOrThrow(input.questionId);
        if (input.selectedOption >= q.options.length) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "보기 번호가 올바르지 않습니다." });
        }
        const scenes = await getExplanationScenes(q, input.selectedOption);
        // 앱이 화면을 여는 동안 AI 목소리를 미리 만들기 시작한다. 앱이 재생할 때 보내는 문장과 같아야
        // (dmu-explanation-player의 cleanText.slice(0, 2000)) 진행 중인 생성을 그대로 이어받는다.
        prepareSpeech(sceneNarrationText(scenes).slice(0, 2000)).catch((error) =>
          console.warn("[Scenes] Speech pre-generation failed:", error instanceof Error ? error.message : error)
        );
        return { scenes };
      }),

    // 오답노트 전용: 문제은행의 고정 해설 대신, 학생이 실제로 고른 오답을
    // 콕 집어서 "왜 그게 틀렸고 정답은 왜 맞는지"를 설명한다.
    // 로그인한 사용자만: 공개해 두면 주소만 알아도 누구나 호출해서 AI 비용을 써버릴 수 있다.
    //
    // questionId를 주면 문제 내용은 서버의 문제은행에서 가져오고(클라이언트가 보낸 글로 캐시가
    // 오염되지 않게), "문제 + 고른 답"별로 정상 생성된 해설을 저장해 다음 사람에게 그대로 준다.
    // 같은 해설 문장이 되므로 동그래 AI 목소리(speech_cache)도 재사용된다.
    generateForWrongAnswer: protectedProcedure
      .input(
        z.object({
          questionId: z.string().optional(),
          question: z.string(),
          options: z.array(z.string()),
          selectedOption: z.number(),
          correctOption: z.number(),
        })
      )
      .mutation(async ({ input: rawInput }) => {
        const bankQuestion = rawInput.questionId ? questionById.get(rawInput.questionId) : undefined;
        const input = bankQuestion
          ? {
              ...rawInput,
              question: bankQuestion.question,
              options: bankQuestion.options,
              correctOption: bankQuestion.answer,
            }
          : rawInput;

        if (bankQuestion) {
          const cached = await loadCachedExplanation(bankQuestion.id, input.selectedOption);
          if (cached) return { success: true, explanation: cached };
        }

        try {
          const optionsList = input.options
            .map((opt, idx) => `${idx + 1}. ${opt}`)
            .join("\n");

          const { text: explanation, complete } = await generateText({
            instructions:
              "당신은 IT 자격증 시험 문제 해설 전문가입니다. 학생이 실제로 고른 오답을 기준으로, 그 오답이 왜 틀렸는지와 정답이 왜 맞는지를 자연스러운 음성 해설처럼 설명하세요. 약 30초 분량으로 읽을 수 있는 길이로 작성하고, 학생을 탓하지 말고 격려하는 어조를 쓰세요.",
            prompt: `문제: ${input.question}\n\n선택지:\n${optionsList}\n\n학생이 선택한 답: ${
              input.options[input.selectedOption]
            }\n정답: ${
              input.options[input.correctOption]
            }\n\n학생이 왜 이 선택지를 오답으로 골랐을지 짚어주고, 그 선택지가 왜 틀렸는지, 그리고 정답이 왜 맞는지 설명해주세요.`,
            maxOutputTokens: 2048,
          });

          if (!explanation || explanation.trim().length === 0) {
            console.error("[Server] Empty personalized explanation from AI");
            throw new Error("Empty explanation from AI");
          }

          // 끝까지 정상으로 만들어진 해설만 저장한다 (토큰 한도로 중간에 잘린 해설은 저장하지 않음).
          if (bankQuestion && complete && input.selectedOption !== bankQuestion.answer) {
            await saveCachedExplanation(bankQuestion.id, input.selectedOption, explanation.trim());
          }

          return { success: true, explanation: explanation.trim() };
        } catch (error) {
          console.error("[Server] Personalized wrong-answer explanation error:", error);
          console.error("[Server] Error details:", error instanceof Error ? error.message : String(error));
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;

import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { initDb } from "../db/init";
import { googleOAuthRouter } from "../auth/google-oauth";
import { serveSpeech } from "../lib/tts";
import { speechPrewarmStatus, startSpeechPrewarm } from "../lib/tts-prewarm";

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  await initDb();

  const app = express();
  const server = createServer(app);
  // Render 같은 프록시 뒤에서도 req.protocol이 https로 잡히게 (Google OAuth 콜백 주소 계산에 필요)
  app.set("trust proxy", true);

  // Enable CORS for all routes - reflect the request origin to support credentials
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
    }
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization",
    );
    res.header("Access-Control-Allow-Credentials", "true");

    // Handle preflight requests
    if (req.method === "OPTIONS") {
      res.sendStatus(200);
      return;
    }
    next();
  });

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  // NOTE: AI 해설 생성은 tRPC `vision.recognizeQuestion`(사진인식 시 문제+해설을 한 번에 생성)과
  // `explain.generateForWrongAnswer`(오답노트 맞춤 해설)로 통일했다(server/routers.ts).
  // NOTE: 서버 영상 합성(ffmpeg/ImageMagick 기반 "말하는 캐릭터 mp4") 파이프라인은 제거했다.
  // 원인: 캐릭터 이미지 경로가 원 개발 환경의 로컬 절대경로로 하드코딩되어 있어
  // 다른 환경에서는 항상 실패했다. 대신 클라이언트에서 실시간으로 TTS + 캐릭터
  // 애니메이션을 재생하는 방식(components/dmu-explanation-player.tsx)을 사용한다.
  // 자세한 배경은 ADSP_퀴즈앱_재기획서.md 2-2절 참고.

  app.use("/api/auth/google", googleOAuthRouter);
  app.get("/api/tts/:id.wav", serveSpeech);
  // 동그래 기본 해설 음성 미리 만들기 진행 상황 (몇 개 준비됐는지)
  app.get("/api/tts-status", async (_req, res) => {
    res.json(await speechPrewarmStatus());
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`[api] server listening on port ${port}`);
    startSpeechPrewarm(); // 실서버에서만 동작 (server/lib/tts-prewarm.ts)
  });
}

startServer().catch(console.error);

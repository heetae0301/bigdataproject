import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import { verifyToken } from "../auth/jwt";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  userId: string | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  const authHeader = opts.req.headers.authorization;
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice("Bearer ".length) : null;
  const payload = token ? verifyToken(token) : null;

  return {
    req: opts.req,
    res: opts.res,
    userId: payload?.userId ?? null,
  };
}

import { db } from "./client";

// 이미 존재하던 로컬 DB에 컬럼을 추가한다. 컬럼이 이미 있으면 SQLite가 에러를 던지는데, 그건 무시한다.
async function addColumnIfMissing(statement: string): Promise<void> {
  try {
    await db.run(statement);
  } catch {
    // 컬럼이 이미 존재함 - 정상.
  }
}

/**
 * schema.ts와 동일한 테이블을 만드는 부트스트랩. drizzle-kit 마이그레이션 없이
 * `pnpm dev`만으로 로컬 DB가 바로 준비되도록 서버 시작 시 한 번 실행한다.
 * 컬럼을 바꿀 때는 이 파일도 schema.ts와 같이 수정해야 한다.
 */
export async function initDb(): Promise<void> {
  await db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      nickname TEXT NOT NULL DEFAULT '',
      password_hash TEXT NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);

  // 이미 존재하던 로컬 DB(nickname/exam_date 컬럼 추가 전에 만들어진)를 위한 마이그레이션.
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN nickname TEXT NOT NULL DEFAULT ''`);
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN exam_date TEXT`);
  // Google 로그인 연동 전의 DB. 기존 계정은 google_id=NULL이라 이메일/비밀번호로만 로그인된다.
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN google_id TEXT`);
  // NULL은 여러 개 허용하면서 실제 google_id 값만 유일하게 강제하는 부분 유니크 인덱스.
  await db.run(
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_users_google_id ON users (google_id) WHERE google_id IS NOT NULL`
  );
  // 비밀번호 찾기 기능 추가 전의 DB.
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN reset_code_hash TEXT`);
  await addColumnIfMissing(`ALTER TABLE users ADD COLUMN reset_code_expires_at INTEGER`);

  await db.run(`
    CREATE TABLE IF NOT EXISTS wrong_answers (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      subject TEXT NOT NULL,
      selected_option INTEGER NOT NULL,
      correct_option INTEGER NOT NULL,
      timestamp INTEGER NOT NULL,
      correct_streak INTEGER NOT NULL DEFAULT 0,
      next_review_at INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, question_id)
    )
  `);
  // 반복 학습 컬럼 추가 전의 DB. 기존 오답은 next_review_at=0이라 바로 복습 대상이 된다.
  await addColumnIfMissing(
    `ALTER TABLE wrong_answers ADD COLUMN correct_streak INTEGER NOT NULL DEFAULT 0`
  );
  await addColumnIfMissing(
    `ALTER TABLE wrong_answers ADD COLUMN next_review_at INTEGER NOT NULL DEFAULT 0`
  );

  await db.run(`
    CREATE TABLE IF NOT EXISTS question_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      subject TEXT NOT NULL,
      correct INTEGER NOT NULL,
      timestamp INTEGER NOT NULL
    )
  `);
  await db.run(
    `CREATE INDEX IF NOT EXISTS idx_question_attempts_user ON question_attempts (user_id, question_id)`
  );

  await db.run(`
    CREATE TABLE IF NOT EXISTS mock_exam_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      taken_at INTEGER NOT NULL,
      total INTEGER NOT NULL,
      correct INTEGER NOT NULL,
      subject_scores TEXT NOT NULL,
      passed INTEGER NOT NULL,
      duration_seconds INTEGER NOT NULL
    )
  `);
  // 지난 회차 다시 보기 컬럼 추가 전의 DB. 기존 기록은 answers=NULL이라 다시 볼 수 없다.
  await addColumnIfMissing(`ALTER TABLE mock_exam_results ADD COLUMN answers TEXT`);
  // 기출 회차 실전 응시 기록. 기존 기록은 NULL(= 무작위 모의고사)로 남는다.
  await addColumnIfMissing(`ALTER TABLE mock_exam_results ADD COLUMN round INTEGER`);

  await db.run(`
    CREATE TABLE IF NOT EXISTS question_notes (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      note TEXT NOT NULL,
      updated_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, question_id)
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS bookmarks (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      question_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, question_id)
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS study_stats (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      total_answered INTEGER NOT NULL DEFAULT 0,
      total_correct INTEGER NOT NULL DEFAULT 0,
      last_studied_at INTEGER,
      streak_days INTEGER NOT NULL DEFAULT 0,
      last_streak_date TEXT
    )
  `);
  // 최장 연속 학습일 배지 추가 전의 DB. 기존 기록은 0부터 시작하고,
  // progress 라우터가 현재 streak_days와 max를 취해 보정한다.
  await addColumnIfMissing(
    `ALTER TABLE study_stats ADD COLUMN best_streak INTEGER NOT NULL DEFAULT 0`
  );

  await db.run(`
    CREATE TABLE IF NOT EXISTS subject_stats (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL,
      total INTEGER NOT NULL DEFAULT 0,
      correct INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, subject)
    )
  `);

  await db.run(`
    CREATE TABLE IF NOT EXISTS daily_log (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      date TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY (user_id, date)
    )
  `);

  // 동그래 맞춤 해설 공용 캐시: "문제 + 고른 오답"마다 한 번 만든 해설을 모두가 같이 쓴다.
  await db.run(`
    CREATE TABLE IF NOT EXISTS explanation_cache (
      question_id TEXT NOT NULL,
      selected_option INTEGER NOT NULL,
      explanation TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      PRIMARY KEY (question_id, selected_option)
    )
  `);

  // 동그래 그림 해설 공용 캐시: "문제 + 고른 답"마다 한 번 만든 장면 대본(JSON)을 모두가 같이 쓴다.
  await db.run(`
    CREATE TABLE IF NOT EXISTS scene_cache (
      question_id TEXT NOT NULL,
      selected_option INTEGER NOT NULL,
      scenes_json TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      PRIMARY KEY (question_id, selected_option)
    )
  `);

  // 동그래 AI 목소리 공용 캐시: 해설 문장(+목소리) 해시마다 한 번 만든 WAV를 저장한다.
  // 처음 버전(speech_cache)은 말투 지시문까지 소리 내어 읽은 잘못된 음성이라 테이블째 버리고 v2로 새로 쌓는다.
  await db.run(`DROP TABLE IF EXISTS speech_cache`);
  await db.run(`
    CREATE TABLE IF NOT EXISTS speech_cache_v2 (
      text_hash TEXT PRIMARY KEY,
      wav BLOB NOT NULL,
      duration_sec REAL NOT NULL,
      created_at INTEGER NOT NULL
    )
  `);
}

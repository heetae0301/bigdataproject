import { sqliteTable, text, integer, real, blob, primaryKey } from "drizzle-orm/sqlite-core";

export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  nickname: text("nickname").notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: integer("created_at").notNull(),
  // 시험일(YYYY-MM-DD, KST). 홈 화면 D-day 표시에 쓴다.
  examDate: text("exam_date"),
  // Google 로그인으로 가입/연동한 계정의 Google 고유 ID(payload.sub). 이메일/비밀번호로만
  // 가입한 계정은 null. passwordHash는 이 경우에도 (무작위 값으로) 채워 넣어 컬럼 제약은 그대로 둔다.
  googleId: text("google_id"),
  // 비밀번호 재설정 인증코드(6자리)를 bcrypt 해시로 저장. 평문은 이메일로만 나가고 DB에는 안 남는다.
  resetCodeHash: text("reset_code_hash"),
  // 위 코드의 만료 시각(ms). 이 시각이 지나면 코드가 맞아도 재설정 거부.
  resetCodeExpiresAt: integer("reset_code_expires_at"),
});

export const wrongAnswers = sqliteTable(
  "wrong_answers",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: text("question_id").notNull(),
    subject: text("subject").notNull(),
    selectedOption: integer("selected_option").notNull(),
    correctOption: integer("correct_option").notNull(),
    timestamp: integer("timestamp").notNull(),
    // 반복 학습: 복습일에 맞힌 횟수(연속). WRONG_GRADUATE_STREAK에 도달하면 오답노트에서 졸업.
    correctStreak: integer("correct_streak").notNull().default(0),
    // 다음 복습 예정 시각(ms). 이 시각 이후에 맞혀야 correctStreak가 올라간다.
    nextReviewAt: integer("next_review_at").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.questionId] })]
);

// 문제별 풀이 기록 (한 번 풀 때마다 한 줄). 진도율, 안 푼 문제 우선 출제,
// 자주 틀리는 문제 순위를 여기서 계산한다.
export const questionAttempts = sqliteTable("question_attempts", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  questionId: text("question_id").notNull(),
  subject: text("subject").notNull(),
  correct: integer("correct").notNull(), // 0 | 1
  timestamp: integer("timestamp").notNull(),
});

export const mockExamResults = sqliteTable("mock_exam_results", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  userId: text("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  takenAt: integer("taken_at").notNull(),
  total: integer("total").notNull(),
  correct: integer("correct").notNull(),
  // 과목별 점수 JSON: { [subject]: { total, correct } }
  subjectScores: text("subject_scores").notNull(),
  passed: integer("passed").notNull(), // 0 | 1
  durationSeconds: integer("duration_seconds").notNull(),
  // 문제별 답안 JSON: [{ questionId, selectedOption }]. 지난 회차 다시 보기에 쓴다.
  // 이 컬럼이 생기기 전의 기록은 null이라 다시 볼 수 없다.
  answers: text("answers"),
  // 기출 회차 실전 응시면 회차 번호(예: 48), 무작위 모의고사면 null.
  round: integer("round"),
});

// 문제별 개인 메모 (문제당 하나). 풀이 화면과 오답노트에서 같이 본다.
export const questionNotes = sqliteTable(
  "question_notes",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: text("question_id").notNull(),
    note: text("note").notNull(),
    updatedAt: integer("updated_at").notNull(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.questionId] })]
);

export const bookmarks = sqliteTable(
  "bookmarks",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: text("question_id").notNull(),
    createdAt: integer("created_at").notNull(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.questionId] })]
);

export const studyStats = sqliteTable("study_stats", {
  userId: text("user_id")
    .primaryKey()
    .references(() => users.id, { onDelete: "cascade" }),
  totalAnswered: integer("total_answered").notNull().default(0),
  totalCorrect: integer("total_correct").notNull().default(0),
  lastStudiedAt: integer("last_studied_at"),
  streakDays: integer("streak_days").notNull().default(0),
  lastStreakDate: text("last_streak_date"),
  // 지금까지의 최장 연속 학습일. 연속이 끊겨도 배지는 유지하기 위해 따로 둔다.
  bestStreak: integer("best_streak").notNull().default(0),
});

export const subjectStats = sqliteTable(
  "subject_stats",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    subject: text("subject").notNull(),
    total: integer("total").notNull().default(0),
    correct: integer("correct").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.subject] })]
);

export const dailyLog = sqliteTable(
  "daily_log",
  {
    userId: text("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    date: text("date").notNull(),
    count: integer("count").notNull().default(0),
  },
  (table) => [primaryKey({ columns: [table.userId, table.date] })]
);

// 동그래 맞춤 해설 공용 캐시: "문제 + 고른 오답"마다 AI가 정상으로 만든 해설을 저장해 모두가 같이 쓴다.
// 사용자 개인 데이터가 아니라서 user_id가 없다(회원 탈퇴와 무관).
export const explanationCache = sqliteTable(
  "explanation_cache",
  {
    questionId: text("question_id").notNull(),
    selectedOption: integer("selected_option").notNull(),
    explanation: text("explanation").notNull(),
    createdAt: integer("created_at").notNull(),
  },
  (t) => [primaryKey({ columns: [t.questionId, t.selectedOption] })]
);

// 동그래 그림 해설 공용 캐시: "문제 + 고른 답"마다 AI가 만든 장면 대본(JSON, lib/explanation-scenes.ts)을 저장한다.
// 맞힌 경우(selected_option = 정답)도 저장한다 — 그림 해설은 맞혔을 때도 보여주기 때문.
export const sceneCache = sqliteTable(
  "scene_cache",
  {
    questionId: text("question_id").notNull(),
    selectedOption: integer("selected_option").notNull(),
    scenesJson: text("scenes_json").notNull(),
    createdAt: integer("created_at").notNull(),
  },
  (t) => [primaryKey({ columns: [t.questionId, t.selectedOption] })]
);

// 동그래 AI 목소리 공용 캐시: 해설 문장(+목소리 이름)의 해시마다 정상으로 만든 WAV를 저장한다.
// 서버 메모리 캐시(server/lib/tts.ts)는 Render가 잠들면 비워지므로 여기서 다시 채운다.
// (처음 버전 speech_cache는 말투 지시문까지 읽은 잘못된 음성이라 폐기하고 v2로 바꿨다 — server/db/init.ts)
export const speechCache = sqliteTable("speech_cache_v2", {
  textHash: text("text_hash").primaryKey(),
  wav: blob("wav", { mode: "buffer" }).notNull(),
  durationSec: real("duration_sec").notNull(),
  createdAt: integer("created_at").notNull(),
});

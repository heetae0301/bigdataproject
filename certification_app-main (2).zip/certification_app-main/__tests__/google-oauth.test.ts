import { afterEach, describe, expect, it, vi } from "vitest";
import { isAllowedReturnUrl, issueLoginCode, takeLoginCode } from "../server/auth/google-oauth";
import { signOAuthState, verifyOAuthState } from "../server/auth/jwt";

describe("Google OAuth 앱 복귀 주소 허용 목록", () => {
  afterEach(() => {
    delete process.env.EXPO_RETURN_HOSTS;
  });

  it("앱 자체 스킴과 같은 와이파이의 Expo Go 주소는 허용한다", () => {
    expect(isAllowedReturnUrl("manus20240115103045://auth/google")).toBe(true);
    expect(isAllowedReturnUrl("exp://192.168.0.5:8081/--/auth/google")).toBe(true);
    expect(isAllowedReturnUrl("exp://10.0.2.2:8081/--/auth/google")).toBe(true);
    expect(isAllowedReturnUrl("exp://127.0.0.1:8081/--/auth/google")).toBe(true);
  });

  it("외부 Expo Go 주소는 EXPO_RETURN_HOSTS에 등록한 것만 허용한다", () => {
    const url = "exps://grant-lecturer-subtly.ngrok-free.dev/--/auth/google";
    expect(isAllowedReturnUrl(url)).toBe(false);
    process.env.EXPO_RETURN_HOSTS = "grant-lecturer-subtly.ngrok-free.dev";
    expect(isAllowedReturnUrl(url)).toBe(true);
    expect(isAllowedReturnUrl("exps://attacker.ngrok-free.dev/--/auth/google")).toBe(false);
  });

  it("EAS 업데이트(u.expo.dev)는 우리 프로젝트 주소만 허용한다", () => {
    const project = "c7ad6e1f-de42-47ae-8596-29cf717bdbe7";
    expect(isAllowedReturnUrl(`exp://u.expo.dev/${project}/group/abc/--/auth/google`)).toBe(true);
    expect(isAllowedReturnUrl(`exp://u.expo.dev/${project}/--/auth/google?channel-name=x`)).toBe(true);
    expect(isAllowedReturnUrl("exp://u.expo.dev/00000000-other-project/--/auth/google")).toBe(false);
    expect(isAllowedReturnUrl(`exp://u.expo.dev/${project}evil/--/auth/google`)).toBe(false);
  });

  it("웹 주소·다른 스킴·잘못된 값은 거부한다", () => {
    expect(isAllowedReturnUrl("https://evil.example.com/steal")).toBe(false);
    expect(isAllowedReturnUrl("javascript:alert(1)")).toBe(false);
    expect(isAllowedReturnUrl("otherapp://auth/google")).toBe(false);
    expect(isAllowedReturnUrl("")).toBe(false);
    expect(isAllowedReturnUrl("exp://8.8.8.8/--/auth/google")).toBe(false);
  });
});

describe("OAuth state 서명", () => {
  it("서명한 복귀 주소를 그대로 돌려주고, 변조되면 null", () => {
    const state = signOAuthState("exp://192.168.0.5:8081/--/auth/google");
    expect(verifyOAuthState(state)).toBe("exp://192.168.0.5:8081/--/auth/google");
    expect(verifyOAuthState(state.slice(0, -2) + "xx")).toBeNull();
    expect(verifyOAuthState("garbage")).toBeNull();
  });
});

describe("1회용 로그인 코드", () => {
  const result = { token: "jwt", user: { id: "u1", email: "a@b.c", nickname: "a" } };

  it("한 번만 쓸 수 있다", () => {
    const code = issueLoginCode(result);
    expect(takeLoginCode(code)).toEqual(result);
    expect(takeLoginCode(code)).toBeNull();
    expect(takeLoginCode("unknown")).toBeNull();
  });

  it("2분이 지나면 만료된다", () => {
    vi.useFakeTimers();
    try {
      const code = issueLoginCode(result);
      vi.advanceTimersByTime(2 * 60 * 1000 + 1);
      expect(takeLoginCode(code)).toBeNull();
    } finally {
      vi.useRealTimers();
    }
  });
});

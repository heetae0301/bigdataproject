import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";

// 실제 OpenAI를 부르지 않고, 호출마다 정해 둔 결과를 돌려주는 가짜 클라이언트로 바꾼다.
const responsesCreate = vi.fn();
const speechCreate = vi.fn();
vi.mock("openai", async (importOriginal) => {
  const actual = await importOriginal<typeof import("openai")>();
  return {
    ...actual,
    default: vi.fn().mockImplementation(() => ({
      responses: { create: responsesCreate },
      audio: { speech: { create: speechCreate } },
    })),
  };
});

const { APIError, APIConnectionError } = await import("openai");
const { generateText, synthesizeSpeech, AI_TEXT_MODEL, AI_TEXT_FALLBACK_MODEL, TTS_MODEL, TTS_VOICE } = await import(
  "../server/lib/ai"
);

const apiError = (status: number, code?: string) => new APIError(status, code ? { code } : {}, `status ${status}`, new Headers());
const ok = (text: string, status = "completed") => ({ output_text: text, status });
const modelsCalled = () => responsesCreate.mock.calls.map(([params]) => params.model);

describe("generateText (재시도·대체 모델)", () => {
  beforeEach(() => {
    process.env.OPENAI_API_KEY = "test-key";
    responsesCreate.mockReset();
    vi.useFakeTimers();
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  async function run(request = { prompt: "hi" }) {
    const promise = generateText(request);
    promise.catch(() => {}); // 아래에서 기대값으로 검사하기 전에 unhandled rejection 경고가 나지 않게
    await vi.runAllTimersAsync();
    return promise;
  }

  it("성공하면 기본 모델 한 번만 호출하고, 끝까지 만들어졌는지 알려준다", async () => {
    responsesCreate.mockResolvedValueOnce(ok("A"));
    await expect(run()).resolves.toEqual({ text: "A", complete: true });
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL]);
  });

  it("토큰 한도로 잘린 응답(incomplete)은 complete=false (캐시에 저장하지 않게)", async () => {
    responsesCreate.mockResolvedValueOnce(ok("잘린 해설", "incomplete"));
    await expect(run()).resolves.toEqual({ text: "잘린 해설", complete: false });
  });

  it("5xx(서버 바쁨)이면 같은 모델로 한 번 더 시도한다", async () => {
    responsesCreate.mockRejectedValueOnce(apiError(503)).mockResolvedValueOnce(ok("B"));
    await expect(run()).resolves.toMatchObject({ text: "B" });
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL, AI_TEXT_MODEL]);
  });

  it("네트워크 연결 실패도 서버 바쁨처럼 다시 시도한다", async () => {
    responsesCreate.mockRejectedValueOnce(new APIConnectionError({ message: "down" })).mockResolvedValueOnce(ok("N"));
    await expect(run()).resolves.toMatchObject({ text: "N" });
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL, AI_TEXT_MODEL]);
  });

  it("429 요청 한도(rate limit)면 재시도 없이 대체 모델로 넘어간다", async () => {
    responsesCreate.mockRejectedValueOnce(apiError(429, "rate_limit_exceeded")).mockResolvedValueOnce(ok("C"));
    await expect(run()).resolves.toMatchObject({ text: "C" });
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL, AI_TEXT_FALLBACK_MODEL]);
  });

  it("429 insufficient_quota(결제 한도)면 대체 모델도 안 부르고 바로 안내", async () => {
    responsesCreate.mockRejectedValue(apiError(429, "insufficient_quota"));
    const error = await run().catch((e) => e);
    expect(error).toBeInstanceOf(TRPCError);
    expect(error.code).toBe("TOO_MANY_REQUESTS");
    expect(error.message).toContain("한도");
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL]);
  });

  it("두 모델 모두 요청 한도면 TOO_MANY_REQUESTS와 안내 문구", async () => {
    responsesCreate.mockRejectedValue(apiError(429));
    const error = await run().catch((e) => e);
    expect(error.code).toBe("TOO_MANY_REQUESTS");
    expect(error.message).toContain("잠시 후");
  });

  it("두 모델 모두 바쁘면 SERVICE_UNAVAILABLE와 안내 문구", async () => {
    responsesCreate.mockRejectedValue(apiError(503));
    const error = await run().catch((e) => e);
    expect(error.code).toBe("SERVICE_UNAVAILABLE");
    expect(error.message).toContain("바빠요");
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL, AI_TEXT_MODEL, AI_TEXT_FALLBACK_MODEL, AI_TEXT_FALLBACK_MODEL]);
  });

  it("그 밖의 오류(예: 400 잘못된 요청)는 재시도하지 않고 그대로 던진다", async () => {
    responsesCreate.mockRejectedValue(apiError(400));
    const error = await run().catch((e) => e);
    expect(error).toBeInstanceOf(APIError);
    expect(modelsCalled()).toEqual([AI_TEXT_MODEL]);
  });

  it("사진은 data URL로, JSON 요청은 json_object 형식으로 보낸다", async () => {
    responsesCreate.mockResolvedValueOnce(ok("{}"));
    await run({ prompt: "JSON으로", imageBase64: "QUJD", json: true } as never);
    const params = responsesCreate.mock.calls[0][0];
    expect(params.input[0].content[1]).toMatchObject({ type: "input_image", image_url: "data:image/jpeg;base64,QUJD" });
    expect(params.text).toEqual({ format: { type: "json_object" } });
  });

  it("JSON 요청인데 사용자 메시지에 'json'이 없으면 덧붙인다 (OpenAI가 400으로 거절함)", async () => {
    responsesCreate.mockResolvedValueOnce(ok("{}"));
    await run({ instructions: "JSON으로 답하세요", prompt: "칠판 대본을 만들어 주세요", json: true } as never);
    expect(responsesCreate.mock.calls[0][0].input[0].content[0].text).toMatch(/json/i);
  });

  it("키가 없으면 호출하지 않고 에러", async () => {
    delete process.env.OPENAI_API_KEY;
    await expect(run()).rejects.toThrow("OPENAI_API_KEY");
    expect(responsesCreate).not.toHaveBeenCalled();
  });
});

describe("synthesizeSpeech", () => {
  beforeEach(() => {
    process.env.OPENAI_API_KEY = "test-key";
    speechCreate.mockReset();
  });

  it("동그래 목소리·말투 지시·PCM 형식으로 요청하고, 본문에는 해설만 넣는다", async () => {
    speechCreate.mockResolvedValueOnce({ arrayBuffer: async () => new Uint8Array([1, 2, 3, 4]).buffer });
    const audio = await synthesizeSpeech("차분 프라이버시는 노이즈를 추가하는 기법입니다.");
    expect(audio.length).toBe(4);
    const params = speechCreate.mock.calls[0][0];
    expect(params).toMatchObject({
      model: TTS_MODEL,
      voice: TTS_VOICE,
      input: "차분 프라이버시는 노이즈를 추가하는 기법입니다.",
      response_format: "pcm",
    });
    expect(params.instructions).toBeTruthy();
  });

  it("빈 오디오면 에러", async () => {
    speechCreate.mockResolvedValueOnce({ arrayBuffer: async () => new ArrayBuffer(0) });
    await expect(synthesizeSpeech("x")).rejects.toThrow("오디오");
  });
});

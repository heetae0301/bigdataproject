import { describe, it, expect } from "vitest";
import {
  generateSubtitlesFromExplanation,
  splitIntoSentenceSegments,
  findSegmentForCharIndex,
} from "../lib/ai-service";

describe("ai-service subtitle generation", () => {
  it("텍스트를 문장 단위로 자막 분할", () => {
    const explanation = "첫 번째 문장입니다. 두 번째 문장입니다. 세 번째 문장입니다.";
    const result = generateSubtitlesFromExplanation(explanation, 30);

    expect(result.subtitles).toHaveLength(3);
    expect(result.subtitles[0].startTime).toBe(0);
    expect(result.subtitles[0].text).toBe("첫 번째 문장입니다");
    expect(result.subtitles[2].endTime).toBe(30);
  });

  it("SRT 형식 자막 생성", () => {
    const explanation = "테스트 문장입니다.";
    const result = generateSubtitlesFromExplanation(explanation, 10);

    expect(result.srtSubtitles).toContain("1\n");
    expect(result.srtSubtitles).toContain("00:00:00,000");
    expect(result.srtSubtitles).toContain("테스트 문장입니다");
  });

  it("빈 문장은 필터링", () => {
    const explanation = "문장 하나. . . 문장 둘.";
    const result = generateSubtitlesFromExplanation(explanation, 20);

    result.subtitles.forEach((sub) => {
      expect(sub.text.length).toBeGreaterThan(0);
    });
  });

  it("자막 시간이 연속적으로 배치됨", () => {
    const explanation = "A 문장. B 문장. C 문장. D 문장.";
    const result = generateSubtitlesFromExplanation(explanation, 20);

    for (let i = 1; i < result.subtitles.length; i++) {
      expect(result.subtitles[i].startTime).toBe(result.subtitles[i - 1].endTime);
    }
  });

  it("단일 문장도 처리 가능", () => {
    const explanation = "하나의 문장만 있습니다.";
    const result = generateSubtitlesFromExplanation(explanation, 5);

    expect(result.subtitles).toHaveLength(1);
    expect(result.subtitles[0].startTime).toBe(0);
    expect(result.subtitles[0].endTime).toBe(5);
  });

  it("ExplanationResult 구조 확인", () => {
    const explanation = "데이터 분석 준전문가 시험에서는 통계 기본 개념이 중요합니다.";
    const result = generateSubtitlesFromExplanation(explanation, 15);

    expect(result).toHaveProperty("subtitles");
    expect(result).toHaveProperty("srtSubtitles");
    expect(Array.isArray(result.subtitles)).toBe(true);
    expect(typeof result.srtSubtitles).toBe("string");

    const sub = result.subtitles[0];
    expect(sub).toHaveProperty("startTime");
    expect(sub).toHaveProperty("endTime");
    expect(sub).toHaveProperty("text");
    expect(typeof sub.startTime).toBe("number");
    expect(typeof sub.endTime).toBe("number");
    expect(typeof sub.text).toBe("string");
  });
});

describe("splitIntoSentenceSegments (onBoundary 동기화용 문자 위치 분할)", () => {
  it("각 문장의 startChar/endChar가 원본 문자열 위치와 일치", () => {
    const text = "첫 번째 문장입니다. 두 번째 문장입니다.";
    const segments = splitIntoSentenceSegments(text);

    expect(segments).toHaveLength(2);
    segments.forEach((seg) => {
      expect(text.slice(seg.startChar, seg.endChar)).toBe(seg.text);
    });
  });

  it("문장 사이 공백이 있어도 다음 문장의 시작 위치를 정확히 찾음", () => {
    // Speech.speak가 실제로 읽는, 공백이 정규화된 문자열을 가정
    const text = "안녕하세요. 오늘은 날씨가 좋습니다. 산책하기 딱 좋은 날이에요.";
    const segments = splitIntoSentenceSegments(text);

    expect(segments.map((s) => s.text)).toEqual([
      "안녕하세요",
      "오늘은 날씨가 좋습니다",
      "산책하기 딱 좋은 날이에요",
    ]);
  });
});

describe("findSegmentForCharIndex (onBoundary charIndex → 문장 매칭)", () => {
  const text = "안녕하세요. 오늘은 날씨가 좋습니다. 산책하기 딱 좋은 날이에요.";
  const segments = splitIntoSentenceSegments(text);

  it("각 세그먼트 시작 위치의 charIndex는 해당 세그먼트를 반환", () => {
    segments.forEach((seg) => {
      const found = findSegmentForCharIndex(segments, seg.startChar);
      expect(found?.text).toBe(seg.text);
    });
  });

  it("문장 중간 charIndex도 해당 세그먼트를 반환", () => {
    const secondSegment = segments[1];
    const midpoint = secondSegment.startChar + 2;
    const found = findSegmentForCharIndex(segments, midpoint);
    expect(found?.text).toBe(secondSegment.text);
  });

  it("구두점/공백 위의 charIndex는 직전 세그먼트를 반환 (자막이 끊기지 않음)", () => {
    const firstEnd = segments[0].endChar; // "." 바로 위 위치
    const found = findSegmentForCharIndex(segments, firstEnd);
    expect(found?.text).toBe(segments[0].text);
  });

  it("charIndex가 텍스트 시작보다 앞이면 첫 세그먼트를 반환", () => {
    const found = findSegmentForCharIndex(segments, -1);
    expect(found?.text).toBe(segments[0].text);
  });
});

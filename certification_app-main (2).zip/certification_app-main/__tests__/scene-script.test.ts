import { beforeEach, describe, expect, it, vi } from "vitest";

// 실제 AI와 DB 캐시를 부르지 않는다.
const generateText = vi.fn();
vi.mock("../server/lib/ai", () => ({
  generateText: (...args: unknown[]) => generateText(...args),
}));
const loadCachedScenes = vi.fn();
const saveCachedScenes = vi.fn();
vi.mock("../server/lib/ai-cache-store", () => ({
  loadCachedScenes: (...args: unknown[]) => loadCachedScenes(...args),
  saveCachedScenes: (...args: unknown[]) => saveCachedScenes(...args),
}));

const { sanitizeScenes, getExplanationScenes, SCENE_SCRIPT_VERSION } = await import("../server/lib/scene-script");
const { allQuestions } = await import("../data/questions");

const q = allQuestions[0];
const wrongOption = (q.answer + 1) % q.options.length;

const keyword = { narration: "핵심 용어를 보자.", visual: { type: "keyword", term: "메타데이터", definition: "데이터를 설명하는 데이터" } };
const steps = (highlight?: number) => ({
  narration: "순서대로 볼게요.",
  visual: { type: "steps", steps: ["정의", "수집", "분석"], ...(highlight === undefined ? {} : { highlight }) },
});

describe("sanitizeScenes", () => {
  it("options 장면은 AI가 쓴 내용 대신 문제은행의 보기·고른 답·정답으로 채운다", () => {
    const scenes = sanitizeScenes(
      { scenes: [{ narration: "보기를 보자.", visual: { type: "options", options: ["가짜1", "가짜2"], selectedOption: 9, correctOption: 9 } }, keyword] },
      q,
      wrongOption
    );
    expect(scenes?.[0].visual).toEqual({ type: "options", options: q.options, selectedOption: wrongOption, correctOption: q.answer });
  });

  it("틀에 안 맞는 장면은 버리고, 남은 장면이 2개 미만이면 null", () => {
    const broken = { narration: "잘못된 장면", visual: { type: "video" } };
    const noNarration = { visual: keyword.visual };
    expect(sanitizeScenes({ scenes: [keyword, broken, noNarration] }, q, q.answer)).toBeNull();
    expect(sanitizeScenes({ scenes: [keyword, broken, steps()] }, q, q.answer)).toHaveLength(2);
  });

  it("범위를 벗어난 강조 번호는 지우고, 맞는 번호는 둔다", () => {
    const scenes = sanitizeScenes({ scenes: [steps(7), steps(1)] }, q, q.answer)!;
    expect(scenes[0].visual).not.toHaveProperty("highlight");
    expect(scenes[1].visual).toMatchObject({ highlight: 1 });
  });

  it("장면은 최대 6개까지만 쓴다", () => {
    expect(sanitizeScenes({ scenes: Array.from({ length: 9 }, () => keyword) }, q, q.answer)).toHaveLength(6);
  });

  it("scenes 배열이 없으면 null", () => {
    expect(sanitizeScenes(null, q, q.answer)).toBeNull();
    expect(sanitizeScenes({ scenes: "x" }, q, q.answer)).toBeNull();
  });
});

describe("getExplanationScenes", () => {
  beforeEach(() => {
    generateText.mockReset();
    loadCachedScenes.mockReset().mockResolvedValue(null);
    saveCachedScenes.mockReset().mockResolvedValue(undefined);
    vi.spyOn(console, "error").mockImplementation(() => {});
  });

  it("캐시에 쓸 수 있는 대본이 있으면 AI를 부르지 않는다", async () => {
    loadCachedScenes.mockResolvedValue(JSON.stringify({ version: SCENE_SCRIPT_VERSION, scenes: [keyword, steps()] }));
    await expect(getExplanationScenes(q, q.answer)).resolves.toHaveLength(2);
    expect(generateText).not.toHaveBeenCalled();
  });

  it("대본 규칙이 바뀌기 전에 저장된 대본은 새로 만들어 덮어쓴다", async () => {
    loadCachedScenes.mockResolvedValue(JSON.stringify({ scenes: [keyword, steps()] }));
    generateText.mockResolvedValueOnce({ text: JSON.stringify({ scenes: [keyword, steps(), keyword] }), complete: true });
    await expect(getExplanationScenes(q, wrongOption)).resolves.toHaveLength(3);
    expect(JSON.parse(saveCachedScenes.mock.calls[0][2])).toMatchObject({ version: SCENE_SCRIPT_VERSION });
  });

  it("보기 번호는 숫자로, 학생에게 직접 말하도록 요청한다", async () => {
    generateText.mockResolvedValueOnce({ text: JSON.stringify({ scenes: [keyword, steps()] }), complete: true });
    await getExplanationScenes(q, wrongOption);
    const { instructions, prompt } = generateText.mock.calls[0][0];
    expect(instructions).toContain('"3번"처럼 아라비아 숫자');
    expect(prompt).not.toContain("학생은");
    expect(prompt).toContain(`${wrongOption + 1}번(오답)을 골랐고`);
  });

  it("```json 펜스로 감싼 응답도 읽고, 끝까지 만들어진 대본만 캐시에 저장한다", async () => {
    const text = "```json\n" + JSON.stringify({ scenes: [keyword, steps()] }) + "\n```";
    generateText.mockResolvedValueOnce({ text, complete: true });
    await expect(getExplanationScenes(q, wrongOption)).resolves.toHaveLength(2);
    expect(saveCachedScenes).toHaveBeenCalledWith(q.id, wrongOption, expect.any(String));

    generateText.mockResolvedValueOnce({ text, complete: false });
    await getExplanationScenes(q, wrongOption);
    expect(saveCachedScenes).toHaveBeenCalledTimes(1);
  });

  it("형식이 깨진 옛 캐시는 무시하고 새로 만든다", async () => {
    loadCachedScenes.mockResolvedValue("{not json");
    generateText.mockResolvedValueOnce({ text: JSON.stringify({ scenes: [keyword, steps()] }), complete: true });
    await expect(getExplanationScenes(q, q.answer)).resolves.toHaveLength(2);
  });

  it("쓸 수 없는 대본이면 에러를 던져 앱이 자막 해설로 대체하게 한다", async () => {
    generateText.mockResolvedValueOnce({ text: JSON.stringify({ scenes: [keyword] }), complete: true });
    await expect(getExplanationScenes(q, q.answer)).rejects.toThrow("Unusable scene script");
    generateText.mockResolvedValueOnce({ text: "죄송해요, 만들 수 없어요", complete: true });
    await expect(getExplanationScenes(q, q.answer)).rejects.toThrow();
    expect(saveCachedScenes).not.toHaveBeenCalled();
  });
});

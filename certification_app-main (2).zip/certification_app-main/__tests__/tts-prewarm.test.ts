import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TRPCError } from "@trpc/server";

// 실제 음성 생성/DB 대신 가짜: 저장된 해시 목록과 "만들기" 호출만 기록한다.
const stored = new Set<string>();
const prepareSpeech = vi.fn(async (text: string) => {
  stored.add(`hash:${text}`);
  return { id: "x", durationSec: 1 };
});
let userGenerating = false;
vi.mock("../server/lib/tts", () => ({
  prepareSpeech,
  speechHash: (text: string) => `hash:${text}`,
  storedSpeechHashes: async () => new Set(stored),
  isGeneratingForUser: () => userGenerating,
}));

const { _prewarmTickForTest, prewarmEnabled, speechPrewarmStatus } = await import("../server/lib/tts-prewarm");

describe("동그래 기본 해설 음성 미리 만들기", () => {
  beforeEach(() => {
    stored.clear();
    prepareSpeech.mockClear();
    userGenerating = false;
  });
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("실서버(production + 원격 DB)에서 TTS_PREWARM=1일 때만 켜진다 — 음성 생성은 요금이 나간다", () => {
    vi.stubEnv("TTS_PREWARM", "1");
    vi.stubEnv("NODE_ENV", "development");
    vi.stubEnv("DATABASE_URL", "");
    expect(prewarmEnabled()).toBe(false);
    vi.stubEnv("NODE_ENV", "production");
    expect(prewarmEnabled()).toBe(false);
    vi.stubEnv("DATABASE_URL", "libsql://example.turso.io");
    expect(prewarmEnabled()).toBe(true);
    vi.stubEnv("TTS_PREWARM", "");
    expect(prewarmEnabled()).toBe(false);
    vi.stubEnv("TTS_PREWARM", "0");
    expect(prewarmEnabled()).toBe(false);
  });

  it("아직 음성이 없는 해설을 하나 만들고 2분 뒤로 다음 차례를 잡는다", async () => {
    const next = await _prewarmTickForTest();
    expect(prepareSpeech).toHaveBeenCalledTimes(1);
    expect(next).toBe(2 * 60 * 1000);
  });

  it("이미 만든 해설은 건너뛴다", async () => {
    await _prewarmTickForTest();
    await _prewarmTickForTest();
    const [first] = prepareSpeech.mock.calls[0];
    const [second] = prepareSpeech.mock.calls[1];
    expect(second).not.toBe(first);
  });

  it("사용자가 목소리를 만드는 중이면 양보한다", async () => {
    userGenerating = true;
    const next = await _prewarmTickForTest();
    expect(prepareSpeech).not.toHaveBeenCalled();
    expect(next).toBe(2 * 60 * 1000);
  });

  it("할당량 초과(429)면 1시간 쉰다", async () => {
    prepareSpeech.mockRejectedValueOnce(new TRPCError({ code: "TOO_MANY_REQUESTS", message: "quota" }));
    const next = await _prewarmTickForTest();
    expect(next).toBe(60 * 60 * 1000);
    expect((await speechPrewarmStatus()).lastError).toBe("quota");
  });

  it("진행 상황: 준비된 개수 / 전체", async () => {
    await _prewarmTickForTest();
    const status = await speechPrewarmStatus();
    expect(status.ready).toBe(1);
    expect(status.total).toBeGreaterThan(900); // 일반 600 + 기출 331 (같은 해설은 하나로)
  });
});

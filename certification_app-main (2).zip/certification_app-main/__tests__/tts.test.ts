import { beforeEach, describe, expect, it, vi } from "vitest";

// 실제 OpenAI TTS를 부르지 않는다: 1초짜리 무음 PCM(24kHz, 16bit mono)을 돌려주는 가짜.
const synthesizeSpeech = vi.fn();
vi.mock("../server/lib/ai", () => ({ synthesizeSpeech, TTS_PCM_SAMPLE_RATE: 24000, TTS_VOICE: "cedar" }));
// DB 캐시도 가짜로: 메모리 Map에 저장한다.
const speechDb = new Map<string, { wav: Buffer; durationSec: number }>();
const saveCachedSpeech = vi.fn(async (hash: string, wav: Buffer, durationSec: number) => {
  speechDb.set(hash, { wav, durationSec });
});
vi.mock("../server/lib/ai-cache-store", () => ({
  loadCachedSpeech: async (hash: string) => speechDb.get(hash) ?? null,
  saveCachedSpeech,
}));

const { prepareSpeech, serveSpeech, toWav, wavDurationSec, _resetTtsCacheForTest } = await import(
  "../server/lib/tts"
);

const ONE_SECOND_PCM = Buffer.alloc(24000 * 2);
function fakeRes() {
  const res: any = { statusCode: 200, headers: {} as Record<string, unknown>, body: undefined as Buffer | undefined };
  res.status = (code: number) => ((res.statusCode = code), res);
  res.setHeader = (k: string, v: unknown) => ((res.headers[k] = v), res);
  res.end = (body?: Buffer) => ((res.body = body), res);
  return res;
}

describe("WAV 변환", () => {
  it("헤더 없는 PCM에 WAV 헤더를 붙이고 길이를 계산한다", () => {
    const wav = toWav(ONE_SECOND_PCM, "audio/L16;rate=24000");
    expect(wav.subarray(0, 4).toString()).toBe("RIFF");
    expect(wav.length).toBe(44 + ONE_SECOND_PCM.length);
    expect(wavDurationSec(wav)).toBeCloseTo(1);
  });

  it("이미 WAV면 그대로 둔다", () => {
    const wav = toWav(ONE_SECOND_PCM, "audio/L16;rate=24000");
    expect(toWav(wav, "audio/wav")).toBe(wav);
  });
});

describe("prepareSpeech", () => {
  beforeEach(() => {
    _resetTtsCacheForTest();
    speechDb.clear();
    saveCachedSpeech.mockClear();
    synthesizeSpeech.mockReset();
    synthesizeSpeech.mockResolvedValue(ONE_SECOND_PCM);
  });

  it("정상으로 만든 음성은 DB에 저장하고, 서버 재시작(메모리 비움) 후에는 DB에서 꺼내 AI를 다시 부르지 않는다", async () => {
    await prepareSpeech("저장될 해설");
    expect(saveCachedSpeech).toHaveBeenCalledTimes(1);

    _resetTtsCacheForTest(); // Render가 잠들었다 깨어난 상황
    const { durationSec } = await prepareSpeech("저장될 해설");
    expect(durationSec).toBeCloseTo(1);
    expect(synthesizeSpeech).toHaveBeenCalledTimes(1);
  });

  it("해설 텍스트를 그대로 음성으로 만들고 PCM에 WAV 헤더를 붙여 재생 길이를 돌려준다", async () => {
    const { durationSec } = await prepareSpeech("차분 프라이버시는 노이즈를 추가하는 기법입니다.");
    expect(durationSec).toBeCloseTo(1);
    expect(synthesizeSpeech).toHaveBeenCalledWith("차분 프라이버시는 노이즈를 추가하는 기법입니다.");
  });

  it("같은 해설은 저장해 둔 음성을 다시 쓴다 (비용 절약)", async () => {
    const a = await prepareSpeech("같은 해설");
    const b = await prepareSpeech("같은 해설");
    expect(b.id).toBe(a.id);
    expect(synthesizeSpeech).toHaveBeenCalledTimes(1);
  });

  it("동시에 같은 해설을 요청해도 한 번만 만든다", async () => {
    const [a, b] = await Promise.all([prepareSpeech("동시 요청"), prepareSpeech("동시 요청")]);
    expect(a.id).toBe(b.id);
    expect(synthesizeSpeech).toHaveBeenCalledTimes(1);
  });

  it("실패하면 에러를 그대로 던지고(앱이 폰 목소리로 대체), 다음 요청은 다시 시도한다", async () => {
    synthesizeSpeech.mockRejectedValueOnce(new Error("quota"));
    await expect(prepareSpeech("실패 후 재시도")).rejects.toThrow("quota");
    await expect(prepareSpeech("실패 후 재시도")).resolves.toHaveProperty("id");
    expect(synthesizeSpeech).toHaveBeenCalledTimes(2);
  });
});

describe("serveSpeech", () => {
  beforeEach(() => {
    _resetTtsCacheForTest();
    speechDb.clear();
    synthesizeSpeech.mockResolvedValue(ONE_SECOND_PCM);
  });

  it("전체 파일과 Range 요청(206)을 처리하고, 없는 id는 404", async () => {
    const { id } = await prepareSpeech("파일 제공");
    const total = 44 + ONE_SECOND_PCM.length;

    const full = fakeRes();
    serveSpeech({ params: { id }, headers: {} } as any, full);
    expect(full.statusCode).toBe(200);
    expect(full.headers["Content-Type"]).toBe("audio/wav");
    expect(full.body.length).toBe(total);

    const partial = fakeRes();
    serveSpeech({ params: { id }, headers: { range: "bytes=0-1" } } as any, partial);
    expect(partial.statusCode).toBe(206);
    expect(partial.headers["Content-Range"]).toBe(`bytes 0-1/${total}`);
    expect(partial.body.toString()).toBe("RI");

    const missing = fakeRes();
    serveSpeech({ params: { id: "nope" }, headers: {} } as any, missing);
    expect(missing.statusCode).toBe(404);
  });
});

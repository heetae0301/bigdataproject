import { describe, expect, it, vi } from "vitest";
import { clampDailyGoal, stepDailyGoal } from "@/lib/app-settings";

// vi.mock은 import보다 먼저 실행되도록 끌어올려진다
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: { getItem: vi.fn(), setItem: vi.fn() },
}));

describe("clampDailyGoal", () => {
  it("1~200 사이 정수로 맞춘다", () => {
    expect(clampDailyGoal(0)).toBe(1);
    expect(clampDailyGoal(-5)).toBe(1);
    expect(clampDailyGoal(999)).toBe(200);
    expect(clampDailyGoal(12.6)).toBe(13);
    expect(clampDailyGoal(35)).toBe(35);
  });

  it("숫자가 아니면 기본값(20)", () => {
    expect(clampDailyGoal(NaN)).toBe(20);
    expect(clampDailyGoal(Number("abc"))).toBe(20);
  });
});

describe("stepDailyGoal", () => {
  it("5 단위로 맞춰서 움직인다", () => {
    expect(stepDailyGoal(20, 1)).toBe(25);
    expect(stepDailyGoal(20, -1)).toBe(15);
    expect(stepDailyGoal(23, 1)).toBe(25);
    expect(stepDailyGoal(23, -1)).toBe(20);
  });

  it("5 이하에서는 1씩, 범위 밖으로는 안 나간다", () => {
    expect(stepDailyGoal(5, -1)).toBe(4);
    expect(stepDailyGoal(1, -1)).toBe(1);
    expect(stepDailyGoal(3, 1)).toBe(4);
    expect(stepDailyGoal(4, 1)).toBe(5);
    expect(stepDailyGoal(200, 1)).toBe(200);
    expect(stepDailyGoal(198, 1)).toBe(200);
  });
});

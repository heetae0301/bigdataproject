import { describe, it, expect, beforeAll, beforeEach } from "vitest";

/**
 * lib/storage.ts는 이제 tRPC를 통해 서버 DB(server/db/schema.ts)에서
 * 오답노트/학습통계를 읽고 쓴다 (로그인 붙이면서 AsyncStorage에서 이전했다).
 * 그래서 여기서는 클라이언트 래퍼 대신, 실제 로직이 있는 서버 라우터
 * (server/routers.ts의 progress 라우터)를 인메모리 SQLite로 직접 테스트한다.
 */
process.env.DATABASE_URL = ":memory:";

let appRouter: (typeof import("../server/routers"))["appRouter"];

function createCaller(userId: string | null) {
  return appRouter.createCaller({ req: {} as never, res: {} as never, userId });
}

async function createTestUser(email: string) {
  const caller = createCaller(null);
  const { user } = await caller.auth.signup({ email, nickname: "테스트유저", password: "password123" });
  return user.id;
}

beforeAll(async () => {
  const { initDb } = await import("../server/db/init");
  await initDb();
  ({ appRouter } = await import("../server/routers"));
});

describe("Auth", () => {
  it("signs up a new user", async () => {
    const caller = createCaller(null);
    const { user, token } = await caller.auth.signup({
      email: "signup-test@example.com",
      nickname: "가입테스트",
      password: "password123",
    });
    expect(user.email).toBe("signup-test@example.com");
    expect(token).toBeTruthy();
  });

  it("rejects duplicate signup", async () => {
    const caller = createCaller(null);
    await caller.auth.signup({ email: "dup@example.com", nickname: "중복테스트", password: "password123" });
    await expect(
      caller.auth.signup({ email: "dup@example.com", nickname: "중복테스트2", password: "password123" })
    ).rejects.toThrow();
  });

  it("logs in with correct credentials", async () => {
    const caller = createCaller(null);
    await caller.auth.signup({ email: "login-test@example.com", nickname: "로그인테스트", password: "password123" });
    const { user } = await caller.auth.login({
      email: "login-test@example.com",
      password: "password123",
    });
    expect(user.email).toBe("login-test@example.com");
  });

  it("rejects login with wrong password", async () => {
    const caller = createCaller(null);
    await caller.auth.signup({ email: "wrongpw@example.com", nickname: "비번테스트", password: "password123" });
    await expect(
      caller.auth.login({ email: "wrongpw@example.com", password: "nope" })
    ).rejects.toThrow();
  });
});

describe("WrongAnswers", () => {
  let userId: string;

  beforeEach(async () => {
    userId = await createTestUser(`wrong-${Date.now()}-${Math.random()}@example.com`);
  });

  it("returns empty array initially", async () => {
    const caller = createCaller(userId);
    const result = await caller.progress.getWrongAnswers();
    expect(result).toEqual([]);
  });

  it("adds and retrieves a wrong answer", async () => {
    const caller = createCaller(userId);
    await caller.progress.addWrongAnswer({
      questionId: "di-001",
      subject: "1과목(데이터 이해)",
      selectedOption: 2,
      correctOption: 3,
      timestamp: Date.now(),
    });
    const result = await caller.progress.getWrongAnswers();
    expect(result).toHaveLength(1);
    expect(result[0].questionId).toBe("di-001");
  });

  it("removes a wrong answer", async () => {
    const caller = createCaller(userId);
    await caller.progress.addWrongAnswer({
      questionId: "di-001",
      subject: "1과목(데이터 이해)",
      selectedOption: 2,
      correctOption: 3,
      timestamp: Date.now(),
    });
    await caller.progress.removeWrongAnswer({ questionId: "di-001" });
    const result = await caller.progress.getWrongAnswers();
    expect(result).toHaveLength(0);
  });

  it("clears all wrong answers", async () => {
    const caller = createCaller(userId);
    await caller.progress.addWrongAnswer({
      questionId: "di-001",
      subject: "1과목(데이터 이해)",
      selectedOption: 2,
      correctOption: 3,
      timestamp: Date.now(),
    });
    await caller.progress.addWrongAnswer({
      questionId: "da-001",
      subject: "2과목(데이터 분석 기획)",
      selectedOption: 0,
      correctOption: 2,
      timestamp: Date.now(),
    });
    await caller.progress.clearWrongAnswers();
    const result = await caller.progress.getWrongAnswers();
    expect(result).toHaveLength(0);
  });

  it("deduplicates wrong answers by questionId", async () => {
    const caller = createCaller(userId);
    const wa = {
      questionId: "di-001",
      subject: "1과목(데이터 이해)" as const,
      selectedOption: 0,
      correctOption: 3,
      timestamp: Date.now(),
    };
    await caller.progress.addWrongAnswer(wa);
    await caller.progress.addWrongAnswer({ ...wa, selectedOption: 1 });
    const result = await caller.progress.getWrongAnswers();
    expect(result).toHaveLength(1);
    expect(result[0].selectedOption).toBe(1);
  });

  it("isolates wrong answers between users", async () => {
    const otherUserId = await createTestUser(`other-${Date.now()}-${Math.random()}@example.com`);
    const caller = createCaller(userId);
    const otherCaller = createCaller(otherUserId);

    await caller.progress.addWrongAnswer({
      questionId: "di-001",
      subject: "1과목(데이터 이해)",
      selectedOption: 2,
      correctOption: 3,
      timestamp: Date.now(),
    });

    expect(await caller.progress.getWrongAnswers()).toHaveLength(1);
    expect(await otherCaller.progress.getWrongAnswers()).toHaveLength(0);
  });
});

describe("StudyStats", () => {
  let userId: string;

  beforeEach(async () => {
    userId = await createTestUser(`stats-${Date.now()}-${Math.random()}@example.com`);
  });

  it("returns default stats initially", async () => {
    const caller = createCaller(userId);
    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(0);
    expect(stats.totalCorrect).toBe(0);
    expect(stats.streakDays).toBe(0);
  });

  it("records a correct answer", async () => {
    const caller = createCaller(userId);
    await caller.progress.recordAnswer({ subject: "1과목(데이터 이해)", isCorrect: true });
    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(1);
    expect(stats.totalCorrect).toBe(1);
    expect(stats.bySubject["1과목(데이터 이해)"].total).toBe(1);
    expect(stats.bySubject["1과목(데이터 이해)"].correct).toBe(1);
  });

  it("records an incorrect answer", async () => {
    const caller = createCaller(userId);
    await caller.progress.recordAnswer({ subject: "2과목(데이터 분석 기획)", isCorrect: false });
    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(1);
    expect(stats.totalCorrect).toBe(0);
    expect(stats.bySubject["2과목(데이터 분석 기획)"].total).toBe(1);
    expect(stats.bySubject["2과목(데이터 분석 기획)"].correct).toBe(0);
  });

  it("accumulates multiple answers", async () => {
    const caller = createCaller(userId);
    await caller.progress.recordAnswer({ subject: "1과목(데이터 이해)", isCorrect: true });
    await caller.progress.recordAnswer({ subject: "1과목(데이터 이해)", isCorrect: false });
    await caller.progress.recordAnswer({ subject: "2과목(데이터 분석 기획)", isCorrect: true });
    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(3);
    expect(stats.totalCorrect).toBe(2);
  });

  it("resets stats", async () => {
    const caller = createCaller(userId);
    await caller.progress.recordAnswer({ subject: "1과목(데이터 이해)", isCorrect: true });
    await caller.progress.resetStudyStats();
    const stats = await caller.progress.getStudyStats();
    expect(stats.totalAnswered).toBe(0);
  });

  it("rejects calls without a logged-in user", async () => {
    const caller = createCaller(null);
    await expect(caller.progress.getStudyStats()).rejects.toThrow();
  });
});

describe("Questions data", () => {
  it("has 600 questions total", async () => {
    const { questions } = await import("../data/questions");
    expect(questions).toHaveLength(600);
  });

  it("has 200 questions per subject", async () => {
    const { questions, SUBJECTS } = await import("../data/questions");
    for (const subject of SUBJECTS) {
      const count = questions.filter((q) => q.subject === subject).length;
      expect(count).toBe(200);
    }
  });

  it("has no duplicate question ids", async () => {
    const { questions } = await import("../data/questions");
    const ids = questions.map((q) => q.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it("all questions have valid answer index", async () => {
    const { questions } = await import("../data/questions");
    for (const q of questions) {
      expect(q.answer).toBeGreaterThanOrEqual(0);
      expect(q.answer).toBeLessThan(q.options.length);
    }
  });

  it("getRandomQuestions returns correct count", async () => {
    const { getRandomQuestions } = await import("../data/questions");
    const result = getRandomQuestions("전체", 5);
    expect(result).toHaveLength(5);
  });
});

import { describe, it, expect } from "vitest";
import { generateText, synthesizeSpeech } from "../server/lib/ai";

/**
 * OpenAI API 키 연결 테스트 (실제 호출).
 * 호출할 때마다 비용이 드니 평소 테스트에서는 건너뛰고, 키를 바꿨을 때만 `RUN_AI_LIVE=1 pnpm test`로 돌린다.
 */
const runLive = process.env.RUN_AI_LIVE === "1";

describe.skipIf(!runLive)("OpenAI API Connection", () => {
  it("OPENAI_API_KEY가 설정돼 있다", () => {
    expect(process.env.OPENAI_API_KEY).toBeTruthy();
  });

  it("글 생성 모델이 답한다", async () => {
    const { text } = await generateText({ prompt: "OK라고만 답해 주세요.", maxOutputTokens: 256 });
    expect(text.length).toBeGreaterThan(0);
  }, 60_000);

  it("음성 합성 모델이 오디오를 돌려준다", async () => {
    const audio = await synthesizeSpeech("안녕하세요, 동그래예요.");
    expect(audio.length).toBeGreaterThan(1000);
  }, 60_000);
});
